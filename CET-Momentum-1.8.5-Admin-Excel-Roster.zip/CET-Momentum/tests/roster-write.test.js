import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createCore,hash} from '../server/core.js';
import {newRoster,mergeWorkbook,readRoster} from '../server/roster-workbook.js';

const make=(username,name,status='Enabled')=>({username,name,status,email:username.split('\\').at(-1)+'@example.test',company:'CET'});
async function bytes(rows){const book=newRoster();mergeWorkbook(book,rows);return Buffer.from(await book.workbook.xlsx.writeBuffer());}

test('admin add writes Excel and SQLite, preserves access flags, and stays synced',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-write-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice')]));await core.sync();
  core.db.prepare('UPDATE users SET admin=1,special=1 WHERE username=?').run('dib\\alice');
  const result=await core.addUser(make('DIB\\BOB','Bob'),'dib\\alice');
  assert.equal(result.created,1);assert.equal(result.count,2);
  assert.equal(core.db.prepare('SELECT name FROM users WHERE username=?').get('dib\\bob').name,'Bob');
  const book=await readRoster(fs.readFileSync(filename));assert.deepEqual(book.rows.map(u=>u.username),['dib\\alice','dib\\bob']);
  assert.equal(core.db.prepare('SELECT special FROM users WHERE username=?').get('dib\\alice').special,1);
  assert.equal((await core.sync()).error,null);
  assert.equal((await core.sync()).hash,hash(fs.readFileSync(filename)));
  await assert.rejects(core.addUser(make('dib\\bob','Another Bob'),'dib\\alice'),/already exists/);
  assert.equal((await readRoster(fs.readFileSync(filename))).rows.length,2);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('Excel upload merges by username, leaves other users and history intact, rejects self lockout and bad files',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-upload-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice'),make('dib\\charlie','Charlie')]));await core.sync();
  core.db.prepare('UPDATE users SET admin=1 WHERE username=?').run('dib\\alice');
  const charlie=core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\charlie');
  core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(charlie.id,'2026-10-01','2026-10-01T10:00:00Z');
  const upload=await bytes([make('DIB\\CHARLIE','Charles','Disabled'),make('DIB\\DAVID','David')]);
  const result=await core.uploadRoster(upload,'dib\\alice');assert.deepEqual([result.created,result.updated,result.count],[1,1,3]);
  assert.equal(core.db.prepare('SELECT name FROM users WHERE id=?').get(charlie.id).name,'Charles');
  assert.equal(core.db.prepare('SELECT excel_enabled FROM users WHERE id=?').get(charlie.id).excel_enabled,0);
  assert.equal(core.db.prepare('SELECT count(*) n FROM attendance WHERE user_id=?').get(charlie.id).n,1);
  assert.equal(core.db.prepare('SELECT admin FROM users WHERE username=?').get('dib\\alice').admin,1);
  const saved=fs.readFileSync(filename),digest=hash(saved);
  await assert.rejects(core.uploadRoster(await bytes([make('dib\\alice','Alice','Disabled')]),'dib\\alice'),/own portal access/);
  await assert.rejects(core.uploadRoster(Buffer.from('not a workbook'),'dib\\alice'));
  const duplicate=newRoster();duplicate.sheet.addRow(['','David','dib\\david','','','','','Enabled']);duplicate.sheet.addRow(['','David 2','DIB\\DAVID','','','','','Enabled']);
  await assert.rejects(core.uploadRoster(Buffer.from(await duplicate.workbook.xlsx.writeBuffer()),'dib\\alice'),/Duplicate/);
  assert.equal(hash(fs.readFileSync(filename)),digest);
  assert.equal(core.syncState().hash,digest);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});
