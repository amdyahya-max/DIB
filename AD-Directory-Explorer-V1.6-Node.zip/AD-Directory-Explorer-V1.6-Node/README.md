# AD Directory Explorer V1.6 — Node

## Fix in V1.6

V1.5 introduced a PowerShell parser error in the Employee ID fallback logic. The fallback was written as an inline `if/elseif` expression inside the `PSCustomObject`, which Windows PowerShell 5.1 does not parse in that form.

V1.6 resolves Employee ID into normal variables **before** building the result object.

Employee ID priority remains:

```text
1. employeeID
2. comment
3. employeeNumber
```

All V1.5 UI features remain:
- Company column
- Default 8 columns
- Multi-select Columns menu
- Searchable department typing field
- Dynamic CSV/Excel export based on visible columns

Run:

```text
node server.js
```

Open:

```text
http://localhost:8085
```
## Enhancements in V1.5

1. **Company** is now included in the default user list.
2. Added a **Columns** multi-select. Exactly eight business columns are shown by default:
   - Employee ID
   - Name
   - Username
   - Email
   - Department
   - Company
   - Title
   - Manager

   Additional fields can be enabled or removed at any time. The user's selection is retained in the browser.
3. **Department** is now a searchable typing field backed by the AD department list. Start typing and select the matching department instead of scrolling through a long dropdown.
4. CSV and Excel export now follow the currently selected visible columns.

Start:

```text
node server.js
```

Open:

```text
http://localhost:8085
```

## Employee ID fallback improvement

The application now resolves Employee ID in this order:

```text
1. employeeID
2. comment
3. employeeNumber
```

This covers users where the corporate employee ID is stored in the AD `comment` field (for example values such as `CT2178`) instead of `employeeID`.

The detail panel also shows which AD attribute supplied the displayed Employee ID.

Start as before:

```text
node server.js
```

Then open:

```text
http://localhost:8085
```

## Fix in V1.3

V1.2 used a PowerShell helper function named `FT`. On Windows PowerShell, `ft` is a built-in alias for `Format-Table`. Because aliases take precedence over functions, account-expiry values were accidentally being sent to `Format-Table`, producing an error similar to:

```text
FT : Cannot convert System.Int64...
FullyQualifiedErrorId : DictionaryKeyUnknownType,Microsoft.PowerShell.Commands.FormatTableCommand
```

V1.3 renames the helper to `Convert-FileTimeIso` and also makes manager lookup more defensive.

Start as before:

```text
node server.js
```

Then browse to:

```text
http://localhost:8085
```

This version is designed for corporate Windows environments where:

- `.ps1` execution is blocked
- `.cmd` files are blocked
- Node.js itself is permitted
- NPM installation is restricted

The application runs with:

```text
node server.js
```

No NPM packages are required.

## Start

1. Extract the ZIP.
2. Open PowerShell or Command Prompt in the extracted folder.
3. Run:

```text
node server.js
```

4. Open:

```text
http://localhost:8085
```

5. Stop with `Ctrl+C`.

## How it works

Node hosts the local web application. For each read-only AD request, Node calls:

```text
powershell.exe -NoProfile -NonInteractive -Command <inline command>
```

The PowerShell commands use `System.DirectoryServices`, the same technique already proven to work on your PC.

No `.ps1` script is executed.

## Security

- Binds only to `127.0.0.1`
- Read-only directory searches
- Uses your current Windows identity
- No stored AD password
- No database
- No arbitrary LDAP endpoint exposed