let environment = 'PWCORE';
let selectedScenario = null;
let selectedScenarioMeta = null;
let lastResult = null;
let filteredMatchedRows = [];

const $ = id => document.getElementById(id);

async function json(url, options={}) {
  const r = await fetch(url, options);
  const data = await r.json();
  if (!r.ok) throw new Error(data.detail || 'Request failed');
  return data;
}

async function init() {
  try {
    const h = await json('/api/v1/health');
    $('health').textContent = `API ${h.status} • v${h.version}`;
    const s = await json('/api/v1/scenarios');
    renderQuestions(s.scenarios);
  } catch(e) { $('health').textContent = 'API unavailable'; }
  $('exportExcelBtn').disabled = true;
}

function renderQuestions(items) {
  const host = $('questionTiles'); host.innerHTML='';
  items.forEach((q, i) => {
    const b=document.createElement('button');
    b.className='question-tile'; b.dataset.id=q.id;
    const status = q.mode === 'guidance' ? 'Guidance' : 'Query + Compare';
    b.innerHTML=`<span class="qno">${i+1}</span><strong>${q.label}</strong><small>${status}</small>`;
    b.onclick=()=>selectQuestion(q, b); host.appendChild(b);
  });
  if(items.length) host.querySelector(`[data-id="${items[0].id}"]`).click();
}

function selectQuestion(q, button) {
  document.querySelectorAll('.question-tile').forEach(x=>x.classList.remove('active'));
  button.classList.add('active'); selectedScenario=q.id; selectedScenarioMeta=q;
  $('questionHelp').textContent=q.description;
  $('searchBtn').textContent = q.mode === 'guidance' ? 'Show Guidance' : 'Search, Fetch & Compare';
  $('guidancePanel').classList.add('hidden');
  if (q.mode !== 'guidance') $('comparisonArea').classList.remove('hidden');
}

document.querySelectorAll('.env-btn').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('.env-btn').forEach(x=>x.classList.remove('active'));
  b.classList.add('active'); environment=b.dataset.env;
});

$('searchBtn').onclick=run;
async function run() {
  if(!selectedScenario) return;
  const guidanceMode = selectedScenarioMeta && selectedScenarioMeta.mode === 'guidance';
  $('searchBtn').disabled=true; $('exportExcelBtn').disabled=true;
  $('searchBtn').textContent=guidanceMode ? 'Loading guidance…' : 'Fetching & comparing…';
  try {
    const data=await json('/api/v1/reconcile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({environment,scenario:selectedScenario})});
    lastResult=data; renderResult(data);
  } catch(e) { $('resultMessage').textContent=e.message; }
  finally {
    $('searchBtn').disabled=false;
    $('searchBtn').textContent=guidanceMode ? 'Show Guidance' : 'Search, Fetch & Compare';
    $('exportExcelBtn').disabled=!lastResult || lastResult.mode === 'guidance';
  }
}

function renderResult(d) {
  if (d.mode === 'guidance') {
    $('comparisonArea').classList.add('hidden'); $('guidancePanel').classList.remove('hidden');
    $('guidanceTitle').textContent=d.guidance.title;
    $('creditGuidance').innerHTML=d.guidance.credit.map(x=>`<li>${x}</li>`).join('');
    $('debitGuidance').innerHTML=d.guidance.debit.map(x=>`<li>${x}</li>`).join('');
    $('guidanceNote').textContent=d.guidance.note; return;
  }
  $('guidancePanel').classList.add('hidden'); $('comparisonArea').classList.remove('hidden');
  const s=d.summary; ['v2Count','v3Count','matchedCount','v2OnlyCount','v3OnlyCount'].forEach(k=>$(k).textContent=s[k]);
  $('v2OnlyLabel').textContent=s.v2OnlyCount; $('v3OnlyLabel').textContent=s.v3OnlyCount;
  $('resultTitle').textContent=`${d.scenario.label} — ${d.environment}`;
  $('resultMessage').textContent='V2 population fetched, V3 lookup completed, and card numbers reconciled.';
  fillMatched(d.matched); fillSingle('v2OnlyBody',d.v2Only); fillSingle('v3OnlyBody',d.v3Only);
  filteredMatchedRows = [...d.matched];
  $('searchBox').value='';
  $('exportExcelBtn').disabled=filteredMatchedRows.length===0;
  $('copyCardsBtn').disabled=filteredMatchedRows.length===0;
}

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fillMatched(rows) {$('matchedBody').innerHTML=rows.map(r=>`<tr><td>${esc(r.cardNumber)}</td><td>${esc(r.clientCode)}</td><td>${esc(r.v2Status)}</td><td>${esc(r.v3Status)}</td><td>${esc(r.productType)}</td><td>${esc(r.primaryCard)}</td></tr>`).join('') || '<tr><td colspan="6">No matched records</td></tr>';}
function fillSingle(id,rows) {$(id).innerHTML=rows.map(r=>`<tr><td>${esc(r.cardNumber)}</td><td>${esc(r.clientCode)}</td><td>${esc(r.status)}</td><td>${esc(r.productType)}</td><td>${esc(r.primaryCard)}</td></tr>`).join('') || '<tr><td colspan="5">No records</td></tr>';}

function applyMatchedFilter() {
  if(!lastResult || lastResult.mode === 'guidance') { filteredMatchedRows=[]; return; }
  const q=$('searchBox').value.trim().toLowerCase();
  filteredMatchedRows = lastResult.matched.filter(r => {
    const hay=[r.cardNumber,r.clientCode,r.v2Status,r.v3Status,r.productType,r.primaryCard]
      .map(v=>String(v??'').toLowerCase()).join(' ');
    return !q || hay.includes(q);
  });
  fillMatched(filteredMatchedRows);
  $('copyCardsBtn').disabled=filteredMatchedRows.length===0;
  $('exportExcelBtn').disabled=filteredMatchedRows.length===0;
  $('resultMessage').textContent = q
    ? `${filteredMatchedRows.length} of ${lastResult.matched.length} matched records shown after filter.`
    : 'V2 population fetched, V3 lookup completed, and card numbers reconciled.';
}

$('copyCardsBtn').onclick=async()=>{
  if(!lastResult || lastResult.mode === 'guidance' || !filteredMatchedRows.length) return;
  const cards=filteredMatchedRows.map(x=>x.cardNumber).filter(Boolean);
  await navigator.clipboard.writeText([...new Set(cards)].join('\n'));
  $('copyCardsBtn').textContent=`Copied ${cards.length}`; setTimeout(()=>$('copyCardsBtn').textContent='Copy Cards',1200);
};

$('exportExcelBtn').onclick=async()=>{
  if(!lastResult || lastResult.mode==='guidance' || !filteredMatchedRows.length) return;
  const btn=$('exportExcelBtn'); const old=btn.textContent; btn.disabled=true; btn.textContent='Preparing…';
  try{
    const r=await fetch('/api/v1/export-excel',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        environment:lastResult.environment,
        scenario:lastResult.scenario.id,
        records:filteredMatchedRows,
        filterText:$('searchBox').value.trim()
      })
    });
    if(!r.ok){let d={};try{d=await r.json()}catch{};throw new Error(d.detail||'Excel export failed');}
    const blob=await r.blob(); const cd=r.headers.get('content-disposition')||''; const m=cd.match(/filename="?([^";]+)"?/i);
    const filename=m?m[1]:`PowerCard_${lastResult.environment}_${lastResult.scenario.id}_matched.xlsx`;
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }catch(e){alert(e.message);}finally{btn.disabled=filteredMatchedRows.length===0;btn.textContent=old;}
};

$('searchBox').oninput=applyMatchedFilter;
init();
