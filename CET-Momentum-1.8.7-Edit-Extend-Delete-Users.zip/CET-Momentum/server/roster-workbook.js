import ExcelJS from 'exceljs';
const normalize=value=>String(value||'').trim().toLowerCase();
const validDate=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&!isNaN(Date.parse(value))&&new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value;

export const headers=['Employee ID','Name','Username','Email','Company','Title','Manager','Status','Account Expiry','Password Expiry','Telephone','Mobile'];
export const keys=['employee_id','name','username','email','company','title','manager','status','account_expiry','password_expiry','telephone','mobile'];
export const hasNoExpiry=value=>!String(value||'').trim()||String(value).trim().toLowerCase()==='never';
export const expiryAllowsAccess=(value,today)=>hasNoExpiry(value)||String(value)>=today;

export function validateRoster(rows){
 if(!Array.isArray(rows)||!rows.length)throw Error('Empty roster rejected. Last valid roster remains active.');
 if(rows.length>10000)throw Error('Roster is limited to 10,000 users.');
 const seen=new Set();
 for(const r of rows){
  r.username=normalize(r.username);r.name=String(r.name||'').trim();
  if(!r.username||!r.name)throw Error('Every populated row needs Username and Name.');
  if(r.username.length>160)throw Error('Windows Username is too long: '+r.username);
  if(r.name.length>200)throw Error('Name is too long: '+r.username);
  if(seen.has(r.username))throw Error('Duplicate Username: '+r.username);seen.add(r.username);
  if(!['Enabled','Disabled','Expired'].includes(r.status))throw Error('Status must be Enabled, Disabled or Expired: '+r.username);
  r.account_expiry=hasNoExpiry(r.account_expiry)?(String(r.account_expiry||'').trim()?'Never':''):String(r.account_expiry).trim();
  if(r.account_expiry&&!hasNoExpiry(r.account_expiry)&&!validDate(r.account_expiry))throw Error('Invalid Account Expiry: '+r.username+'. Use a date, Never, or blank.');
  for(const key of keys)if(String(r[key]||'').length>500||/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(String(r[key]||'')))throw Error('Invalid '+key.replaceAll('_',' ')+' for '+r.username);
 }
 return rows;
}

export async function readRoster(bytes){
 const workbook=new ExcelJS.Workbook();await workbook.xlsx.load(bytes);
 const sheet=workbook.getWorksheet('Users')||workbook.worksheets[0];
 if(!sheet)throw Error('Workbook has no worksheet.');
 const map={};sheet.getRow(1).eachCell((cell,i)=>map[String(cell.text).trim().toLowerCase()]=i);
 for(const heading of headers)if(!map[heading.toLowerCase()])throw Error('Missing header: '+heading);
 if(sheet.rowCount>10002)throw Error('Roster is limited to 10,000 users.');
 const rows=[];
 sheet.eachRow((row,i)=>{
  if(i===1)return;
  const record={};
  for(let j=0;j<headers.length;j++){
   const cell=row.getCell(map[headers[j].toLowerCase()]);
   if(cell.value?.formula)throw Error('Formula cells are not supported in the roster.');
   let value=cell.value instanceof Date?cell.value.toISOString().slice(0,10):String(cell.text||'').trim();
   if(keys[j]==='status')value=value?value[0].toUpperCase()+value.slice(1).toLowerCase():'';
   record[keys[j]]=value;
  }
  if(Object.values(record).some(Boolean))rows.push(record);
 });
 validateRoster(rows);
 return {workbook,sheet,map,rows};
}

export function newRoster(){
 const workbook=new ExcelJS.Workbook(),sheet=workbook.addWorksheet('Users');
 sheet.addRow(headers);sheet.getRow(1).font={bold:true};sheet.views=[{state:'frozen',ySplit:1}];
 headers.forEach((heading,i)=>sheet.getColumn(i+1).width=Math.max(16,heading.length+5));
 const map=Object.fromEntries(headers.map((heading,i)=>[heading.toLowerCase(),i+1]));
 return {workbook,sheet,map,rows:[]};
}

export function mergeWorkbook(current,incoming){
 validateRoster(incoming);
 const byUsername=new Map();
 current.sheet.eachRow((row,i)=>{if(i>1){const username=normalize(row.getCell(current.map.username).text);if(username)byUsername.set(username,i);}});
 let created=0,updated=0;
 for(const record of incoming){
  const rowNumber=byUsername.get(record.username);
  const row=rowNumber?current.sheet.getRow(rowNumber):current.sheet.addRow([]);
  if(rowNumber)updated++;else {created++;byUsername.set(record.username,row.number);}
  for(let i=0;i<headers.length;i++)row.getCell(current.map[headers[i].toLowerCase()]).value=String(record[keys[i]]||'');
  row.commit();
 }
 return {created,updated};
}
