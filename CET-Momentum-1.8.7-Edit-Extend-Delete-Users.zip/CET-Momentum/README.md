# CET Momentum 1.8.7 portal update

This ZIP adds Edit, Extend, and Delete actions to Administration → Users. Status shows effective access (Active, Expired, Disabled, Blocked or Removed). Extend uses a calendar to update Excel and SQLite. Delete removes a user from the Excel roster, revokes their helper devices and sessions, and keeps attendance/audit history in SQLite. Column filtering, Never/blank account expiry, add/upload, automatic race animation, and IIS subpath support remain. Follow [deployment/UPDATE-1.8.7.md](deployment/UPDATE-1.8.7.md) to deploy it.

The CET Helper remains at 1.2.9. Keep the existing production `.env`, `data`, `storage`, `downloads`, `helper`, `Node`, and `node_modules` folders. Attendance and enrollment data are not included in this ZIP.

The animation runs in the browser. On the Windows Server session, the captured diagnostic reported `reducedMotion: true`, `animation: "none"`, and confirmed that the CSS keyframes were present. CET Race now shows **Animate cars** when the browser asks for reduced motion. Clicking it enables race-car motion for this portal in that browser; **Reduce motion** restores the system preference. Replay restarts the animation.

The portal logs one diagnostic per race view or replay in `STORAGE_DIR/logs/portal.log`, under the `race.diagnostics` event. It reports the browser motion preference, car animation style, keyframe availability, browser visibility, and observed animation activity. Open CET Race with its tab visible and leave it open for about five seconds before checking the log.
