Regression checks use temporary directories only. Tests are intended for developer verification with Node 24. No production credentials or data are included.
