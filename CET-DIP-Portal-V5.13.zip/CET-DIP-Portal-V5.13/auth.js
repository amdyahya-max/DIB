const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{promisify}=require('node:util');
const {DatabaseSync}=require('node:sqlite');
const dir=path.join(__dirname,'data');fs.mkdirSync(dir,{recursive:true});
const db=new DatabaseSync(path.join(dir,'intake.sqlite'));db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS portal_users(username TEXT PRIMARY KEY,salt TEXT NOT NULL,password_hash TEXT NOT NULL,enabled INTEGER NOT NULL,role TEXT NOT NULL,version INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS auth_metadata(name TEXT PRIMARY KEY,value TEXT NOT NULL);`);
const roles=['Administrator','Assessor','Requester','Viewer'],derive=promisify(crypto.scrypt),opts={N:32768,r:8,p:1,maxmem:64*1024*1024};
if(!db.prepare('PRAGMA table_info(portal_users)').all().some(c=>c.name==='must_change_password'))db.exec('ALTER TABLE portal_users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0');
for(const col of ['display_name','email','department','job_title','phone'])if(!db.prepare('PRAGMA table_info(portal_users)').all().some(c=>c.name===col))db.exec("ALTER TABLE portal_users ADD COLUMN "+col+" TEXT NOT NULL DEFAULT ''");
db.exec("CREATE UNIQUE INDEX IF NOT EXISTS portal_email_unique ON portal_users(lower(email)) WHERE email<>''");
function profile(b,required){const v={};for(let k of ['displayName','email','department','jobTitle','phone']){if(b[k]!==undefined&&typeof b[k]!=='string')throw Error('Invalid user profile.');v[k]=String(b[k]||'').trim();if(v[k].length>(k==='phone'?50:200))throw Error('Profile field is too long.');}v.email=v.email.toLowerCase();if(required&&(!v.displayName||!v.email))throw Error('Name and email are required.');if(v.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email))throw Error('Enter a valid email address.');return v;}
function normalize(n){return String(n||'').trim().toLowerCase();}
function valid(n,u){return n===normalize(n) && n.length>0 && n.length<=150 && u && /^[a-f0-9]{32}$/.test(u.salt) && /^[a-f0-9]{128}$/.test(u.hash) && typeof u.enabled==='boolean' && roles.includes(u.role) && Number.isInteger(u.version) && u.version>=1;}
const insert=db.prepare('INSERT INTO portal_users(username,salt,password_hash,enabled,role,version) VALUES(?,?,?,?,?,?)');
// One-time migration. Existing database accounts are never overwritten.
db.exec('BEGIN IMMEDIATE');try{
if(!db.prepare("SELECT value FROM auth_metadata WHERE name='json_migrated'").get()){
 const legacy=path.join(dir,'users.json');let count=0;
 if(fs.existsSync(legacy)){let old=JSON.parse(fs.readFileSync(legacy,'utf8'));if(!old || Array.isArray(old) || typeof old!=='object')throw Error('Invalid legacy users.json');for(const [n,u]of Object.entries(old)){if(!valid(n,u))throw Error('Invalid legacy account record; migration cancelled.');if(!db.prepare('SELECT username FROM portal_users WHERE username=?').get(n)){insert.run(n,u.salt,u.hash,u.enabled?1:0,u.role,u.version);count++;}}}
 db.prepare('INSERT INTO auth_metadata(name,value) VALUES(?,?)').run('json_migrated',new Date().toISOString());
 if(count)console.log('Migrated '+count+' portal accounts into SQLite. Legacy file retained for backup only.');
}db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
const versions=new WeakMap();
function users(){const result=Object.fromEntries(db.prepare('SELECT * FROM portal_users').all().map(r=>[r.username,{salt:r.salt,hash:r.password_hash,enabled:!!r.enabled,role:r.role,version:r.version,mustChangePassword:!!r.must_change_password,displayName:r.display_name,email:r.email,department:r.department,jobTitle:r.job_title,phone:r.phone}]));versions.set(result,JSON.stringify(result));return result;}
function save(v){const expected=versions.get(v);if(expected===undefined)throw Error('Read accounts before saving.');db.exec('BEGIN IMMEDIATE');try{
const current=users();if(JSON.stringify(current)!==expected)throw Error('Accounts changed concurrently. Retry the command.');
for(const [n,u]of Object.entries(v))if(!valid(n,u))throw Error('Invalid account data.');
if(Object.values(current).some(u=>u.enabled && u.role==='Administrator') && !Object.values(v).some(u=>u.enabled && u.role==='Administrator'))throw Error('Cannot remove last active administrator.');
const put=db.prepare('INSERT INTO portal_users(username,salt,password_hash,enabled,role,version) VALUES(?,?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET salt=excluded.salt,password_hash=excluded.password_hash,enabled=excluded.enabled,role=excluded.role,version=excluded.version');
for(const [n,u]of Object.entries(v))put.run(n,u.salt,u.hash,u.enabled?1:0,u.role,u.version);
db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
async function hash(password){let salt=crypto.randomBytes(16).toString('hex');return {salt,hash:(await derive(password,salt,64,opts)).toString('hex')};}
async function verify(password,u){const out=await derive(password,u?u.salt:'dummy-not-a-real-user',64,opts);const expected=Buffer.from(u?u.hash:'00'.repeat(64),'hex');return expected.length===out.length && crypto.timingSafeEqual(out,expected) && !!u;}
function userList(){return Object.entries(users()).map(([username,u])=>({username,enabled:u.enabled,role:u.role,version:u.version,mustChangePassword:u.mustChangePassword,displayName:u.displayName,email:u.email,department:u.department,jobTitle:u.jobTitle,phone:u.phone}));}
function log(actor,action,details){db.prepare('INSERT INTO audit(issue_id,at,actor,action,details) VALUES(?,?,?,?,?)').run('0',new Date().toISOString(),actor,action,JSON.stringify(details));}
function passwordRule(password){if(typeof password!=='string'||password.length<12||password.length>256)throw Error('Use a password of 12–256 characters.');}
async function manage(b,actor){
 if(typeof b.username!=='string')throw Error('Username is required.');const key=normalize(b.username);if(['__proto__','constructor','prototype'].includes(key))throw Error('Choose a different username.');if(!key||key.length>150||!/^[a-z0-9._@\\-]+$/.test(key))throw Error('Enter a valid username.');
 if(!['create','edit','delete','reset'].includes(b.action))throw Error('Invalid user action.');
 let fields;if(['create','edit'].includes(b.action))fields=profile(b,true);let hashed;if(['create','reset'].includes(b.action)){passwordRule(b.password);hashed=await hash(b.password);}
 db.exec('BEGIN IMMEDIATE');try{let old=users()[key];
 if(b.action==='create'){if(old)throw Error('Username already exists.');if(!roles.includes(b.role)||typeof b.enabled!=='boolean')throw Error('Invalid role/status.');db.prepare('INSERT INTO portal_users(username,salt,password_hash,enabled,role,version,must_change_password) VALUES(?,?,?,?,?,1,?)').run(key,hashed.salt,hashed.hash,b.enabled?1:0,b.role,b.mustChangePassword===false?0:1);}
 else{if(!old)throw Error('User not found.');if(b.version!==old.version)throw Error('CONFLICT');if(key===actor&&(b.action==='delete'||(b.action==='edit'&&(!b.enabled||b.role!=='Administrator'))))throw Error('You cannot delete, disable or remove your own administrator access.');
 if(b.action==='delete'){db.prepare('DELETE FROM ro_members WHERE username=?').run(key);db.prepare('DELETE FROM portal_users WHERE username=?').run(key);}
 if(b.action==='edit'){if(!roles.includes(b.role)||typeof b.enabled!=='boolean')throw Error('Invalid role/status.');db.prepare('UPDATE portal_users SET role=?,enabled=?,version=version+1 WHERE username=?').run(b.role,b.enabled?1:0,key);}
 if(b.action==='reset')db.prepare('UPDATE portal_users SET salt=?,password_hash=?,must_change_password=?,version=version+1 WHERE username=?').run(hashed.salt,hashed.hash,b.mustChangePassword===false?0:1,key);
 }
 if(fields){if(db.prepare("SELECT username FROM portal_users WHERE lower(email)=? AND username<>?").get(fields.email,key))throw Error('Email already belongs to another portal user.');db.prepare('UPDATE portal_users SET display_name=?,email=?,department=?,job_title=?,phone=? WHERE username=?').run(fields.displayName,fields.email,fields.department,fields.jobTitle,fields.phone,key);}
 if(!db.prepare("SELECT username FROM portal_users WHERE enabled=1 AND role='Administrator' LIMIT 1").get())throw Error('Cannot remove the last active administrator.');
 log(actor,'USER_'+b.action.toUpperCase(),{username:key,previous:old?{role:old.role,enabled:old.enabled}:null,role:b.role,enabled:b.enabled,profile:fields,previousProfile:old?{displayName:old.displayName,email:old.email,department:old.department,jobTitle:old.jobTitle,phone:old.phone}:null,mustChangePassword:['create','reset'].includes(b.action)?b.mustChangePassword!==false:undefined});db.exec('COMMIT');return userList();
 }catch(e){db.exec('ROLLBACK');throw e;}
}
async function changePassword(username,currentPassword,newPassword,version){passwordRule(newPassword);if(typeof currentPassword!=='string'||currentPassword.length>256)throw Error('Current password is required.');let u=users()[username];if(!u||!u.enabled||u.version!==version)throw Error('CONFLICT');if(!await verify(currentPassword,u))throw Error('Current password is incorrect.');if(await verify(newPassword,u))throw Error('Choose a different password.');let h=await hash(newPassword);db.exec('BEGIN IMMEDIATE');try{let r=db.prepare('UPDATE portal_users SET salt=?,password_hash=?,must_change_password=0,version=version+1 WHERE username=? AND version=? AND enabled=1').run(h.salt,h.hash,username,version);if(!r.changes)throw Error('CONFLICT');log(username,'PASSWORD_CHANGED',{username});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
module.exports={users,save,normalize,hash,verify,userList,manage,changePassword};
