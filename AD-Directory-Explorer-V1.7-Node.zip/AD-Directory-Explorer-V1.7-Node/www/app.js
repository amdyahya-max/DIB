
const state = {
  mode: "department",
  users: [],
  filtered: [],
  sortKey: "name",
  sortDir: 1,
  departments: []
};

const $ = id => document.getElementById(id);

const COLUMN_DEFS = [
  { key:"employeeId",      label:"Employee ID",      default:true,  render:u => textCell(u.employeeId) },
  { key:"name",            label:"Name",             default:true,  render:u => `<span class="linkish" data-user="${escapeHtml(u.username)}">${escapeHtml(u.name || "—")}</span>`, wrap:true },
  { key:"username",        label:"Username",         default:true,  render:u => textCell(u.username) },
  { key:"email",           label:"Email",            default:true,  render:u => textCell(u.email) },
  { key:"department",      label:"Department",       default:true,  render:u => textCell(u.department), wrap:true },
  { key:"company",         label:"Company",          default:true,  render:u => textCell(u.company), wrap:true },
  { key:"title",           label:"Title",            default:true,  render:u => textCell(u.title), wrap:true },
  { key:"manager",         label:"Manager",          default:true,  render:u => textCell(u.manager), wrap:true },

  { key:"status",          label:"Status",            default:false, render:u => `<span class="badge ${escapeHtml(u.status)}">${escapeHtml(u.status || "—")}</span>` },
  { key:"accountExpiry",   label:"Account Expiry",    default:false, render:u => expiryDisplay(u.accountExpiry) },
  { key:"passwordExpiry",  label:"Password Expiry",   default:false, render:u => formatDate(u.passwordExpiry) },
  { key:"lastLogon",       label:"Last Logon",        default:false, render:u => formatDate(u.lastLogon, true) },
  { key:"office",          label:"Office",            default:false, render:u => textCell(u.office) },
  { key:"telephone",       label:"Telephone",         default:false, render:u => textCell(u.telephone) },
  { key:"mobile",          label:"Mobile",            default:false, render:u => textCell(u.mobile) },
  { key:"managerEmail",    label:"Manager Email",     default:false, render:u => textCell(u.managerEmail) },
  { key:"upn",             label:"UPN",               default:false, render:u => textCell(u.upn) },
  { key:"employeeNumber",  label:"Employee Number",   default:false, render:u => textCell(u.employeeNumber) },
  { key:"whenCreated",     label:"Created",           default:false, render:u => formatDate(u.whenCreated, true) },
  { key:"whenChanged",     label:"Last AD Change",    default:false, render:u => formatDate(u.whenChanged, true) },
  { key:"homeDirectory",   label:"Home Directory",    default:false, render:u => textCell(u.homeDirectory), wrap:true }
];

const DETAILS_COLUMN = { key:"__details", label:"Details" };

let visibleColumns = new Set(
  JSON.parse(localStorage.getItem("adExplorerColumns") || "null") ||
  COLUMN_DEFS.filter(c => c.default).map(c => c.key)
);

function escapeHtml(v) {
  return String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function textCell(v) {
  return escapeHtml(v || "—");
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2500);
}

async function api(path) {
  const res = await fetch(path, { cache: "no-store" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function setMode(mode) {
  state.mode = mode;
  document.querySelectorAll(".mode-tab").forEach(b =>
    b.classList.toggle("active", b.dataset.mode === mode)
  );

  $("departmentField").classList.toggle("hidden", mode !== "department");
  $("groupField").classList.toggle("hidden", mode !== "group");
  $("userField").classList.toggle("hidden", mode !== "user");
  $("recursiveField").style.display = mode === "group" ? "block" : "none";
}

async function checkHealth() {
  try {
    const h = await api("/api/health");
    const pill = $("healthPill");
    pill.className = "pill good";
    pill.textContent = `Connected • ${h.user}`;
    pill.title = `Base DN: ${h.baseDN}`;
  } catch (e) {
    const pill = $("healthPill");
    pill.className = "pill bad";
    pill.textContent = "AD connection failed";
    pill.title = e.message;
  }
}

async function loadDepartments(force = false) {
  const input = $("departmentInput");
  const list = $("departmentOptions");
  if (force) input.placeholder = "Refreshing departments…";

  try {
    const data = await api("/api/departments");
    state.departments = data.items || [];
    list.innerHTML = state.departments
      .map(d => `<option value="${escapeHtml(d)}"></option>`)
      .join("");
    input.placeholder = "Start typing a department…";
  } catch (e) {
    input.placeholder = "Unable to load departments";
    toast(e.message);
  }
}

function resolveDepartmentInput(raw) {
  const v = raw.trim();
  if (!v) return "";
  const exact = state.departments.find(d => d.toLowerCase() === v.toLowerCase());
  if (exact) return exact;

  const matches = state.departments.filter(d => d.toLowerCase().includes(v.toLowerCase()));
  if (matches.length === 1) return matches[0];
  return v;
}

async function searchDirectory() {
  let value = "";

  if (state.mode === "department") value = resolveDepartmentInput($("departmentInput").value);
  if (state.mode === "group") value = $("groupInput").value.trim();
  if (state.mode === "user") value = $("userInput").value.trim();

  if (!value) {
    toast("Enter or select a search value.");
    return;
  }

  // If department typed value isn't exact and multiple options match, guide user.
  if (state.mode === "department") {
    const exact = state.departments.some(d => d.toLowerCase() === value.toLowerCase());
    if (!exact) {
      const matches = state.departments.filter(d => d.toLowerCase().includes(value.toLowerCase()));
      if (matches.length > 1) {
        toast(`Multiple departments match "${value}". Please select one from the suggestions.`);
        return;
      }
    }
  }

  const btn = $("searchBtn");
  btn.disabled = true;
  btn.textContent = "Searching…";

  try {
    const recursive = $("recursiveCheckbox").checked;
    const qs = new URLSearchParams({
      mode: state.mode,
      value,
      recursive: String(recursive)
    });

    const data = await api(`/api/users?${qs}`);
    state.users = data.items || [];
    applyFilters();
    toast(`${data.count} user${data.count === 1 ? "" : "s"} found`);
  } catch (e) {
    state.users = [];
    applyFilters();
    toast(e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Search directory";
  }
}

function daysUntil(dateString) {
  if (!dateString) return null;
  const d = new Date(dateString);
  if (Number.isNaN(d.getTime())) return null;
  return Math.ceil((d.getTime() - Date.now()) / 86400000);
}

function applyFilters() {
  const text = $("filterInput").value.trim().toLowerCase();
  const status = $("statusFilter").value;
  const expiry = $("expiryFilter").value;

  state.filtered = state.users.filter(u => {
    if (text) {
      const hay = [
        u.employeeId,u.name,u.username,u.email,u.department,u.company,u.title,u.manager,
        u.managerEmail,u.office,u.mobile,u.telephone,u.upn
      ].join(" ").toLowerCase();
      if (!hay.includes(text)) return false;
    }

    if (status && u.status !== status) return false;

    const days = daysUntil(u.accountExpiry);
    if (expiry === "expired" && !(days !== null && days < 0)) return false;
    if (expiry === "30" && !(days !== null && days >= 0 && days <= 30)) return false;
    if (expiry === "60" && !(days !== null && days >= 0 && days <= 60)) return false;
    if (expiry === "never" && u.accountExpiry) return false;

    return true;
  });

  renderUsers();
  updateStats();
}

function formatDate(v, includeTime = false) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return escapeHtml(v);
  const opts = includeTime
    ? { year:"numeric", month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit" }
    : { year:"numeric", month:"short", day:"2-digit" };
  return d.toLocaleString(undefined, opts);
}

function expiryDisplay(v) {
  if (!v) return `<span class="badge">Never</span>`;
  const days = daysUntil(v);
  if (days !== null && days < 0) return `<span class="badge Expired">${formatDate(v)}</span>`;
  if (days !== null && days <= 30) return `<span class="badge warning">${formatDate(v)}</span>`;
  return formatDate(v);
}

function getVisibleColumnDefs() {
  return COLUMN_DEFS.filter(c => visibleColumns.has(c.key));
}

function renderTableHead() {
  const cols = getVisibleColumnDefs();
  $("usersThead").innerHTML = `
    <tr>
      ${cols.map(c => `<th data-key="${escapeHtml(c.key)}">${escapeHtml(c.label)} <span>↕</span></th>`).join("")}
      <th>${DETAILS_COLUMN.label}</th>
    </tr>`;
}

function renderUsers() {
  renderTableHead();

  const tbody = $("usersTbody");
  const cols = getVisibleColumnDefs();

  const rows = [...state.filtered].sort((a,b) => {
    const av = (a[state.sortKey] ?? "").toString().toLowerCase();
    const bv = (b[state.sortKey] ?? "").toString().toLowerCase();
    return av.localeCompare(bv, undefined, { numeric:true }) * state.sortDir;
  });

  if (!rows.length) {
    tbody.innerHTML = `
      <tr class="empty-row"><td colspan="${cols.length + 1}">
        <div class="empty-state">
          <strong>No users to display</strong>
          <span>Adjust the search or filters.</span>
        </div>
      </td></tr>`;
  } else {
    tbody.innerHTML = rows.map(u => `
      <tr>
        ${cols.map(c => `<td class="${c.wrap ? "wrap" : ""}">${c.render(u)}</td>`).join("")}
        <td><button class="detail-btn" data-user="${escapeHtml(u.username)}">Open</button></td>
      </tr>
    `).join("");
  }

  const enabled = state.filtered.length > 0;
  $("csvBtn").disabled = !enabled;
  $("excelBtn").disabled = !enabled;
  updateColumnBadge();
}

function updateStats() {
  $("userCount").textContent = state.filtered.length;
  $("enabledCount").textContent = state.filtered.filter(x => x.enabled).length;
  $("expiringCount").textContent = state.filtered.filter(x => {
    const d = daysUntil(x.accountExpiry);
    return d !== null && d >= 0 && d <= 30;
  }).length;
}

function buildColumnPicker() {
  const menu = $("columnPickerMenu");
  menu.innerHTML = `
    <div class="column-picker-title">
      <strong>Columns shown</strong>
      <button id="resetColumnsBtn" type="button">Reset</button>
    </div>
    <div class="column-picker-list">
      ${COLUMN_DEFS.map(c => `
        <label class="column-option">
          <input type="checkbox" data-col="${escapeHtml(c.key)}" ${visibleColumns.has(c.key) ? "checked" : ""}>
          <span>${escapeHtml(c.label)}</span>
        </label>
      `).join("")}
    </div>`;

  menu.querySelectorAll("input[data-col]").forEach(cb => {
    cb.addEventListener("change", () => {
      const key = cb.dataset.col;
      if (cb.checked) visibleColumns.add(key);
      else visibleColumns.delete(key);

      // Keep at least one data column.
      if (visibleColumns.size === 0) {
        visibleColumns.add("name");
        const nameBox = menu.querySelector('input[data-col="name"]');
        if (nameBox) nameBox.checked = true;
        toast("At least one column must remain visible.");
      }

      localStorage.setItem("adExplorerColumns", JSON.stringify([...visibleColumns]));
      renderUsers();
    });
  });

  const reset = $("resetColumnsBtn");
  if (reset) {
    reset.addEventListener("click", () => {
      visibleColumns = new Set(COLUMN_DEFS.filter(c => c.default).map(c => c.key));
      localStorage.setItem("adExplorerColumns", JSON.stringify([...visibleColumns]));
      buildColumnPicker();
      renderUsers();
      toast("Default 8 columns restored");
    });
  }
}

function updateColumnBadge() {
  $("columnCountBadge").textContent = `(${visibleColumns.size})`;
}

async function openUser(username) {
  if (!username) return;

  $("drawerBackdrop").classList.remove("hidden");
  $("detailDrawer").classList.remove("hidden");
  $("detailDrawer").setAttribute("aria-hidden", "false");
  $("drawerTitle").textContent = "Loading…";
  $("drawerSub").textContent = username;
  $("drawerBody").innerHTML = `<div class="empty-state">Retrieving user profile from AD…</div>`;

  try {
    const u = await api(`/api/user?username=${encodeURIComponent(username)}`);
    $("drawerTitle").textContent = u.name || u.username;
    $("drawerSub").textContent = `${u.username || ""}${u.email ? " • " + u.email : ""}`;

    const item = (label, value) => `
      <div class="detail-item">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(value || "—")}</strong>
      </div>`;

    $("drawerBody").innerHTML = `
      <div class="detail-section">
        <h4>Identity</h4>
        <div class="detail-grid">
          ${item("Employee ID", u.employeeId)}
          ${item("Employee ID source", u.employeeIdSource)}
          ${item("Username", u.username)}
          ${item("Full name", u.name)}
          ${item("Email", u.email)}
          ${item("UPN", u.upn)}
          ${item("Company", u.company)}
          ${item("Department", u.department)}
          ${item("Title", u.title)}
        </div>
      </div>

      <div class="detail-section">
        <h4>Manager & Contact</h4>
        <div class="detail-grid">
          ${item("Manager", u.manager)}
          ${item("Manager email", u.managerEmail)}
          ${item("Office", u.office)}
          ${item("Telephone", u.telephone)}
          ${item("Mobile", u.mobile)}
          ${item("Home directory", u.homeDirectory)}
        </div>
      </div>

      <div class="detail-section">
        <h4>Account</h4>
        <div class="detail-grid">
          ${item("Status", u.status)}
          ${item("Account expiry", u.accountExpiry ? formatDate(u.accountExpiry) : "Never")}
          ${item("Created", formatDate(u.whenCreated, true))}
          ${item("Last AD change", formatDate(u.whenChanged, true))}
          ${item("Last logon", formatDate(u.lastLogon, true))}
          ${item("Password last set", formatDate(u.passwordLastSet, true))}
          ${item("Password expiry", u.passwordExpiry ? formatDate(u.passwordExpiry, true) : (u.passwordNeverExpires ? "Never" : "Not available"))}
          ${item("Password required", u.passwordRequired ? "Yes" : "No")}
          ${item("Password never expires", u.passwordNeverExpires ? "Yes" : "No")}
        </div>
      </div>

      <div class="detail-section">
        <h4>Directory</h4>
        <div class="detail-grid">
          ${item("Description", u.description)}
          ${item("Comment", u.comment)}
          ${item("Distinguished name", u.distinguishedName)}
        </div>
      </div>

      <div class="detail-section">
        <h4>Direct group memberships (${(u.groups || []).length})</h4>
        <div class="group-chips">
          ${(u.groups || []).length
            ? u.groups.map(g => `<span class="group-chip">${escapeHtml(g)}</span>`).join("")
            : `<span class="muted">No direct groups returned.</span>`}
        </div>
      </div>
    `;
  } catch (e) {
    $("drawerTitle").textContent = "Unable to load user";
    $("drawerBody").innerHTML = `<div class="empty-state">${escapeHtml(e.message)}</div>`;
  }
}

function closeDrawer() {
  $("drawerBackdrop").classList.add("hidden");
  $("detailDrawer").classList.add("hidden");
  $("detailDrawer").setAttribute("aria-hidden", "true");
}

async function findGroups() {
  const q = $("groupLookupInput").value.trim();
  const box = $("groupLookupResults");
  box.innerHTML = `<div class="muted">Searching…</div>`;

  try {
    const data = await api(`/api/groups?query=${encodeURIComponent(q)}`);
    if (!data.items.length) {
      box.innerHTML = `<div class="muted">No groups found.</div>`;
      return;
    }

    box.innerHTML = data.items.slice(0,100).map(g => `
      <div class="group-result">
        <div>
          <strong>${escapeHtml(g.name || g.samAccountName)}</strong>
          <small>${escapeHtml(g.description || g.samAccountName || "")}</small>
        </div>
        <button class="button secondary use-group" data-group="${escapeHtml(g.name || g.samAccountName)}">Use</button>
      </div>
    `).join("");
  } catch (e) {
    box.innerHTML = `<div class="muted">${escapeHtml(e.message)}</div>`;
  }
}

function csvCell(v) {
  const s = String(v ?? "");
  return `"${s.replaceAll('"','""')}"`;
}

function exportCsv() {
  const cols = getVisibleColumnDefs().map(c => [c.label, c.key]);
  const rows = [
    cols.map(c => csvCell(c[0])).join(","),
    ...state.filtered.map(u => cols.map(c => csvCell(u[c[1]])).join(","))
  ];
  downloadBlob(new Blob(["\uFEFF" + rows.join("\r\n")], {type:"text/csv;charset=utf-8"}), "AD-Users.csv");
}

function exportExcel() {
  const cols = getVisibleColumnDefs().map(c => [c.label, c.key]);
  const header = cols.map(c => `<th>${escapeHtml(c[0])}</th>`).join("");
  const rows = state.filtered.map(u =>
    `<tr>${cols.map(c => `<td>${escapeHtml(u[c[1]] ?? "")}</td>`).join("")}</tr>`
  ).join("");

  const html = `
    <html><head><meta charset="utf-8"></head><body>
      <table border="1"><thead><tr>${header}</tr></thead><tbody>${rows}</tbody></table>
    </body></html>`;

  downloadBlob(new Blob([html], {type:"application/vnd.ms-excel;charset=utf-8"}), "AD-Users.xls");
}

function downloadBlob(blob, filename) {
  const a = document.createElement("a");
  const url = URL.createObjectURL(blob);
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

document.querySelectorAll(".mode-tab").forEach(btn =>
  btn.addEventListener("click", () => setMode(btn.dataset.mode))
);

$("searchBtn").addEventListener("click", searchDirectory);
$("refreshLookupsBtn").addEventListener("click", async () => {
  await Promise.all([checkHealth(), loadDepartments(true)]);
  toast("Lookups refreshed");
});
$("filterInput").addEventListener("input", applyFilters);
$("statusFilter").addEventListener("change", applyFilters);
$("expiryFilter").addEventListener("change", applyFilters);
$("groupLookupBtn").addEventListener("click", findGroups);
$("csvBtn").addEventListener("click", exportCsv);
$("excelBtn").addEventListener("click", exportExcel);
$("drawerClose").addEventListener("click", closeDrawer);
$("drawerBackdrop").addEventListener("click", closeDrawer);

$("columnPickerBtn").addEventListener("click", e => {
  e.stopPropagation();
  $("columnPickerMenu").classList.toggle("hidden");
});
document.addEventListener("click", e => {
  const picker = document.querySelector(".column-picker");
  if (picker && !picker.contains(e.target)) $("columnPickerMenu").classList.add("hidden");
});

$("groupLookupResults").addEventListener("click", e => {
  const b = e.target.closest(".use-group");
  if (!b) return;
  setMode("group");
  $("groupInput").value = b.dataset.group;
  toast("Group selected");
});

$("usersTbody").addEventListener("click", e => {
  const el = e.target.closest("[data-user]");
  if (el) openUser(el.dataset.user);
});

$("usersThead").addEventListener("click", e => {
  const th = e.target.closest("th[data-key]");
  if (!th) return;
  const key = th.dataset.key;
  if (state.sortKey === key) state.sortDir *= -1;
  else { state.sortKey = key; state.sortDir = 1; }
  renderUsers();
});

["departmentInput","groupInput","userInput","groupLookupInput"].forEach(id => {
  $(id).addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    if (id === "groupLookupInput") findGroups();
    else searchDirectory();
  });
});

(async function init(){
  setMode("department");
  buildColumnPicker();
  renderUsers();
  await Promise.all([checkHealth(), loadDepartments()]);
})();
