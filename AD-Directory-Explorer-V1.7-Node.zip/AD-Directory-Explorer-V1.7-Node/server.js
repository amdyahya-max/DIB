
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8085);
const HOST = '127.0.0.1';
const ROOT = __dirname;
const WWW = path.join(ROOT, 'www');

function psQuote(s) {
  return "'" + String(s ?? '').replace(/'/g, "''") + "'";
}

function runPS(script) {
  return new Promise((resolve, reject) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { windowsHide: true, maxBuffer: 20 * 1024 * 1024, cwd: ROOT },
      (err, stdout, stderr) => {
        if (err) {
          reject(new Error((stderr || err.message || 'PowerShell failed').trim()));
          return;
        }
        resolve(stdout.trim());
      }
    );
  });
}

function sendJson(res, obj, code=200) {
  const body = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function sendText(res, text, code=200, type='text/plain; charset=utf-8') {
  const body = Buffer.from(text);
  res.writeHead(code, {'Content-Type': type, 'Content-Length': body.length});
  res.end(body);
}

function contentType(file) {
  const ext = path.extname(file).toLowerCase();
  return {
    '.html':'text/html; charset=utf-8',
    '.css':'text/css; charset=utf-8',
    '.js':'application/javascript; charset=utf-8',
    '.json':'application/json; charset=utf-8',
    '.svg':'image/svg+xml',
    '.png':'image/png',
    '.ico':'image/x-icon'
  }[ext] || 'application/octet-stream';
}

const commonPs = String.raw`
Add-Type -AssemblyName System.DirectoryServices

function Esc([string]$s) {
  if ($null -eq $s) { return "" }
  $sb = New-Object System.Text.StringBuilder
  foreach($c in $s.ToCharArray()) {
    switch ([int][char]$c) {
      0  { [void]$sb.Append("\00") }
      40 { [void]$sb.Append("\28") }
      41 { [void]$sb.Append("\29") }
      42 { [void]$sb.Append("\2a") }
      92 { [void]$sb.Append("\5c") }
      default { [void]$sb.Append($c) }
    }
  }
  $sb.ToString()
}

function Prop($p,[string]$n) {
  try {
    if ($p.Contains($n) -and $p[$n] -and $p[$n].Count -gt 0) { return $p[$n][0] }
  } catch {}
  return $null
}
function SProp($p,[string]$n) {
  $v=Prop $p $n
  if($null -eq $v){ return "" }
  return [string]$v
}
function Convert-FileTimeIso($v) {
  if($null -eq $v){ return $null }
  try {
    $n=[Int64]$v
    if($n -eq 0 -or $n -eq 9223372036854775807){ return $null }
    return [DateTime]::FromFileTimeUtc($n).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss")
  } catch { return $null }
}
function Convert-DateTimeIso($v) {
  if($null -eq $v){ return $null }
  try { return ([DateTime]$v).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss") } catch { return $null }
}
$base=([ADSI]"LDAP://RootDSE").defaultNamingContext
$root=New-Object System.DirectoryServices.DirectoryEntry("LDAP://$base")

function Searcher([string]$f,[string[]]$props) {
  $s=New-Object System.DirectoryServices.DirectorySearcher($root)
  $s.Filter=$f
  $s.PageSize=1000
  $s.SearchScope=[System.DirectoryServices.SearchScope]::Subtree
  foreach($x in $props){ [void]$s.PropertiesToLoad.Add($x) }
  return $s
}
`;

function userMapperPs() {
  return String.raw`
function UserObj($r,[bool]$detail=$false) {
  $p=$r.Properties
  $uac=0
  $raw=Prop $p "useraccountcontrol"
  if($null -ne $raw){ try{$uac=[int]$raw}catch{} }
  $enabled=(($uac -band 2) -eq 0)
  $passwordRequired=(($uac -band 0x20) -eq 0)
  $passwordNeverExpires=(($uac -band 0x10000) -ne 0)

  $expiry=Convert-FileTimeIso (Prop $p "accountexpires")
  $status=if($enabled){"Enabled"}else{"Disabled"}
  if($enabled -and $expiry){
    try { if([DateTime]$expiry -lt (Get-Date)){ $status="Expired" } } catch {}
  }

  $managerName=""
  $managerEmail=""
  $managerDN=SProp $p "manager"
  if($managerDN){
    $me=$null
    try{
      $me=New-Object System.DirectoryServices.DirectoryEntry("LDAP://$managerDN")
      $managerName=[string]$me.Properties["displayName"].Value
      $managerEmail=[string]$me.Properties["mail"].Value
    }catch{
      $managerName=""
      $managerEmail=""
    }finally{
      if($null -ne $me){ $me.Dispose() }
    }
  }

  $groups=@()
  if($detail -and $p.Contains("memberof")){
    foreach($g in $p["memberof"]){
      $gs=[string]$g
      if($gs -match '^CN=((?:\\.|[^,])+)'){ $groups += ($Matches[1] -replace '\\,',',' -replace '\\\\','\') }
      else { $groups += $gs }
    }
    $groups=@($groups | Sort-Object -Unique)
  }

  # Resolve Employee ID safely before constructing the object.
  # Corporate AD data may store the ID in employeeID, comment, or employeeNumber.
  $resolvedEmployeeId=""
  $resolvedEmployeeIdSource=""

  $candidateEmployeeId=SProp $p "employeeid"
  $candidateDescription=SProp $p "description"
  $candidateComment=SProp $p "comment"
  $candidateEmployeeNumber=SProp $p "employeenumber"

  # `net user <name> /domain` shows a field labelled "Comment".
  # In AD this is commonly backed by the LDAP `description` attribute,
  # not the LDAP `comment` attribute. Prefer employeeID, then description,
  # then comment, then employeeNumber.
  if(-not [string]::IsNullOrWhiteSpace($candidateEmployeeId)){
    $resolvedEmployeeId=$candidateEmployeeId
    $resolvedEmployeeIdSource="employeeID"
  }
  elseif(-not [string]::IsNullOrWhiteSpace($candidateDescription)){
    $resolvedEmployeeId=$candidateDescription
    $resolvedEmployeeIdSource="description (net user Comment)"
  }
  elseif(-not [string]::IsNullOrWhiteSpace($candidateComment)){
    $resolvedEmployeeId=$candidateComment
    $resolvedEmployeeIdSource="comment"
  }
  elseif(-not [string]::IsNullOrWhiteSpace($candidateEmployeeNumber)){
    $resolvedEmployeeId=$candidateEmployeeNumber
    $resolvedEmployeeIdSource="employeeNumber"
  }

  [PSCustomObject]@{
    username=SProp $p "samaccountname"
    name=SProp $p "displayname"
    email=SProp $p "mail"
    upn=SProp $p "userprincipalname"
    employeeId=$resolvedEmployeeId
    employeeIdSource=$resolvedEmployeeIdSource
    employeeNumber=SProp $p "employeenumber"
    department=SProp $p "department"
    title=SProp $p "title"
    company=SProp $p "company"
    manager=$managerName
    managerEmail=$managerEmail
    office=SProp $p "physicaldeliveryofficename"
    telephone=SProp $p "telephonenumber"
    mobile=SProp $p "mobile"
    status=$status
    enabled=$enabled
    accountExpiry=$expiry
    passwordLastSet=Convert-FileTimeIso (Prop $p "pwdlastset")
    passwordExpiry=Convert-FileTimeIso (Prop $p "msds-userpasswordexpirytimecomputed")
    passwordRequired=$passwordRequired
    passwordNeverExpires=$passwordNeverExpires
    lastLogon=Convert-FileTimeIso (Prop $p "lastlogontimestamp")
    whenCreated=Convert-DateTimeIso (Prop $p "whencreated")
    whenChanged=Convert-DateTimeIso (Prop $p "whenchanged")
    homeDirectory=SProp $p "homedirectory"
    description=SProp $p "description"
    comment=SProp $p "comment"
    distinguishedName=SProp $p "distinguishedname"
    groups=$groups
  }
}
$props=@("samaccountname","displayname","mail","userprincipalname","employeeid","employeenumber","department","title","company","manager","physicaldeliveryofficename","telephonenumber","mobile","useraccountcontrol","accountexpires","pwdlastset","lastlogontimestamp","whencreated","whenchanged","distinguishedname","memberof","homedirectory","description","comment","msds-userpasswordexpirytimecomputed")
`;
}

async function handleApi(req, res, u) {
  try {
    if (u.pathname === '/api/health') {
      const ps = commonPs + `
[PSCustomObject]@{
 ok=$true
 baseDN=[string]$base
 machine=$env:COMPUTERNAME
 user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
 timestamp=(Get-Date).ToString("s")
} | ConvertTo-Json -Compress
`;
      const out = await runPS(ps);
      return sendJson(res, JSON.parse(out || '{}'));
    }

    if (u.pathname === '/api/departments') {
      const ps = commonPs + `
$s=Searcher "(&(objectCategory=person)(objectClass=user)(department=*))" @("department")
$set=New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
try{
  foreach($r in $s.FindAll()){
    $d=SProp $r.Properties "department"
    if($d){ [void]$set.Add($d.Trim()) }
  }
  [PSCustomObject]@{items=@($set | Sort-Object)} | ConvertTo-Json -Depth 4 -Compress
}finally{$s.Dispose();$root.Dispose()}
`;
      const out = await runPS(ps);
      return sendJson(res, JSON.parse(out || '{"items":[]}'));
    }

    if (u.pathname === '/api/groups') {
      const q = u.searchParams.get('query') || '';
      const ps = commonPs + `
$q=Esc ${psQuote(q)}
$filter=if([string]::IsNullOrWhiteSpace(${psQuote(q)})){"(objectCategory=group)"}else{"(&(objectCategory=group)(|(cn=*$q*)(name=*$q*)(samAccountName=*$q*)))"}
$s=Searcher $filter @("cn","name","samaccountname","distinguishedname","description")
$s.SizeLimit=200
$o=@()
try{
 foreach($r in $s.FindAll()){
   $o += [PSCustomObject]@{
    name=SProp $r.Properties "name"
    samAccountName=SProp $r.Properties "samaccountname"
    description=SProp $r.Properties "description"
    distinguishedName=SProp $r.Properties "distinguishedname"
   }
 }
 [PSCustomObject]@{items=@($o | Sort-Object name)} | ConvertTo-Json -Depth 5 -Compress
}finally{$s.Dispose();$root.Dispose()}
`;
      const out = await runPS(ps);
      return sendJson(res, JSON.parse(out || '{"items":[]}'));
    }

    if (u.pathname === '/api/users') {
      const mode = (u.searchParams.get('mode') || '').toLowerCase();
      const value = u.searchParams.get('value') || '';
      const recursive = (u.searchParams.get('recursive') || 'true') !== 'false';

      let filterPs;
      if (mode === 'department') {
        filterPs = `$filter="(&(objectCategory=person)(objectClass=user)(department=$(Esc ${psQuote(value)})))"`;
      } else if (mode === 'user') {
        filterPs = `$e=Esc ${psQuote(value)}; $filter="(&(objectCategory=person)(objectClass=user)(|(samAccountName=*$e*)(displayName=*$e*)(mail=*$e*)(employeeID=*$e*)(userPrincipalName=*$e*)))"`;
      } else if (mode === 'group') {
        filterPs = `
$gq=Esc ${psQuote(value)}
$gs=Searcher "(&(objectCategory=group)(|(cn=$gq)(samAccountName=$gq)(name=$gq)))" @("distinguishedname")
try{$gr=$gs.FindOne()}finally{$gs.Dispose()}
if($null -eq $gr){ throw "AD group '${value.replace(/'/g,"''")}' was not found." }
$gdn=Esc (SProp $gr.Properties "distinguishedname")
$filter=${recursive ? `"(&(objectCategory=person)(objectClass=user)(memberOf:1.2.840.113556.1.4.1941:=$gdn))"` : `"(&(objectCategory=person)(objectClass=user)(memberOf=$gdn))"`}
`;
      } else {
        return sendJson(res, {error:'Unsupported search mode.'}, 400);
      }

      const ps = commonPs + userMapperPs() + `
${filterPs}
$s=Searcher $filter $props
$o=@()
try{
 foreach($r in $s.FindAll()){ $o += UserObj $r $false }
 [PSCustomObject]@{count=$o.Count;items=@($o | Sort-Object name)} | ConvertTo-Json -Depth 7 -Compress
}finally{$s.Dispose();$root.Dispose()}
`;
      const out = await runPS(ps);
      return sendJson(res, JSON.parse(out || '{"count":0,"items":[]}'));
    }

    if (u.pathname === '/api/user') {
      const username = u.searchParams.get('username') || '';
      const ps = commonPs + userMapperPs() + `
$e=Esc ${psQuote(username)}
$s=Searcher "(&(objectCategory=person)(objectClass=user)(|(samAccountName=$e)(userPrincipalName=$e)))" $props
try{
 $r=$s.FindOne()
 if($null -eq $r){ [PSCustomObject]@{error="User not found."} | ConvertTo-Json -Compress; exit 3 }
 UserObj $r $true | ConvertTo-Json -Depth 8 -Compress
}finally{$s.Dispose();$root.Dispose()}
`;
      try {
        const out = await runPS(ps);
        return sendJson(res, JSON.parse(out || '{}'));
      } catch (e) {
        if ((e.message || '').includes('User not found')) return sendJson(res,{error:'User not found.'},404);
        throw e;
      }
    }

    sendJson(res, {error:'API endpoint not found.'}, 404);
  } catch (e) {
    sendJson(res, {error:e.message || 'Server error'}, 500);
  }
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://${HOST}:${PORT}`);
  if (u.pathname.startsWith('/api/')) return handleApi(req,res,u);

  let rel = decodeURIComponent(u.pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.resolve(WWW, '.' + rel);
  if (!file.startsWith(path.resolve(WWW))) return sendText(res,'Forbidden',403);
  fs.readFile(file, (err, data) => {
    if (err) return sendText(res,'Not found',404);
    res.writeHead(200, {'Content-Type':contentType(file),'Content-Length':data.length});
    res.end(data);
  });
});

server.listen(PORT, HOST, () => {
  console.log('');
  console.log('AD Directory Explorer V1.2 (Node)');
  console.log('---------------------------------');
  console.log(`URL: http://localhost:${PORT}`);
  console.log('No NPM packages required.');
  console.log('Press Ctrl+C to stop.');
  console.log('');
});
