const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{promisify}=require('node:util');
const file=path.join(__dirname,'data','users.json');
const derive=promisify(crypto.scrypt);const opts={N:32768,r:8,p:1,maxmem:64*1024*1024};
function users(){return JSON.parse(fs.readFileSync(file,'utf8'));}
function save(v){fs.writeFileSync(file+'.tmp',JSON.stringify(v,null,2),{mode:0o600});fs.renameSync(file+'.tmp',file);}
function normalize(n){return String(n||'').trim().toLowerCase();}
async function hash(password){let salt=crypto.randomBytes(16).toString('hex');return {salt,hash:(await derive(password,salt,64,opts)).toString('hex')};}
async function verify(password,u){const out=await derive(password,u?u.salt:'dummy-not-a-real-user',64,opts);const expected=Buffer.from(u?u.hash:'00'.repeat(64),'hex');return expected.length===out.length && crypto.timingSafeEqual(out,expected) && !!u;}
module.exports={users,save,normalize,hash,verify};
