CET DIP PORTAL V3 — NODE AUTHENTICATION + JIRA BRIDGE

This is the next authentication prototype, not the full intake workflow. Uses built-in Node modules only. Use a supported Node LTS release (22 or 24 recommended). No npm install needed. No Windows authentication, AD trust, ASP.NET or CLR application pool dependency.

INITIAL SETUP — POWERSHELL
1. Extract to a private application directory, e.g. C:\CET\DIP-V3. Back up DIP V1 and IIS settings first.
2. Open PowerShell in that directory.
3. Run:
   node manage-users.js add 'dib\muhammad.yahya' Administrator
   Enter and confirm a NEW SEPARATE PORTAL PASSWORD (minimum 12 characters). Input is hidden. No default password exists. Do not use your bank/AD password.
4. Run:
   node server.js
   Backend binds only to 127.0.0.1:4000. If port 4000 is occupied by the old Jira test, stop that instance first or change config.json port and web.config upstream together.

IIS /DIP DEPLOYMENT
- IIS URL Rewrite and ARR required. Enable ARR proxy as used for your other Node portals.
- Use a dedicated DIP IIS application pointing to this folder. App pool can use No Managed Code; CLR/ASP.NET is unnecessary.
- For DIP only: Anonymous Authentication ENABLED; Windows Authentication DISABLED. Application login is enforced by Node.
- Supplied web.config rewrites all requests to Node. Do not mix V2 Identity.ashx or V2 web.config into V3. Check inherited parent rules do not intercept DIP first.
- Keep HTTPS binding/certificate working at https://dxb01-vwu-afna1.dibuat.ae/DIP/.
- Ensure IIS does not inject a conflicting X-Frame-Options header. Node sends CSP frame-ancestors https://connectjira.dib.ae.
- Backend handles both stripped and preserved /DIP paths. A trailing slash is required for relative asset/API paths; open /DIP/ explicitly.
- App folders contain private hashes. Node serves only its fixed public assets. Verify /DIP/data/users.json and /DIP/config.json do not return their contents. Restrict filesystem access to application operators/service identity.
- Run interactively for the first test; later register Node as a Windows service using your approved deployment method. Restarting Node logs out all sessions.

LOCALHOST TEST
config.json defaults to the HTTPS server URL (secure cookies). For local testing, change ONLY publicUrl to http://localhost:4000/ then run node server.js and open that URL. Restore the supplied HTTPS URL before server deployment. Localhost HTTP uses SameSite=Lax; production HTTPS uses Secure, HttpOnly, SameSite=None. Do not use HTTP for server login.

CONFLUENCE TEST
Use the included Confluence-Bridge-Macro.html, or retain the unchanged working V1 macro. Sign into the portal using the newly created portal account. Fetch five DMGT issues. Portal authenticates independently and validates bridge input through its backend before displaying it. Jira browser session remains on connectjira.dib.ae; Windows server never calls Jira.

BROWSER COOKIES
Confluence dib.ae and portal dibuat.ae are different sites. Embedded login requires session-cookie support in that context. SameSite=None; Secure does not override browser third-party-cookie blocking. If login fails with session/CSRF errors, open /DIP/ directly to verify login, then ask browser administrators about a narrowly scoped approved policy. Opening directly alone may not fix blocked iframe cookies. Do not use URL tokens or disable cookie protections globally. This browser compatibility must be proven before full rollout.

USER MANAGEMENT — RUN ON SERVER IN POWERSHELL
node manage-users.js list
node manage-users.js add 'dib\another.user' Assessor
node manage-users.js reset 'dib\another.user'
node manage-users.js disable 'dib\another.user'
node manage-users.js enable 'dib\another.user'
node manage-users.js role 'dib\another.user' Viewer
Roles: Administrator, Assessor, Requester, Viewer. All can view the five-issue bridge. Only Administrator can call /api/admin/users. This is the current role permission matrix; intake/approval permissions will be added later.
Last enabled administrator cannot be disabled/demoted by these commands. Password resets, role changes and disable/enable invalidate existing user sessions at their next API request. Run management commands serially. Back up data/users.json; it contains salted password hashes, not plaintext passwords. Empty JSON object is shipped; no real accounts or secrets are included.

IMPLEMENTED SECURITY
Scrypt password hashes with random salts; constant-time comparison; generic login failures; five failed attempts per username in 15 minutes; concurrency/session limits; rotated random session ID after login; anti-CSRF header and exact portal Origin check on POST; 30-minute idle and 8-hour maximum sessions; backend enabled-user and role checks; secure production cookies; no-store responses; CSP; text-only issue rendering; bounded request/input sizes. Sessions and throttling are in memory, suited to this single-process pilot, not a multi-instance production deployment.

BOUNDARIES
Domain ID is a portal username only; portal does not prove AD/Confluence identity. Browser bridge data is untrusted and not an authoritative Jira source. No Jira writes, saved intake records, attachments, MFA, admin editing UI, approval workflow, durable audit log or background synchronization yet. No claims of production readiness. The external identity/auth design can later move to enterprise SSO.

TEST CHECKLIST
- Anonymous admin/API and bridge calls rejected.
- Wrong password rejected; right password succeeds.
- Viewer cannot list users; Administrator can.
- Logout invalidates session.
- Disabled user session fails on next API request.
- Invalid bridge input and cross-origin/missing-CSRF writes rejected.
- Live IIS HTTPS, iframe cookies, Confluence Jira session require on-site testing.
