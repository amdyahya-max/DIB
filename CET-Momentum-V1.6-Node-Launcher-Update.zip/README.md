> CET Momentum v1.6 adds Node-based launch and helper-assembly options. See UPDATE-V1.6.txt.

# CET Momentum

New helper installations can request access without an enrollment code. In CET Helper, enter the portal URL and click **Request administrator approval**. A user must exist in the enabled Excel roster. In **Administration > Helpers**, verify the displayed reference with the employee, then approve or reject the specific PC request. Requests expire after 24 hours. The helper checks every 15 seconds and opens the portal once approved. Each PC receives separate access; approved PCs share the user's attendance records. Existing enrolled helpers remain valid.

Reported usernames and PC names are not independently verified Windows domain identity. Verify the reference with the intended employee before approval. HTTPS is required for remote use; HTTP localhost is supported for local testing. Pending installations cannot access portal data. Admin roles are separate from device approval. Requests and decisions are audited, and users are limited to five new requests in 24 hours.

For first administrator setup, run the Node commands shown in the Windows first-run section below. In the helper, expand **First administrator / enrollment code**. Node.js 24 must be available in the application Node folder.

## Apply the v1.1 device approval update (historical notes)

1. Stop the portal and back up the entire CET-Momentum folder, including storage.
2. Extract the update ZIP into that folder and replace the supplied application files. It contains no Excel roster, SQLite database, or .env.
3. From PowerShell in the application root, run `.\Node\node.exe .\Start-Portal.js`. The new request tables are created automatically, preserving existing data.
4. On PCs using the new approval flow, quit CET Helper from the tray and run downloads\CET-Helper-Setup.exe. Existing connection data is retained. No administrator elevation is requested. The installer remains unsigned.
5. Restart the helper and press Ctrl+F5 in the portal. Existing enrolled users do not need to enroll again.

Includes administrator toggles, self-block prevention, last-active-admin safeguard, and table alignment fixes. Remote PC helpers must use the shared HTTPS portal address, not localhost.

Validation: all nine automated tests passed with expanded HTTP checks for approval, rejection, expiry, pre-approval denial, and independent device revocation; frontend production build passed. The Windows installer was rebuilt, but native Windows startup, UI, and installation still need acceptance testing on your PC.

---

# CET Momentum — version 1.0

Node.js + Express + React + SQLite timesheet self-confirmation portal, with an Electron Windows identity and reminder helper. No .NET application or Windows Authentication is used by the portal.

## First run on your Windows PC

1. Extract the complete Node.js 24 Windows distribution, including npm files, into the application's `Node` folder. Node 20 and earlier are not supported.
2. Extract this entire package into a writable directory such as `C:\CETMomentum`.
3. Run `whoami` in PowerShell or Windows Terminal. Copy the complete result, for example `DIB\yahya`, into the **Username** column in `data\CET_Users.xlsx`. Fill Name and set Status to **Enabled**. Add the other employees and consultants as required. Keep the 12 supplied headers in row 1 and the worksheet name `Users`.
4. Open PowerShell in the application root and run `.\Node\node.exe .\Start-Portal.js` when Node is inside the app folder, or `..\Node\node.exe .\Start-Portal.js` when Node is in the parent CET-Momentum folder. This creates `.env` from `.env.example`, installs packages through Node if needed, builds the portal if needed, and starts the server. Internet access to the npm registry is needed only if packages must be installed. Keep PowerShell open during local testing.
5. In a second PowerShell window, navigate to the application root and grant yourself the first admin role with Node:

   ```powershell
   .\Node\node.exe .\scripts\admin.js grant "DIB\yahya"
   .\Node\node.exe .\scripts\admin.js enroll "DIB\yahya"

   Use `..\Node\node.exe` instead when Node is in the parent CET-Momentum folder.
   ```

   Substitute the exact result of `whoami`. The second command prints a one-time enrolment code that expires in 24 hours. Do not share it with other users.

6. Open **http://localhost:5000/**. Use that exact address, rather than `127.0.0.1`, because the configured portal origin must match.
7. Click **Download CET Helper** and run the installer. It installs for the current Windows user under `%LOCALAPPDATA%\Programs\CET Helper`, with `RequestExecutionLevel user`. Administrator elevation is not requested. Corporate application policies can still block it. The included installer is unsigned; have IT approve/sign it before distributing it widely.
8. In CET Helper, enter `http://localhost:5000` and your one-time code. Click **Connect account**. The helper reads `whoami`, enrols the account, and starts at Windows sign-in. Keep the portal open: it detects the helper and opens your calendar automatically. If the browser asks for local-network access, allow it for this trusted portal.

After this first setup there is no username/password screen. The helper reconnects automatically. The Administration menu appears only after the admin role has been granted. Only one helper runs per Windows account.

For source-based helper testing, use the Electron runtime in `helper\node_modules` after installing its packages. The normal employee setup uses the included per-user installer. Automatic startup is enabled only for the installed helper. The compiled helper is included at `downloads\CET-Helper-Setup.exe`. No Node installation is needed on employee PCs when they use this installer.

If your browser blocks communication with the local helper, choose **Open CET Calendar** from the helper's tray menu. This issues a short-lived single-use connection link through the server and opens your authenticated calendar without relying on browser-to-localhost communication. This fallback also requires successful enrolment and current roster access. Desktop reminders remain available through the helper.

## Enrol other people

1. Add their complete Windows account to Excel with Status `Enabled`. Save and close Excel.
2. Wait for the sync or use **Administration → Users → Sync now**.
3. Click **Enrol** next to the user. Give that person the single-use code through your organisation's approved channel.
4. They install CET Helper, configure the shared portal URL and enter their code once.

An enabled username alone cannot create a session. Enrolment requires the administrator-issued code, which binds a device credential to that roster account. This is an administrator-approved credential model, not Windows domain attestation. Protect codes and the helper's per-user connection file. For stronger centrally enforced identity, corporate SSO can be added later.

If the identified account is absent, removed, expired or disabled, the portal displays **“This portal is available only to authorised CET users. Please contact the CET administrator.”** A missing helper displays installation guidance. Eligibility checking during setup grants no access; all protected operations check the authenticated session and current SQLite user status again.

## Excel and SQLite

The authoritative workbook is `data\CET_Users.xlsx`. Its columns are:

`Employee ID, Name, Username, Email, Company, Title, Manager, Status, Account Expiry, Password Expiry, Telephone, Mobile`.

- Username and Name are required for every populated row. Status accepts `Enabled`, `Expired`, `Disabled` (case-insensitive). Status must be explicit. Use exact domain-qualified usernames from `whoami`.
- Blank rows are ignored. Usernames ignore case and surrounding whitespace. Duplicate usernames reject the entire import.
- Employee IDs and telephone numbers remain text. Expiry dates should be Excel date cells or `YYYY-MM-DD`. Account Expiry blocks access after that date. Password Expiry is informational and does not affect Windows identity or portal access.
- New rows create users. Existing rows update roster fields. Removed rows mark users inactive without deleting confirmations.
- File events are debounced; a periodic check every 60 seconds catches missed events. Temporary Excel files are ignored because only the configured filename is read.
- Invalid, missing, empty or partially saved files retain the last valid roster. Admin shows the sync error; the next valid save retries. Never intentionally empty the workbook to disable everyone: use explicit Disabled rows or admin blocks.
- Import is transactional. Leader tags, administrator roles, admin blocks, joining/leaving dates and leave records survive sync.
- SQLite is at `storage\cet.sqlite`. It contains users, confirmations, leave, settings, enrolled devices, short-lived sessions and audit records. No data is written back into Excel.

The template has 100 blank input rows and extends as an Excel table. Do not put explanatory text or formulas inside the roster. No fictional user records are shipped.

## Calendar and race rules

- My Calendar opens by default. Each eligible day is a box. Clicking it opens the Magnitude confirmation statement. A date can be confirmed only once.
- Today uses **Asia/Dubai**, even when the server is in a different timezone. Future dates are blocked by the server.
- Current and previous month confirmations are allowed by default. Admin can turn off previous-month confirmation. Older months remain viewable, with no new user submissions.
- Default working days are Monday–Friday. Admin can change them and add holidays. Approved leave and joining/leaving dates reduce each user's eligible target.
- One confirmed eligible day earns one point. The car position is confirmed days / full-month eligible days. Rank is confirmed days / eligible days due through today. Equal ratios share a rank.
- Streak counts consecutive eligible dates through today. If today is a working day and is not confirmed, the streak is zero until it is confirmed. Holidays and leave do not interrupt it.
- Leader-tagged users see regular participants and all tagged leaders. Regular users receive only regular participant data, including counts and ranks. Administrators see all users and confirmations in Admin reports; an admin who is not leader-tagged still has the regular race view.
- Admin corrections require a reason and are audited. Changing holiday/leave rules changes eligible race targets, while underlying confirmation records are retained.

These records are **users' confirmation that they logged their timesheet in Magnitude**. This version does not access Magnitude or verify submitted hours.

## Reminders

Configure times, snooze, grace period, working days, holidays, sound and the Magnitude URL under **Administration → Settings**. Defaults: 16:00 and 17:00 Dubai time; 15-minute snooze; 120-minute resume grace.

- The helper fetches settings and today's status every 15 seconds while running.
- It only reminds for an eligible day that is not confirmed. Confirming today stops further reminders after the next helper refresh.
- With the portal visible and connected, the reminder appears inside the portal. With it closed/backgrounded, the helper shows a native reminder window and attempts a Windows notification. Windows notification settings can suppress the toast; the helper window remains the fallback.
- Actions: Open Magnitude (when a URL is configured), Open Calendar, Snooze, Dismiss. Opening Magnitude alone does not mark attendance.
- Schedule deduplication is stored per Windows user. One latest due reminder is shown after resume within the configured grace period, rather than all missed reminders.
- The PC must be awake and the helper running. A stopped helper cannot generate alerts. Browser throttling, sleep, network delays and a server outage can delay alerts; this is not an exact-to-the-second scheduling service.

## Administration

- Users: search, block/unblock portal access, leader toggle, enrolment codes, joining/leaving dates and Excel sync health.
- Blocking takes precedence over Excel. Unblocking cannot enable a row that Excel marks Disabled/Expired or has removed.
- Records: monthly report, CSV export, approved leave, reason-required corrections.
- Helpers: revoke credentials and immediately invalidate the helper's browser sessions.
- Audit: recent syncs, user updates, enrolments, settings changes and attendance changes.

Grant/revoke admin roles from the server console:

```bat
Node\node.exe scripts\admin.js grant "DIB\username"
Node\node.exe scripts\admin.js revoke "DIB\username"
```

Local filesystem/server console access is privileged. Protect the installation, `.env`, Excel roster and SQLite directory with appropriate Windows permissions. Do not expose those folders through IIS.

If you accidentally block the only administrator, run `Node\node.exe scripts\admin.js unblock "DIB\username"` from the server console. This removes the admin block, but Excel must still list the account as Enabled.

## Windows Server and IIS

Keep this as a single Node server instance with the database on a local disk. Multiple clustered processes and network-share SQLite storage are not supported in this version.

1. Copy the project to the server, install Node 24 and run `npm ci`. The prebuilt frontend is included; rebuild with `npm run build` when source changes.
2. Configure `.env` with `HOST=127.0.0.1` and `PORT=5000`.
3. Choose exactly one public address:

   Dedicated host:
   ```env
   PUBLIC_URL=https://cet.example.internal
   BASE_PATH=
   ```

   IIS application path:
   ```env
   PUBLIC_URL=https://intranet.example.internal/CETGamification
   BASE_PATH=/CETGamification
   ```

   No trailing slash in `.env`. Open the portal URL with an optional final `/`. The helper must use this same address. The Node origin check uses the configured public HTTPS origin, not the backend loopback address.

4. Install IIS **URL Rewrite** and **Application Request Routing**. Enable proxy at the server level in ARR's **Server Proxy Settings**.
5. For a dedicated host, copy `deployment\web.config.root.example` into that site's proxy directory as `web.config`. For `/CETGamification`, create an IIS application/virtual directory at that path and put `deployment\web.config.subpath.example` inside its proxy directory as `web.config`. The subpath rule is relative to that application's directory; do not paste it into the site's root unchanged.
6. Configure the HTTPS certificate and make the public address reachable from employee PCs. IIS anonymous access is appropriate for this helper/session model; Windows Authentication is not needed. Keep Node listening on loopback.
7. Configure a Windows service wrapper. The supplied `deployment\CETMomentum.xml.example` is for **WinSW**. Obtain the appropriate WinSW executable from its official releases, rename it `CETMomentum.exe`, place it beside `CETMomentum.xml`, and adjust the paths in the XML. Install/start from an elevated server console:

   ```bat
   CETMomentum.exe install
   CETMomentum.exe start
   ```

   Choose a supported WinSW binary/runtime for your server. Service installation needs server administrator rights; employee helper installation does not. Give the service account read permission on `data` and modify permission on `storage` and `service-logs`. Use an account with the minimum necessary permissions.

8. Existing local-test helper enrolment points to localhost. For deployment, revoke the local device, issue a fresh enrolment code and connect the helper to the new HTTPS address. The helper currently has no automatic configuration migration or updater.

Official references:
- Node SQLite: https://nodejs.org/docs/latest-v24.x/api/sqlite.html
- IIS ARR: https://learn.microsoft.com/en-us/iis/extensions/url-rewrite-module/reverse-proxy-with-url-rewrite-v2-and-application-request-routing
- WinSW: https://github.com/winsw/winsw
- Electron notifications: https://www.electronjs.org/docs/latest/tutorial/notifications

## Rebuild the helper

On Windows, double-click `Build-Helper.cmd` or run:

```bat
cd helper
npm ci
npm run dist:win
npm run publish:local
```

This uses electron-builder's per-user NSIS configuration. The included executable was built from the same packaged helper using the provided `helper\installer.nsi` per-user NSIS script. Signing is not configured. For corporate distribution, sign the executable and installer through IT's approved certificate/build process. The NSIS script is also supplied for reproducible builds with a locally installed NSIS toolchain.

## Backups and checks

Before backup, stop the Node service/process cleanly and copy `storage` and `data`; restart afterwards. Restore both to recover roster settings, attendance, device credentials and audit history. Do not copy only the active SQLite file while WAL writes are in progress.

Run `npm test` for the integration tests and `npm run build` for frontend validation. Tests use disposable isolated databases and do not modify the real roster.

Linux checks cover the server, SQLite, Excel import, session flow, duplicate prevention, leader privacy, access revocation and reminder scheduling logic. The Windows installer, non-admin installation, startup, browser local-network policy, Windows notifications and IIS service/proxy behaviour require acceptance testing on your Windows PC/server. Start with your own enabled account before distributing the helper.

## Troubleshooting

| Symptom | Action |
|---|---|
| Portal asks to install helper after installation | Start CET Helper from Start Menu/tray. Check its portal URL matches `.env`. Allow local-network access for the portal if prompted. Use Check Again. Port 47831 must be available. |
| Authorised users only | Verify the exact `whoami` account is enabled in SQLite/Excel, account expiry is valid and no admin block is set. Review sync errors. |
| Enrolment code rejected | Check the account matches, code is unused and issued within 24 hours. Issue a new code if necessary. |
| SQLite is unavailable | Use Node 24 LTS. Confirm `storage` is writable and located on local disk. |
| Excel sync fails | Keep all 12 row-1 headers, use explicit Status, remove duplicate accounts, save and close the workbook, then Sync now. |
| No reminder | Verify Dubai-time settings, today's eligibility, helper running and portal/server connectivity. A confirmed date gets no reminder. |
| IIS 502 | Check the Node service, loopback port, ARR Enable Proxy and `.env` address/path. |
| Subpath loads with missing assets/API | Ensure the IIS application path and BASE_PATH match exactly, and use the subpath XML in that application's proxy folder. |
