import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const nodeMajor=Number(process.versions.node.split('.')[0]);
const npmCandidates=[
  path.join(root,'Node','node_modules','npm','bin','npm-cli.js'),
  path.resolve(path.dirname(process.execPath),'node_modules','npm','bin','npm-cli.js'),
  path.resolve(path.dirname(process.execPath),'..','node_modules','npm','bin','npm-cli.js'),
];
const npmCli=npmCandidates.find(file=>fs.existsSync(file));
function run(exe,args,opts={}){return new Promise((resolve,reject)=>{const child=spawn(exe,args,{cwd:root,stdio:'inherit',windowsHide:false,...opts});child.once('error',reject);child.once('exit',(code,signal)=>resolve({code:code??(signal?1:0),signal}));});}
function fail(message){console.error(`\nCET Momentum startup: ${message}`);process.exitCode=1;}
async function main(){
  if(nodeMajor!==24){fail(`Node.js 24 is required. This runtime is ${process.versions.node}. In PowerShell, run: .\\Node\\node.exe .\\Start-Portal.js`);return;}
  const example=path.join(root,'.env.example'),envFile=path.join(root,'.env');
  if(!fs.existsSync(envFile)){
    if(!fs.existsSync(example)){fail('.env.example is missing. Restore the application package.');return;}
    fs.copyFileSync(example,envFile);
    console.log('Created .env from .env.example. Review its portal URL and settings if needed.');
  }
  if(!fs.existsSync(path.join(root,'node_modules'))){
    if(!npmCli){fail('Portal packages are not installed and npm-cli.js was not found inside the Node folder. Restore the complete Node.js 24 distribution under Node, including node_modules/npm.');return;}
    console.log('Installing portal packages with the bundled Node runtime…');
    const result=await run(process.execPath,[npmCli,'ci','--no-audit','--no-fund']);
    if(result.code!==0){fail(`npm package setup stopped with exit code ${result.code}.`);return;}
  }
  if(!fs.existsSync(path.join(root,'dist','index.html'))){
    if(!npmCli){fail('The built portal is missing and npm-cli.js was not found in the Node distribution.');return;}
    console.log('Building the portal…');
    const result=await run(process.execPath,[npmCli,'run','build']);
    if(result.code!==0){fail(`Portal build stopped with exit code ${result.code}.`);return;}
  }
  console.log(`Starting CET Momentum with Node.js ${process.versions.node}. Keep this window open while using the portal.`);
  console.log('By default, open http://localhost:5000/ (or the PUBLIC_URL in .env).');
  const child=spawn(process.execPath,['server/index.js'],{cwd:root,stdio:'inherit',windowsHide:false});
  const forward=signal=>{if(child.exitCode===null)child.kill(signal);};
  process.once('SIGINT',()=>forward('SIGINT'));
  process.once('SIGTERM',()=>forward('SIGTERM'));
  child.once('error',error=>fail(`Could not start the portal: ${error.message}`));
  child.once('exit',(code,signal)=>{process.exitCode=code??(signal?1:0);});
}
main().catch(error=>fail(error.message));
