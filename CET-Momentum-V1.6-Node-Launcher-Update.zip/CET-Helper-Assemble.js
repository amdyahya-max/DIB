'use strict';
// Reassembles the CET Helper installer using the Node runtime already shipped
// with CET Momentum. Supports flat extraction or Windows' separate ZIP folders.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = __dirname;
const NAMES = Array.from({length: 5}, (_, i) => `CET-Helper-Setup.part${String(i + 1).padStart(2, '0')}`);
const EXPECTED_BYTES = 98592242;
const EXPECTED_SHA256 = '65e27c589de255fc38531493516a7854a783fce1634776bae0fa5820010a60a9';
function locate(name, index) {
  const partFolder = `CET-Helper-Part-${String(index + 1).padStart(2, '0')}-of-05`;
  const candidates = [
    path.join(ROOT, name),
    path.join(ROOT, partFolder, name),
    path.join(ROOT, '..', name),
    path.join(ROOT, '..', partFolder, name),
    path.join(ROOT, '..', '..', partFolder, name),
  ];
  return candidates.find(p => { try { return fs.statSync(p).isFile(); } catch { return false; } });
}
const files = NAMES.map((name, i) => locate(name, i));
const missing = NAMES.filter((_, i) => !files[i]);
if (missing.length) {
  console.error('Some installer pieces were not found:');
  for (const part of missing) console.error(`  ${part}`);
  console.error('\nExtract all five ZIP files first. Keep the extracted folders together under MOM,');
  console.error('or extract all five part files into one folder. Then run this script again.');
  process.exit(1);
}
const output = path.join(ROOT, 'CET-Helper-Setup.exe');
try {
  const hash = crypto.createHash('sha256');
  let size = 0;
  const chunks = [];
  for (const file of files) {
    const bytes = fs.readFileSync(file);
    size += bytes.length;
    hash.update(bytes);
    chunks.push(bytes);
  }
  const digest = hash.digest('hex');
  if (size !== EXPECTED_BYTES || digest !== EXPECTED_SHA256) {
    console.error('The pieces do not match the original installer.');
    console.error(`Size: ${size} bytes; SHA-256: ${digest}`);
    process.exit(2);
  }
  fs.writeFileSync(output, Buffer.concat(chunks, size));
  console.log(`Installer assembled and verified: ${output}`);
  console.log('Double-click CET-Helper-Setup.exe to install CET Helper.');
} catch (error) {
  try { fs.rmSync(output, {force: true}); } catch {}
  console.error(`Assembly failed: ${error.message}`);
  process.exit(3);
}
