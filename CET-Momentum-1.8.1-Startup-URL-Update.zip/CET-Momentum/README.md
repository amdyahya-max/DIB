# CET Momentum 1.8.1 update

For the blank-screen correction, portal diagnostics and trailing-slash/case normalization, follow [deployment/UPDATE-1.8.1.md](deployment/UPDATE-1.8.1.md). The supplied `dist` is already built. Preserve your production `.env`, Excel roster and SQLite storage. Helper 1.2.9 is unchanged.

# CET Momentum 1.8.0 — complete Windows package

Includes the built portal, Windows Node.js 24.19.0 with npm, Windows-compatible portal/helper dependencies and the published CET Helper 1.2.9 installer. Normal deployment requires no npm download or helper rebuild.

Public portal: https://dxb01-vwu-afna1.dibuat.ae/CETGamification/

Node listens on `127.0.0.1:5000`. IIS serves HTTPS and proxies `/CETGamification` to Node. `.env` and `.env.example` contain this public URL and `BASE_PATH=/CETGamification`.

## Upgrade an existing portal

Stop the portal/NSSM service and back up the application folder. Preserve your existing `.env`, `data` and `storage` folders. These contain configuration, the roster, attendance, settings, roles and helper enrollments. Do not replace them with the blank roster or empty storage directory from this ZIP.

Replace application files, `dist`, `downloads`, `helper`, `node_modules` and `Node`. Keep the installer and `downloads/helper-release.json` together. Review your existing `.env`, set the public URL and base path above, then restart. SQLite tables are upgraded automatically.

Check `https://dxb01-vwu-afna1.dibuat.ae/CETGamification/api/info`. It should report portal `version: "1.8.0"` and `helperRelease.version: "1.2.9"`.

## First installation

Extract `CET-Momentum` to a stable directory such as `C:\CETMomentum`. Populate `data\CET_Users.xlsx`, worksheet **Users**, with real accounts. Keep the twelve headers unchanged. **Username** is the exact Windows account, such as `DIB\yahya`. **Status** must be `Enabled`, `Disabled` or `Expired`. Optional dates use `yyyy-mm-dd`. The package contains no enabled demonstration accounts. An empty roster is deliberately rejected until populated.

From PowerShell in the application folder, grant the first administrator role and generate their single-use enrollment code:

```powershell
& '.\Node\node.exe' '.\scripts\admin.js' grant 'DIB\yahya'
& '.\Node\node.exe' '.\scripts\admin.js' enroll 'DIB\yahya'
& '.\Node\node.exe' '.\Start-Portal.js'
```

Replace the sample account with your enabled roster username. The enrollment code expires after 24 hours. On the server, check `http://127.0.0.1:5000/CETGamification/api/info`. Use the public HTTPS URL through IIS for sign-in and normal use. Configure NSSM/IIS using `deployment\WINDOWS-SERVER-IIS.md`. The ready-to-copy subpath proxy file is `deployment\web.config`.

Install `downloads\CET-Helper-Setup.exe` on your PC as your normal Windows user. It is a per-user tray app, starts at Windows sign-in and is not a Windows service. Connect the first administrator using the enrollment code. Other users can request enrollment and await approval in **Enrolled Helpers**. Each PC has its own enrollment.

In Administration, configure the actual Magnitude URL, working days, holidays and reminder times. Reminder times use Dubai time. No CMD launcher is required.

## Existing helper connections

The FQDN is the default for fresh installations. An upgrade retains an existing helper's saved portal URL and enrollment. If your PC still uses the localhost test portal, open **CET Helper → Settings**, change its portal URL to the FQDN and connect/enroll with that server. Changing the embedded default does not silently transfer enrollment between servers. Preserve the server database to retain existing server enrollments.

The portal offers **Update helper** when a newer release is published. The helper validates the download, closes, installs, verifies the installed version, restarts and reports its running version. This release retains the automatic updater you validated on Windows. PCs with an older broken updater may need this installer run manually once.

## Included functionality

- Calendar opens by default, with current/previous month access and Magnitude window before confirmation. Confirmations are user declarations; the portal cannot inspect Magnitude submissions.
- Self-service absence marking/removal and bulk weekend access for selected users.
- Animated race, top 25 and further participants, compact position bar, two credits for same-day logging and one for later logging, server-enforced leader privacy.
- Compact administration and collapsible sidebar. Attendance activity highlights missing days/current and previous month. Multi-select email reminders open the default email client; Outlook must be configured as that client.
- Excel-to-SQLite synchronization, enable/disable access, administrator roles, protection against disabling your own portal access, helper approval/revocation, attendance corrections and audit history.
- Background/in-portal reminders and helper/portal update diagnostics.

## Recovery admin CLI

Run `Node\node.exe scripts\admin.js COMMAND "DOMAIN\username"`:

| Command | Purpose |
| --- | --- |
| `grant` | Grant administrator role. |
| `revoke` | Remove administrator role. |
| `enroll` | Print a single-use enrollment code valid for 24 hours. |
| `unblock` | Clear an admin access block; Excel status still controls access. |

The recovery CLI runs outside the portal UI protections. Use it deliberately.

## Logs and builds

Helper logs: `%APPDATA%\CET Helper\logs`. Portal update log: `data\logs\helper-update.log`. NSSM stdout/stderr: `service-logs`.

See `helper\BUILD-AND-UPDATE.md`, `helper\CODE-SIGNING.md` and `VALIDATION.md`. The supplied installer is unsigned because no corporate code-signing certificate was supplied.
