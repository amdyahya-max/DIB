CET DIP V4.1 - Confluence native login and demand registration
===========================================================
First implementation package; replaces V3 server files, preserves existing users.
Node runtime REQUIRED: Node 22.13+ or Node 24. Use an approved supported build.
Uses built-in node:sqlite, no npm dependencies. Older Node builds cannot run it.

UPGRADE ON WINDOWS SERVER
1. Back up E:\DIP (especially data\users.json and config.json).
2. Stop-Service CET-DIP
3. Copy V4.1 files into E:\DIP. Keep existing config.json if customised.
   This ZIP intentionally does NOT contain users.json or an intake database.
   Do not overwrite your existing data folder. No account password is supplied.
4. Verify E:\DIP\node\node.exe --version meets the requirement.
5. LocalService needs Modify on data and logs as previously configured:
   Set-Location E:\DIP
   icacls .\data /grant '*S-1-5-19:(OI)(CI)(M)' /T
   icacls .\logs /grant '*S-1-5-19:(OI)(CI)(M)' /T
6. Start-Service CET-DIP
7. Check logs and Test-NetConnection 127.0.0.1 -Port 4000.
   Keep the existing IIS reverse proxy /DIP and HTTPS binding.

FRESH INSTALL ONLY
No users.json is required. SQLite tables are created automatically.
Use manage-users.js (interactive password prompt) to create the administrator:
Set-Location E:\DIP
.\node\node.exe .\manage-users.js add "dib\muhammad.yahya" Administrator
Existing users.json is migrated on the FIRST V4.1 startup. Do not edit it afterwards. See manage-users.js usage for other roles.

CONFLUENCE
Replace the old iframe macro with the entire contents of
Confluence-DIP-V4.1-Macro.html in an approved HTML macro. No html/head/body wrappers.
Confluence URL: https://connectjira.dib.ae/collaboration
DIP API URL: https://dxb01-vwu-afna1.dibuat.ae/DIP/api
Reference page: 197890530. These addresses are in native.js and the generated macro.
If editing native.js, regenerate the inline macro or edit its corresponding script.
The macro includes scoped CSS and no external dependencies.

REFERENCE PAGE TABLE: Property | Value
PageId | 197890530
FilterID | 21120
DemandOwner | actual Jira field ID, for example customfield_12345
PlatformOwner | actual Jira field ID
AccountableExecutiveLead | actual Jira field ID
Platform | actual Jira field ID
Size | actual Jira field ID

The field IDs above MUST be real IDs from your Jira/reference design.
Do not paste the example customfield_12345 blindly.
DemandOwner/PlatformOwner may map to reporter/assignee only if those truly
represent the business roles. Missing mappings display a warning and blanks.
Remove PortalPassword from the page. Credentials are entered in the login form.
Do not store a domain password, salted hash or API token in the reference page.

BEHAVIOUR
- Portal username and separate portal password entered directly in Confluence.
- Exact origin CORS; session token held only in page memory (not localStorage).
- Page reload requires login again. Logout revokes token. Server restart clears sessions.
- Sessions: 30-minute idle expiry and 8-hour maximum; account disable/version
  changes revoke sessions through the existing V3 user management mechanism.
- Jira uses the CURRENT browser user's Jira session. The user needs saved-filter
  access and issue permissions. No Jira service-account token is included.
- Automatic fetch after login, then every five minutes while page remains open.
- Paginates saved filter, up to 50 pages/5000 issues; no unattended scheduled sync.
- DAG Queue: Under Discussion mapping from existing V21.1 design, minus registered IDs.
- Select a demand to see owners, platform, size, created date, plain-text description
  and attachment links. Rich Jira wiki markup is currently displayed as text.
- Search matches key/title/platform/status. Default Jira order is oldest created.
- Register Demand: Administrator or Assessor only. Saves registration atomically.
- SQLite data\intake.sqlite: unique Jira issue ID and key; server timestamp,
  authenticated registering user, original snapshot, current data, sync timestamp,
  pending-fitment state and registration audit event.
- Original registration snapshot/date/user remain unchanged by Jira refresh.
- Registered Queue persists even if an item leaves the saved filter.
- Only registered items are eligible for future fitment. Fitment checklist/decisions
  and assessment workflow are NOT implemented in this first registration slice.
- Administrator/Assessor refreshes update current data for records present in filter.
  Viewer/Requester can read queues but cannot register or persist refresh updates.
- Records absent from the filter retain last known data/sync date, not a false live state.
- Documents are metadata and direct Jira links, not copied files in portal storage.

TRUST AND LIMITS
This remains a browser-fed integration. Portal cannot independently verify Jira
payloads without server-to-Jira connectivity; authorized users can alter their
submitted data. Registration timestamps/users are server-generated, while Jira
fields are browser-supplied. Not a trusted service-account synchronization.
All page scripts on the Confluence origin share that execution environment; allow
only trusted macros/scripts and use restricted reference-page editing permissions.
Confluence CSP must allow connection to the DIP HTTPS origin.
Full fitment, Jira writeback, individual record access partitions and file replication
are outside this first version. Queues are shared with authenticated portal users.
Back up SQLite using an approved SQLite backup procedure or stop the service before
copying the database and WAL/SHM files together. Do not copy only a live .sqlite file.

VALIDATION
Backend integration checks passed: unauthenticated access, wrong login, origin
rejection, administrator registration, noneligible rejection, duplicate conflict,
viewer write denial, snapshot/date preservation after sync and logout revocation.
JavaScript syntax passed. Macro fragment checked for no && entity hazards.
Live IIS/Confluence/browser testing has NOT been performed in your environment.
The generated login image is a visual concept, not a tested application screenshot.

V4.1 ACCOUNT DATABASE UPDATE
============================
Accounts now live in data\intake.sqlite, table portal_users, alongside registrations.
The first start imports existing users.json, preserving salts, password hashes,
roles, enabled status and session versions. Import and migration marker are one
transaction. Invalid legacy data stops startup without a partial import.
After migration users.json is NOT read for login or account maintenance. It is
retained untouched for rollback; archive it securely after confirming the upgrade.
CLI manage-users.js commands now read/write SQLite. No plaintext passwords are
stored. Existing passwords continue working. Username normalization is unchanged.
The database checks last-admin protection and concurrent account updates.
Do not create a fresh database and start it before copying legacy users.json: the
first startup marks migration complete even when no legacy file exists.
For an existing V4 installation, stop the service and keep the existing data folder.
For rollback, restore the complete pre-upgrade backup; edits made after migration
are not reflected in the legacy JSON file.
Person and lock icons are inline SVG inside login fields; labels remain accessible.
