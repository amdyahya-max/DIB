const fs=require('node:fs'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
fs.mkdirSync(path.join(__dirname,'data'),{recursive:true});
const db=new DatabaseSync(path.join(__dirname,'data','intake.sqlite'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
const schema="CREATE TABLE registrations(id TEXT PRIMARY KEY, issue_key TEXT NOT NULL UNIQUE, registered_at TEXT NOT NULL, registered_by TEXT NOT NULL, fitment_state TEXT NOT NULL DEFAULT 'Pending fitment')";
const columns=db.prepare('PRAGMA table_info(registrations)').all();
if(columns.some(c=>c.name==='snapshot')){
 const backup=path.join(__dirname,'data','intake-before-lean-'+Date.now()+'.sqlite');
 db.exec("VACUUM INTO '"+backup.replace(/'/g,"''")+"'");
 db.exec('BEGIN IMMEDIATE');try{db.exec('ALTER TABLE registrations RENAME TO registrations_legacy');db.exec(schema);db.exec('INSERT INTO registrations(id,issue_key,registered_at,registered_by,fitment_state) SELECT id,issue_key,registered_at,registered_by,fitment_state FROM registrations_legacy');db.exec('DROP TABLE registrations_legacy');db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
 db.exec('VACUUM');
}else if(!columns.length)db.exec(schema);
db.exec('CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, issue_id TEXT NOT NULL, at TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL)');
db.exec('CREATE TABLE IF NOT EXISTS jira_cache(issue_id TEXT PRIMARY KEY REFERENCES registrations(id),payload TEXT NOT NULL,refreshed_at TEXT NOT NULL)');
exports.list=()=>db.prepare('SELECT r.*,c.payload,c.refreshed_at FROM registrations r LEFT JOIN jira_cache c ON c.issue_id=r.id ORDER BY r.registered_at DESC').all().map(r=>{const {payload,...record}=r;return {...record,cached_data:payload?JSON.parse(payload):null};});
function cache(issue,now){db.prepare('INSERT INTO jira_cache(issue_id,payload,refreshed_at) VALUES(?,?,?) ON CONFLICT(issue_id) DO UPDATE SET payload=excluded.payload,refreshed_at=excluded.refreshed_at').run(issue.id,JSON.stringify(issue),now);}

exports.register=(issue,user)=>{const now=new Date().toISOString();db.exec('BEGIN IMMEDIATE');try{db.prepare('INSERT INTO registrations(id,issue_key,registered_at,registered_by) VALUES(?,?,?,?)').run(issue.id,issue.key,now,user);db.prepare('INSERT INTO audit(issue_id,at,actor,action) VALUES(?,?,?,?)').run(issue.id,now,user,'REGISTER');cache(issue,now);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}};
exports.sync=(issues)=>{const now=new Date().toISOString();db.exec('BEGIN IMMEDIATE');try{for(const issue of issues)if(db.prepare('SELECT id FROM registrations WHERE id=?').get(issue.id))cache(issue,now);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}};
