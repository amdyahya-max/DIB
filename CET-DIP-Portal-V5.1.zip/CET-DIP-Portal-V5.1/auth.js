const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{promisify}=require('node:util');
const {DatabaseSync}=require('node:sqlite');
const dir=path.join(__dirname,'data');fs.mkdirSync(dir,{recursive:true});
const db=new DatabaseSync(path.join(dir,'intake.sqlite'));db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS portal_users(username TEXT PRIMARY KEY,salt TEXT NOT NULL,password_hash TEXT NOT NULL,enabled INTEGER NOT NULL,role TEXT NOT NULL,version INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS auth_metadata(name TEXT PRIMARY KEY,value TEXT NOT NULL);`);
const roles=['Administrator','Assessor','Requester','Viewer'],derive=promisify(crypto.scrypt),opts={N:32768,r:8,p:1,maxmem:64*1024*1024};
function normalize(n){return String(n||'').trim().toLowerCase();}
function valid(n,u){return n===normalize(n) && n.length>0 && n.length<=150 && u && /^[a-f0-9]{32}$/.test(u.salt) && /^[a-f0-9]{128}$/.test(u.hash) && typeof u.enabled==='boolean' && roles.includes(u.role) && Number.isInteger(u.version) && u.version>=1;}
const insert=db.prepare('INSERT INTO portal_users(username,salt,password_hash,enabled,role,version) VALUES(?,?,?,?,?,?)');
// One-time migration. Existing database accounts are never overwritten.
db.exec('BEGIN IMMEDIATE');try{
if(!db.prepare("SELECT value FROM auth_metadata WHERE name='json_migrated'").get()){
 const legacy=path.join(dir,'users.json');let count=0;
 if(fs.existsSync(legacy)){let old=JSON.parse(fs.readFileSync(legacy,'utf8'));if(!old || Array.isArray(old) || typeof old!=='object')throw Error('Invalid legacy users.json');for(const [n,u]of Object.entries(old)){if(!valid(n,u))throw Error('Invalid legacy account record; migration cancelled.');if(!db.prepare('SELECT username FROM portal_users WHERE username=?').get(n)){insert.run(n,u.salt,u.hash,u.enabled?1:0,u.role,u.version);count++;}}}
 db.prepare('INSERT INTO auth_metadata(name,value) VALUES(?,?)').run('json_migrated',new Date().toISOString());
 if(count)console.log('Migrated '+count+' portal accounts into SQLite. Legacy file retained for backup only.');
}db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
const versions=new WeakMap();
function users(){const result=Object.fromEntries(db.prepare('SELECT * FROM portal_users').all().map(r=>[r.username,{salt:r.salt,hash:r.password_hash,enabled:!!r.enabled,role:r.role,version:r.version}]));versions.set(result,JSON.stringify(result));return result;}
function save(v){const expected=versions.get(v);if(expected===undefined)throw Error('Read accounts before saving.');db.exec('BEGIN IMMEDIATE');try{
const current=users();if(JSON.stringify(current)!==expected)throw Error('Accounts changed concurrently. Retry the command.');
for(const [n,u]of Object.entries(v))if(!valid(n,u))throw Error('Invalid account data.');
if(Object.values(current).some(u=>u.enabled && u.role==='Administrator') && !Object.values(v).some(u=>u.enabled && u.role==='Administrator'))throw Error('Cannot remove last active administrator.');
const put=db.prepare('INSERT INTO portal_users(username,salt,password_hash,enabled,role,version) VALUES(?,?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET salt=excluded.salt,password_hash=excluded.password_hash,enabled=excluded.enabled,role=excluded.role,version=excluded.version');
for(const [n,u]of Object.entries(v))put.run(n,u.salt,u.hash,u.enabled?1:0,u.role,u.version);
db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
async function hash(password){let salt=crypto.randomBytes(16).toString('hex');return {salt,hash:(await derive(password,salt,64,opts)).toString('hex')};}
async function verify(password,u){const out=await derive(password,u?u.salt:'dummy-not-a-real-user',64,opts);const expected=Buffer.from(u?u.hash:'00'.repeat(64),'hex');return expected.length===out.length && crypto.timingSafeEqual(out,expected) && !!u;}
module.exports={users,save,normalize,hash,verify};
