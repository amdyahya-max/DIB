
const state = {
  mode: "department",
  users: [],
  filtered: [],
  sortKey: "name",
  sortDir: 1
};

const $ = id => document.getElementById(id);

function escapeHtml(v) {
  return String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2500);
}

async function api(path) {
  const res = await fetch(path, { cache: "no-store" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function setMode(mode) {
  state.mode = mode;
  document.querySelectorAll(".mode-tab").forEach(b =>
    b.classList.toggle("active", b.dataset.mode === mode)
  );

  $("departmentField").classList.toggle("hidden", mode !== "department");
  $("groupField").classList.toggle("hidden", mode !== "group");
  $("userField").classList.toggle("hidden", mode !== "user");
  $("recursiveField").style.display = mode === "group" ? "block" : "none";
}

async function checkHealth() {
  try {
    const h = await api("/api/health");
    const pill = $("healthPill");
    pill.className = "pill good";
    pill.textContent = `Connected • ${h.user}`;
    pill.title = `Base DN: ${h.baseDN}`;
  } catch (e) {
    const pill = $("healthPill");
    pill.className = "pill bad";
    pill.textContent = "AD connection failed";
    pill.title = e.message;
  }
}

async function loadDepartments(force = false) {
  const select = $("departmentSelect");
  select.innerHTML = `<option value="">${force ? "Refreshing…" : "Loading departments…"}</option>`;

  try {
    const data = await api("/api/departments");
    select.innerHTML = `<option value="">Select a department…</option>` +
      data.items.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join("");
  } catch (e) {
    select.innerHTML = `<option value="">Unable to load departments</option>`;
    toast(e.message);
  }
}

async function searchDirectory() {
  let value = "";

  if (state.mode === "department") value = $("departmentSelect").value;
  if (state.mode === "group") value = $("groupInput").value.trim();
  if (state.mode === "user") value = $("userInput").value.trim();

  if (!value) {
    toast("Enter or select a search value.");
    return;
  }

  const btn = $("searchBtn");
  btn.disabled = true;
  btn.textContent = "Searching…";

  try {
    const recursive = $("recursiveCheckbox").checked;
    const qs = new URLSearchParams({
      mode: state.mode,
      value,
      recursive: String(recursive)
    });

    const data = await api(`/api/users?${qs}`);
    state.users = data.items || [];
    applyFilters();
    toast(`${data.count} user${data.count === 1 ? "" : "s"} found`);
  } catch (e) {
    state.users = [];
    applyFilters();
    toast(e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Search directory";
  }
}

function daysUntil(dateString) {
  if (!dateString) return null;
  const d = new Date(dateString);
  if (Number.isNaN(d.getTime())) return null;
  return Math.ceil((d.getTime() - Date.now()) / 86400000);
}

function applyFilters() {
  const text = $("filterInput").value.trim().toLowerCase();
  const status = $("statusFilter").value;
  const expiry = $("expiryFilter").value;

  state.filtered = state.users.filter(u => {
    if (text) {
      const hay = [
        u.employeeId,u.name,u.username,u.email,u.department,u.title,u.manager,
        u.managerEmail,u.office,u.company
      ].join(" ").toLowerCase();
      if (!hay.includes(text)) return false;
    }

    if (status && u.status !== status) return false;

    const days = daysUntil(u.accountExpiry);
    if (expiry === "expired" && !(days !== null && days < 0)) return false;
    if (expiry === "30" && !(days !== null && days >= 0 && days <= 30)) return false;
    if (expiry === "60" && !(days !== null && days >= 0 && days <= 60)) return false;
    if (expiry === "never" && u.accountExpiry) return false;

    return true;
  });

  renderUsers();
  updateStats();
}

function formatDate(v, includeTime = false) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return escapeHtml(v);
  const opts = includeTime
    ? { year:"numeric", month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit" }
    : { year:"numeric", month:"short", day:"2-digit" };
  return d.toLocaleString(undefined, opts);
}

function expiryDisplay(v) {
  if (!v) return `<span class="badge">Never</span>`;
  const days = daysUntil(v);
  if (days !== null && days < 0) return `<span class="badge Expired">${formatDate(v)}</span>`;
  if (days !== null && days <= 30) return `<span class="badge warning">${formatDate(v)}</span>`;
  return formatDate(v);
}

function renderUsers() {
  const tbody = $("usersTbody");
  const rows = [...state.filtered].sort((a,b) => {
    const av = (a[state.sortKey] ?? "").toString().toLowerCase();
    const bv = (b[state.sortKey] ?? "").toString().toLowerCase();
    return av.localeCompare(bv, undefined, { numeric:true }) * state.sortDir;
  });

  if (!rows.length) {
    tbody.innerHTML = `
      <tr class="empty-row"><td colspan="12">
        <div class="empty-state">
          <strong>No users to display</strong>
          <span>Adjust the search or filters.</span>
        </div>
      </td></tr>`;
  } else {
    tbody.innerHTML = rows.map(u => `
      <tr>
        <td>${escapeHtml(u.employeeId || "—")}</td>
        <td class="wrap"><span class="linkish" data-user="${escapeHtml(u.username)}">${escapeHtml(u.name || "—")}</span></td>
        <td>${escapeHtml(u.username || "—")}</td>
        <td>${escapeHtml(u.email || "—")}</td>
        <td class="wrap">${escapeHtml(u.department || "—")}</td>
        <td class="wrap">${escapeHtml(u.title || "—")}</td>
        <td class="wrap">${escapeHtml(u.manager || "—")}</td>
        <td><span class="badge ${escapeHtml(u.status)}">${escapeHtml(u.status || "—")}</span></td>
        <td>${expiryDisplay(u.accountExpiry)}</td>
        <td>${formatDate(u.passwordExpiry)}</td>
        <td>${formatDate(u.lastLogon, true)}</td>
        <td><button class="detail-btn" data-user="${escapeHtml(u.username)}">Open</button></td>
      </tr>
    `).join("");
  }

  const enabled = state.filtered.length > 0;
  $("csvBtn").disabled = !enabled;
  $("excelBtn").disabled = !enabled;
}

function updateStats() {
  $("userCount").textContent = state.filtered.length;
  $("enabledCount").textContent = state.filtered.filter(x => x.enabled).length;
  $("expiringCount").textContent = state.filtered.filter(x => {
    const d = daysUntil(x.accountExpiry);
    return d !== null && d >= 0 && d <= 30;
  }).length;
}

async function openUser(username) {
  if (!username) return;

  $("drawerBackdrop").classList.remove("hidden");
  $("detailDrawer").classList.remove("hidden");
  $("detailDrawer").setAttribute("aria-hidden", "false");
  $("drawerTitle").textContent = "Loading…";
  $("drawerSub").textContent = username;
  $("drawerBody").innerHTML = `<div class="empty-state">Retrieving user profile from AD…</div>`;

  try {
    const u = await api(`/api/user?username=${encodeURIComponent(username)}`);
    $("drawerTitle").textContent = u.name || u.username;
    $("drawerSub").textContent = `${u.username || ""}${u.email ? " • " + u.email : ""}`;

    const item = (label, value) => `
      <div class="detail-item">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(value || "—")}</strong>
      </div>`;

    $("drawerBody").innerHTML = `
      <div class="detail-section">
        <h4>Identity</h4>
        <div class="detail-grid">
          ${item("Employee ID", u.employeeId)}
          ${item("Username", u.username)}
          ${item("Full name", u.name)}
          ${item("Email", u.email)}
          ${item("UPN", u.upn)}
          ${item("Company", u.company)}
          ${item("Department", u.department)}
          ${item("Title", u.title)}
        </div>
      </div>

      <div class="detail-section">
        <h4>Manager & Contact</h4>
        <div class="detail-grid">
          ${item("Manager", u.manager)}
          ${item("Manager email", u.managerEmail)}
          ${item("Office", u.office)}
          ${item("Telephone", u.telephone)}
          ${item("Mobile", u.mobile)}
          ${item("Home directory", u.homeDirectory)}
        </div>
      </div>

      <div class="detail-section">
        <h4>Account</h4>
        <div class="detail-grid">
          ${item("Status", u.status)}
          ${item("Account expiry", u.accountExpiry ? formatDate(u.accountExpiry) : "Never")}
          ${item("Created", formatDate(u.whenCreated, true))}
          ${item("Last AD change", formatDate(u.whenChanged, true))}
          ${item("Last logon", formatDate(u.lastLogon, true))}
          ${item("Password last set", formatDate(u.passwordLastSet, true))}
          ${item("Password expiry", u.passwordExpiry ? formatDate(u.passwordExpiry, true) : (u.passwordNeverExpires ? "Never" : "Not available"))}
          ${item("Password required", u.passwordRequired ? "Yes" : "No")}
          ${item("Password never expires", u.passwordNeverExpires ? "Yes" : "No")}
        </div>
      </div>

      <div class="detail-section">
        <h4>Directory</h4>
        <div class="detail-grid">
          ${item("Description", u.description)}
          ${item("Comment", u.comment)}
          ${item("Distinguished name", u.distinguishedName)}
        </div>
      </div>

      <div class="detail-section">
        <h4>Direct group memberships (${(u.groups || []).length})</h4>
        <div class="group-chips">
          ${(u.groups || []).length
            ? u.groups.map(g => `<span class="group-chip">${escapeHtml(g)}</span>`).join("")
            : `<span class="muted">No direct groups returned.</span>`}
        </div>
      </div>
    `;
  } catch (e) {
    $("drawerTitle").textContent = "Unable to load user";
    $("drawerBody").innerHTML = `<div class="empty-state">${escapeHtml(e.message)}</div>`;
  }
}

function closeDrawer() {
  $("drawerBackdrop").classList.add("hidden");
  $("detailDrawer").classList.add("hidden");
  $("detailDrawer").setAttribute("aria-hidden", "true");
}

async function findGroups() {
  const q = $("groupLookupInput").value.trim();
  const box = $("groupLookupResults");
  box.innerHTML = `<div class="muted">Searching…</div>`;

  try {
    const data = await api(`/api/groups?query=${encodeURIComponent(q)}`);
    if (!data.items.length) {
      box.innerHTML = `<div class="muted">No groups found.</div>`;
      return;
    }

    box.innerHTML = data.items.slice(0,100).map(g => `
      <div class="group-result">
        <div>
          <strong>${escapeHtml(g.name || g.samAccountName)}</strong>
          <small>${escapeHtml(g.description || g.samAccountName || "")}</small>
        </div>
        <button class="button secondary use-group" data-group="${escapeHtml(g.name || g.samAccountName)}">Use</button>
      </div>
    `).join("");
  } catch (e) {
    box.innerHTML = `<div class="muted">${escapeHtml(e.message)}</div>`;
  }
}

function csvCell(v) {
  const s = String(v ?? "");
  return `"${s.replaceAll('"','""')}"`;
}

function exportCsv() {
  const cols = [
    ["Employee ID","employeeId"],["Name","name"],["Username","username"],["Email","email"],
    ["Department","department"],["Title","title"],["Manager","manager"],["Manager Email","managerEmail"],
    ["Status","status"],["Account Expiry","accountExpiry"],["Password Expiry","passwordExpiry"],["Last Logon","lastLogon"],
    ["Office","office"],["Telephone","telephone"],["Mobile","mobile"]
  ];

  const rows = [
    cols.map(c => csvCell(c[0])).join(","),
    ...state.filtered.map(u => cols.map(c => csvCell(u[c[1]])).join(","))
  ];

  downloadBlob(new Blob(["\uFEFF" + rows.join("\r\n")], {type:"text/csv;charset=utf-8"}), "AD-Users.csv");
}

function exportExcel() {
  const cols = [
    ["Employee ID","employeeId"],["Name","name"],["Username","username"],["Email","email"],
    ["Department","department"],["Title","title"],["Manager","manager"],["Manager Email","managerEmail"],
    ["Status","status"],["Account Expiry","accountExpiry"],["Password Expiry","passwordExpiry"],
    ["Last Logon","lastLogon"],["Office","office"],["Telephone","telephone"],["Mobile","mobile"]
  ];

  const header = cols.map(c => `<th>${escapeHtml(c[0])}</th>`).join("");
  const rows = state.filtered.map(u =>
    `<tr>${cols.map(c => `<td>${escapeHtml(u[c[1]] ?? "")}</td>`).join("")}</tr>`
  ).join("");

  const html = `
    <html><head><meta charset="utf-8"></head><body>
      <table border="1"><thead><tr>${header}</tr></thead><tbody>${rows}</tbody></table>
    </body></html>`;

  downloadBlob(
    new Blob([html], {type:"application/vnd.ms-excel;charset=utf-8"}),
    "AD-Users.xls"
  );
}

function downloadBlob(blob, filename) {
  const a = document.createElement("a");
  const url = URL.createObjectURL(blob);
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

document.querySelectorAll(".mode-tab").forEach(btn =>
  btn.addEventListener("click", () => setMode(btn.dataset.mode))
);

$("searchBtn").addEventListener("click", searchDirectory);
$("refreshLookupsBtn").addEventListener("click", async () => {
  await Promise.all([checkHealth(), loadDepartments(true)]);
  toast("Lookups refreshed");
});
$("filterInput").addEventListener("input", applyFilters);
$("statusFilter").addEventListener("change", applyFilters);
$("expiryFilter").addEventListener("change", applyFilters);
$("groupLookupBtn").addEventListener("click", findGroups);
$("csvBtn").addEventListener("click", exportCsv);
$("excelBtn").addEventListener("click", exportExcel);
$("drawerClose").addEventListener("click", closeDrawer);
$("drawerBackdrop").addEventListener("click", closeDrawer);

$("groupLookupResults").addEventListener("click", e => {
  const b = e.target.closest(".use-group");
  if (!b) return;
  setMode("group");
  $("groupInput").value = b.dataset.group;
  toast("Group selected");
});

$("usersTbody").addEventListener("click", e => {
  const el = e.target.closest("[data-user]");
  if (el) openUser(el.dataset.user);
});

document.querySelector("#usersTable thead").addEventListener("click", e => {
  const th = e.target.closest("th[data-key]");
  if (!th) return;
  const key = th.dataset.key;
  if (state.sortKey === key) state.sortDir *= -1;
  else { state.sortKey = key; state.sortDir = 1; }
  renderUsers();
});

["groupInput","userInput","groupLookupInput"].forEach(id => {
  $(id).addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    if (id === "groupLookupInput") findGroups();
    else searchDirectory();
  });
});

(async function init(){
  setMode("department");
  await Promise.all([checkHealth(), loadDepartments()]);
})();
