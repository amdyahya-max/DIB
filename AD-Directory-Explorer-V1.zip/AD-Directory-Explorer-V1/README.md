# AD Directory Explorer V1

A dependency-free, read-only Windows web application for querying on-premises Active Directory.

## What it does

- Search users by:
  - Department
  - AD Group
  - Individual user (name, username, email, employee ID, UPN)
- Optional nested group membership search
- Shows:
  - Employee ID
  - Username / full name
  - Email / UPN
  - Department / title / company
  - Manager and manager email
  - Office / phone / mobile
  - Enabled / disabled / expired status
  - Account expiry
  - Password last set / password expiry
  - Password required / password never expires
  - Last logon timestamp
  - Account created / last changed
  - Home directory
  - Direct group memberships
- Client-side sorting and filtering
- Export CSV
- Export Excel-compatible `.xls`
- No NPM packages
- No RSAT / ActiveDirectory PowerShell module required
- No database
- Uses the Windows identity that starts the PowerShell process

## Requirements

- Windows PC joined to, or able to query, your Active Directory domain
- Windows PowerShell 5.1 or PowerShell with `System.DirectoryServices`
- Network access to a domain controller
- Directory read permissions for the signed-in Windows user

You already validated the core LDAP approach with:

```powershell
New-Object System.DirectoryServices.DirectorySearcher
```

## Start

1. Extract the folder.
2. Open Windows PowerShell.
3. Change to the extracted folder:

```powershell
cd "C:\Path\To\AD-Directory-Explorer-V1"
```

4. Start:

```powershell
.\Start-ADExplorer.ps1
```

If your execution policy blocks scripts, run this only for the current PowerShell process:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\Start-ADExplorer.ps1
```

5. The browser should open:

```text
http://localhost:8085
```

To use a different port:

```powershell
.\Start-ADExplorer.ps1 -Port 8090
```

To prevent automatic browser launch:

```powershell
.\Start-ADExplorer.ps1 -NoBrowser
```

Stop with `Ctrl+C`.

## Security

This V1 is intentionally bound only to:

```text
127.0.0.1 / localhost
```

It is not remotely accessible from other PCs.

The application performs read-only LDAP searches. It does not store AD credentials and does not expose an arbitrary LDAP query endpoint.

## Notes on AD fields

### Account expiry
`accountExpires` is converted from Windows FILETIME. AD's "never expires" special values are displayed as `Never`.

### Password expiry
The app requests:

```text
msDS-UserPasswordExpiryTimeComputed
```

This is preferable to guessing the password expiry from `pwdLastSet`. If your AD does not expose that computed property, the UI displays `Not available` unless the account is configured as password-never-expires.

### Last logon
The app uses `lastLogonTimestamp`, which is replicated and suitable for general directory reporting, but it is not guaranteed to be the exact latest interactive logon across all domain controllers.

### Group membership
The user detail panel shows the direct `memberOf` groups. Group search can use Active Directory's recursive matching rule to include nested members.

## Files

- `Start-ADExplorer.ps1` — AD query logic + local HTTP server
- `www/index.html` — portal page
- `www/styles.css` — UI design
- `www/app.js` — browser logic