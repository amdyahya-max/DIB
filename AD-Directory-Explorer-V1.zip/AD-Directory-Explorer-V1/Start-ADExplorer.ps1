param(
    [int]$Port = 8085,
    [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.DirectoryServices

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$WebRoot = Join-Path $ScriptRoot "www"

# ----------------------------
# Utility / LDAP helper methods
# ----------------------------

function Escape-LdapFilterValue {
    param([AllowNull()][string]$Value)

    if ($null -eq $Value) { return "" }

    # RFC 4515 escaping for LDAP filter values.
    $sb = New-Object System.Text.StringBuilder
    foreach ($c in $Value.ToCharArray()) {
        switch ([int][char]$c) {
            0  { [void]$sb.Append("\00") }
            40 { [void]$sb.Append("\28") } # (
            41 { [void]$sb.Append("\29") } # )
            42 { [void]$sb.Append("\2a") } # *
            92 { [void]$sb.Append("\5c") } # \
            default { [void]$sb.Append($c) }
        }
    }
    return $sb.ToString()
}

function Get-DefaultNamingContext {
    $rootDse = New-Object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
    try {
        $value = [string]$rootDse.Properties["defaultNamingContext"].Value
        if ([string]::IsNullOrWhiteSpace($value)) {
            throw "Active Directory defaultNamingContext was empty."
        }
        return $value
    }
    finally {
        $rootDse.Dispose()
    }
}

$BaseDN = Get-DefaultNamingContext
$DirectoryRoot = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$BaseDN")

$ManagerCache = @{}

$CommonProperties = @(
    "samaccountname",
    "displayname",
    "mail",
    "userprincipalname",
    "employeeid",
    "employeenumber",
    "department",
    "title",
    "company",
    "manager",
    "physicaldeliveryofficename",
    "telephonenumber",
    "mobile",
    "useraccountcontrol",
    "accountexpires",
    "pwdlastset",
    "lastlogontimestamp",
    "whencreated",
    "whenchanged",
    "distinguishedname",
    "memberof",
    "homedirectory",
    "description",
    "comment",
    "msds-userpasswordexpirytimecomputed"
)

function New-DirectorySearcher {
    param(
        [string]$Filter,
        [string[]]$Properties = $CommonProperties,
        [int]$PageSize = 1000
    )

    $searcher = New-Object System.DirectoryServices.DirectorySearcher($DirectoryRoot)
    $searcher.Filter = $Filter
    $searcher.PageSize = $PageSize
    $searcher.SearchScope = [System.DirectoryServices.SearchScope]::Subtree

    foreach ($p in $Properties) {
        [void]$searcher.PropertiesToLoad.Add($p)
    }

    return $searcher
}

function Get-Prop {
    param(
        $Properties,
        [string]$Name
    )

    if ($null -eq $Properties) { return $null }

    try {
        if ($Properties.Contains($Name) -and
            $null -ne $Properties[$Name] -and
            $Properties[$Name].Count -gt 0) {
            return $Properties[$Name][0]
        }
    }
    catch {}

    return $null
}

function Get-StringProp {
    param($Properties, [string]$Name)
    $value = Get-Prop $Properties $Name
    if ($null -eq $value) { return "" }
    return [string]$value
}

function Convert-FileTimeToIso {
    param($Value)

    if ($null -eq $Value) { return $null }

    try {
        $n = [Int64]$Value
        if ($n -eq 0 -or $n -eq 9223372036854775807) {
            return $null
        }
        return [DateTime]::FromFileTimeUtc($n).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss")
    }
    catch {
        return $null
    }
}

function Convert-DateValueToIso {
    param($Value)
    if ($null -eq $Value) { return $null }
    try {
        return ([DateTime]$Value).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss")
    }
    catch {
        try { return ([DateTime]$Value).ToString("yyyy-MM-ddTHH:mm:ss") } catch { return $null }
    }
}

function Get-CnFromDn {
    param([string]$Dn)
    if ([string]::IsNullOrWhiteSpace($Dn)) { return "" }

    # Friendly fallback only; manager/group detail resolution uses LDAP when needed.
    if ($Dn -match '^CN=((?:\\.|[^,])+)') {
        return ($Matches[1] -replace '\\,', ',' -replace '\\\\', '\')
    }
    return $Dn
}

function Resolve-Manager {
    param([string]$ManagerDN)

    if ([string]::IsNullOrWhiteSpace($ManagerDN)) {
        return [PSCustomObject]@{ name = ""; email = ""; username = "" }
    }

    if ($ManagerCache.ContainsKey($ManagerDN)) {
        return $ManagerCache[$ManagerDN]
    }

    $escaped = Escape-LdapFilterValue $ManagerDN
    $searcher = New-DirectorySearcher `
        -Filter "(&(objectCategory=person)(objectClass=user)(distinguishedName=$escaped))" `
        -Properties @("displayname", "mail", "samaccountname")

    try {
        $r = $searcher.FindOne()
        if ($null -ne $r) {
            $m = [PSCustomObject]@{
                name     = Get-StringProp $r.Properties "displayname"
                email    = Get-StringProp $r.Properties "mail"
                username = Get-StringProp $r.Properties "samaccountname"
            }
            $ManagerCache[$ManagerDN] = $m
            return $m
        }
    }
    catch {}
    finally {
        $searcher.Dispose()
    }

    $fallback = [PSCustomObject]@{
        name     = Get-CnFromDn $ManagerDN
        email    = ""
        username = ""
    }
    $ManagerCache[$ManagerDN] = $fallback
    return $fallback
}

function Convert-SearchResultToUser {
    param(
        $Result,
        [switch]$Detailed
    )

    $p = $Result.Properties

    $uac = 0
    $uacRaw = Get-Prop $p "useraccountcontrol"
    if ($null -ne $uacRaw) {
        try { $uac = [int]$uacRaw } catch { $uac = 0 }
    }

    $enabled = (($uac -band 2) -eq 0)
    $passwordRequired = (($uac -band 0x20) -eq 0)
    $passwordNeverExpires = (($uac -band 0x10000) -ne 0)

    $accountExpiryRaw = Get-Prop $p "accountexpires"
    $accountExpiry = Convert-FileTimeToIso $accountExpiryRaw

    $pwdLastSet = Convert-FileTimeToIso (Get-Prop $p "pwdlastset")
    $pwdExpiry = Convert-FileTimeToIso (Get-Prop $p "msds-userpasswordexpirytimecomputed")
    $lastLogon = Convert-FileTimeToIso (Get-Prop $p "lastlogontimestamp")

    $managerDN = Get-StringProp $p "manager"
    $manager = Resolve-Manager $managerDN

    $status = if ($enabled) { "Enabled" } else { "Disabled" }

    if ($enabled -and $accountExpiry) {
        try {
            if ([DateTime]$accountExpiry -lt (Get-Date)) {
                $status = "Expired"
            }
        }
        catch {}
    }

    $groups = @()
    if ($Detailed -and $p.Contains("memberof")) {
        foreach ($g in $p["memberof"]) {
            $groups += Get-CnFromDn ([string]$g)
        }
        $groups = @($groups | Sort-Object -Unique)
    }

    [PSCustomObject]@{
        username             = Get-StringProp $p "samaccountname"
        name                 = Get-StringProp $p "displayname"
        email                = Get-StringProp $p "mail"
        upn                  = Get-StringProp $p "userprincipalname"
        employeeId           = Get-StringProp $p "employeeid"
        employeeNumber       = Get-StringProp $p "employeenumber"
        department           = Get-StringProp $p "department"
        title                = Get-StringProp $p "title"
        company              = Get-StringProp $p "company"
        manager              = $manager.name
        managerEmail         = $manager.email
        managerUsername      = $manager.username
        office               = Get-StringProp $p "physicaldeliveryofficename"
        telephone            = Get-StringProp $p "telephonenumber"
        mobile               = Get-StringProp $p "mobile"
        status               = $status
        enabled              = $enabled
        accountExpiry        = $accountExpiry
        passwordLastSet      = $pwdLastSet
        passwordExpiry       = $pwdExpiry
        passwordRequired     = $passwordRequired
        passwordNeverExpires = $passwordNeverExpires
        lastLogon            = $lastLogon
        whenCreated          = Convert-DateValueToIso (Get-Prop $p "whencreated")
        whenChanged          = Convert-DateValueToIso (Get-Prop $p "whenchanged")
        homeDirectory        = Get-StringProp $p "homedirectory"
        description          = Get-StringProp $p "description"
        comment              = Get-StringProp $p "comment"
        distinguishedName    = Get-StringProp $p "distinguishedname"
        groups               = $groups
    }
}

function Find-GroupByName {
    param([string]$Name)

    $escaped = Escape-LdapFilterValue $Name

    # Try common exact identifiers first.
    $filter = "(&(objectCategory=group)(|(cn=$escaped)(samAccountName=$escaped)(name=$escaped)))"
    $searcher = New-DirectorySearcher -Filter $filter -Properties @("cn","name","samaccountname","distinguishedname")

    try {
        return $searcher.FindOne()
    }
    finally {
        $searcher.Dispose()
    }
}

function Get-Departments {
    $searcher = New-DirectorySearcher `
        -Filter "(&(objectCategory=person)(objectClass=user)(department=*))" `
        -Properties @("department")

    try {
        $set = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        $results = $searcher.FindAll()

        foreach ($r in $results) {
            $d = Get-StringProp $r.Properties "department"
            if (-not [string]::IsNullOrWhiteSpace($d)) {
                [void]$set.Add($d.Trim())
            }
        }

        return @($set | Sort-Object)
    }
    finally {
        $searcher.Dispose()
    }
}

function Search-Groups {
    param([string]$Query)

    $q = Escape-LdapFilterValue $Query

    if ([string]::IsNullOrWhiteSpace($Query)) {
        $filter = "(objectCategory=group)"
    }
    else {
        $filter = "(&(objectCategory=group)(|(cn=*$q*)(name=*$q*)(samAccountName=*$q*)))"
    }

    $searcher = New-DirectorySearcher `
        -Filter $filter `
        -Properties @("cn","name","samaccountname","distinguishedname","description")

    $searcher.SizeLimit = 200

    try {
        $output = @()
        foreach ($r in $searcher.FindAll()) {
            $output += [PSCustomObject]@{
                name              = Get-StringProp $r.Properties "name"
                samAccountName    = Get-StringProp $r.Properties "samaccountname"
                description       = Get-StringProp $r.Properties "description"
                distinguishedName = Get-StringProp $r.Properties "distinguishedname"
            }
        }
        return @($output | Sort-Object name)
    }
    finally {
        $searcher.Dispose()
    }
}

function Search-Users {
    param(
        [string]$Mode,
        [string]$Value,
        [bool]$Recursive = $true
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        throw "A search value is required."
    }

    $escaped = Escape-LdapFilterValue $Value
    $filter = ""

    switch ($Mode.ToLowerInvariant()) {
        "department" {
            $filter = "(&(objectCategory=person)(objectClass=user)(department=$escaped))"
        }

        "group" {
            $group = Find-GroupByName $Value
            if ($null -eq $group) {
                throw "AD group '$Value' was not found."
            }

            $groupDN = Get-StringProp $group.Properties "distinguishedname"
            $escapedGroupDN = Escape-LdapFilterValue $groupDN

            if ($Recursive) {
                # LDAP_MATCHING_RULE_IN_CHAIN - nested group membership
                $filter = "(&(objectCategory=person)(objectClass=user)(memberOf:1.2.840.113556.1.4.1941:=$escapedGroupDN))"
            }
            else {
                $filter = "(&(objectCategory=person)(objectClass=user)(memberOf=$escapedGroupDN))"
            }
        }

        "user" {
            $filter = "(&(objectCategory=person)(objectClass=user)(|(samAccountName=*$escaped*)(displayName=*$escaped*)(mail=*$escaped*)(employeeID=*$escaped*)(userPrincipalName=*$escaped*)))"
        }

        default {
            throw "Unsupported search mode '$Mode'."
        }
    }

    $searcher = New-DirectorySearcher -Filter $filter
    try {
        $users = @()
        foreach ($r in $searcher.FindAll()) {
            $users += Convert-SearchResultToUser $r
        }

        return @($users | Sort-Object name)
    }
    finally {
        $searcher.Dispose()
    }
}

function Get-UserDetail {
    param([string]$Username)

    if ([string]::IsNullOrWhiteSpace($Username)) {
        throw "Username is required."
    }

    $escaped = Escape-LdapFilterValue $Username
    $filter = "(&(objectCategory=person)(objectClass=user)(|(samAccountName=$escaped)(userPrincipalName=$escaped)))"

    $searcher = New-DirectorySearcher -Filter $filter

    try {
        $r = $searcher.FindOne()
        if ($null -eq $r) {
            return $null
        }
        return Convert-SearchResultToUser $r -Detailed
    }
    finally {
        $searcher.Dispose()
    }
}

# ----------------------------
# Minimal local HTTP server
# No IIS / NPM / URLACL needed.
# ----------------------------

function Get-ContentType {
    param([string]$Path)

    switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        ".html" { return "text/html; charset=utf-8" }
        ".css"  { return "text/css; charset=utf-8" }
        ".js"   { return "application/javascript; charset=utf-8" }
        ".json" { return "application/json; charset=utf-8" }
        ".svg"  { return "image/svg+xml" }
        ".png"  { return "image/png" }
        ".ico"  { return "image/x-icon" }
        default { return "application/octet-stream" }
    }
}

function Send-Response {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$StatusCode,
        [string]$StatusText,
        [byte[]]$Body,
        [string]$ContentType = "text/plain; charset=utf-8"
    )

    $header = "HTTP/1.1 $StatusCode $StatusText`r`n" +
              "Content-Type: $ContentType`r`n" +
              "Content-Length: $($Body.Length)`r`n" +
              "Cache-Control: no-store`r`n" +
              "Connection: close`r`n`r`n"

    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($Body.Length -gt 0) {
        $Stream.Write($Body, 0, $Body.Length)
    }
    $Stream.Flush()
}

function Send-Json {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        $Data,
        [int]$StatusCode = 200,
        [string]$StatusText = "OK"
    )

    $json = $Data | ConvertTo-Json -Depth 8 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    Send-Response $Stream $StatusCode $StatusText $bytes "application/json; charset=utf-8"
}

function Parse-QueryString {
    param([string]$Query)

    $map = @{}
    if ([string]::IsNullOrWhiteSpace($Query)) { return $map }

    foreach ($part in $Query.TrimStart("?").Split("&")) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $pair = $part.Split("=", 2)
        $key = [System.Uri]::UnescapeDataString(($pair[0] -replace '\+', ' '))
        $value = ""
        if ($pair.Length -gt 1) {
            $value = [System.Uri]::UnescapeDataString(($pair[1] -replace '\+', ' '))
        }
        $map[$key] = $value
    }

    return $map
}

function Handle-Request {
    param([System.Net.Sockets.TcpClient]$Client)

    $stream = $Client.GetStream()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)

    try {
        $requestLine = $reader.ReadLine()
        if ([string]::IsNullOrWhiteSpace($requestLine)) { return }

        # Consume headers.
        while ($true) {
            $line = $reader.ReadLine()
            if ($null -eq $line -or $line -eq "") { break }
        }

        $parts = $requestLine.Split(" ")
        if ($parts.Length -lt 2) {
            $bytes = [Text.Encoding]::UTF8.GetBytes("Bad request")
            Send-Response $stream 400 "Bad Request" $bytes
            return
        }

        $method = $parts[0]
        $rawTarget = $parts[1]

        if ($method -ne "GET") {
            $bytes = [Text.Encoding]::UTF8.GetBytes("Only GET is supported.")
            Send-Response $stream 405 "Method Not Allowed" $bytes
            return
        }

        $uri = New-Object System.Uri("http://localhost$rawTarget")
        $path = $uri.AbsolutePath
        $query = Parse-QueryString $uri.Query

        try {
            if ($path -eq "/api/health") {
                Send-Json $stream ([PSCustomObject]@{
                    ok = $true
                    baseDN = $BaseDN
                    machine = $env:COMPUTERNAME
                    user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                    timestamp = (Get-Date).ToString("s")
                })
                return
            }

            if ($path -eq "/api/departments") {
                Send-Json $stream ([PSCustomObject]@{
                    items = @(Get-Departments)
                })
                return
            }

            if ($path -eq "/api/groups") {
                $q = if ($query.ContainsKey("query")) { [string]$query["query"] } else { "" }
                Send-Json $stream ([PSCustomObject]@{
                    items = @(Search-Groups $q)
                })
                return
            }

            if ($path -eq "/api/users") {
                $mode = if ($query.ContainsKey("mode")) { [string]$query["mode"] } else { "" }
                $value = if ($query.ContainsKey("value")) { [string]$query["value"] } else { "" }

                $recursive = $true
                if ($query.ContainsKey("recursive")) {
                    $recursive = ([string]$query["recursive"]).ToLowerInvariant() -ne "false"
                }

                $users = @(Search-Users -Mode $mode -Value $value -Recursive $recursive)

                Send-Json $stream ([PSCustomObject]@{
                    count = $users.Count
                    items = $users
                })
                return
            }

            if ($path -eq "/api/user") {
                $username = if ($query.ContainsKey("username")) { [string]$query["username"] } else { "" }
                $user = Get-UserDetail $username
                if ($null -eq $user) {
                    Send-Json $stream ([PSCustomObject]@{ error = "User not found." }) 404 "Not Found"
                }
                else {
                    Send-Json $stream $user
                }
                return
            }

            # Static files
            $relative = $path.TrimStart("/")
            if ([string]::IsNullOrWhiteSpace($relative)) {
                $relative = "index.html"
            }

            # Prevent traversal.
            $candidate = [System.IO.Path]::GetFullPath((Join-Path $WebRoot $relative))
            $webRootFull = [System.IO.Path]::GetFullPath($WebRoot)

            if (-not $candidate.StartsWith($webRootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                $bytes = [Text.Encoding]::UTF8.GetBytes("Forbidden")
                Send-Response $stream 403 "Forbidden" $bytes
                return
            }

            if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
                $bytes = [Text.Encoding]::UTF8.GetBytes("Not found")
                Send-Response $stream 404 "Not Found" $bytes
                return
            }

            $fileBytes = [System.IO.File]::ReadAllBytes($candidate)
            Send-Response $stream 200 "OK" $fileBytes (Get-ContentType $candidate)
        }
        catch {
            $message = $_.Exception.Message
            Send-Json $stream ([PSCustomObject]@{
                error = $message
            }) 500 "Internal Server Error"
        }
    }
    finally {
        $reader.Dispose()
        $stream.Dispose()
        $Client.Close()
    }
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)

try {
    $listener.Start()

    Write-Host ""
    Write-Host "AD Directory Explorer V1" -ForegroundColor Cyan
    Write-Host "------------------------" -ForegroundColor DarkGray
    Write-Host "Active Directory Base DN : $BaseDN"
    Write-Host "Running as               : $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
    Write-Host "URL                      : http://localhost:$Port/"
    Write-Host ""
    Write-Host "Press Ctrl+C to stop." -ForegroundColor Yellow
    Write-Host ""

    if (-not $NoBrowser) {
        try {
            Start-Process "http://localhost:$Port/"
        }
        catch {}
    }

    while ($true) {
        $client = $listener.AcceptTcpClient()
        Handle-Request $client
    }
}
finally {
    $listener.Stop()
    $DirectoryRoot.Dispose()
}