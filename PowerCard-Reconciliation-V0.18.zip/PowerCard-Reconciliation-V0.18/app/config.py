import json
import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT_DIR / "config"
QUERY_DIR = Path(__file__).resolve().parent / "queries"
ENV_FILE = ROOT_DIR / ".env"

# Load project-root .env automatically. Existing Windows/system environment
# variables take precedence over values in .env.
load_dotenv(dotenv_path=ENV_FILE, override=False)




def app_base_path() -> str:
    """Browser-visible application base path when published behind a reverse proxy.

    Examples:
      empty or / -> application is published at site root
      /PowerCard -> application is published below Default Web Site at /PowerCard
    """
    raw = os.getenv("APP_BASE_PATH", "").strip()
    if not raw or raw == "/":
        return ""
    if not raw.startswith("/"):
        raw = "/" + raw
    return raw.rstrip("/")


def public_base_path() -> str:
    """Browser-visible prefix when IIS publishes this app below a site path.

    Example: /PwdRecon.  This prefix is used only for browser redirects and
    cookie scope.  IIS may strip it before forwarding requests to FastAPI, so
    backend routes remain rooted at /.
    """
    raw = os.getenv("PUBLIC_BASE_PATH", "").strip()
    if not raw or raw == "/":
        return ""
    if not raw.startswith("/"):
        raw = "/" + raw
    return raw.rstrip("/")


def auth_db_type() -> str:
    value = os.getenv("AUTH_DB_TYPE", "sqlite").strip().lower()
    if value != "sqlite":
        raise RuntimeError("AUTH_DB_TYPE currently supports only 'sqlite'.")
    return value

def data_source() -> str:
    return os.getenv("DATA_SOURCE", "sqlite").strip().lower()


def oracle_mode() -> str:
    mode = os.getenv("ORACLE_MODE", "thin").strip().lower()
    if mode not in {"thin", "thick"}:
        raise RuntimeError("ORACLE_MODE must be either 'thin' or 'thick'.")
    return mode


def oracle_client_lib_dir() -> str:
    return os.getenv("ORACLE_CLIENT_LIB_DIR", "").strip()


def tns_admin() -> str:
    return os.getenv("TNS_ADMIN", "").strip()


@lru_cache(maxsize=1)
def database_config():
    with (CONFIG_DIR / "databases.json").open("r", encoding="utf-8") as f:
        return json.load(f)


def oracle_setting(environment: str, version: str):
    env_cfg = database_config()[environment.upper()]
    cfg = env_cfg[version.lower()]
    username = os.getenv(cfg["username_env"])
    password = os.getenv(cfg["password_env"])
    if not username or not password:
        missing = [
            name for name, value in (
                (cfg["username_env"], username),
                (cfg["password_env"], password),
            ) if not value
        ]
        raise RuntimeError("Missing Oracle environment variable(s): " + ", ".join(missing))
    return {"dsn": cfg["dsn_alias"], "username": username, "password": password}


def load_query(filename: str) -> str:
    return (QUERY_DIR / filename).read_text(encoding="utf-8").strip()


def oracle_batch_size() -> int:
    try:
        return max(1, min(int(os.getenv("ORACLE_V3_BATCH_SIZE", "500")), 900))
    except ValueError:
        return 500
