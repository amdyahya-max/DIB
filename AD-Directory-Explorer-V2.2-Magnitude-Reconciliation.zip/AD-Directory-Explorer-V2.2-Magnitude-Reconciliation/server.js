
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8085);
const HOST = '127.0.0.1';
const ROOT = __dirname;
const WWW = path.join(ROOT, 'www');
const DATA = path.join(ROOT, 'data');
const MAG_XLSX = path.join(DATA, 'MagnitudeUsers.xlsx');
const MAG_CSV = path.join(DATA, 'MagnitudeUsers.csv');

let magnitudeCache = {
  loaded: false,
  source: '',
  sourcePath: '',
  lastLoaded: null,
  rows: [],
  indexes: { username:new Map(), email:new Map(), employeeId:new Map(), name:new Map() },
  error: ''
};

function psQuote(s) {
  return "'" + String(s ?? '').replace(/'/g, "''") + "'";
}
function normalize(v) { return String(v ?? '').trim().toLowerCase(); }

function parseCsvLine(line) {
  const out = []; let cur = '', q = false;
  for (let i=0; i<line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (q && line[i+1] === '"') { cur += '"'; i++; } else q = !q;
    } else if (ch === ',' && !q) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur); return out;
}
function buildMagnitudeIndexes(rows, source, sourcePath) {
  const indexes = { username:new Map(), email:new Map(), employeeId:new Map(), name:new Map() };
  for (const raw of rows) {
    const row = {
      username:String(raw.username ?? raw['Username'] ?? '').trim(),
      email:String(raw.email ?? raw['Email ID'] ?? raw['Email'] ?? '').trim(),
      name:String(raw.name ?? raw['Name'] ?? '').trim(),
      employeeId:String(raw.employeeId ?? raw['Employee ID'] ?? '').trim()
    };
    if (!row.username && !row.email && !row.name && !row.employeeId) continue;
    if (normalize(row.username)) indexes.username.set(normalize(row.username), row);
    if (normalize(row.email)) indexes.email.set(normalize(row.email), row);
    if (normalize(row.employeeId)) indexes.employeeId.set(normalize(row.employeeId), row);
    if (normalize(row.name)) indexes.name.set(normalize(row.name), row);
  }
  magnitudeCache = { loaded:true, source, sourcePath, lastLoaded:new Date().toISOString(), rows, indexes, error:'' };
  return magnitudeCache;
}
function loadMagnitudeCsv() {
  if (!fs.existsSync(MAG_CSV)) throw new Error('MagnitudeUsers.csv not found.');
  const text = fs.readFileSync(MAG_CSV,'utf8').replace(/^\uFEFF/,'');
  const lines = text.split(/\r?\n/).filter(x=>x.trim());
  if (!lines.length) return buildMagnitudeIndexes([], 'CSV', MAG_CSV);
  const headers = parseCsvLine(lines[0]).map(x=>x.trim());
  const rows = lines.slice(1).map(line => {
    const vals = parseCsvLine(line); const obj = {};
    headers.forEach((h,i)=>obj[h]=vals[i]??''); return obj;
  });
  return buildMagnitudeIndexes(rows,'CSV',MAG_CSV);
}
function runPS(script) {
  return new Promise((resolve,reject)=>{
    execFile('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],
      {windowsHide:true,maxBuffer:30*1024*1024,cwd:ROOT},
      (err,stdout,stderr)=>{
        if(err){reject(new Error((stderr||err.message||'PowerShell failed').trim()));return;}
        resolve(stdout.trim());
      });
  });
}
async function loadMagnitudeXlsx() {
  if (!fs.existsSync(MAG_XLSX)) throw new Error('MagnitudeUsers.xlsx not found.');
  const ps = `
$ErrorActionPreference="Stop"
$path=${psQuote(MAG_XLSX)}
$excel=$null
$wb=$null
$ws=$null
$rows=@()
try {
  $excel=New-Object -ComObject Excel.Application
  $excel.Visible=$false
  $excel.DisplayAlerts=$false
  $wb=$excel.Workbooks.Open($path,$null,$true)
  $ws=$wb.Worksheets.Item("Magnitude Users")
  $used=$ws.UsedRange
  $headerRow=0
  for($r=1;$r -le [Math]::Min($used.Rows.Count,15);$r++){
    $v=[string]$ws.Cells.Item($r,1).Text
    if($v.Trim().ToLower() -eq "username"){$headerRow=$r;break}
  }
  if($headerRow -eq 0){throw "Could not find the Username header in Magnitude Users sheet."}
  $lastRow=$used.Rows.Count
  for($r=$headerRow+1;$r -le $lastRow;$r++){
    $username=[string]$ws.Cells.Item($r,1).Text
    $email=[string]$ws.Cells.Item($r,2).Text
    $name=[string]$ws.Cells.Item($r,3).Text
    $employeeId=[string]$ws.Cells.Item($r,4).Text
    if([string]::IsNullOrWhiteSpace($username) -and [string]::IsNullOrWhiteSpace($email) -and [string]::IsNullOrWhiteSpace($name) -and [string]::IsNullOrWhiteSpace($employeeId)){continue}
    $rows += [PSCustomObject]@{username=$username.Trim();email=$email.Trim();name=$name.Trim();employeeId=$employeeId.Trim()}
  }
  $rows | ConvertTo-Json -Depth 4 -Compress
}
finally {
  if($wb){$wb.Close($false)|Out-Null}
  if($excel){$excel.Quit()}
  if($ws){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($ws)}
  if($wb){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($wb)}
  if($excel){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)}
  [GC]::Collect();[GC]::WaitForPendingFinalizers()
}`;
  const out = await runPS(ps);
  let rows = [];
  if(out){const parsed=JSON.parse(out);rows=Array.isArray(parsed)?parsed:[parsed];}
  return buildMagnitudeIndexes(rows,'Excel',MAG_XLSX);
}
async function refreshMagnitude() {
  try {
    if(fs.existsSync(MAG_XLSX)){
      try{return await loadMagnitudeXlsx();}
      catch(xlsxErr){
        if(fs.existsSync(MAG_CSV)){const c=loadMagnitudeCsv();c.error=`Excel read failed; CSV fallback loaded. ${xlsxErr.message}`;return c;}
        throw xlsxErr;
      }
    }
    return loadMagnitudeCsv();
  } catch(e) {
    magnitudeCache={loaded:false,source:'',sourcePath:'',lastLoaded:new Date().toISOString(),rows:[],indexes:{username:new Map(),email:new Map(),employeeId:new Map(),name:new Map()},error:e.message};
    return magnitudeCache;
  }
}
function magnitudeStatusPayload() {
  return {loaded:magnitudeCache.loaded,source:magnitudeCache.source,sourceFile:magnitudeCache.sourcePath?path.basename(magnitudeCache.sourcePath):'',lastLoaded:magnitudeCache.lastLoaded,records:magnitudeCache.rows.length,error:magnitudeCache.error};
}
function tagMagnitudeUser(user) {
  const i=magnitudeCache.indexes; let match=null, matchedBy='';
  const username=normalize(user.username),email=normalize(user.email),employeeId=normalize(user.employeeId),name=normalize(user.name);
  if(username&&i.username.has(username)){match=i.username.get(username);matchedBy='Username';}
  else if(email&&i.email.has(email)){match=i.email.get(email);matchedBy='Email ID';}
  else if(employeeId&&i.employeeId.has(employeeId)){match=i.employeeId.get(employeeId);matchedBy='Employee ID';}
  else if(name&&i.name.has(name)){match=i.name.get(name);matchedBy='Name';}
  user.magnitudeUser=match?'Yes':'N/A';
  user.magnitudeMatchedBy=matchedBy;
  user.magnitudeReferenceUsername=match?match.username:'';
  user.magnitudeReferenceEmail=match?match.email:'';
  user.magnitudeReferenceEmployeeId=match?match.employeeId:'';
  return user;
}

function escapeLdapFilterValueJs(value) {
  return String(value ?? '')
    .replace(/\\/g, '\\5c')
    .replace(/\*/g, '\\2a')
    .replace(/\(/g, '\\28')
    .replace(/\)/g, '\\29')
    .replace(/\x00/g, '\\00');
}

async function getMagnitudeUnmatchedUsers() {
  const refs = magnitudeCache.rows || [];

  if (!refs.length) {
    return {
      checked: 0,
      matched: 0,
      unmatchedCount: 0,
      unmatched: [],
      checkedAt: new Date().toISOString(),
      source: magnitudeStatusPayload()
    };
  }

  /*
    Compare the Magnitude reference against AD in batches.
    Batching keeps LDAP filters to a reasonable size even when
    the reference file contains hundreds of users.
  */
  const BATCH_SIZE = 25;

  const adUsername = new Set();
  const adEmail = new Set();
  const adEmployeeId = new Set();
  const adName = new Set();

  for (let start = 0; start < refs.length; start += BATCH_SIZE) {
    const batch = refs.slice(start, start + BATCH_SIZE);
    const clauses = [];

    for (const r of batch) {
      if (r.username) {
        clauses.push(`(samAccountName=${escapeLdapFilterValueJs(r.username)})`);
      }

      if (r.email) {
        clauses.push(`(mail=${escapeLdapFilterValueJs(r.email)})`);
      }

      if (r.employeeId) {
        const id = escapeLdapFilterValueJs(r.employeeId);
        clauses.push(`(employeeID=${id})`);
        clauses.push(`(description=${id})`);
        clauses.push(`(comment=${id})`);
        clauses.push(`(employeeNumber=${id})`);
      }

      if (r.name) {
        clauses.push(`(displayName=${escapeLdapFilterValueJs(r.name)})`);
      }
    }

    if (!clauses.length) continue;

    const ldapFilter =
      `(&(objectCategory=person)(objectClass=user)(|${clauses.join('')}))`;

    const ps = commonPs + `
$filter=${psQuote(ldapFilter)}
$props=@(
  "samaccountname",
  "mail",
  "employeeid",
  "description",
  "comment",
  "employeenumber",
  "displayname"
)
$s=Searcher $filter $props
$o=@()
try {
  foreach($r in $s.FindAll()) {
    $p=$r.Properties

    $emp=""
    $empId=SProp $p "employeeid"
    $desc=SProp $p "description"
    $comment=SProp $p "comment"
    $empNo=SProp $p "employeenumber"

    if(-not [string]::IsNullOrWhiteSpace($empId)) {
      $emp=$empId
    }
    elseif(-not [string]::IsNullOrWhiteSpace($desc)) {
      $emp=$desc
    }
    elseif(-not [string]::IsNullOrWhiteSpace($comment)) {
      $emp=$comment
    }
    elseif(-not [string]::IsNullOrWhiteSpace($empNo)) {
      $emp=$empNo
    }

    $o += [PSCustomObject]@{
      username=SProp $p "samaccountname"
      email=SProp $p "mail"
      employeeId=$emp
      name=SProp $p "displayname"
    }
  }

  $o | ConvertTo-Json -Depth 4 -Compress
}
finally {
  $s.Dispose()
  $root.Dispose()
}
`;

    const psOutput = await runPS(ps);

    if (psOutput) {
      const parsed = JSON.parse(psOutput);
      const users = Array.isArray(parsed) ? parsed : [parsed];

      for (const u of users) {
        const username = normalize(u.username);
        const email = normalize(u.email);
        const employeeId = normalize(u.employeeId);
        const name = normalize(u.name);

        if (username) adUsername.add(username);
        if (email) adEmail.add(email);
        if (employeeId) adEmployeeId.add(employeeId);
        if (name) adName.add(name);
      }
    }
  }

  const unmatched = [];
  let matched = 0;

  for (const r of refs) {
    const username = normalize(r.username);
    const email = normalize(r.email);
    const employeeId = normalize(r.employeeId);
    const name = normalize(r.name);

    const found =
      (username && adUsername.has(username)) ||
      (email && adEmail.has(email)) ||
      (employeeId && adEmployeeId.has(employeeId)) ||
      (name && adName.has(name));

    if (found) {
      matched++;
    } else {
      unmatched.push({
        username: r.username || '',
        email: r.email || '',
        name: r.name || '',
        employeeId: r.employeeId || ''
      });
    }
  }

  return {
    checked: refs.length,
    matched,
    unmatchedCount: unmatched.length,
    unmatched,
    checkedAt: new Date().toISOString(),
    source: magnitudeStatusPayload()
  };
}

function sendJson(res,obj,code=200){const body=Buffer.from(JSON.stringify(obj));res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Content-Length':body.length,'Cache-Control':'no-store'});res.end(body);}
function sendText(res,text,code=200,type='text/plain; charset=utf-8'){const body=Buffer.from(text);res.writeHead(code,{'Content-Type':type,'Content-Length':body.length});res.end(body);}
function contentType(file){return{'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'}[path.extname(file).toLowerCase()]||'application/octet-stream';}

const commonPs = String.raw`
Add-Type -AssemblyName System.DirectoryServices
function Esc([string]$s){if($null -eq $s){return ""};$sb=New-Object System.Text.StringBuilder;foreach($c in $s.ToCharArray()){switch([int][char]$c){0{[void]$sb.Append("\00")}40{[void]$sb.Append("\28")}41{[void]$sb.Append("\29")}42{[void]$sb.Append("\2a")}92{[void]$sb.Append("\5c")}default{[void]$sb.Append($c)}}};$sb.ToString()}
function Prop($p,[string]$n){try{if($p.Contains($n)-and$p[$n]-and$p[$n].Count-gt 0){return $p[$n][0]}}catch{};return $null}
function SProp($p,[string]$n){$v=Prop $p $n;if($null -eq $v){return ""};return [string]$v}
function Convert-FileTimeIso($v){if($null -eq $v){return $null};try{$n=[Int64]$v;if($n -eq 0 -or $n -eq 9223372036854775807){return $null};return [DateTime]::FromFileTimeUtc($n).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss")}catch{return $null}}
function Convert-DateTimeIso($v){if($null -eq $v){return $null};try{return([DateTime]$v).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss")}catch{return $null}}
$base=([ADSI]"LDAP://RootDSE").defaultNamingContext
$root=New-Object System.DirectoryServices.DirectoryEntry("LDAP://$base")
function Searcher([string]$f,[string[]]$props){$s=New-Object System.DirectoryServices.DirectorySearcher($root);$s.Filter=$f;$s.PageSize=1000;$s.SearchScope=[System.DirectoryServices.SearchScope]::Subtree;foreach($x in $props){[void]$s.PropertiesToLoad.Add($x)};return $s}
`;
function userMapperPs(){return String.raw`
function UserObj($r,[bool]$detail=$false){
$p=$r.Properties;$uac=0;$raw=Prop $p "useraccountcontrol";if($null -ne $raw){try{$uac=[int]$raw}catch{}}
$enabled=(($uac -band 2)-eq 0);$passwordRequired=(($uac -band 0x20)-eq 0);$passwordNeverExpires=(($uac -band 0x10000)-ne 0)
$expiry=Convert-FileTimeIso(Prop $p "accountexpires");$status=if($enabled){"Enabled"}else{"Disabled"};if($enabled -and $expiry){try{if([DateTime]$expiry -lt(Get-Date)){$status="Expired"}}catch{}}
$managerName="";$managerEmail="";$managerDN=SProp $p "manager";if($managerDN){$me=$null;try{$me=New-Object System.DirectoryServices.DirectoryEntry("LDAP://$managerDN");$managerName=[string]$me.Properties["displayName"].Value;$managerEmail=[string]$me.Properties["mail"].Value}catch{}finally{if($null-ne$me){$me.Dispose()}}}
$groups=@();if($detail -and $p.Contains("memberof")){foreach($g in $p["memberof"]){$gs=[string]$g;if($gs -match '^CN=((?:\\.|[^,])+)'){$groups+=($Matches[1]-replace '\\,',','-replace '\\\\','\')}else{$groups+=$gs}};$groups=@($groups|Sort-Object -Unique)}
$resolvedEmployeeId="";$resolvedEmployeeIdSource="";$candidateEmployeeId=SProp $p "employeeid";$candidateDescription=SProp $p "description";$candidateComment=SProp $p "comment";$candidateEmployeeNumber=SProp $p "employeenumber"
if(-not[string]::IsNullOrWhiteSpace($candidateEmployeeId)){$resolvedEmployeeId=$candidateEmployeeId;$resolvedEmployeeIdSource="employeeID"}elseif(-not[string]::IsNullOrWhiteSpace($candidateDescription)){$resolvedEmployeeId=$candidateDescription;$resolvedEmployeeIdSource="description (net user Comment)"}elseif(-not[string]::IsNullOrWhiteSpace($candidateComment)){$resolvedEmployeeId=$candidateComment;$resolvedEmployeeIdSource="comment"}elseif(-not[string]::IsNullOrWhiteSpace($candidateEmployeeNumber)){$resolvedEmployeeId=$candidateEmployeeNumber;$resolvedEmployeeIdSource="employeeNumber"}
[PSCustomObject]@{username=SProp $p "samaccountname";name=SProp $p "displayname";email=SProp $p "mail";upn=SProp $p "userprincipalname";employeeId=$resolvedEmployeeId;employeeIdSource=$resolvedEmployeeIdSource;employeeNumber=SProp $p "employeenumber";department=SProp $p "department";title=SProp $p "title";company=SProp $p "company";manager=$managerName;managerEmail=$managerEmail;office=SProp $p "physicaldeliveryofficename";telephone=SProp $p "telephonenumber";mobile=SProp $p "mobile";status=$status;enabled=$enabled;accountExpiry=$expiry;passwordLastSet=Convert-FileTimeIso(Prop $p "pwdlastset");passwordExpiry=Convert-FileTimeIso(Prop $p "msds-userpasswordexpirytimecomputed");passwordRequired=$passwordRequired;passwordNeverExpires=$passwordNeverExpires;lastLogon=Convert-FileTimeIso(Prop $p "lastlogontimestamp");whenCreated=Convert-DateTimeIso(Prop $p "whencreated");whenChanged=Convert-DateTimeIso(Prop $p "whenchanged");homeDirectory=SProp $p "homedirectory";description=SProp $p "description";comment=SProp $p "comment";distinguishedName=SProp $p "distinguishedname";groups=$groups}
}
$props=@("samaccountname","displayname","mail","userprincipalname","employeeid","employeenumber","department","title","company","manager","physicaldeliveryofficename","telephonenumber","mobile","useraccountcontrol","accountexpires","pwdlastset","lastlogontimestamp","whencreated","whenchanged","distinguishedname","memberof","homedirectory","description","comment","msds-userpasswordexpirytimecomputed")
`; }

async function handleApi(req,res,u){
try{
if(u.pathname==='/api/health'){const ps=commonPs+`[PSCustomObject]@{ok=$true;baseDN=[string]$base;machine=$env:COMPUTERNAME;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;timestamp=(Get-Date).ToString("s")} | ConvertTo-Json -Compress`;const out=await runPS(ps);return sendJson(res,{...JSON.parse(out||'{}'),magnitude:magnitudeStatusPayload()});}
if(u.pathname==='/api/magnitude/status')return sendJson(res,magnitudeStatusPayload());
if(u.pathname==='/api/magnitude/refresh'){await refreshMagnitude();return sendJson(res,magnitudeStatusPayload());}
if(u.pathname==='/api/magnitude/unmatched'){const result=await getMagnitudeUnmatchedUsers();return sendJson(res,result);}
if(u.pathname==='/api/departments'){const ps=commonPs+`$s=Searcher "(&(objectCategory=person)(objectClass=user)(department=*))" @("department");$set=New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase);try{foreach($r in $s.FindAll()){$d=SProp $r.Properties "department";if($d){[void]$set.Add($d.Trim())}};[PSCustomObject]@{items=@($set|Sort-Object)}|ConvertTo-Json -Depth 4 -Compress}finally{$s.Dispose();$root.Dispose()}`;return sendJson(res,JSON.parse(await runPS(ps)||'{"items":[]}'));}
if(u.pathname==='/api/groups'){const q=u.searchParams.get('query')||'';const ps=commonPs+`$q=Esc ${psQuote(q)};$filter=if([string]::IsNullOrWhiteSpace(${psQuote(q)})){"(objectCategory=group)"}else{"(&(objectCategory=group)(|(cn=*$q*)(name=*$q*)(samAccountName=*$q*)))"};$s=Searcher $filter @("cn","name","samaccountname","distinguishedname","description");$s.SizeLimit=200;$o=@();try{foreach($r in $s.FindAll()){$o += [PSCustomObject]@{name=SProp $r.Properties "name";samAccountName=SProp $r.Properties "samaccountname";description=SProp $r.Properties "description";distinguishedName=SProp $r.Properties "distinguishedname"}};[PSCustomObject]@{items=@($o|Sort-Object name)}|ConvertTo-Json -Depth 5 -Compress}finally{$s.Dispose();$root.Dispose()}`;return sendJson(res,JSON.parse(await runPS(ps)||'{"items":[]}'));}
if(u.pathname==='/api/users'){
const mode=(u.searchParams.get('mode')||'').toLowerCase(),value=u.searchParams.get('value')||'',recursive=(u.searchParams.get('recursive')||'true')!=='false';let filterPs;
if(mode==='department')filterPs=`$filter="(&(objectCategory=person)(objectClass=user)(department=$(Esc ${psQuote(value)})))"`;
else if(mode==='user')filterPs=`$e=Esc ${psQuote(value)};$filter="(&(objectCategory=person)(objectClass=user)(|(samAccountName=*$e*)(displayName=*$e*)(mail=*$e*)(employeeID=*$e*)(description=*$e*)(userPrincipalName=*$e*)))"`;
else if(mode==='group')filterPs=`$gq=Esc ${psQuote(value)};$gs=Searcher "(&(objectCategory=group)(|(cn=$gq)(samAccountName=$gq)(name=$gq)))" @("distinguishedname");try{$gr=$gs.FindOne()}finally{$gs.Dispose()};if($null -eq $gr){throw "AD group not found."};$gdn=Esc(SProp $gr.Properties "distinguishedname");$filter=${recursive?`"(&(objectCategory=person)(objectClass=user)(memberOf:1.2.840.113556.1.4.1941:=$gdn))"`:`"(&(objectCategory=person)(objectClass=user)(memberOf=$gdn))"`}`;
else return sendJson(res,{error:'Unsupported search mode.'},400);
const ps=commonPs+userMapperPs()+`${filterPs};$s=Searcher $filter $props;$o=@();try{foreach($r in $s.FindAll()){$o += UserObj $r $false};[PSCustomObject]@{count=$o.Count;items=@($o|Sort-Object name)}|ConvertTo-Json -Depth 7 -Compress}finally{$s.Dispose();$root.Dispose()}`;
const parsed=JSON.parse(await runPS(ps)||'{"count":0,"items":[]}');parsed.items=(parsed.items||[]).map(tagMagnitudeUser);parsed.magnitude=magnitudeStatusPayload();return sendJson(res,parsed);}
if(u.pathname==='/api/user'){const username=u.searchParams.get('username')||'';const ps=commonPs+userMapperPs()+`$e=Esc ${psQuote(username)};$s=Searcher "(&(objectCategory=person)(objectClass=user)(|(samAccountName=$e)(userPrincipalName=$e)))" $props;try{$r=$s.FindOne();if($null -eq $r){throw "User not found."};UserObj $r $true|ConvertTo-Json -Depth 8 -Compress}finally{$s.Dispose();$root.Dispose()}`;return sendJson(res,tagMagnitudeUser(JSON.parse(await runPS(ps)||'{}')));}
return sendJson(res,{error:'API endpoint not found.'},404);
}catch(e){return sendJson(res,{error:e.message||'Server error'},500);}
}
const server=http.createServer(async(req,res)=>{const u=new URL(req.url,`http://${HOST}:${PORT}`);if(u.pathname.startsWith('/api/'))return handleApi(req,res,u);let rel=decodeURIComponent(u.pathname);if(rel==='/')rel='/index.html';const file=path.resolve(WWW,'.'+rel);if(!file.startsWith(path.resolve(WWW)))return sendText(res,'Forbidden',403);fs.readFile(file,(err,data)=>{if(err)return sendText(res,'Not found',404);res.writeHead(200,{'Content-Type':contentType(file),'Content-Length':data.length});res.end(data);});});
(async()=>{await refreshMagnitude();server.listen(PORT,HOST,()=>{console.log('');console.log('Directory Intelligence V2.2 - Magnitude Reconciliation');console.log('-----------------------------------------------');console.log(`URL: http://localhost:${PORT}`);console.log(`Magnitude source: ${magnitudeCache.source||'Not loaded'} (${magnitudeCache.rows.length} records)`);if(magnitudeCache.error)console.log(`Magnitude note: ${magnitudeCache.error}`);console.log('No NPM packages required.');console.log('Press Ctrl+C to stop.');console.log('');});})();
