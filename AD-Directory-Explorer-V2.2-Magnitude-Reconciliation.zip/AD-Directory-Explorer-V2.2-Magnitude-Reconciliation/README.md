# Directory Intelligence V2.2 – Magnitude Reconciliation Fix

## Fixed

The **Magnitude Missing in AD** button in V2.1 called the endpoint correctly, but
the backend function `getMagnitudeUnmatchedUsers()` was missing from `server.js`.

V2.2 adds the missing backend reconciliation implementation.

The comparison now:

- Reads the Magnitude Excel/CSV reference already loaded by the application
- Checks all reference users against Active Directory
- Matches by Username, Email ID, Employee ID, then Name
- Checks Employee ID against `employeeID`, `description`, `comment`, and `employeeNumber`
- Runs LDAP checks in batches to avoid oversized filters
- Shows only Magnitude reference users that are not found in AD
- Supports search and CSV export in the reconciliation popup


# Directory Intelligence V2.1 – Reconciliation UI Fix

## Fix

V2.0 accidentally inserted the Magnitude reconciliation functions inside `setMode()`.
That meant the page stopped with a browser-side JavaScript `ReferenceError` before the
startup health calls ran, leaving the header permanently at:

- `Magnitude: loading...`
- `AD: connecting...`

V2.1 moves those functions back to top-level scope. No AD/backend logic was changed.

# Directory Intelligence V2.0 – Magnitude Reconciliation

## New reconciliation button

A highlighted **Magnitude Missing in AD** button is shown in the top header.

When clicked, the application compares all records in the Magnitude reference file against Active Directory using:

1. Username
2. Email ID
3. Employee ID
4. Name

This comparison is global against Active Directory, so it is not limited to the currently selected department or group.

The result window shows:
- Excel records checked
- Users matched in AD
- Users not found in AD
- Search/filter within missing users
- Export missing users to CSV
- Re-run comparison


# AD Directory Explorer V1.8 — Node

## Fix in V1.8

V1.7 contained Markdown-style backtick characters inside the embedded PowerShell text in `server.js`.
Because that PowerShell text is itself stored inside a JavaScript template literal, the backticks prematurely ended the JavaScript string and Node reported:

```text
SyntaxError: Unexpected identifier 'net'
```

V1.8 removes those conflicting backticks. The Employee ID logic remains:

```text
employeeID -> description -> comment -> employeeNumber
```

Run:

```text
node server.js
```

Then open:

```text
http://localhost:8085
```

## Employee ID fix in V1.7

The Windows command:

```text
net user <username> /domain
```

shows a field labelled **Comment**. In Active Directory this value is commonly stored in LDAP attribute:

```text
description
```

rather than LDAP attribute:

```text
comment
```

Therefore V1.7 resolves Employee ID in this order:

```text
1. employeeID
2. description   ← corresponds to the "Comment" shown by net user in your environment
3. comment
4. employeeNumber
```

The user detail panel continues to show the source used.

Run:

```text
node server.js
```

Open:

```text
http://localhost:8085
```
## Fix in V1.6

V1.5 introduced a PowerShell parser error in the Employee ID fallback logic. The fallback was written as an inline `if/elseif` expression inside the `PSCustomObject`, which Windows PowerShell 5.1 does not parse in that form.

V1.6 resolves Employee ID into normal variables **before** building the result object.

Employee ID priority remains:

```text
1. employeeID
2. comment
3. employeeNumber
```

All V1.5 UI features remain:
- Company column
- Default 8 columns
- Multi-select Columns menu
- Searchable department typing field
- Dynamic CSV/Excel export based on visible columns

Run:

```text
node server.js
```

Open:

```text
http://localhost:8085
```
## Enhancements in V1.5

1. **Company** is now included in the default user list.
2. Added a **Columns** multi-select. Exactly eight business columns are shown by default:
   - Employee ID
   - Name
   - Username
   - Email
   - Department
   - Company
   - Title
   - Manager

   Additional fields can be enabled or removed at any time. The user's selection is retained in the browser.
3. **Department** is now a searchable typing field backed by the AD department list. Start typing and select the matching department instead of scrolling through a long dropdown.
4. CSV and Excel export now follow the currently selected visible columns.

Start:

```text
node server.js
```

Open:

```text
http://localhost:8085
```

## Employee ID fallback improvement

The application now resolves Employee ID in this order:

```text
1. employeeID
2. comment
3. employeeNumber
```

This covers users where the corporate employee ID is stored in the AD `comment` field (for example values such as `CT2178`) instead of `employeeID`.

The detail panel also shows which AD attribute supplied the displayed Employee ID.

Start as before:

```text
node server.js
```

Then open:

```text
http://localhost:8085
```

## Fix in V1.3

V1.2 used a PowerShell helper function named `FT`. On Windows PowerShell, `ft` is a built-in alias for `Format-Table`. Because aliases take precedence over functions, account-expiry values were accidentally being sent to `Format-Table`, producing an error similar to:

```text
FT : Cannot convert System.Int64...
FullyQualifiedErrorId : DictionaryKeyUnknownType,Microsoft.PowerShell.Commands.FormatTableCommand
```

V1.3 renames the helper to `Convert-FileTimeIso` and also makes manager lookup more defensive.

Start as before:

```text
node server.js
```

Then browse to:

```text
http://localhost:8085
```

This version is designed for corporate Windows environments where:

- `.ps1` execution is blocked
- `.cmd` files are blocked
- Node.js itself is permitted
- NPM installation is restricted

The application runs with:

```text
node server.js
```

No NPM packages are required.

## Start

1. Extract the ZIP.
2. Open PowerShell or Command Prompt in the extracted folder.
3. Run:

```text
node server.js
```

4. Open:

```text
http://localhost:8085
```

5. Stop with `Ctrl+C`.

## How it works

Node hosts the local web application. For each read-only AD request, Node calls:

```text
powershell.exe -NoProfile -NonInteractive -Command <inline command>
```

The PowerShell commands use `System.DirectoryServices`, the same technique already proven to work on your PC.

No `.ps1` script is executed.

## Security

- Binds only to `127.0.0.1`
- Read-only directory searches
- Uses your current Windows identity
- No stored AD password
- No database
- No arbitrary LDAP endpoint exposed