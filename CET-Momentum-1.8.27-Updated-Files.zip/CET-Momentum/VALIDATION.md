> Latest validation: **1.8.18, 48 automated tests and 15 built-browser checks passed**. See `deployment/TEST-RESULTS-1.8.18.md` and `validation/1.8.18`. Earlier records below are historical.

> Latest validation: **1.8.17, 40 tests and built-browser checks passed**. See `deployment/TEST-RESULTS-1.8.17.md` and `validation/1.8.17`. Older records below refer to earlier packages.

> Latest validation: **1.8.16, 38 tests and built-browser checks passed**. See `deployment/TEST-RESULTS-1.8.16.md` and `validation/1.8.16`.

> Latest portal validation: **1.8.15, 35 tests passed and built-browser checks passed**. See `deployment/TEST-RESULTS-1.8.15.md` and `validation/1.8.15`. The older helper build record below is retained for reference.

# Validation — portal 1.8.0 / CET Helper 1.2.9

Checked on Linux on 4 October 2026.

- Portal production build completed with Vite.
- All 14 automated tests passed: Excel synchronization, account/role access, enrollments/device approvals, authentication and HTTP subpath behavior, attendance, absences/weekend eligibility, activity reports, leader privacy and reminders.
- Windows x64 helper built with Electron 38.8.6 and electron-builder 26.15.3, using the standard NSIS per-user target and the same app identity. The existing PowerShell worker handoff is preserved.
- Embedded app version and portal URL checked in app.asar. Packaged main/updater scripts compared against source.
- Published installer size and SHA-256 match helper-release.json.
- Complete package includes Windows Node 24.19.0 and dependencies selected for Windows x64. Node distribution SHA-256 checked against official SHASUMS256.txt.
- Blank twelve-field roster template validated through the application's ExcelJS reader. Its export XML namespaces were normalized for that reader's compatibility.

The previous corrected automatic updater was validated by the user on Windows. The newly cross-built 1.2.9 installer has not been executed on a Windows PC in this Linux environment. Confirm per-user installation/update and the IIS HTTPS connection on your PC/server before wider distribution.

The installer is unsigned. No corporate signing private key was supplied.
