# Helper updates

This release publishes CET Helper 1.2.9. See `helper/BUILD-AND-UPDATE.md` for the current build, upgrade and logging instructions, and `README.md` for deployment. The installed helper reports its running version to the server after upgrading.
