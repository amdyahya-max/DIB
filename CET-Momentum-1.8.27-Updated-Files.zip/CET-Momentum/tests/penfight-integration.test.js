import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createCore,hash,dubaiNow} from '../server/core.js';
import {newRoster,mergeWorkbook} from '../server/roster-workbook.js';
import {penFightEligibility,dubaiDayStart} from '../server/penfight.js';
import {initialState} from '../server/penfight-engine.js';

function fixture(){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-penfight-')),core=createCore({storage:dir,data:dir});const rows=['admin','alice','bob','missing','leader'].map(name=>({username:'dib\\'+name,name,status:'Enabled',email:name+'@example.test'}));core.applyRoster(rows);const users=Object.fromEntries(core.db.prepare('SELECT * FROM users').all().map(u=>[u.name,u]));core.db.prepare('UPDATE users SET admin=1 WHERE id=?').run(users.admin.id);core.db.prepare('UPDATE users SET special=1 WHERE id=?').run(users.leader.id);for(const key of Object.keys(users))users[key]=core.user(users[key].id);return {core,dir,users,rows};}

test('eligibility checks prior months and respects holidays, absence, leave, joining and weekend policy',()=>{
 const {core,dir,users}=fixture();try{
 const u=users.alice,cfg={startDate:'2026-08-31'},now=new Date('2026-10-10T00:01:00+04:00');
 const dates=[];for(let d=new Date('2026-08-31T12:00:00Z');d<new Date('2026-10-10T12:00:00Z');d.setUTCDate(d.getUTCDate()+1)){const date=d.toISOString().slice(0,10);if(core.eligible(u,date))dates.push(date);}
 for(const date of dates)core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(u.id,date,date+'T10:00:00Z');
 assert.equal(penFightEligibility(core,u,cfg,now).ok,true);
 core.db.prepare('DELETE FROM attendance WHERE user_id=? AND date=?').run(u.id,'2026-09-01');assert.deepEqual(penFightEligibility(core,u,cfg,now).missing,['2026-09-01']);
 core.db.prepare('INSERT INTO leave_days VALUES(?,?)').run(u.id,'2026-09-01');assert.equal(penFightEligibility(core,u,cfg,now).ok,true);
 core.db.prepare('DELETE FROM attendance WHERE user_id=? AND date=?').run(u.id,'2026-09-02');core.db.prepare('INSERT INTO self_absences VALUES(?,?,?)').run(u.id,'2026-09-02','test');assert.equal(penFightEligibility(core,u,cfg,now).ok,true);
 const s=core.settings();s.holidays=['2026-09-03'];core.db.prepare('UPDATE settings SET value=?').run(JSON.stringify(s));core.db.prepare('DELETE FROM attendance WHERE user_id=? AND date=?').run(u.id,'2026-09-03');assert.equal(penFightEligibility(core,u,cfg,now).ok,true);
 assert.equal(penFightEligibility(core,{...u,weekend_enabled:1},cfg,now).ok,false);
 assert.equal(penFightEligibility(core,{...u,joining_date:'2026-10-10'},cfg,now).ok,true);
 const atMidnight=penFightEligibility(core,u,{startDate:'2026-10-09'},new Date('2026-10-09T20:00:00Z'));assert.equal(atMidnight.cutoff,'2026-10-09');
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});
test('Dubai limits start at local midnight, not UTC midnight',()=>{assert.equal(dubaiDayStart('2026-10-10'),'2026-10-09T20:00:00.000Z');});
test('attendance gating never grants access after an arbitrary ten-year scan cutoff',()=>{
 const core={db:{prepare:()=>({all:()=>[]})},eligible:(_u,date)=>date==='2026-10-09'};assert.deepEqual(penFightEligibility(core,{id:1},{startDate:'2000-01-01'},new Date('2026-10-10T10:00:00Z')).missing,['2026-10-09']);
});

test('real HTTP Pen Fight defaults OFF; enforces admin, attendance, participants, scoring and bulk cleanup',{timeout:30000},async()=>{
 const {core,dir,users,rows}=fixture();let child;try{
 const book=newRoster();mergeWorkbook(book,rows);fs.writeFileSync(path.join(dir,'CET_Users.xlsx'),Buffer.from(await book.workbook.xlsx.writeBuffer()));
 const day=dubaiNow().date,d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-1);const previous=d.toISOString().slice(0,10);
 const settings=core.settings();settings.workdays=[0,1,2,3,4,5,6];core.db.prepare('UPDATE settings SET value=?').run(JSON.stringify(settings));
 for(const u of Object.values(users))if(u.name!=='missing')core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(u.id,previous,previous+'T10:00:00Z');
 const cookies={};for(const u of Object.values(users)){const secret='session-'+u.name,device='test-device-'+u.name;core.db.prepare('INSERT INTO devices VALUES(?,?,?,?,0)').run(device,u.id,hash('helper-'+u.name),new Date().toISOString());core.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(hash(secret),u.id,device,Date.now()+3600000);cookies[u.name]='cet_session='+secret;}
 const port=6500+Math.floor(Math.random()*1000),origin=`http://localhost:${port}`,url=origin+'/CETGamification/api';
 core.db.exec('CREATE TABLE penfight_config(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,start_date TEXT NOT NULL,max_daily_matches INTEGER NOT NULL DEFAULT 5)');core.db.prepare('INSERT INTO penfight_config VALUES(1,0,?,2)').run(previous);
 child=spawn(process.execPath,['server/index.js'],{env:{...process.env,PORT:String(port),HOST:'127.0.0.1',PUBLIC_URL:origin,BASE_PATH:'/CETGamification',DATA_DIR:dir,STORAGE_DIR:dir},stdio:'pipe'});let logs='';child.stdout.on('data',x=>logs+=x);child.stderr.on('data',x=>logs+=x);let ready=false;for(let i=0;i<100;i++){try{if((await fetch(url+'/info')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}assert.ok(ready,logs);
 const call=async(p,method='GET',body,user='alice',site=origin)=>{const r=await fetch(url+p,{method,headers:{Origin:site,'Content-Type':'application/json',...(user?{Cookie:cookies[user]}:{})},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,data:await r.json()};};
 assert.equal((await call('/penfight/status','GET',undefined,null)).status,401);
 assert.equal((await call('/penfight/status')).data.enabled,false);assert.equal((await call('/penfight/matches','POST',{})).status,403);
 assert.equal((await call('/penfight/admin')).status,403);
 const migrated=(await call('/penfight/admin','GET',undefined,'admin')).data;assert.equal(migrated.penPair,'classic-blue-white');assert.equal(migrated.maxRounds,5);assert.equal(migrated.contestsPerRound,4);assert.equal(migrated.scoringMode,'round-contests');assert.equal(migrated.winsToWin,3);assert.equal(migrated.startDate,previous);assert.equal(migrated.dailyLimit,2);
 const cfg={enabled:true,startDate:previous,dailyLimit:2};assert.equal((await call('/penfight/admin','PUT',{...cfg,penPair:'unknown'},'admin')).status,400);assert.equal((await call('/penfight/admin','PUT',cfg,'alice')).status,403);
 assert.equal((await call('/penfight/admin','PUT',cfg,'admin','https://untrusted.test')).status,403);
 assert.equal((await call('/penfight/admin','PUT',{...cfg,startDate:'2999-01-01'},'admin')).status,400);
 for(const contestsPerRound of [2,20])assert.equal((await call('/penfight/admin','PUT',{...cfg,contestsPerRound},'admin')).status,200);
 assert.equal((await call('/penfight/admin','PUT',{...cfg,contestsPerRound:4},'admin')).status,200);
 assert.equal((await call('/penfight/status','GET',undefined,'missing')).data.eligibility.ok,false);
 for(const p of ['/penfight/lobby','/penfight/my-matches'])assert.equal((await call(p,'GET',undefined,'missing')).status,403);
 assert.equal((await call('/penfight/matches','POST',{},'missing')).status,403);
 const created=await call('/penfight/matches','POST',{});assert.equal(created.status,201);const id=created.data.id;assert.equal(created.data.state.rules.scoringMode,'round-contests');assert.equal(created.data.state.placement,'random');assert.notDeepEqual(created.data.state.pens,initialState().pens);assert.equal(created.data.state.penPair,'classic-blue-white');
 const secondChallenge=await call('/penfight/matches','POST',{});assert.equal(secondChallenge.status,201);assert.notEqual(secondChallenge.data.id,id);assert.equal((await call('/penfight/matches','POST',{})).status,429);assert.equal((await call('/penfight/open-games')).data.length,2);
 assert.equal((await call('/penfight/matches/'+id+'/join','POST',{},'missing')).status,403);
 assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:0,power:.5})).status,409);
 assert.equal((await call('/penfight/matches/'+id+'/join','POST',{},'bob')).status,200);
 assert.equal((await call('/penfight/matches/'+id+'/join','POST',{},'admin')).status,409);
 assert.equal((await call('/penfight/matches/'+id,'GET',undefined,'admin')).status,403);
 assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:0,power:.5},'bob')).status,409);
 assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:0,power:200})).status,409);
 assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:0,power:.5})).status,200);
 core.db.prepare('DELETE FROM attendance WHERE user_id=? AND date=?').run(users.bob.id,previous);
 assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:Math.PI,power:.5})).status,403);
 core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(users.bob.id,previous,previous+'T10:00:00Z');
 // Deterministic final-round fixture: Alice flicks her own pen over the edge, Bob wins his third round.
 const state=initialState();state.score=[0,2];state.round=3;state.pens[0].y=36;core.db.prepare('UPDATE penfight_matches SET state=? WHERE id=?').run(JSON.stringify(state),id);
 const before=core.db.prepare('SELECT count(*) n FROM attendance').get().n;
 const final=await call('/penfight/matches/'+id+'/shot','POST',{angle:-Math.PI/2,power:1,points:9999,winner:0});assert.equal(final.status,200);assert.equal(final.data.state.status,'finished');assert.equal(final.data.state.winner,1);
 assert.deepEqual({...core.db.prepare('SELECT points,wins,played FROM penfight_points WHERE user_id=?').get(users.bob.id)},{points:30,wins:1,played:1});
 assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:0,power:1})).status,409);assert.equal(core.db.prepare('SELECT points FROM penfight_points WHERE user_id=?').get(users.bob.id).points,30);assert.equal(core.db.prepare('SELECT count(*) n FROM attendance').get().n,before);
 core.db.prepare('INSERT INTO penfight_points VALUES(?,?,?,?)').run(users.leader.id,100,3,4);
 assert.ok(!(await call('/penfight/leaderboard')).data.some(x=>x.id===users.leader.id));assert.ok((await call('/penfight/leaderboard','GET',undefined,'leader')).data.some(x=>x.id===users.leader.id));
 const wait=secondChallenge;assert.equal((await call('/penfight/matches/'+wait.data.id+'/cancel','POST',{})).status,200);assert.equal((await call('/penfight/matches/'+wait.data.id+'/join','POST',{},'bob')).status,409);assert.equal((await call('/penfight/matches','POST',{})).status,429);
 // Solo remains private, uses the shared quota, and never awards competitive points.
 assert.equal((await call('/penfight/admin','PUT',{...cfg,dailyLimit:10},'admin')).status,200);
 assert.equal((await call('/penfight/matches','POST',{mode:'invalid'})).status,400);
 assert.equal((await call('/penfight/matches','POST',{mode:'solo'},'missing')).status,403);
 for(const rules of [{contestsPerRound:1},{contestsPerRound:3},{contestsPerRound:22},{contestsPerRound:2.5},{maxRounds:0},{maxRounds:16},{maxRounds:2.5}])assert.equal((await call('/penfight/admin','PUT',{...cfg,dailyLimit:10,...rules},'admin')).status,400);
 assert.equal((await call('/penfight/admin','PUT',{...cfg,dailyLimit:10,maxRounds:7,winsToWin:4,penPair:'classic-blue-red'},'admin')).status,200);
 const practice=await call('/penfight/matches','POST',{mode:'solo',difficulty:'expert',penPair:'personalized'});assert.equal(practice.status,201);const sid=practice.data.id;assert.equal(practice.data.state.penPair,'classic-blue-red');
 assert.deepEqual(practice.data.state.rules,{maxRounds:7,scoringMode:'round-contests',contestsPerRound:4});assert.equal((await call('/penfight/admin','PUT',{...cfg,dailyLimit:10,maxRounds:3,winsToWin:2,penPair:'personalized'},'admin')).status,200);assert.deepEqual((await call('/penfight/matches/'+sid)).data.state.rules,{maxRounds:7,scoringMode:'round-contests',contestsPerRound:4});
 assert.equal((await call('/penfight/matches/'+sid)).data.state.penPair,'classic-blue-red');assert.equal((await call('/penfight/status')).data.penPair,'personalized');assert.equal(practice.data.player1,null);assert.equal(practice.data.player1Name,'CET Bot');assert.equal(practice.data.state.mode,'solo');
 assert.ok(!(await call('/penfight/lobby','GET',undefined,'bob')).data.some(x=>x.id===sid));
 assert.equal((await call('/penfight/matches/'+sid+'/join','POST',{},'bob')).status,409);
 assert.equal((await call('/penfight/matches/'+sid+'/computer','POST',{expectedShot:0},'bob')).status,403);
 assert.equal((await call('/penfight/matches/'+sid+'/computer','POST',{expectedShot:0})).status,409);
 assert.equal((await call('/penfight/matches/'+sid+'/shot','POST',{angle:0,power:.4,expectedShot:0})).status,200);
 assert.equal((await call('/penfight/matches/'+sid+'/computer','POST',{expectedShot:0})).status,409);
 const cpu=await call('/penfight/matches/'+sid+'/computer','POST',{expectedShot:1});assert.equal(cpu.status,200);assert.equal(cpu.data.state.penPair,'classic-blue-red');assert.equal(cpu.data.state.logs.length,2);assert.equal(cpu.data.state.logs[1].player,1);
 assert.equal((await call('/penfight/matches/'+sid+'/computer','POST',{expectedShot:1})).status,409);
 const otherSolo=await call('/penfight/matches','POST',{mode:'solo'});assert.equal(otherSolo.status,201);assert.equal((await call('/penfight/matches/'+otherSolo.data.id+'/cancel','POST',{})).status,200);
 const soloFinal={...initialState(),mode:'solo',difficulty:'expert',score:[0,2],round:3};soloFinal.pens[0].y=36;core.db.prepare('UPDATE penfight_matches SET state=? WHERE id=?').run(JSON.stringify(soloFinal),sid);
 const pointsBefore=core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),usersBefore=core.db.prepare('SELECT count(*) n FROM users').get().n;
 const done=await call('/penfight/matches/'+sid+'/shot','POST',{angle:-Math.PI/2,power:1,expectedShot:0,winner:0,points:999});assert.equal(done.status,200);assert.equal(done.data.state.status,'finished');
 assert.deepEqual(core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),pointsBefore);assert.equal(core.db.prepare('SELECT count(*) n FROM users').get().n,usersBefore);assert.equal(core.db.prepare('SELECT awarded FROM penfight_matches WHERE id=?').get(sid).awarded,1);
 const abandoned=await call('/penfight/matches','POST',{mode:'solo'});assert.equal(abandoned.status,201);assert.equal(abandoned.data.state.penPair,'personalized');assert.equal((await call('/penfight/matches/'+abandoned.data.id+'/cancel','POST',{})).status,200);
 // Both real-player and bot games play every round and preserve a points table.
 assert.equal((await call('/penfight/admin','PUT',{...cfg,dailyLimit:10,maxRounds:3,winsToWin:1,penPair:'classic-blue-white'},'admin')).status,200);
 const fullDuel=await call('/penfight/matches','POST',{mode:'duel',scoringMode:'first-to',layoutSeed:0},'bob');assert.equal(fullDuel.status,201);
 const fid=fullDuel.data.id;assert.deepEqual(fullDuel.data.state.rules,{maxRounds:3,scoringMode:'round-contests',contestsPerRound:4});
 await call('/penfight/matches/'+fid+'/join','POST',{},'alice');
 assert.deepEqual((await call('/penfight/matches/'+fid,'GET',undefined,'alice')).data.state.pens,fullDuel.data.state.pens);
 const forceShot=async(id,winner,bot=false)=>{
  const saved=JSON.parse(core.db.prepare('SELECT state FROM penfight_matches WHERE id=?').get(id).state);saved.pens=initialState().pens;
  const actor=saved.turn;
  if(bot){saved.pens[0].y=15;}else if(actor===winner){saved.pens[actor].x=600;saved.pens[actor].angle=0;saved.pens[1-actor].x=742;saved.pens[1-actor].angle=0;}else saved.pens[actor].y=43;
  core.db.prepare('UPDATE penfight_matches SET state=? WHERE id=?').run(JSON.stringify(saved),id);
  const user=id===fid?(actor===0?'bob':'alice'):'alice';
  const r=await call('/penfight/matches/'+id+(bot?'/computer':'/shot'),'POST',bot?{expectedShot:saved.logs.length}:{angle:actor===winner?0:-Math.PI/2,power:actor===winner?.55:.1,expectedShot:saved.logs.length,winner:actor,points:999},user);
  assert.equal(r.status,200);return r.data;
 };
 const pointsBeforeFull=core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all();
 let full=await forceShot(fid,0);assert.equal(full.state.status,'playing');assert.deepEqual(full.state.score,[1,0]);assert.deepEqual(core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),pointsBeforeFull);
 const firstReset=full.state.pens;assert.notDeepEqual(firstReset,fullDuel.data.state.pens);
 assert.equal(full.state.round,1);assert.equal(full.state.contest,2);assert.deepEqual(full.state.roundScore,[1,0]);
 for(let i=1;i<12;i++){full=await forceShot(fid,i<4?0:1);if(i<11){assert.equal(full.state.status,'playing');assert.deepEqual(core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),pointsBeforeFull);}}
 assert.equal(full.state.status,'finished');assert.equal(full.state.winner,1);assert.deepEqual(full.state.score,[4,8]);assert.deepEqual(full.state.rounds.map(r=>r.points),[[4,0],[0,4],[0,4]]);assert.equal(full.state.contests.length,12);
 assert.deepEqual((await call('/penfight/matches/'+fid,'GET',undefined,'bob')).data.state.rounds,full.state.rounds);
 const bobBefore=pointsBeforeFull.find(p=>p.user_id===users.bob.id).points,aliceBefore=pointsBeforeFull.find(p=>p.user_id===users.alice.id).points;
 assert.equal(core.db.prepare('SELECT points FROM penfight_points WHERE user_id=?').get(users.alice.id).points,aliceBefore+30);assert.equal(core.db.prepare('SELECT points FROM penfight_points WHERE user_id=?').get(users.bob.id).points,bobBefore+10);
 const fullSolo=await call('/penfight/matches','POST',{mode:'solo'});assert.equal(fullSolo.status,201);const sid2=fullSolo.data.id;
 const practicePoints=core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all();
 for(let i=0;i<12;i++){full=await forceShot(sid2,i%2,i%2===1);if(i<11)assert.equal(full.state.status,'playing');assert.equal(full.state.logs.at(-1).player,i%2);}
 assert.equal(full.state.status,'finished');assert.deepEqual(full.state.score,[6,6]);assert.equal(full.state.winner,null);assert.equal(full.state.rounds.length,3);assert.deepEqual(core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),practicePoints);
 // Tags are allocated once and survive roster-name changes. Full names remain in user management.
 const aliceTag=core.db.prepare('SELECT tag FROM penfight_player_tags WHERE user_id=?').get(users.alice.id).tag;
 assert.equal((await call('/penfight/my-matches')).data.find(m=>m.id===sid2).player1Tag,'BOT');
 core.db.prepare('UPDATE users SET name=? WHERE id=?').run('Muhammad Yahya',users.alice.id);
 assert.equal((await call('/penfight/matches/'+sid2)).data.player0Tag,aliceTag);
 assert.equal(core.db.prepare('SELECT count(DISTINCT tag) n FROM penfight_player_tags').get().n,Object.keys(users).length);
 // Either participant can close a joined duel, with no awards or score/history loss.
 const openDuel=await call('/penfight/matches','POST',{mode:'duel'});assert.equal(openDuel.status,201);const eid=openDuel.data.id;
 assert.equal((await call('/penfight/matches/'+eid+'/join','POST',{},'bob')).status,200);
 const endedState=JSON.parse(core.db.prepare('SELECT state FROM penfight_matches WHERE id=?').get(eid).state);endedState.score=[2,1];endedState.logs=[{round:1,player:0,result:'point-0'}];
 core.db.prepare('UPDATE penfight_matches SET state=? WHERE id=?').run(JSON.stringify(endedState),eid);
 const beforeEndPoints=core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all();
 assert.equal((await call('/penfight/matches/'+eid+'/cancel','POST',{},'admin')).status,403);
 assert.equal((await call('/penfight/matches/'+eid+'/cancel','POST',{},'bob')).status,200);
 const ended=(await call('/penfight/matches/'+eid,'GET',undefined,'bob')).data.state;assert.equal(ended.status,'cancelled');assert.deepEqual(ended.score,[2,1]);assert.deepEqual(ended.logs,endedState.logs);assert.equal(ended.endedBy,users.bob.id);assert.ok(ended.endedAt);
 assert.deepEqual(core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),beforeEndPoints);assert.equal(core.db.prepare('SELECT awarded FROM penfight_matches WHERE id=?').get(eid).awarded,0);
 assert.equal((await call('/penfight/matches/'+eid+'/cancel','POST',{},'alice')).status,409);assert.equal((await call('/penfight/matches/'+eid+'/shot','POST',{angle:0,power:.5})).status,409);
 assert.equal((await call('/penfight/matches/'+fid+'/cancel','POST',{},'bob')).status,409);assert.deepEqual(core.db.prepare('SELECT * FROM penfight_points ORDER BY user_id').all(),beforeEndPoints);
 // Old unfinished games are always returned independently of the 20-game history cap.
 const insert=core.db.prepare('INSERT INTO penfight_matches(id,player0,state,created_at,updated_at) VALUES(?,?,?,?,?)');
 insert.run('old-open-visible',users.alice.id,JSON.stringify({...initialState(),mode:'duel'}),'2020-01-01T00:00:00Z','2020-01-01T00:00:00Z');
 for(let i=0;i<25;i++)insert.run('new-history-'+i,users.alice.id,JSON.stringify({...initialState(),mode:'duel',status:'cancelled'}),'2025-01-01T00:00:00Z','2025-01-01T00:00:00Z');
 assert.ok(!(await call('/penfight/my-matches')).data.some(m=>m.id==='old-open-visible'));
 const openList=(await call('/penfight/open-games')).data,old=openList.find(m=>m.id==='old-open-visible');assert.ok(old);assert.equal(old.state.pens,undefined);assert.equal(old.state.logs,undefined);assert.equal(old.state.status,'playing');assert.ok(!openList.some(m=>m.id===eid||m.id===fid));
 assert.equal((await call('/penfight/open-games','GET',undefined,'admin')).data.length,0);assert.equal((await call('/penfight/open-games','GET',undefined,null)).status,401);
 // Ending remains available when attendance becomes incomplete; play remains gated.
 core.db.prepare('DELETE FROM attendance WHERE user_id=? AND date=?').run(users.alice.id,previous);
 assert.equal((await call('/penfight/open-games')).status,200);assert.equal((await call('/penfight/matches/old-open-visible/cancel','POST',{})).status,200);assert.equal((await call('/penfight/matches','POST',{})).status,403);
 core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(users.alice.id,previous,previous+'T10:00:00Z');
 assert.equal((await call('/penfight/admin','PUT',{...cfg,enabled:false},'admin')).status,200);assert.equal((await call('/penfight/leaderboard')).status,403);assert.equal((await call('/penfight/matches/'+id+'/shot','POST',{angle:0,power:1})).status,403);
 core.db.prepare('INSERT INTO penfight_user_access VALUES(?,1,?,?)').run(users.bob.id,new Date().toISOString(),'test');
 assert.equal((await call('/admin/users/bulk-delete','POST',{userIds:[users.bob.id]},'admin')).status,200);assert.equal(core.user(users.bob.id),undefined);assert.equal(core.db.prepare('SELECT count(*) n FROM penfight_user_access WHERE user_id=?').get(users.bob.id).n,0);assert.equal(core.db.prepare('SELECT count(*) n FROM penfight_player_tags WHERE user_id=?').get(users.bob.id).n,0);assert.equal(core.db.prepare('SELECT count(*) n FROM penfight_matches WHERE player0=? OR player1=?').get(users.bob.id,users.bob.id).n,0);assert.equal(core.db.prepare('SELECT count(*) n FROM penfight_points WHERE user_id=?').get(users.bob.id).n,0);assert.ok(core.user(users.admin.id));
 }finally{if(child){child.kill();await new Promise(r=>child.exitCode!==null?r():child.once('exit',r));}core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});
