import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import express from 'express';
import {createCore,dubaiNow} from '../server/core.js';
import {penFightRoutes} from '../server/penfight.js';

async function fixture(){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-player-access-')),core=createCore({storage:dir,data:dir});
 const rows=['admin','alice','bob','missing','leader'].map(name=>({username:'dib\\'+name,name,status:'Enabled',email:name+'@example.test'}));core.applyRoster(rows);
 const users=Object.fromEntries(core.db.prepare('SELECT * FROM users').all().map(u=>[u.name,u]));core.db.prepare('UPDATE users SET admin=1 WHERE id=?').run(users.admin.id);core.db.prepare('UPDATE users SET special=1 WHERE id=?').run(users.leader.id);
 const date=dubaiNow().date,d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-1);const previous=d.toISOString().slice(0,10);
 core.db.prepare('UPDATE settings SET value=?').run(JSON.stringify({...core.settings(),workdays:[0,1,2,3,4,5,6]}));
 for(const name of ['admin','alice','bob','leader'])core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(users[name].id,previous,previous+'T10:00:00Z');
 // Reproduce the pre-access schema and retain its enabled state/settings.
 core.db.exec('CREATE TABLE penfight_config(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,start_date TEXT NOT NULL,max_daily_matches INTEGER NOT NULL DEFAULT 5)');core.db.prepare('INSERT INTO penfight_config VALUES(1,1,?,30)').run(previous);
 const auth=(req,res,next)=>{req.user=core.user(users[req.headers['x-test-user']]?.id);if(!req.user)return res.status(401).json({error:'Auth required'});if(!core.active(req.user))return res.status(403).json({error:'Portal disabled'});next();};
 const admin=(req,res,next)=>req.user.admin?next():res.status(403).json({error:'Admin required'});
 const app=express();app.use(express.json());penFightRoutes(app,core,auth,admin);
 const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
 const call=async(p,method='GET',body,user='admin')=>{const r=await fetch('http://127.0.0.1:'+server.address().port+'/api/penfight'+p,{method,headers:{'x-test-user':user,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,data:await r.json()};};
 const grant=(names,enabled=true)=>call('/admin/access/users','PATCH',{userIds:names.map(n=>users[n].id),enabled});
 return {core,rows,users,app,auth,admin,call,grant,previous,close:async()=>{await new Promise(r=>server.close(r));core.db.close();fs.rmSync(dir,{recursive:true,force:true});}};
}

test('migration preserves existing access, settings and attendance; repeat initialization keeps grants',async()=>{
 const f=await fixture();try{
  const c=(await f.call('/admin')).data;assert.equal(c.accessMode,'all');assert.equal(c.enabled,1);assert.equal(c.dailyLimit,30);assert.equal(c.startDate,f.previous);
  assert.equal((await f.call('/status','GET',undefined,'alice')).data.playerAllowed,true);
  await f.grant(['alice']);await f.call('/admin/access','PUT',{accessMode:'selected'});
  for(let i=0;i<3;i++)penFightRoutes(express.Router(),f.core,f.auth,f.admin);
  assert.equal((await f.call('/admin/access')).data.accessMode,'selected');assert.equal(f.core.db.prepare('SELECT enabled FROM penfight_user_access WHERE user_id=?').get(f.users.alice.id).enabled,1);
  assert.equal(f.core.db.prepare('SELECT count(*) n FROM attendance').get().n,4);
  // New user is not selected by an existing selected-only policy.
  f.core.applyRoster([...f.rows,{username:'dib\\new',name:'New',status:'Enabled',email:'new@example.test'}]);
  const newcomer=(await f.call('/admin/access')).data.users.find(u=>u.name==='New');assert.equal(newcomer.selected,false);assert.equal(newcomer.playerAllowed,false);
 }finally{await f.close();}
});
test('selected-only policy gates solo, duel, reads and bot; administrators still manage without play access',async()=>{
 const f=await fixture();try{
  await f.call('/admin/access','PUT',{accessMode:'selected'});
  assert.equal((await f.call('/status','GET',undefined,'alice')).data.playerAllowed,false);
  for(const p of ['/lobby','/leaderboard','/my-matches','/matches/absent'])assert.equal((await f.call(p,'GET',undefined,'alice')).status,403,p);
  for(const mode of ['solo','duel'])assert.equal((await f.call('/matches','POST',{mode},'alice')).status,403);
  assert.equal((await f.call('/matches','POST',{},'admin')).status,403);
  assert.equal((await f.call('/admin')).status,200);assert.equal((await f.call('/admin/access')).status,200);
  await f.grant(['alice','bob']);const solo=await f.call('/matches','POST',{mode:'solo'},'alice');assert.equal(solo.status,201);
  assert.equal((await f.call('/matches','POST',{mode:'duel'},'bob')).status,201);
  await f.grant(['alice'],false);
  for(const suffix of ['/shot','/computer'])assert.equal((await f.call('/matches/'+solo.data.id+suffix,'POST',{angle:0,power:.5,expectedShot:0},'alice')).status,403);
  // Revocation keeps games and allows the owner to explicitly end them.
  assert.equal((await f.call('/open-games','GET',undefined,'alice')).data.length,1);
  assert.equal((await f.call('/matches/'+solo.data.id+'/cancel','POST',{},'alice')).status,200);
  assert.equal(f.core.db.prepare('SELECT awarded FROM penfight_matches WHERE id=?').get(solo.data.id).awarded,0);
  assert.equal(f.core.db.prepare('SELECT count(*) n FROM penfight_points').get().n,0);
 }finally{await f.close();}
});
test('revoking opponent removes lobby/leaderboard entries and blocks new joins and shots',async()=>{
 const f=await fixture();try{
  await f.grant(['alice','bob','leader']);await f.call('/admin/access','PUT',{accessMode:'selected'});
  const waiting=(await f.call('/matches','POST',{},'bob')).data;
  const leader=(await f.call('/matches','POST',{},'leader')).data;
  assert.deepEqual((await f.call('/lobby','GET',undefined,'alice')).data.map(m=>m.id),[waiting.id]); // special privacy retained
  assert.equal((await f.call('/matches/'+leader.id+'/join','POST',{},'alice')).status,403);
  const duel=(await f.call('/matches','POST',{},'bob')).data;assert.equal((await f.call('/matches/'+duel.id+'/join','POST',{},'alice')).status,200);
  f.core.db.prepare('INSERT INTO penfight_points VALUES(?,?,?,?)').run(f.users.bob.id,30,1,1);
  await f.grant(['bob'],false);
  assert.equal((await f.call('/lobby','GET',undefined,'alice')).data.length,0);assert.equal((await f.call('/leaderboard','GET',undefined,'alice')).data.length,0);
  assert.equal((await f.call('/matches/'+waiting.id+'/join','POST',{},'alice')).status,403);
  const before=f.core.db.prepare('SELECT state FROM penfight_matches WHERE id=?').get(duel.id).state;
  assert.equal((await f.call('/matches/'+duel.id+'/shot','POST',{angle:0,power:.5},'alice')).status,403);
  assert.equal(f.core.db.prepare('SELECT state FROM penfight_matches WHERE id=?').get(duel.id).state,before);
  assert.equal(f.core.db.prepare('SELECT points FROM penfight_points WHERE user_id=?').get(f.users.bob.id).points,30);
 }finally{await f.close();}
});
test('player grants do not bypass attendance, disabled portal accounts or the global switch',async()=>{
 const f=await fixture();try{
  await f.grant(['alice','missing']);await f.call('/admin/access','PUT',{accessMode:'selected'});
  assert.equal((await f.call('/status','GET',undefined,'missing')).data.playerAllowed,true);
  const blocked=await f.call('/matches','POST',{mode:'solo'},'missing');assert.equal(blocked.status,403);assert.match(blocked.data.error,/attendance/);
  f.core.db.prepare('UPDATE users SET admin_blocked=1 WHERE id=?').run(f.users.alice.id);
  assert.equal((await f.call('/matches','POST',{},'alice')).status,403);assert.equal((await f.call('/admin/access')).data.users.find(u=>u.id===f.users.alice.id).playerAllowed,false);
  f.core.db.prepare('UPDATE users SET admin_blocked=0 WHERE id=?').run(f.users.alice.id);
  const cfg=(await f.call('/admin')).data;await f.call('/admin','PUT',{...cfg,enabled:false});assert.equal((await f.call('/matches','POST',{},'alice')).status,403);
  assert.equal((await f.call('/admin/access')).data.users.find(u=>u.id===f.users.alice.id).selected,true);
 }finally{await f.close();}
});
test('access mutations require admin, validate atomically and survive roster synchronization',async()=>{
 const f=await fixture();try{
  for(const method of ['GET','PUT'])assert.equal((await f.call('/admin/access',method,method==='PUT'?{accessMode:'selected'}:undefined,'alice')).status,403);
  assert.equal((await f.call('/admin/access/users','PATCH',{userIds:[f.users.bob.id],enabled:true},'alice')).status,403);
  assert.equal((await f.call('/admin/access','PUT',{accessMode:'invalid'})).status,400);
  for(const body of [{userIds:[],enabled:true},{userIds:['1'],enabled:true},{userIds:[f.users.alice.id],enabled:'true'},{userIds:[f.users.alice.id,99999],enabled:true}])assert.equal((await f.call('/admin/access/users','PATCH',body)).status,400);
  assert.equal(f.core.db.prepare('SELECT count(*) n FROM penfight_user_access').get().n,0);
  assert.equal((await f.call('/admin/access/users','PATCH',{userIds:[f.users.alice.id,f.users.alice.id,f.users.bob.id],enabled:true})).data.changed,2);
  f.core.applyRoster(f.rows.map(u=>({...u,name:u.name+' updated'})));
  assert.equal(f.core.db.prepare('SELECT count(*) n FROM penfight_user_access WHERE enabled=1').get().n,2);
  assert.equal(f.core.db.prepare("SELECT count(*) n FROM audit WHERE action='penfight.access.users'").get().n,1);
  await f.call('/admin/access','PUT',{accessMode:'selected'});await f.grant(['bob'],false);
  await f.call('/admin/access','PUT',{accessMode:'all'});assert.equal((await f.call('/status','GET',undefined,'bob')).data.playerAllowed,true);
  await f.call('/admin/access','PUT',{accessMode:'selected'});assert.equal((await f.call('/status','GET',undefined,'bob')).data.playerAllowed,false);
 }finally{await f.close();}
});
