import test from 'node:test';import assert from 'node:assert/strict';import {penDesign,penPairDesigns,PEN_PAIRS,DEFAULT_PEN_PAIR} from '../src/pen-designs.js';
test('users retain distinct pen colours and stable ballpoint models; bot has its own pen',()=>{for(let id=1;id<=200;id++){assert.deepEqual(penDesign(id),penDesign(id));assert.notEqual(penDesign(id).accent,penDesign(id+1).accent);assert.ok(penDesign(id).model>=0&&penDesign(id).model<4);}assert.notDeepEqual(penDesign(1),penDesign('bot'));});

test('capped pairs are distinct, stable and do not depend on player identity',()=>{
 for(const pair of PEN_PAIRS.filter(p=>p.id!=='personalized')){
  const pens=penPairDesigns(pair.id,1,'bot');assert.equal(pens.length,2);assert.notEqual(pens[0].label,pens[1].label);
  assert.ok(pens.every(p=>p.capped&&p.pairId===pair.id));assert.deepEqual(pens,penPairDesigns(pair.id,200,399));
 }
 const defaults=penPairDesigns(DEFAULT_PEN_PAIR,1,2);assert.equal(defaults[0].barrel,'blue');assert.equal(defaults[1].barrel,'ivory');
 assert.deepEqual(penPairDesigns('personalized',1,'bot'),[penDesign(1),penDesign('bot')]);
 assert.deepEqual(penPairDesigns(undefined,1,'bot'),[penDesign(1),penDesign('bot')]);
});
