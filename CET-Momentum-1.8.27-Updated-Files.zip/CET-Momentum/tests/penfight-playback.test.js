import test from 'node:test';
import assert from 'node:assert/strict';
import {playMotion,motionSample} from '../src/penfight-playback.js';

function rig(){
 let now=0,show=true,id=0;const timers=new Map(),frames=new Map(),samples=[];let completed;
 const stop=playMotion({duration:3200,onTick:t=>samples.push(t),onComplete:s=>completed=s,
  clock:()=>now,visible:()=>show,requestFrame:fn=>{frames.set(++id,fn);return id;},cancelFrame:i=>frames.delete(i),
  setTimer:fn=>{timers.set(++id,fn);return id;},clearTimer:i=>timers.delete(i)});
 return {samples,stop,timers,frames,get completed(){return completed;},hide:()=>show=false,show:()=>show=true,
  step(ms=16,fallback=false){now+=ms;const callback=(fallback?timers:frames).values().next().value;assert.ok(callback);callback();}};
}
test('RAF and timer share one timeline, finish once and leave no callbacks',()=>{
 const r=rig();r.step();assert.equal(r.timers.size,1);assert.equal(r.frames.size,1);
 while(!r.completed)r.step();assert.equal(r.samples.at(-1),3200);assert.equal(r.completed.timerFrames,0);
 assert.equal(r.timers.size,0);assert.equal(r.frames.size,0);r.stop();
});
test('timer fallback completes playback if requestAnimationFrame never calls back',()=>{
 const r=rig();while(!r.completed)r.step(48,true);assert.equal(r.samples.at(-1),3200);
 assert.equal(r.completed.timerFrames,r.completed.frames);assert.equal(r.frames.size,0);
});
test('a long delayed frame cannot skip the fall and hidden-tab time is paused',()=>{
 const r=rig();r.step(950);assert.equal(r.samples.at(-1),80);
 r.hide();r.step(6000,true);const before=r.samples.at(-1);r.show();r.step(6000,true);assert.equal(r.samples.at(-1),before);
 while(!r.completed)r.step();assert.ok(r.completed.clampedGaps>=2);assert.equal(r.completed.hiddenTicks,1);
});
test('cancelling playback removes both schedulers without completion',()=>{
 const r=rig();r.step();r.stop();assert.equal(r.frames.size,0);assert.equal(r.timers.size,0);assert.equal(r.completed,undefined);
});
test('interpolation shows motion, rolling, falling, landing, then authoritative final pens',()=>{
 const start={x:0,y:0,angle:0,roll:0},end={x:100,y:20,angle:2,roll:8};
 const motion={frames:[[start],[end]],fall:{durationMs:3200}},final=[{x:300,y:200,angle:1,roll:0}];
 assert.deepEqual(motionSample(motion,475,final).pens,[{x:50,y:10,angle:1,roll:4}]);
 assert.equal(motionSample(motion,950+1850*.72,final).fall,.72);
 assert.equal(motionSample(motion,3199,final).done,false);
 assert.deepEqual(motionSample(motion,3200,final),{pens:final,index:-1,fall:0,done:true});
});
