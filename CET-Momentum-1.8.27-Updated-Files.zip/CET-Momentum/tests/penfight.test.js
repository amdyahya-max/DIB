import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,shot,computerShot,isOut,BOUNDARY,startingPens,roundResults,roundRules,tippingEdge} from '../server/penfight-engine.js';
test('Pen Fight creates a two-pen game with no points',()=>{const s=initialState();assert.equal(s.pens.length,2);assert.deepEqual(s.score,[0,0]);assert.equal(s.turn,0);});
test('Pen Fight accepts a legal shot and switches player when play continues',()=>{const state=initialState(),next=shot(state,0,0,0.5);assert.equal(state.turn,0);assert.equal(next.logs.length,1);assert.ok(next.turn===1||next.round>1);});
test('Pen Fight rejects out-of-turn shots and invalid strength',()=>{assert.throws(()=>shot(initialState(),1,0,0.5),/Not your turn/);assert.throws(()=>shot(initialState(),0,0,2),/Invalid shot/);});
test('best-of-five needs three wins and returns motion for both players',()=>{const s=initialState();s.score=[0,1];s.round=2;s.pens[0].y=36;const n=shot(s,0,-Math.PI/2,1);assert.deepEqual(n.score,[0,2]);assert.equal(n.status,'playing');assert.equal(n.round,3);assert.ok(n.motion.frames.length>1);const final=initialState();final.score=[0,2];final.round=3;final.pens[0].y=36;assert.equal(shot(final,0,-Math.PI/2,1).winner,1);});
test('rounds end after forty scoreless flicks so games cannot run indefinitely',()=>{let s=initialState();for(let i=0;i<200&&s.status==='playing';i++){// Keep both pens in the centre to test the round cap deterministically.
 s.pens=initialState().pens; s=shot(s,s.turn,0,.1);
 }assert.equal(s.status,'finished');assert.equal(s.round,5);assert.equal(s.winner,null);assert.ok(s.logs.length<=200);});

test('capsule impacts produce finite spin, trails and collision effects',()=>{const state=initialState();state.pens[1].x=400;state.pens[1].y=263;const next=shot(state,0,0,.65);assert.equal(next.logs[0].hit,true);assert.ok(next.motion.impacts.length>0);assert.ok(next.motion.frames.some(f=>Math.abs(f[1].angle-Math.PI)>.01));for(const frame of next.motion.frames)for(const pen of frame)for(const field of ['x','y','angle','vx','vy'])assert.ok(Number.isFinite(pen[field]));});
test('all computer levels choose legal moves without mutating the game',()=>{for(const level of ['easy','balanced','expert']){const state=initialState();state.turn=1;const before=structuredClone(state),move=computerShot(state,level);assert.ok(move.power>=.1&&move.power<=1);assert.ok(move.angle>=-Math.PI&&move.angle<=Math.PI);assert.deepEqual(state,before);const next=shot(state,1,move.angle,move.power);assert.equal(next.logs.length,1);assert.notEqual(next.logs[0].result,'point-0');}assert.throws(()=>computerShot(initialState()),/computer turn/);});

test('partial overhang and edge contact remain supported on all four edges',()=>{
 const p=initialState().pens[0];
 for(const q of [{x:35,y:250},{x:805,y:250},{x:180,y:35},{x:180,y:465},{x:850,y:250},{x:180,y:27}])assert.equal(isOut({...p,...q},true),false);
 assert.equal(isOut({...p,x:865,y:250},true),true);
 assert.equal(isOut({...p,x:-26,y:250},true),true);
 assert.equal(isOut({...p,y:26.9}),true);assert.equal(isOut({...p,y:473.1}),true);
 assert.equal(isOut({...p,x:180,y:15,angle:Math.PI/2}),false);
 const s=initialState();s.pens[1].x=805;s.pens[1].angle=0;
 const next=shot(s,0,Math.PI,.1);assert.equal(next.logs[0].result,'next');assert.deepEqual(next.score,[0,0]);assert.equal(next.pens[1].x,805);
});
test('configured target and round cap determine the winner; legacy games retain defaults',()=>{
 const s=initialState({maxRounds:7,winsToWin:4});s.score=[0,3];s.pens[0].y=43;const win=shot(s,0,-Math.PI/2,.1);assert.equal(win.status,'finished');assert.equal(win.winner,1);assert.deepEqual(win.rules,{maxRounds:7,winsToWin:4});
 const cap=initialState({maxRounds:2,winsToWin:2});cap.round=2;cap.score=[1,0];cap.pens[0].y=43;const draw=shot(cap,0,-Math.PI/2,.1);assert.equal(draw.status,'finished');assert.equal(draw.winner,null);
 const quick=initialState({maxRounds:1,winsToWin:1});quick.pens[0].y=43;assert.equal(shot(quick,0,-Math.PI/2,.1).status,'finished');
 const legacy=initialState();delete legacy.rules;assert.deepEqual(shot(legacy,0,0,.1).rules,{maxRounds:5,winsToWin:3});
});


test('rotated pen corner misses use the actual polygon, with the cap and nib footprint',()=>{
 const p={...initialState().pens[0],x:830,y:10,angle:Math.PI/4};
 assert.equal(isOut(p,true),true); // bounding boxes overlap, but polygon misses the corner
 for(const pair of ['classic-blue-white','classic-blue-red','premium-navy-burgundy']){
  const s=initialState();s.penPair=pair;s.pens[0]={...p,x:760,y:250};
  const n=shot(s,0,Math.PI/4,.1);assert.equal(n.logs[0].result,'next');assert.equal(n.penPair,pair);
 }
});
test('random starts stay safe and separate, with varied centres and angles each round',()=>{
 const layouts=new Set();
 for(let seed=0;seed<64;seed++)for(let round=1;round<=15;round++){
  const pens=startingPens(seed,round);assert.deepEqual(pens,startingPens(seed,round));
  for(const p of pens){assert.equal(isOut(p,true),false);assert.equal(p.vx,0);assert.equal(p.vy,0);assert.equal(p.av,0);assert.ok(p.angle>=-Math.PI&&p.angle<=Math.PI);}
  assert.ok(Math.hypot(pens[0].x-pens[1].x,pens[0].y-pens[1].y)>200);
  assert.equal(pens[0].x+pens[1].x,840);assert.equal(pens[0].y+pens[1].y,500);
  layouts.add(JSON.stringify(pens));
 }
 assert.equal(layouts.size,960);assert.notEqual(startingPens(123,1)[0].angle,startingPens(123,2)[0].angle);
});
function finishRound(s,winner){
 s=structuredClone(s);s.pens=initialState().pens;
 s.pens[1-winner].y=15;s.pens[winner].x=420;
 return shot(s,s.turn,0,.1);
}
test('all-round scoring allows a comeback and finishes only after the configured last round',()=>{
 let s=initialState({maxRounds:5,scoringMode:'all-rounds'},91);
 const starts=[s.pens];for(const [i,winner] of [0,0,1,1,1].entries()){
  s=finishRound(s,winner);assert.equal(s.rounds.length,i+1);assert.deepEqual(s.rounds[i].points,winner===0?[1,0]:[0,1]);assert.deepEqual(s.rounds[i].total,s.score);
  if(i<4){assert.equal(s.status,'playing');assert.equal(s.turn,(i+2)%2===1?0:1);assert.notDeepEqual(s.pens,starts.at(-1));assert.deepEqual(s.pens,startingPens(91,i+2));starts.push(s.pens);}
 }
 assert.equal(s.status,'finished');assert.equal(s.winner,1);assert.deepEqual(s.score,[2,3]);assert.deepEqual(s.rounds.map(r=>r.round),[1,2,3,4,5]);
});
test('an unreachable lead never ends an all-round match early',()=>{
 let s=initialState({maxRounds:5,scoringMode:'all-rounds'},30);
 for(let i=0;i<4;i++){s=finishRound(s,0);assert.equal(s.status,'playing');}
 s=finishRound(s,0);assert.equal(s.status,'finished');assert.deepEqual(s.score,[5,0]);
});
test('both pens out awards zero each and counts as a completed round; final equal totals draw',()=>{
 let s=initialState({maxRounds:3,scoringMode:'all-rounds'},13);s=finishRound(s,0);s=finishRound(s,1);
 s.pens=initialState().pens;s.pens.forEach(p=>p.y=15);s=shot(s,s.turn,0,.1);
 assert.equal(s.status,'finished');assert.equal(s.winner,null);assert.deepEqual(s.score,[1,1]);assert.deepEqual(s.rounds[2].points,[0,0]);assert.equal(s.rounds[2].reason,'both-out');
});
test('forty scoreless flicks draw a round, preserve zero points and rerandomise the next round',()=>{
 let s=initialState({maxRounds:2,scoringMode:'all-rounds'},16);
 for(let i=0;i<80;i++){s.pens=initialState().pens;s=shot(s,s.turn,0,.1);}
 assert.equal(s.status,'finished');assert.equal(s.winner,null);assert.deepEqual(s.score,[0,0]);assert.equal(s.rounds.length,2);assert.deepEqual(s.rounds.map(r=>r.shots),[40,40]);assert.ok(s.rounds.every(r=>r.reason==='shot-limit'));
});
test('all-round single-round and fifteen-round settings finish at their exact round count',()=>{
 for(const maxRounds of [1,15]){let s=initialState({maxRounds,scoringMode:'all-rounds'},4);for(let i=0;i<maxRounds;i++)s=finishRound(s,i%2);assert.equal(s.status,'finished');assert.equal(s.rounds.length,maxRounds);assert.deepEqual(s.rules,{maxRounds,scoringMode:'all-rounds'});}
});
test('random match CPU trials are repeatable and cannot alter the next-round layout or history',()=>{
 const s=initialState({maxRounds:5,scoringMode:'all-rounds'},17);s.turn=1;const before=structuredClone(s);
 for(const level of ['easy','balanced','expert']){assert.deepEqual(computerShot(s,level),computerShot(s,level));assert.deepEqual(s,before);}
});
test('old match rules and round results reconstruct without changing the saved history',()=>{
 const s={logs:[{result:'next'},{result:'point-0'},{result:'draw'},{result:'next'},{result:'point-1'}]};const before=structuredClone(s);
 assert.deepEqual(roundResults(s).map(r=>r.points),[[1,0],[0,0],[0,1]]);assert.deepEqual(roundResults(s).at(-1).total,[1,1]);assert.deepEqual(s,before);assert.deepEqual(roundRules({maxRounds:7,winsToWin:4}),{maxRounds:7,winsToWin:4});
});

test('grouped rounds count four contests, alternate starts equally and finish only after all five rounds',()=>{
 let s=initialState({maxRounds:5,scoringMode:'round-contests',contestsPerRound:4},17),previous=s.pens;
 const starts=[];for(let i=0;i<20;i++){
  starts.push(s.turn);const before=structuredClone(s);s=finishRound(s,i<8?0:1);assert.equal(before.contests.length,i);
  assert.equal(s.contests.length,i+1);assert.equal(s.rounds.length,Math.floor((i+1)/4));
  if(i<19){assert.equal(s.status,'playing');assert.equal(s.round,Math.floor((i+1)/4)+1);assert.equal(s.contest,(i+1)%4+1);assert.notDeepEqual(s.pens,previous);assert.deepEqual(s.pens,startingPens(17,i+2));previous=s.pens;}
 }
 assert.deepEqual(starts,Array.from({length:20},(_,i)=>i%2));assert.equal(s.status,'finished');assert.equal(s.winner,1);assert.deepEqual(s.score,[8,12]);
 assert.deepEqual(s.rounds.map(r=>r.points),[[4,0],[4,0],[0,4],[0,4],[0,4]]);assert.deepEqual(s.rounds.at(-1).total,s.score);
});
test('draws use up contests without points; a tied match finishes after the last contest',()=>{
 let s=initialState({maxRounds:1,scoringMode:'round-contests',contestsPerRound:4},4);
 s=finishRound(s,0);s=finishRound(s,1);assert.equal(s.round,1);assert.equal(s.contest,3);assert.deepEqual(s.roundScore,[1,1]);assert.equal(s.rounds.length,0);
 for(let i=0;i<2;i++){s.pens=initialState().pens;s.pens.forEach(p=>p.y=15);s=shot(s,s.turn,0,.1);}
 assert.equal(s.status,'finished');assert.equal(s.winner,null);assert.deepEqual(s.score,[1,1]);assert.equal(s.contests.length,4);assert.equal(s.rounds.length,1);assert.deepEqual(s.rounds[0].points,[1,1]);assert.equal(s.contests.at(-1).reason,'both-out');
});
test('scoreless limit draws one contest, rather than an entire grouped round',()=>{
 let s=initialState({maxRounds:1,scoringMode:'round-contests',contestsPerRound:2},1);
 for(let i=0;i<40;i++){s.pens=initialState().pens;s=shot(s,s.turn,0,.1);}
 assert.equal(s.round,1);assert.equal(s.contest,2);assert.equal(s.rounds.length,0);assert.equal(s.contests.length,1);assert.equal(s.contests[0].reason,'shot-limit');assert.equal(s.turn,1);assert.deepEqual(s.score,[0,0]);
});
test('even contest rules accept both limits, reject odd snapshots and preserve immutable CPU trials',()=>{
 for(const n of [2,4,20]){assert.equal(roundRules({scoringMode:'round-contests',contestsPerRound:n}).contestsPerRound,n);let s=initialState({maxRounds:1,scoringMode:'round-contests',contestsPerRound:n},2);for(let i=0;i<n;i++)s=finishRound(s,i%2);assert.equal(s.status,'finished');assert.deepEqual(s.score,[n/2,n/2]);}
 for(const n of [0,1,3,21,2.5])assert.equal(roundRules({scoringMode:'round-contests',contestsPerRound:n}).contestsPerRound,4);
 const s=initialState({scoringMode:'round-contests'},9);s.turn=1;const before=structuredClone(s);
 for(const level of ['easy','balanced','expert']){assert.deepEqual(computerShot(s,level),computerShot(s,level));assert.deepEqual(s,before);}
});

test('knockouts record losing pens and correct fall edges without mutating physics or granting extra points',()=>{
 for(const [edge,axis,value,angle] of [['left','x',80,Math.PI],['right','x',765,0],['top','y',42,-Math.PI/2],['bottom','y',460,Math.PI/2]]){
  const s=initialState({scoringMode:'round-contests'},19);s.pens=initialState().pens;s.pens[0][axis]=value;const before=structuredClone(s),n=shot(s,0,angle,.5);
  assert.deepEqual(s,before);assert.deepEqual(n.motion.fall.losers,[0]);assert.deepEqual(n.motion.fall.edges,[edge]);assert.equal(n.motion.fall.durationMs,3200);assert.deepEqual(n.score,[0,1]);assert.equal(n.contest,2);assert.equal(n.motion.frames.at(-1)[0][axis]===n.pens[0][axis],false);
 }
 const both=initialState();both.pens.forEach(p=>p.y=15);assert.deepEqual(shot(both,0,0,.1).motion.fall.losers,[0,1]);assert.equal(shot(initialState(),0,0,.1).motion.fall,undefined);
});

test('off-centre impulse creates opposite spin while a centre flick has no artificial torque',()=>{
 const s=initialState();s.pens[0]={...s.pens[0],x:420,y:250};s.pens[1]={...s.pens[1],x:150,y:100};
 const left=shot(s,0,Math.PI/2,.15,-.7),right=shot(s,0,Math.PI/2,.15,.7),centre=shot(s,0,Math.PI/2,.15,0);
 assert.ok(left.motion.frames[1][0].av<0);assert.ok(right.motion.frames[1][0].av>0);assert.equal(centre.motion.frames[1][0].av,0);
 assert.throws(()=>shot(s,0,0,.5,2),/Invalid hit position/);assert.throws(()=>shot(s,0,0,.5,NaN),/Invalid hit position/);
});
test('rolling phase follows lateral travel, while pure axial motion slides without rolling',()=>{
 const s=initialState();s.pens[0]={...s.pens[0],x:350,y:250};s.pens[1]={...s.pens[1],x:700,y:100};
 const lateral=shot(s,0,Math.PI/2,.1),axial=shot(s,0,0,.1),f=lateral.motion.frames[1][0];
 assert.ok(f.roll>0);assert.ok(Math.abs(f.roll-(f.y-250)/7)<1e-9);assert.equal(axial.motion.frames[1][0].roll,0);
 const again=shot(lateral,lateral.turn,0,.1);assert.equal(again.motion.frames[0][0].roll,lateral.pens[0].roll);
});
test('every knockout frame is fully unsupported; scoring waits past half-overhang',()=>{
 const s=initialState();s.pens[0].x=640;s.pens[1].x=770;s.pens[1].angle=0;
 const n=shot(s,0,0,.5);assert.equal(n.logs[0].hit,true);assert.equal(n.logs[0].result,'point-0');
 assert.ok(n.motion.frames.some(f=>f[1].x>805&&!isOut(f[1],true)));
 assert.equal(isOut(n.motion.frames.at(-1)[1],true),true);
});

// Uniform centre-of-mass balance is separate from complete geometric support loss.
test('mass centre beyond any edge tips until completely fallen; exactly half stays balanced',()=>{
 for(const [axis,edge,bound,outward] of [['x','left',35,-1],['x','right',805,1],['y','top',35,-1],['y','bottom',465,1]]){
  const s=initialState();s.pens[0]={...s.pens[0],x:420,y:250};s.pens[1]={...s.pens[1],x:650,y:250,angle:axis==='x'?0:Math.PI/2};s.pens[1][axis]=bound;
  assert.equal(tippingEdge(s.pens[1]),null);const stable=shot(s,0,0,.1);assert.deepEqual(stable.score,[0,0]);
  s.pens[1][axis]=bound+outward*15;assert.equal(isOut(s.pens[1]),false);assert.equal(tippingEdge(s.pens[1]),edge);
  const before=structuredClone(s),n=shot(s,0,0,.1);assert.deepEqual(s,before);assert.deepEqual(n.score,[1,0]);assert.ok(n.motion.frames.some(f=>f[1].tilt>0&&!isOut(f[1])));assert.equal(isOut(n.motion.frames.at(-1)[1]),true);assert.deepEqual(n.motion.fall.edges,[edge]);
 }
});
test('an inward nudge can recover a barely overbalanced pen before its fall',()=>{
 const s=initialState();s.pens[0].x=806;s.pens[1]={...s.pens[1],x:300,y:100};const n=shot(s,0,Math.PI,.1);assert.equal(n.logs.at(-1).result,'next');assert.ok(n.pens[0].x<805);assert.deepEqual(n.score,[0,0]);assert.equal(n.pens[0].tilt,0);
});
