import test from 'node:test';
import assert from 'node:assert/strict';
import {soundKey,loadSound,saveSound,motionSoundCues,fallSoundCues,PenFightSound} from '../src/penfight-sound.js';
import {FALL_START_MS,FALL_TRAVEL_MS,FLOOR_CONTACT,FLOOR_BOUNCES,fallHeight} from '../src/penfight-fall.js';
import {initialState,shot} from '../server/penfight-engine.js';

test('sound defaults off and is scoped independently to a user and portal path',()=>{
 const values=new Map(),storage={getItem:k=>values.get(k),setItem:(k,v)=>values.set(k,v)},a=soundKey(1,'/CETGamification/'),b=soundKey(2,'/CETGamification/');
 assert.equal(a,soundKey(1,'/cetgamification'));assert.equal(loadSound(storage,a),false);assert.notEqual(a,b);
 assert.equal(saveSound(storage,a,true),true);assert.equal(loadSound(storage,a),true);assert.equal(loadSound(storage,b),false);
 assert.equal(loadSound({getItem:()=>{throw Error('blocked');}},a),false);assert.equal(saveSound(null,a,true),false);
 assert.equal(saveSound(storage,a,false),true);assert.equal(loadSound(storage,a),false);assert.notEqual(a,soundKey(1,'/other-portal'));
});
function context(){
 const param=()=>({events:[],setValueAtTime(v,t){this.events.push({v,t});},exponentialRampToValueAtTime(v,t){this.events.push({v,t});}});
 const node=()=>({connect(){},disconnect(){this.disconnected=true;}});
 return {state:'suspended',currentTime:4,destination:{},sampleRate:44100,gains:[],oscillators:[],buffers:[],sources:[],async resume(){this.state='running';},async close(){this.state='closed';},
 createGain(){const n={...node(),gain:param()};this.gains.push(n);return n;},createBiquadFilter(){return {...node(),frequency:param(),Q:{value:0}};},
 createBuffer(channels,length,sampleRate){const data=new Float32Array(length),b={getChannelData:()=>data,length,sampleRate};this.buffers.push(b);return b;},createBufferSource(){const n={...node(),starts:[],stops:[],start(t){this.starts.push(t);},stop(t){this.stops.push(t);}};this.sources.push(n);return n;},
 createOscillator(){const n={...node(),frequency:param(),starts:[],stops:[],start(t){this.starts.push(t);},stop(t){this.stops.push(t);}};this.oscillators.push(n);return n;}};
}
test('muted audio creates no context; unmuting unlocks and louder hits follow power',async()=>{
 const c=context();let created=0;const audio=new PenFightSound(()=>{created++;return c;});assert.equal(audio.play('hit',1),false);assert.equal(created,0);
 await audio.unlock();audio.setEnabled(true);assert.equal(c.state,'running');audio.play('hit',.1);audio.play('hit',1);
 const peak=g=>Math.max(...g.gain.events.map(e=>e.v));assert.ok(peak(c.gains[1])>peak(c.gains[0])*3);assert.ok(peak(c.gains[1])<=.16);assert.equal(c.oscillators.length,2);
 assert.ok(c.oscillators[1].frequency.events[0].v>c.oscillators[0].frequency.events[0].v);assert.ok(c.oscillators.every(o=>o.starts.length===1&&o.stops[0]>o.starts[0]));
 audio.setEnabled(false);assert.ok(c.oscillators.every(o=>o.stops.length===2));assert.equal(audio.voices.size,0);assert.equal(audio.play('hit',1),false);audio.destroy();assert.equal(c.state,'closed');
});
test('rolling clicks are short and quiet, have bounded simultaneous voices and clean up',async()=>{
 const c=context(),audio=new PenFightSound(()=>c);await audio.unlock();audio.setEnabled(true);
 for(let i=0;i<12;i++)assert.equal(audio.play('roll',.65),true);assert.equal(audio.play('roll',.65),false);
 assert.ok(c.gains.every(g=>Math.max(...g.gain.events.map(e=>e.v))<.055));assert.ok(c.oscillators.every(o=>o.type==='triangle'&&o.stops[0]-o.starts[0]<.07));
 c.oscillators[0].onended();assert.equal(audio.voices.size,11);assert.equal(c.oscillators[0].disconnected,true);assert.equal(audio.play('hit',NaN),true);
 audio.stop();assert.equal(audio.voices.size,0);audio.destroy();
});
test('browser audio denial is reported and suspended audio never schedules nodes',async()=>{
 const audio=new PenFightSound(()=>{throw Error('denied');});await assert.rejects(()=>audio.unlock(),/denied/);
 const c=context();c.resume=async()=>{};const paused=new PenFightSound(()=>c);await assert.rejects(()=>paused.unlock(),/paused/);paused.setEnabled(true);assert.equal(paused.play('hit'),false);assert.equal(c.oscillators.length,0);paused.destroy();
});
test('motion cues track actual hits and rolling with slower, quieter clicks as velocity decays',()=>{
 const s=initialState();s.pens[0]={...s.pens[0],x:420,y:250};s.pens[1]={...s.pens[1],x:700,y:100};const lateral=shot(s,0,Math.PI/2,.25),cues=motionSoundCues(lateral.motion,.25),roll=cues.filter(c=>c.kind==='roll');
 assert.deepEqual(cues[0],{frame:0,kind:'flick',power:.25});assert.ok(roll.length>=2);assert.ok(roll.length<=10);assert.ok(roll.at(-1).power<roll[0].power);assert.ok(roll.every((c,i)=>!i||c.frame-roll[i-1].frame>=6));
 assert.ok(roll.at(-1).frame-roll.at(-2).frame>=roll[1].frame-roll[0].frame);
 const hit=initialState();hit.pens[1].x=400;hit.pens[1].y=263;const motion=shot(hit,0,0,.65).motion;assert.deepEqual(motionSoundCues(motion).filter(c=>c.kind==='hit').map(c=>c.frame),motion.impacts.map(c=>c.frame));
 assert.deepEqual(motionSoundCues(null),[]);assert.equal(motionSoundCues(shot(s,0,0,.1).motion).some(c=>c.kind==='roll'),false);
});

test('fall and floor contact sounds use noise, plastic knock and tile resonance with softer bounce power',async()=>{
 const c=context(),audio=new PenFightSound(()=>c);await audio.unlock();audio.setEnabled(true);assert.equal(audio.play('fall',.8),true);assert.equal(c.sources.length,1);assert.equal(c.oscillators.length,0);assert.ok(c.buffers[0].getChannelData(0).some(v=>v!==0));
 audio.stop();assert.equal(audio.play('floor',.8),true);assert.equal(audio.voices.size,3);assert.equal(c.sources.length,2);assert.equal(c.oscillators.length,2);assert.ok(c.oscillators[0].frequency.events[0].v<1100);assert.ok(c.oscillators[1].frequency.events[0].v>2300);assert.equal(c.oscillators[1].frequency.events.length,1);
 const peak=g=>Math.max(...g.gain.events.map(e=>e.v));const first=peak(c.gains[1]);audio.stop();audio.play('floor',.8*.16);assert.ok(peak(c.gains[4])<first*.2);audio.setEnabled(false);assert.equal(audio.voices.size,0);assert.ok(c.sources.every(s=>s.stops.length===2));assert.equal(audio.play('floor',1),false);audio.destroy();
});
test('fall cues align with the first visible floor contact and each diminishing bounce, once for a double fall',()=>{
 assert.deepEqual(fallSoundCues(null),[]);assert.deepEqual(fallSoundCues({frames:[]}),[]);
 const s=initialState();s.pens[0].y=15;const cues=fallSoundCues(shot(s,0,0,.1).motion);assert.equal(cues.length,4);assert.equal(cues[0].kind,'fall');assert.equal(cues[0].at,FALL_START_MS);assert.equal(cues[1].at,FALL_START_MS+FALL_TRAVEL_MS*FLOOR_CONTACT);
 for(const [i,t] of [FLOOR_CONTACT,...FLOOR_BOUNCES].entries()){assert.ok(Math.abs(fallHeight(t)-1)<1e-12);assert.equal(cues[i+1].at,FALL_START_MS+FALL_TRAVEL_MS*t);}assert.ok(cues[1].power>cues[2].power&&cues[2].power>cues[3].power);
 s.pens[1].y=15;assert.equal(fallSoundCues(shot(s,0,0,.1).motion).length,4);
});
test('visual fall accelerates toward the floor, bounces twice and rests without changing the scoring timeline',()=>{
 assert.equal(fallHeight(0),0);assert.equal(fallHeight(1),1);assert.equal(fallHeight(-1),0);assert.equal(fallHeight(2),1);assert.equal(fallHeight(FLOOR_CONTACT/2),.25);assert.ok(fallHeight(.8)<1);assert.ok(fallHeight(.925)<1);assert.ok(fallHeight(.8)<fallHeight(.925));assert.equal(fallHeight(.98),1);
 for(let i=0;i<=1000;i++)assert.ok(fallHeight(i/1000)>=0&&fallHeight(i/1000)<=1);assert.ok(FALL_START_MS+FALL_TRAVEL_MS*FLOOR_BOUNCES[1]<3200);
});
