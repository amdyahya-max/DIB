> Historical 1.8.13 integration notes. For this built 1.8.14 release, use deployment/UPDATE-1.8.14-PENFIGHT.md. The old inherited-dist warning below applies only to the earlier source-only package.

# CET Momentum 1.8.13 – Pen Fight Arena

## Base preservation
The original `CET-Momentum-Complete-Source-1.8.12-Helper-1.2.9.zip` remains unchanged and is NOT superseded as the **BASE (NO PEN GAME)** version. The Pen Fight release is a separate ZIP.

## Included
- Existing CET Momentum portal 1.8.12 source extended to 1.8.13; CET Helper remains 1.2.9 and is unmodified.
- New Pen Fight React page and CSS, hidden user menu until the administrator enables the module.
- Admin controls at top of Administration, default feature OFF.
- Authorized, authenticated player endpoints and database tables; game state calculated on server.
- Attendance check uses CET confirmations; scheduled workdays, holidays, joining date, leave and absence are excluded automatically via existing `core.eligible()`.
- Independent Pen Fight match points and leaderboard; no changes to CET Race credits.
- Default check start = first day of deployment month (stored when the new database tables are first created). Administrators should set the correct policy start date before enabling.
- Limit on challenges created daily per player. The app must be restarted after installation and portal frontend rebuilt.

## Deploy carefully
1. Back up the LIVE `storage` SQLite files, `data/CET_Users.xlsx`, and `.env` first; **do not replace** these with content from the ZIP.
2. Extract the Pen Fight-enabled ZIP to a NEW folder, without replacing the 1.8.12 base. Do not deploy over a running installation.
3. Copy deployment configuration, roster and production storage from your existing installation only after verified backups.
4. Install dependencies: `npm ci` (Node 24), then `npm run build`. **Important:** bundled `dist/` is inherited from the base ZIP and does not contain the new game until this command succeeds.
5. Run `npm test`, then launch in a staging environment using your existing deployment scripts.
6. In Administration, configure Pen Fight check start date and daily limit; enable the module. Until enabled no user can play and the user menu is hidden.
7. Test with two separate enrolled CET Helper user accounts (not admin demo users) and validate both authorized and missing-attendance cases.
8. Deploy during an approved window only after these checks pass. Existing IIS subpath and helper architecture are unchanged.

## Operational notes
- Opening an already-created game via `My matches` is supported. Existing live matches are saved in the existing SQLite DB alongside CET data.
- The game supports Quick Duel multiplayer; Squad Clash and Tournament were concept designs and are not implemented in this release.
- The server rechecks eligibility before creating, joining, viewing or taking shots; direct endpoint access cannot bypass attendance.
- Leaderboard access does not require attendance completion, but creating/joining/playing does.
- All database changes are additive. Config is stored in `penfight_config`; matches in `penfight_matches`; awards in `penfight_points`.
- Default Pen Fight state is OFF after first startup.
