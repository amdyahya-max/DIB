// Recorded in storage/logs/portal.log; no F12 or browser console is needed.
export function penFightDiagnostic(status,details={}){
 const payload={status,version:'1.8.27',...details,visibility:document.visibilityState,
  reducedMotion:window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  automaticMotion:true,css:[...document.querySelectorAll('link[rel="stylesheet"]')].map(l=>new URL(l.href).pathname.split('/').pop()).slice(0,2),browser:navigator.userAgent.slice(0,100)};
 const path=location.pathname.replace(/\/$/,'')+'/api/client-errors';
 fetch(path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({event:'penfight.diagnostics',page:location.pathname,message:JSON.stringify(payload)})}).catch(()=>{});
}
