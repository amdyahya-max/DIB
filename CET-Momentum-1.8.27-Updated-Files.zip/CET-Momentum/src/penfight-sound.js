// Entirely local sound. No audio assets, helper calls or server preferences.
import {FALL_START_MS,FALL_TRAVEL_MS,FLOOR_CONTACT,FLOOR_BOUNCES} from './penfight-fall.js';
export const soundKey=(userId,path='/')=>'cet:penfight:sound:v1:'+path.toLowerCase().replace(/\/$/,'')+':'+userId;
export function loadSound(storage,key){try{return storage.getItem(key)==='on';}catch{return false;}}
export function saveSound(storage,key,on){try{storage.setItem(key,on?'on':'off');return true;}catch{return false;}}
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function motionSoundCues(motion,power=.5){
 if(!motion?.frames?.length)return [];
 const cues=[{frame:0,kind:'flick',power:clamp(power,.1,1)}];
 for(const hit of motion.impacts||[])cues.push({frame:hit.frame,kind:'hit',power:clamp(hit.strength||0,.08,1)});
 let last=-10,phase=[0,0];const minGap=Math.max(2,Math.ceil((motion.frames.length-1)*.11));
 for(let i=1;i<motion.frames.length;i++){
  let strongest=0;
  for(let j=0;j<2;j++){const p=motion.frames[i][j],old=motion.frames[i-1][j],delta=Math.abs((p.roll||0)-(old.roll||0));phase[j]+=delta;if(phase[j]>=Math.PI*1.5){strongest=Math.max(strongest,Math.hypot(p.vx||0,p.vy||0));}}
  if(strongest>.35&&i-last>=minGap){cues.push({frame:i,kind:'roll',power:clamp(strongest/24,.12,.65)});last=i;phase=[0,0];}
 }
 return cues.sort((a,b)=>a.frame-b.frame);
}
export function fallSoundCues(motion){
 if(!motion?.fall?.losers?.length)return [];
 const frame=motion.frames?.at(-1)||[],speed=Math.max(...motion.fall.losers.map(i=>Math.hypot(frame[i]?.vx||0,frame[i]?.vy||0))),power=clamp(.55+speed/40,.55,1);
 // One combined impact for a simultaneous two-pen fall avoids doubling volume.
 return [{at:FALL_START_MS,kind:'fall',power},
  {at:FALL_START_MS+FALL_TRAVEL_MS*FLOOR_CONTACT,kind:'floor',power},
  ...FLOOR_BOUNCES.map((t,i)=>({at:FALL_START_MS+FALL_TRAVEL_MS*t,kind:'floor',power:power*(i?.16:.36)}))];
}
export class PenFightSound{
 constructor(makeContext=()=>{const C=globalThis.AudioContext||globalThis.webkitAudioContext;if(!C)throw Error('Audio is unavailable in this browser');return new C();}){this.makeContext=makeContext;this.enabled=false;this.context=null;this.voices=new Set();this.noiseSeed=7919;}
 async unlock(){if(!this.context)this.context=this.makeContext();if(this.context.state==='suspended')await this.context.resume();if(this.context.state!=='running')throw Error('Audio is paused by the browser');return true;}
 setEnabled(on){this.enabled=!!on;if(!on)this.stop();}
 play(kind,power=.5){
  const ctx=this.context;if(!this.enabled||globalThis.document?.hidden||ctx?.state!=='running'||this.voices.size>=12)return false;
  if(kind==='fall'||kind==='floor')return this.surface(kind,power);
  const p=clamp(Number.isFinite(power)?power:.5,.05,1),roll=kind==='roll',hit=kind==='hit',duration=roll?.048:hit?.12:.085,t=ctx.currentTime;
  const gain=ctx.createGain(),osc=ctx.createOscillator(),low=ctx.createBiquadFilter();osc.type=roll?'triangle':'sine';osc.frequency.setValueAtTime(roll?380+p*250:hit?650+p*850:430+p*550,t);osc.frequency.exponentialRampToValueAtTime(roll?140:hit?160:120,t+duration);
  low.type='lowpass';low.frequency.value=roll?1800:4500;gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(roll?.035+p*.025:.04+p*p*.12,t+.004);gain.gain.exponentialRampToValueAtTime(.0001,t+duration);
  osc.connect(low);low.connect(gain);gain.connect(ctx.destination);this.voices.add(osc);osc.onended=()=>{this.voices.delete(osc);osc.disconnect();low.disconnect();gain.disconnect();};osc.start(t);osc.stop(t+duration+.015);return true;
 }
 surface(kind,power){
  const ctx=this.context,p=clamp(Number.isFinite(power)?power:.6,.05,1),fall=kind==='fall',duration=fall?.24:.11,t=ctx.currentTime;
  if(this.voices.size+(fall?1:3)>12)return false;
  const buffer=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*duration),ctx.sampleRate),samples=buffer.getChannelData(0);let seed=++this.noiseSeed,smooth=0;
  for(let i=0;i<samples.length;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const white=seed/2147483648-1;smooth=.92*smooth+.08*white;samples[i]=fall?smooth*2.5:white*.8+smooth*.2;}
  const noise=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),gain=ctx.createGain();noise.buffer=buffer;filter.type=fall?'lowpass':'highpass';filter.Q.value=fall?.5:.7;
  filter.frequency.setValueAtTime(fall?1800:1700,t);if(fall)filter.frequency.exponentialRampToValueAtTime(650,t+duration);
  const envelope=(node,peak,life)=>{node.gain.setValueAtTime(.0001,t);node.gain.exponentialRampToValueAtTime(peak,t+(fall?.018:.0015));node.gain.exponentialRampToValueAtTime(.0001,t+life);};
  envelope(gain,fall?.017+p*.012:.09*p,duration);noise.connect(filter);filter.connect(gain);gain.connect(ctx.destination);this.track(noise,[filter,gain],t,duration);
  if(!fall){
   // Plastic barrel knock plus a short bright tile resonance; no musical sweep.
   for(const [type,freq,peak,life] of [['triangle',820+p*130,.06*p,.085],['sine',2380+p*170,.028*p,.135]]){
    const osc=ctx.createOscillator(),g=ctx.createGain();osc.type=type;osc.frequency.setValueAtTime(freq,t);envelope(g,peak,life);osc.connect(g);g.connect(ctx.destination);this.track(osc,[g],t,life);
   }
  }
  return true;
 }
 track(source,nodes,time,duration){this.voices.add(source);source.onended=()=>{this.voices.delete(source);source.disconnect();for(const node of nodes)node.disconnect();};source.start(time);source.stop(time+duration+.015);}
 stop(){for(const voice of this.voices){try{voice.stop();}catch{}}this.voices.clear();}
 destroy(){this.stop();this.enabled=false;this.context?.close().catch(()=>{});}
}
