import {FALL_START_MS,FALL_TRAVEL_MS} from './penfight-fall.js';

// Presentation only. The server remains authoritative for physics and scores.
export function motionSample(motion,elapsed,finalPens){
 const frames=motion.frames,duration=motion.fall?.durationMs||FALL_START_MS;
 const done=elapsed>=duration,progress=Math.min(1,elapsed/FALL_START_MS);
 const position=progress*(frames.length-1),index=Math.floor(position),blend=position-index;
 const next=frames[Math.min(index+1,frames.length-1)];
 const pens=done?finalPens:frames[index].map((p,i)=>Object.fromEntries(Object.entries(p).map(([key,value])=>[key,typeof value==='number'?value+((next[i][key]??value)-value)*blend:value])));
 return {pens,index:done?-1:index,fall:!done&&motion.fall?Math.max(0,Math.min(1,(elapsed-FALL_START_MS)/FALL_TRAVEL_MS)):0,done};
}

export function playMotion({duration,onTick,onComplete,clock=()=>performance.now(),visible=()=>!document.hidden,
 requestFrame=fn=>requestAnimationFrame(fn),cancelFrame=id=>cancelAnimationFrame(id),
 setTimer=(fn,ms)=>setTimeout(fn,ms),clearTimer=id=>clearTimeout(id)}){
 let stopped=false,frame=null,timer=null,last=clock(),elapsed=0,wasVisible=visible();
 const stats={frames:0,timerFrames:0,clampedGaps:0,maxGapMs:0,hiddenTicks:0};
 function clear(){if(frame!==null)cancelFrame(frame);if(timer!==null)clearTimer(timer);frame=timer=null;}
 function schedule(){
  try{frame=requestFrame(()=>tick(false));}catch{frame=null;}
  // One timer races one RAF; the winner cancels the other. No double timeline.
  timer=setTimer(()=>tick(true),wasVisible?48:160);
 }
 function tick(fallback){
  if(stopped)return;clear();const time=clock(),gap=Math.max(0,time-last);last=time;
  const showing=visible();
  if(!showing){stats.hiddenTicks++;wasVisible=false;schedule();return;}
  // Resume without consuming time spent in a background tab. Bound visible
  // stalls too, so a slow/RDP frame cannot skip the whole fall and landing.
  const delta=wasVisible?Math.min(gap,80):0;wasVisible=true;
  stats.maxGapMs=Math.max(stats.maxGapMs,Math.round(gap));if(delta<gap)stats.clampedGaps++;
  elapsed=Math.min(duration,elapsed+delta);stats.frames++;if(fallback)stats.timerFrames++;
  onTick(elapsed);
  if(elapsed>=duration){stopped=true;onComplete({...stats});return;}
  schedule();
 }
 schedule();
 return ()=>{stopped=true;clear();};
}
