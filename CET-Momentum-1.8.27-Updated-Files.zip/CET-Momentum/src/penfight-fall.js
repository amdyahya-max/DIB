// Shared visual/audio timeline; server scoring and the 3.2-second fall stay unchanged.
export const FALL_START_MS=950;
export const FALL_TRAVEL_MS=1850;
export const FLOOR_CONTACT=.72;
export const FLOOR_BOUNCES=[.88,.97];
export function fallHeight(progress){
 const t=Math.max(0,Math.min(1,progress));
 if(t<=FLOOR_CONTACT)return (t/FLOOR_CONTACT)**2;
 if(t<=FLOOR_BOUNCES[0])return 1-.11*Math.sin(Math.PI*(t-FLOOR_CONTACT)/(FLOOR_BOUNCES[0]-FLOOR_CONTACT));
 if(t<=FLOOR_BOUNCES[1])return 1-.035*Math.sin(Math.PI*(t-FLOOR_BOUNCES[0])/(FLOOR_BOUNCES[1]-FLOOR_BOUNCES[0]));
 return 1;
}
