import {useEffect} from 'react';
// Follow the actual toolbar height, loaded data and window size in every Admin list.
export function useAdminListSpace(ref){
 useEffect(()=>{
  const root=ref.current;if(!root)return;let frame;
  const measure=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{
   for(const list of root.querySelectorAll('.table-scroll,.pf-access-table-wrap')){
    const top=list.getBoundingClientRect().top+window.scrollY;
    list.style.setProperty('--admin-list-space',Math.max(220,window.innerHeight-top-42)+'px');
   }
  });};
  const observer=new MutationObserver(measure);observer.observe(root,{childList:true,subtree:true});
  const sizeObserver=new ResizeObserver(measure);sizeObserver.observe(root);
  window.addEventListener('resize',measure);measure();
  return()=>{cancelAnimationFrame(frame);observer.disconnect();sizeObserver.disconnect();window.removeEventListener('resize',measure);};
 },[ref]);
}
