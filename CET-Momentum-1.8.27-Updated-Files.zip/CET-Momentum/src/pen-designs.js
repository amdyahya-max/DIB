// Original CET designs; stable user IDs keep the same pen across sessions.
export function penDesign(userId){
 const bot=userId==='bot';let n=Number(userId);
 if(!Number.isFinite(n)){n=0;for(const c of String(userId))n=(n*31+c.charCodeAt(0))>>>0;}
 n=Math.abs(Math.trunc(n));const model=bot?2:(Math.max(1,n)-1)%4,hue=bot?37:Number(((n*137.508+75)%360).toFixed(3));
 return {model,hue,label:['CET Glide','CET Click','CET Chrome','CET Flow'][model],accent:`hsl(${hue} 65% 43%)`,light:`hsl(${hue} 85% 76%)`,dark:`hsl(${hue} 65% 24%)`,pale:`hsl(${hue} 70% 93%)`};
}

// Original CET capped-pen designs. The same pair is used by both participants,
// with equal length/width so a cosmetic setting cannot change the physics.
export const DEFAULT_PEN_PAIR='classic-blue-white';
export const PEN_PAIRS=Object.freeze([
 {id:DEFAULT_PEN_PAIR,name:'Classic blue & white',description:'Blue barrel + blue cover against white barrel + blue cover.'},
 {id:'classic-blue-red',name:'Classic blue & red',description:'White barrels with contrasting blue and red covers.'},
 {id:'premium-navy-burgundy',name:'Premium navy & burgundy',description:'Brushed silver barrels with navy and burgundy covers.'},
 {id:'personalized',name:'Existing personalised pens',description:'Keep the original per-user colours and pen models.'}
]);
export function penPairDesigns(pairId,user0,user1){
 if(pairId==='personalized'||!PEN_PAIRS.some(p=>p.id===pairId))return [penDesign(user0),penDesign(user1)];
 const blue={accent:'#155fc7',light:'#70b2ff',dark:'#09376e',pale:'#e7f1ff'},red={accent:'#bd283f',light:'#f28394',dark:'#65142b',pale:'#fff0f3'},navy={accent:'#233a60',light:'#7895b9',dark:'#101c36',pale:'#e9eef6'},burgundy={accent:'#73304f',light:'#ba7b97',dark:'#351025',pale:'#f8edf3'};
 const profiles=pairId==='premium-navy-burgundy'?[
  {...navy,barrel:'silver',label:'Silver · navy cover'}, {...burgundy,barrel:'silver',label:'Silver · burgundy cover'}
 ]:pairId==='classic-blue-red'?[
  {...blue,barrel:'ivory',label:'White · blue cover'}, {...red,barrel:'ivory',label:'White · red cover'}
 ]:[{...blue,barrel:'blue',label:'Blue · blue cover'}, {...blue,barrel:'ivory',label:'White · blue cover'}];
 return profiles.map((p,seat)=>({...p,model:seat,capped:true,pairId}));
}
