import crypto from 'node:crypto';
import {playerAccessRoutes} from './penfight-access.js';
import {DEFAULT_PEN_PAIR,PEN_PAIRS} from '../src/pen-designs.js';
import {initialState,shot,computerShot} from './penfight-engine.js';
import {dubaiNow,validDate} from './core.js';

export const dubaiDayStart=date=>new Date(date+'T00:00:00+04:00').toISOString();
export function penFightEligibility(core,u,cfg,now=new Date()) {
 const today=dubaiNow(now).date;
 const d=new Date(today+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-1);
 const cutoff=d.toISOString().slice(0,10),start=[cfg.startDate,u.joining_date||cfg.startDate].sort().at(-1);
 const found=new Set(core.db.prepare('SELECT date FROM attendance WHERE user_id=? AND date BETWEEN ? AND ?').all(u.id,start,cutoff).map(r=>r.date));
 const missing=[];
 for(let cursor=new Date(start+'T12:00:00Z'),end=new Date(cutoff+'T12:00:00Z');cursor<=end;cursor.setUTCDate(cursor.getUTCDate()+1)) {
  const date=cursor.toISOString().slice(0,10);
  if(core.eligible(u,date)&&!found.has(date))missing.push(date);
  if(missing.length>=40)break; // Limit response size, never grant access when the sample is incomplete.
 }
 return {ok:!missing.length,cutoff,start,missing,reason:missing.length?'Please confirm required attendance through yesterday before playing.':null};
}
export function penFightRoutes(router,core,auth,admin){
 const {db}=core;
 db.exec(`CREATE TABLE IF NOT EXISTS penfight_config (id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0, start_date TEXT NOT NULL, max_daily_matches INTEGER NOT NULL DEFAULT 5);
 CREATE TABLE IF NOT EXISTS penfight_matches(id TEXT PRIMARY KEY,player0 INTEGER NOT NULL REFERENCES users(id),player1 INTEGER REFERENCES users(id),state TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,awarded INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS penfight_points(user_id INTEGER PRIMARY KEY REFERENCES users(id),points INTEGER NOT NULL DEFAULT 0,wins INTEGER NOT NULL DEFAULT 0,played INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS penfight_player_tags(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,tag TEXT NOT NULL UNIQUE);
 CREATE INDEX IF NOT EXISTS ix_penfight_match_players ON penfight_matches(player0,player1,created_at);`);
 const columns=new Set(db.prepare('PRAGMA table_info(penfight_config)').all().map(c=>c.name));
 if(!columns.has('max_rounds'))db.exec('ALTER TABLE penfight_config ADD COLUMN max_rounds INTEGER NOT NULL DEFAULT 5');
 if(!columns.has('wins_to_win'))db.exec('ALTER TABLE penfight_config ADD COLUMN wins_to_win INTEGER NOT NULL DEFAULT 3');
 if(!columns.has('contests_per_round'))db.exec('ALTER TABLE penfight_config ADD COLUMN contests_per_round INTEGER NOT NULL DEFAULT 4');
 if(!columns.has('pen_pair'))db.exec(`ALTER TABLE penfight_config ADD COLUMN pen_pair TEXT NOT NULL DEFAULT '${DEFAULT_PEN_PAIR}'`);
 db.prepare('INSERT OR IGNORE INTO penfight_config(id,enabled,start_date,max_daily_matches) VALUES(1,0,?,5)').run(dubaiNow().month+'-01');
 const config=()=>({...db.prepare('SELECT access_mode AS accessMode,enabled,start_date AS startDate,max_daily_matches AS dailyLimit,max_rounds AS maxRounds,wins_to_win AS winsToWin,pen_pair AS penPair,contests_per_round AS contestsPerRound FROM penfight_config WHERE id=1').get(),scoringMode:'round-contests'});
 const {allowed,requirePlayer}=playerAccessRoutes(router,core,auth,admin,config);
 const audit=(u,a,v)=>core.audit(u.username,'penfight.'+a,v);
 const denied=(res,message,status=403)=>res.status(status).json({error:message});
 const gate=(req,res,next)=>config().enabled?next():denied(res,'Pen Fight is disabled by the administrator.');
 const eligibility=u=>penFightEligibility(core,u,config());
 const access=(req,res,next)=>{if(!allowed(req.user))return denied(res,'Pen Fight access has not been enabled for your account. Please contact the CET administrator.');const e=eligibility(req.user);if(!e.ok)return denied(res,e.reason);next();};
 const visible=(viewer,u)=>!!u&&core.active(u)&&(viewer.special||!u.special||viewer.id===u.id);
 const available=(viewer,u)=>visible(viewer,u)&&visible(u,viewer)&&allowed(u)&&eligibility(u).ok;
 const row=id=>db.prepare('SELECT * FROM penfight_matches WHERE id=?').get(id);
 const name=(id,u,fallback)=>{const p=core.user(id);return visible(u,p)?p.name:fallback;};
 const playerTag=id=>{
  const saved=db.prepare('SELECT tag FROM penfight_player_tags WHERE user_id=?').get(id);if(saved)return saved.tag;
  const person=core.user(id);if(!person)return '—';
  const words=(person.name||'').match(/[\p{L}\p{N}]+/gu)||['P'];
  const base=(Array.from(words[0])[0]+(words.length>1?Array.from(words.at(-1))[0]:'')).toLocaleUpperCase('en');
  let tag=base,n=1;while(tag==='BOT'||db.prepare('SELECT 1 FROM penfight_player_tags WHERE tag=?').get(tag))tag=base+(++n);
  db.prepare('INSERT INTO penfight_player_tags(user_id,tag) VALUES(?,?)').run(id,tag);return tag;
 };
 // Persist tags by user ID. Import order and page refresh cannot change a player's tag.
 for(const person of db.prepare('SELECT id FROM users ORDER BY id').all())playerTag(person.id);
 const visibleTag=(id,u)=>visible(u,core.user(id))?playerTag(id):'—';
 const solo=m=>JSON.parse(m.state).mode==='solo';
 const present=(m,u)=>({id:m.id,player0:m.player0,player1:m.player1,player0Name:name(m.player0,u,'Private participant'),player0Tag:visibleTag(m.player0,u),player1Tag:solo(m)?'BOT':m.player1?visibleTag(m.player1,u):'—',player1Name:solo(m)?'CET Bot':m.player1?name(m.player1,u,'Private participant'):'Waiting for opponent',me:m.player0===u.id?0:1,state:JSON.parse(m.state)});
 router.get('/api/penfight/status',auth,(req,res)=>{const c=config();res.json({enabled:!!c.enabled,playerAllowed:allowed(req.user),accessMode:c.accessMode,admin:!!req.user.admin,penPair:c.penPair,eligibility:c.enabled?eligibility(req.user):null,rules:{maxRounds:c.maxRounds,scoringMode:c.scoringMode,contestsPerRound:c.contestsPerRound},config:req.user.admin?c:undefined});});
 router.get('/api/penfight/admin',auth,admin,(req,res)=>res.json({...config(),matches:db.prepare('SELECT COUNT(*) count FROM penfight_matches').get().count,completed:db.prepare('SELECT COUNT(*) count FROM penfight_matches WHERE awarded=1').get().count}));
 router.put('/api/penfight/admin',auth,admin,(req,res)=>{const b=req.body||{},c=config(),maxRounds=b.maxRounds??c.maxRounds,penPair=b.penPair??c.penPair,contestsPerRound=b.contestsPerRound??c.contestsPerRound;if(!Number.isInteger(contestsPerRound)||contestsPerRound<2||contestsPerRound>20||contestsPerRound%2!==0)return denied(res,'Scoring contests per round must be an even whole number from 2 to 20.',400);if(!PEN_PAIRS.some(p=>p.id===penPair))return denied(res,'Choose a valid pen pair.',400);if(!Number.isInteger(maxRounds)||maxRounds<1||maxRounds>15)return denied(res,'Rounds per match must be a whole number from 1 to 15.',400);if(typeof b.enabled!=='boolean'||!validDate(b.startDate)||b.startDate>dubaiNow().date||!Number.isInteger(b.dailyLimit)||b.dailyLimit<1||b.dailyLimit>30)return denied(res,'Choose a valid checking start date through today and a daily challenge limit of 1 to 30.',400);db.prepare('UPDATE penfight_config SET enabled=?,start_date=?,max_daily_matches=?,max_rounds=?,pen_pair=?,contests_per_round=? WHERE id=1').run(+b.enabled,b.startDate,b.dailyLimit,maxRounds,penPair,contestsPerRound);audit(req.user,'settings',{before:c,after:config()});res.json({...config(),matches:db.prepare('SELECT COUNT(*) count FROM penfight_matches').get().count,completed:db.prepare('SELECT COUNT(*) count FROM penfight_matches WHERE awarded=1').get().count});});
 router.get('/api/penfight/lobby',auth,gate,access,(req,res)=>res.json(db.prepare("SELECT id,player0,created_at FROM penfight_matches WHERE player1 IS NULL AND COALESCE(json_extract(state,'$.mode'),'duel')='duel' AND json_extract(state, '$.status')='playing' ORDER BY created_at DESC").all().filter(r=>r.player0!==req.user.id&&available(req.user,core.user(r.player0))).slice(0,30).map(r=>({...r,name:core.user(r.player0).name,tag:playerTag(r.player0)}))));
 router.get('/api/penfight/leaderboard',auth,gate,requirePlayer,(req,res)=>res.json(db.prepare('SELECT p.user_id AS id,u.name,p.points,p.wins,p.played FROM penfight_points p JOIN users u ON u.id=p.user_id ORDER BY p.points DESC,p.wins DESC,u.name').all().filter(r=>visible(req.user,core.user(r.id))&&allowed(core.user(r.id))).slice(0,50).map(r=>({...r,tag:playerTag(r.id)}))));
 router.get('/api/penfight/my-matches',auth,gate,access,(req,res)=>res.json(db.prepare('SELECT id,player0,player1,state FROM penfight_matches WHERE player0=? OR player1=? ORDER BY created_at DESC LIMIT 20').all(req.user.id,req.user.id).map(m=>present(m,req.user))));
 router.get('/api/penfight/open-games',auth,gate,(req,res)=>res.json(
  db.prepare("SELECT id,player0,player1,state,created_at,updated_at FROM penfight_matches WHERE (player0=? OR player1=?) AND json_extract(state,'$.status')='playing' ORDER BY updated_at DESC,id").all(req.user.id,req.user.id).map(m=>{
   const game=present(m,req.user),s=game.state;
   return {...game,createdAt:m.created_at,updatedAt:m.updated_at,state:{status:s.status,mode:s.mode||'duel',difficulty:s.difficulty,round:s.round,score:s.score,rules:s.rules,turn:s.turn}};
  })
 ));
 router.post('/api/penfight/matches',auth,gate,access,(req,res)=>{const mode=req.body?.mode||'duel',difficulty=req.body?.difficulty||'balanced';if(!['duel','solo'].includes(mode)||!['easy','balanced','expert'].includes(difficulty))return denied(res,'Choose a valid game mode and computer level.',400);const c=config();const count=db.prepare('SELECT COUNT(*) count FROM penfight_matches WHERE player0=? AND created_at>=?').get(req.user.id,dubaiDayStart(dubaiNow().date)).count;if(count>=c.dailyLimit)return denied(res,'Daily challenge limit reached. Return tomorrow!',429);const id=crypto.randomUUID(),now=new Date().toISOString();db.prepare('INSERT INTO penfight_matches(id,player0,state,created_at,updated_at) VALUES(?,?,?,?,?)').run(id,req.user.id,JSON.stringify({...initialState({maxRounds:c.maxRounds,scoringMode:c.scoringMode,contestsPerRound:c.contestsPerRound},crypto.randomBytes(4).readUInt32LE()),penPair:c.penPair,mode,difficulty:mode==='solo'?difficulty:undefined}),now,now);audit(req.user,'create',{id});res.status(201).json(present(row(id),req.user));});
 router.post('/api/penfight/matches/:id/cancel',auth,gate,(req,res)=>{
  const m=row(req.params.id);if(!m)return denied(res,'Match not found.',404);
  if(![m.player0,m.player1].includes(req.user.id))return denied(res,'Only a participant can end this game.');
  const state=JSON.parse(m.state);if(state.status!=='playing'||m.awarded)return denied(res,'This game is no longer open.',409);
  const now=new Date().toISOString();state.status='cancelled';state.endedBy=req.user.id;state.endedAt=now;
  db.exec('BEGIN IMMEDIATE');try{
   const changed=db.prepare('UPDATE penfight_matches SET state=?,updated_at=? WHERE id=? AND state=? AND awarded=0').run(JSON.stringify(state),now,m.id,m.state);
   if(!changed.changes){db.exec('ROLLBACK');return denied(res,'The game has changed. Refresh and try again.',409);}
   audit(req.user,'cancel',{id:m.id,mode:solo(m)?'solo':'duel',joined:!!m.player1});db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');return denied(res,e.message,409);}
  res.json({ok:true});
 });
 router.post('/api/penfight/matches/:id/join',auth,gate,access,(req,res)=>{const m=row(req.params.id);if(!m)return denied(res,'Match not found.',404);if(solo(m)||m.player0===req.user.id||m.player1||JSON.parse(m.state).status!=='playing')return denied(res,'Challenge not available.',409);if(!available(req.user,core.user(m.player0)))return denied(res,'This challenge is no longer available.');const joined=db.prepare("UPDATE penfight_matches SET player1=?,updated_at=? WHERE id=? AND player1 IS NULL AND json_extract(state,'$.status')='playing'").run(req.user.id,new Date().toISOString(),m.id);if(!joined.changes)return denied(res,'Challenge no longer available.',409);audit(req.user,'join',{id:m.id});res.json(present(row(m.id),req.user));});
 router.get('/api/penfight/matches/:id',auth,gate,access,(req,res)=>{const m=row(req.params.id);if(!m)return denied(res,'Match not found.',404);if(![m.player0,m.player1].includes(req.user.id))return denied(res,'Not a participant.');res.json(present(m,req.user));});
 const commit=(m,next,u,player,res)=>{
  db.exec('BEGIN IMMEDIATE');try{
   const current=row(m.id);if(current.state!==m.state||current.awarded)throw Error('Match already updated. Refresh and try again.');
   db.prepare('UPDATE penfight_matches SET state=?,updated_at=? WHERE id=?').run(JSON.stringify(next),new Date().toISOString(),m.id);
   if(next.status==='finished'){
    db.prepare('UPDATE penfight_matches SET awarded=1 WHERE id=?').run(m.id);
    // Solo is practice: never award competitive points or create a synthetic user.
    if(!solo(m))for(let i=0;i<2;i++){const id=i===0?m.player0:m.player1,win=next.winner===i;db.prepare('INSERT INTO penfight_points(user_id,points,wins,played) VALUES(?,?,?,1) ON CONFLICT(user_id) DO UPDATE SET points=points+excluded.points,wins=wins+excluded.wins,played=played+1').run(id,win?30:10,+win);}
   }
   audit(u,'shot',{id:m.id,mode:solo(m)?'solo':'duel',player,finished:next.status==='finished'});db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');return denied(res,e.message,409);}
  res.json(present(row(m.id),u));
 };
 router.post('/api/penfight/matches/:id/shot',auth,gate,access,(req,res)=>{
  const m=row(req.params.id);if(!m)return denied(res,'Match not found.',404);
  if(![m.player0,m.player1].includes(req.user.id)||(!solo(m)&&!m.player1))return denied(res,'Both players must join.',409);
  if(!solo(m)&&!available(req.user,core.user(m.player0===req.user.id?m.player1:m.player0)))return denied(res,'Your opponent is no longer eligible.');
  const player=m.player0===req.user.id?0:1,b=req.body||{},state=JSON.parse(m.state);let next;
  if(b.expectedShot!==undefined&&b.expectedShot!==state.logs.length)return denied(res,'The game has moved on. Refresh and try again.',409);
  try{next=shot(state,player,b.angle,b.power,b.hitOffset??0);}catch(e){return denied(res,e.message,409);}commit(m,next,req.user,player,res);
 });
 router.post('/api/penfight/matches/:id/computer',auth,gate,access,(req,res)=>{
  const m=row(req.params.id);if(!m)return denied(res,'Match not found.',404);
  if(!solo(m)||m.player0!==req.user.id)return denied(res,'This is not your solo game.');
  const state=JSON.parse(m.state);if(req.body?.expectedShot!==state.logs.length)return denied(res,'The game has moved on. Refresh and try again.',409);
  let next;try{const aim=computerShot(state,state.difficulty);next=shot(state,1,aim.angle,aim.power,aim.hitOffset);}catch(e){return denied(res,e.message,409);}commit(m,next,req.user,1,res);
 });
}
