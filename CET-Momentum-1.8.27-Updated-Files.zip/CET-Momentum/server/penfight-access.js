// Game permission is separate from portal access, administrator role and attendance.
export function playerAccessRoutes(router,core,auth,admin,config){
 const {db}=core;
 const columns=db.prepare('PRAGMA table_info(penfight_config)').all();
 if(!columns.some(c=>c.name==='access_mode'))db.exec("ALTER TABLE penfight_config ADD COLUMN access_mode TEXT NOT NULL DEFAULT 'all' CHECK(access_mode IN('all','selected'))");
 db.exec(`CREATE TABLE IF NOT EXISTS penfight_user_access(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN(0,1)),updated_at TEXT NOT NULL,updated_by TEXT NOT NULL)`);
 const allowed=u=>!!u&&core.active(u)&&(config().accessMode==='all'||!!db.prepare('SELECT enabled FROM penfight_user_access WHERE user_id=?').get(u.id)?.enabled);
 const requirePlayer=(req,res,next)=>allowed(req.user)?next():res.status(403).json({error:'Pen Fight access has not been enabled for your account. Please contact the CET administrator.'});
 const roster=()=>{
  const c=config();
  return {enabled:!!c.enabled,accessMode:c.accessMode,users:db.prepare(`SELECT u.*,COALESCE(a.enabled,0) AS game_enabled,a.updated_at AS game_updated_at
   FROM users u LEFT JOIN penfight_user_access a ON a.user_id=u.id WHERE u.roster_active=1 ORDER BY u.name COLLATE NOCASE,u.id`).all().map(u=>({
    id:u.id,name:u.name,username:u.username,email:u.email||'',company:u.company||'',admin:!!u.admin,
    portalStatus:core.accessStatus(u),selected:!!u.game_enabled,
    playerAllowed:allowed(u),updatedAt:u.game_updated_at||null
   }))};
 };
 router.get('/api/penfight/admin/access',auth,admin,(req,res)=>res.json(roster()));
 router.put('/api/penfight/admin/access',auth,admin,(req,res)=>{
  const mode=req.body?.accessMode;if(!['all','selected'].includes(mode))return res.status(400).json({error:'Choose All eligible users or Selected players only.'});
  const before=config().accessMode;
  db.exec('BEGIN IMMEDIATE');try{
   db.prepare('UPDATE penfight_config SET access_mode=? WHERE id=1').run(mode);
   core.audit(req.user.username,'penfight.access.policy',{before,after:mode});db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  res.json(roster());
 });
 router.patch('/api/penfight/admin/access/users',auth,admin,(req,res)=>{
  const b=req.body||{};
  if(typeof b.enabled!=='boolean'||!Array.isArray(b.userIds)||!b.userIds.length||b.userIds.length>1000||b.userIds.some(id=>!Number.isSafeInteger(id)||id<1))return res.status(400).json({error:'Select 1 to 1,000 users and an enable or disable action.'});
  const ids=[...new Set(b.userIds)],users=ids.map(id=>core.user(id));
  if(users.some(u=>!u||!u.roster_active))return res.status(400).json({error:'One or more selected users are no longer in the roster. Refresh and select again.'});
  const now=new Date().toISOString(),upsert=db.prepare(`INSERT INTO penfight_user_access VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,updated_at=excluded.updated_at,updated_by=excluded.updated_by`);
  db.exec('BEGIN IMMEDIATE');try{
   for(const id of ids)upsert.run(id,+b.enabled,now,req.user.username);
   core.audit(req.user.username,'penfight.access.users',{userIds:ids,enabled:b.enabled});db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  res.json({...roster(),changed:ids.length});
 });
 return {allowed,requirePlayer};
}
