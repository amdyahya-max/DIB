import {PEN_PAIRS} from '../src/pen-designs.js';
// Physical tabletop coordinates, also used by the perspective renderer. No scoring line.
export const BOUNDARY=Object.freeze({left:35,right:805,top:35,bottom:465});
export function roundRules(value={}){
 const maxRounds=Number.isInteger(value.maxRounds)&&value.maxRounds>=1&&value.maxRounds<=15?value.maxRounds:5;
 if(value.scoringMode==='round-contests')return {maxRounds,scoringMode:'round-contests',contestsPerRound:Number.isInteger(value.contestsPerRound)&&value.contestsPerRound>=2&&value.contestsPerRound<=20&&value.contestsPerRound%2===0?value.contestsPerRound:4};
 if(value.scoringMode==='all-rounds')return {maxRounds,scoringMode:'all-rounds'};
 // Existing match snapshots keep their original first-to rules.
 return {maxRounds,winsToWin:Number.isInteger(value.winsToWin)&&value.winsToWin>=1&&value.winsToWin<=maxRounds?value.winsToWin:Math.min(3,maxRounds)};
}
export function penFootprint(p,capped=false){
 const c=Math.cos(p.angle),s=Math.sin(p.angle);
 return (capped?[[-55,-8],[60,-8],[60,8],[-55,8]]:[[-55,-8],[43,-8],[60,0],[43,8],[-55,8]]).map(([x,y])=>({x:p.x+x*c-y*s,y:p.y+x*s+y*c}));
}
export function penBounds(p,capped=false){
 const points=penFootprint(p,capped);
 return {left:Math.min(...points.map(q=>q.x)),right:Math.max(...points.map(q=>q.x)),top:Math.min(...points.map(q=>q.y)),bottom:Math.max(...points.map(q=>q.y))};
}
export function isOut(p,capped=false){
 // Separating-axis test against the tabletop. Any overlap (even edge contact)
 // is geometric contact; tippingEdge separately tests balance. Rotated corner
 // misses are not approximated with an AABB.
 const pen=penFootprint(p,capped),table=[{x:BOUNDARY.left,y:BOUNDARY.top},{x:BOUNDARY.right,y:BOUNDARY.top},{x:BOUNDARY.right,y:BOUNDARY.bottom},{x:BOUNDARY.left,y:BOUNDARY.bottom}];
 const axes=[{x:1,y:0},{x:0,y:1},...pen.map((q,i)=>{const n=pen[(i+1)%pen.length];return {x:-(n.y-q.y),y:n.x-q.x};})];
 return axes.some(axis=>{const a=pen.map(q=>q.x*axis.x+q.y*axis.y),b=table.map(q=>q.x*axis.x+q.y*axis.y);return Math.max(...a)<Math.min(...b)-1e-7||Math.max(...b)<Math.min(...a)-1e-7;});
}
// Uniform-barrel centre of mass approximation: half-overhang balances at the edge.
export function tippingEdge(p){return p.x<BOUNDARY.left?'left':p.x>BOUNDARY.right?'right':p.y<BOUNDARY.top?'top':p.y>BOUNDARY.bottom?'bottom':null;}
const usesCover=state=>PEN_PAIRS.some(p=>p.id===state.penPair&&p.id!=='personalized');
const legacyPens=()=>[{x:180,y:250,angle:0,vx:0,vy:0,av:0,roll:0,tilt:0},{x:660,y:250,angle:Math.PI,vx:0,vy:0,av:0,roll:0,tilt:0}];
export function startingPens(seed,round=1){
 // A per-match seed is selected by the server. Pure round generation keeps
 // CPU trial shots deterministic and never rerolls a layout on refresh.
 let n=((seed>>>0)^Math.imul(round,0x9e3779b9))>>>0;
 const random=()=>{n=(n+0x6d2b79f5)>>>0;let t=n;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};
 const x=130+random()*170,y=125+random()*250;
 const make=(x,y)=>({x,y,angle:(random()*2-1)*Math.PI,vx:0,vy:0,av:0,roll:0,tilt:0});
 // Mirrored centres have equal distance to the table edges, with ample space
 // between pens. Independent angles avoid the old straight head-to-head reset.
 return [make(x,y),make(840-x,500-y)];
}
export function initialState(rules={},seed=(Math.random()*4294967296)>>>0){
 const normalized=roundRules(rules),random=!!normalized.scoringMode;
 return {rules:normalized,...(normalized.scoringMode==='round-contests'?{contest:1,roundScore:[0,0],contests:[]}:{}),...(random?{layoutSeed:seed>>>0,placement:'random',rounds:[]}:{}),pens:random?startingPens(seed,1):legacyPens(),round:1,score:[0,0],turn:0,status:'playing',winner:null,logs:[]};
}
export function roundResults(state){
 if(Array.isArray(state.rounds))return state.rounds;
 // Reconstruct old saved match histories without modifying their results.
 const rounds=[],total=[0,0];let count=0;
 for(const log of state.logs||[]){count++;if(log.result==='next')continue;
  const winner=log.result==='point-0'?0:log.result==='point-1'?1:null,points=[0,0];
  if(winner!==null){points[winner]=1;total[winner]++;}
  rounds.push({round:rounds.length+1,points,total:[...total],winner,reason:winner===null?'draw':'out',shots:count});count=0;
 }
 return rounds;
}
function contacts(a,b){
 // Find the closest points on the two pen capsules (110px barrels, 9px radius).
 const ends=p=>[-1,1].map(k=>({x:p.x+k*55*Math.cos(p.angle),y:p.y+k*55*Math.sin(p.angle)}));
 const [a0,a1]=ends(a),[b0,b1]=ends(b);
 const project=(p,u,v)=>{const dx=v.x-u.x,dy=v.y-u.y,t=Math.max(0,Math.min(1,((p.x-u.x)*dx+(p.y-u.y)*dy)/(dx*dx+dy*dy)));return {x:u.x+t*dx,y:u.y+t*dy};};
 const pairs=[[a0,project(a0,b0,b1)],[a1,project(a1,b0,b1)],[project(b0,a0,a1),b0],[project(b1,a0,a1),b1]];
 const ax=a1.x-a0.x,ay=a1.y-a0.y,bx=b1.x-b0.x,by=b1.y-b0.y,den=ax*by-ay*bx;
 if(Math.abs(den)>1e-6){const dx=b0.x-a0.x,dy=b0.y-a0.y,t=(dx*by-dy*bx)/den,u=(dx*ay-dy*ax)/den;if(t>=0&&t<=1&&u>=0&&u<=1){const p={x:a0.x+t*ax,y:a0.y+t*ay};pairs.push([p,p]);}}
 return pairs.sort((p,q)=>Math.hypot(p[1].x-p[0].x,p[1].y-p[0].y)-Math.hypot(q[1].x-q[0].x,q[1].y-q[0].y))[0];
}
export function shot(state,player,angle,power,hitOffset=0){
 if(state.status!=='playing'||player!==state.turn)throw Error('Not your turn');
 if(!Number.isFinite(hitOffset)||Math.abs(hitOffset)>1)throw Error('Invalid hit position');
 if(!Number.isFinite(angle)||!Number.isFinite(power)||power<.1||power>1||angle< -Math.PI||angle>Math.PI)throw Error('Invalid shot');
 const out=p=>isOut(p,usesCover(state));
 const s=structuredClone(state),p=s.pens[player];s.rules=roundRules(s.rules);s.rounds=roundResults(s);p.vx=Math.cos(angle)*power*24;p.vy=Math.sin(angle)*power*24;
 // Off-centre impulse: angular momentum = lever arm × linear impulse / inertia.
 const inertia=110*110/12;p.av=hitOffset*48*24*power*Math.sin(angle-p.angle)/inertia;
 for(const pen of s.pens){pen.roll??=0;pen.tilt=0;}
 let hit=false;const frames=[s.pens.map(p=>({...p}))],impacts=[];
 for(let t=0;t<150;t++){
  for(const pen of s.pens){
   const edge=tippingEdge(pen);
   if(edge&&!out(pen)){
    // Gravity acts outward once the mass centre has left its support. A light
    // nudge back onto the table can recover before the pen has completely left.
    pen.tilt=Math.min(.8,(pen.tilt||0)+.022);
    const gravity=.11+(pen.tilt||0)*.24;
    if(edge==='left')pen.vx-=gravity;else if(edge==='right')pen.vx+=gravity;else if(edge==='top')pen.vy-=gravity;else pen.vy+=gravity;
   }else if(!edge)pen.tilt=0;
   pen.av??=0;const c=Math.cos(pen.angle),sn=Math.sin(pen.angle),along=pen.vx*c+pen.vy*sn,across=-pen.vx*sn+pen.vy*c;
   // Cylinder rolls about its long axis: phase = lateral travel / barrel radius.
   pen.roll+=across/7;pen.x+=pen.vx;pen.y+=pen.vy;pen.angle+=pen.av;
   // Axial sliding has more resistance than lateral rolling; spin loses energy.
   pen.vx=along*.947*c-across*.963*sn;pen.vy=along*.947*sn+across*.963*c;pen.av*=.954;
  }
  const [a,b]=s.pens,[ca,cb]=contacts(a,b),dx=cb.x-ca.x,dy=cb.y-ca.y,d=Math.hypot(dx,dy);
  if(d<18){const fallback=Math.atan2(b.y-a.y,b.x-a.x),nx=d>.001?dx/d:Math.cos(fallback),ny=d>.001?dy/d:Math.sin(fallback),overlap=(18-d)/2;
   a.x-=nx*overlap;a.y-=ny*overlap;b.x+=nx*overlap;b.y+=ny*overlap;
   const ra={x:ca.x-a.x,y:ca.y-a.y},rb={x:cb.x-b.x,y:cb.y-b.y};
   const rel=(a.vx-a.av*ra.y-b.vx+b.av*rb.y)*nx+(a.vy+a.av*ra.x-b.vy-b.av*rb.x)*ny;
   if(rel>0){const ta=ra.x*ny-ra.y*nx,tb=rb.x*ny-rb.y*nx,I=110*110/12,impulse=1.75*rel/(2+(ta*ta+tb*tb)/I);
    a.vx-=impulse*nx;a.vy-=impulse*ny;b.vx+=impulse*nx;b.vy+=impulse*ny;a.av-=impulse*ta/I;b.av+=impulse*tb/I;hit=true;
    if(impacts.length<12)impacts.push({frame:frames.length,x:(ca.x+cb.x)/2,y:(ca.y+cb.y)/2,strength:Math.min(1,impulse/15)});
   }
  }
  if(t%3===0)frames.push(s.pens.map(p=>({...p})));
  if(s.pens.some(out))break;
 }
 const losers=s.pens.map((p,i)=>out(p)?i:-1).filter(i=>i>=0);let result='next';
 if(losers.length===1){const winner=1-losers[0];s.score[winner]++;result='point-'+winner;}else if(losers.length===2)result='draw';
 s.logs.push({round:s.round,...(s.rules.scoringMode==='round-contests'?{contest:s.contest}:{}),player,angle,power,hitOffset,hit,result});let roundShots=1;
 for(let i=s.logs.length-2;i>=0&&s.logs[i].result==='next';i--)roundShots++;
 const exhausted=!losers.length&&roundShots>=40;
 if(exhausted)s.logs.at(-1).result='draw';frames.push(s.pens.map(p=>({...p})));s.motion={id:s.logs.length,frames,impacts};
 if(losers.length)s.motion.fall={losers,durationMs:3200,edges:losers.map(i=>{return tippingEdge(s.pens[i])||'bottom';})};
 if(losers.length||exhausted){
  const winner=losers.length===1?1-losers[0]:null,points=[0,0];if(winner!==null)points[winner]=1;
  const reason=exhausted?'shot-limit':losers.length===2?'both-out':'out';
  if(s.rules.scoringMode==='round-contests'){
   s.contests.push({round:s.round,contest:s.contest,points,total:[...s.score],winner,reason,shots:roundShots});
   s.roundScore=s.roundScore.map((n,i)=>n+points[i]);
   if(s.contest===s.rules.contestsPerRound){
    const subtotal=[...s.roundScore];
    s.rounds.push({round:s.round,points:subtotal,total:[...s.score],winner:subtotal[0]===subtotal[1]?null:subtotal[0]>subtotal[1]?0:1,contests:s.contest});
    if(s.round===s.rules.maxRounds){s.status='finished';s.winner=s.score[0]===s.score[1]?null:s.score[0]>s.score[1]?0:1;}
    else{s.round++;s.contest=1;s.roundScore=[0,0];}
   }else s.contest++;
   if(s.status==='playing'){
    const index=(s.round-1)*s.rules.contestsPerRound+s.contest;
    s.pens=startingPens(s.layoutSeed,index);s.turn=(index-1)%2;
   }
  }else{
   s.rounds.push({round:s.round,points,total:[...s.score],winner,reason,shots:roundShots});
   const early=s.rules.scoringMode!=='all-rounds'&&s.score.some(n=>n>=s.rules.winsToWin);
   if(early||s.round>=s.rules.maxRounds){s.status='finished';s.winner=s.score[0]===s.score[1]?null:(s.score[0]>s.score[1]?0:1);}
   else{s.round++;s.pens=s.placement==='random'?startingPens(s.layoutSeed,s.round):legacyPens();s.turn=s.round%2===1?0:1;}
  }
 }else s.turn=1-player;
 for(const pen of s.pens){pen.vx=0;pen.vy=0;pen.av=0;pen.tilt=0;}return s;
}
export function computerShot(state,difficulty='balanced'){
 if(state.status!=='playing'||state.turn!==1)throw Error('Not the computer turn');
 const bot=state.pens[1],human=state.pens[0],base=Math.atan2(human.y-bot.y,human.x-bot.x);
 const offsets=difficulty==='easy'?[-.18,0,.18]:difficulty==='expert'?[-.28,-.14,-.07,0,.07,.14,.28]:[-.16,0,.16];
 const powers=difficulty==='easy'?[.35,.6,.8]:difficulty==='expert'?[.18,.3,.45,.6,.75,.9,1]:[.3,.5,.7,.9];
 const edge=p=>{const b=penBounds(p,usesCover(state));return Math.min(b.left-BOUNDARY.left,BOUNDARY.right-b.right,b.top-BOUNDARY.top,BOUNDARY.bottom-b.bottom);};let best=null;
 for(const offset of offsets)for(const power of powers)for(const hitOffset of (difficulty==='expert'?[-.55,0,.55]:[0])){const angle=Math.atan2(Math.sin(base+offset),Math.cos(base+offset)),next=shot(state,1,angle,power,hitOffset),log=next.logs.at(-1),b=next.pens[1],h=next.pens[0];
  const score=(log.result==='point-1'?10000:log.result==='point-0'?-10000:0)+(log.hit?110:0)+edge(b)*.16-edge(h)*.22-Math.hypot(h.x-b.x,h.y-b.y)*.13;
  if(!best||score>best.score)best={angle,power,hitOffset,score};
 }
 return {angle:best.angle,power:best.power,hitOffset:best.hitOffset};
}
