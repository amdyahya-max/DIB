'use strict';

// Harmless Windows launch probe: no installer, settings, or enrollment changes.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { launchPowerShellWorker, psQuote } = require('./update-launcher.cjs');
const dir = path.join(os.tmpdir(), 'CET-Launcher-Probe');
const runFile = path.join(dir, 'run.json');
const survivedFile = path.join(dir, 'worker-survived.txt');

async function main() {
  if (process.platform !== 'win32') throw new Error('Run this probe on the Windows PC where CET Helper is installed.');
  if (process.argv.includes('--results')) {
    const run = JSON.parse(fs.readFileSync(runFile, 'utf8'));
    const survived = fs.existsSync(survivedFile) && fs.readFileSync(survivedFile, 'utf8').trim() === run.id;
    console.log(survived ? 'PASS: the updater worker started and survived the Node launcher exiting.' : 'NOT CONFIRMED: the worker survival marker is missing. Wait five seconds after the probe and retry.');
    console.log('Diagnostic folder: ' + dir);
    process.exitCode = survived ? 0 : 1;
    return;
  }
  fs.mkdirSync(dir, { recursive: true });
  const id = crypto.randomUUID();
  fs.writeFileSync(runFile, JSON.stringify({ id, started: new Date().toISOString() }));
  try { fs.unlinkSync(survivedFile); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  const oldAck = path.join(dir, 'old-started.txt');
  try { fs.unlinkSync(oldAck); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  const executable = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const oldCommand = Buffer.from(`Set-Content -LiteralPath ${psQuote(oldAck)} -Value 'started'`, 'utf16le').toString('base64');
  const fd = fs.openSync(path.join(dir, 'old-launch.log'), 'w');
  let oldExit = null;
  const old = spawn(executable, ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', oldCommand], { detached: true, windowsHide: true, shell: false, stdio: ['ignore', fd, fd] });
  old.once('spawn', () => fs.closeSync(fd));
  old.once('error', e => { oldExit = 'spawn error: ' + e.message; try { fs.closeSync(fd); } catch {} });
  old.once('exit', code => { oldExit = code; });
  old.unref();
  await new Promise(resolve => setTimeout(resolve, 2000));
  console.log('Previous launch configuration: exit=' + oldExit + '; acknowledgement=' + fs.existsSync(oldAck));
  if (oldExit === null) try { old.kill(); } catch {}
  const ackFile = path.join(dir, 'worker-started.txt');
  const scriptPath = path.join(dir, 'worker.ps1');
  fs.writeFileSync(scriptPath, '\ufeff' + `Set-Content -LiteralPath ${psQuote(ackFile)} -Value 'started'\nStart-Sleep -Seconds 4\nSet-Content -LiteralPath ${psQuote(survivedFile)} -Value ${psQuote(id)}\n`, 'utf8');
  // Keep the probe's existing terminal visible. The installed Electron app
  // has no parent console, and uses the module's hidden-launcher default.
  await launchPowerShellWorker({ scriptPath, ackFile, outputPath: path.join(dir, 'worker-output.log'), errorPath: path.join(dir, 'worker-error.log'), launcherOutputPath: path.join(dir, 'launcher.log'), timeoutMs: 20000, hideLauncherWindow: false, log: (event, detail) => console.log(JSON.stringify({ event, ...detail })) });
  console.log('PASS: the corrected launcher received the worker startup acknowledgement.');
  console.log('Wait five seconds, then run the same command with --results to verify survival after this process exits.');
  console.log('Diagnostic folder: ' + dir);
}

main().then(() => process.exit(process.exitCode || 0)).catch(e => { console.error('FAIL: ' + e.message); process.exit(1); });
