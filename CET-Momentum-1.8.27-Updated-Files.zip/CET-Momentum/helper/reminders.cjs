function dueReminder(now,state,config){
 const date=now.date,time=now.time,minute=t=>Number(t.slice(0,2))*60+Number(t.slice(3));
 if(!config.eligible||config.confirmed)return null;
 if(state.snoozeUntil){if(Date.now()<state.snoozeUntil)return null;return {id:`${date}-snooze-${state.snoozeUntil}`,date,time};}
 const times=config.settings.reminderTimes.filter(t=>minute(time)>=minute(t)&&minute(time)-minute(t)<=config.settings.graceMinutes);
 const latest=times.at(-1);if(!latest)return null;const id=`${date}-${latest}`;
 if(state.fired.includes(id))return null;return {id,date,time:latest};
}
module.exports={dueReminder};
