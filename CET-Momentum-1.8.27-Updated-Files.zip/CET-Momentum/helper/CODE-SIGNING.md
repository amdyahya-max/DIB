# Signing the CET Helper for Windows

The distributed `CET-Helper-Setup.exe` is currently unsigned. For internal rollout, ask CET/DIB IT Security or the corporate PKI team to sign each release with the organization's approved **Code Signing** certificate. Do not use a TLS/server certificate. A signature identifies the publisher and detects changes to signed files; it does not by itself mean Windows policy will allow execution.

## Recommended: sign during the Electron build

The helper is built with Electron Builder (`helper/package.json`, `dist:win`, NSIS target). Electron Builder can sign the packaged Windows executables and installer during the build. This is preferable to signing only the outer setup file after packaging.

Build on the approved Windows signing machine or CI runner. Keep the private key in the enterprise certificate store, HSM or protected build secret store. Never put a `.pfx` file or its password in source control, the portal folder, or a distributed ZIP.

### PFX certificate provided by IT

On the Windows build runner, IT should make the PFX available at a protected location and expose these variables securely to the build process:

- `CSC_LINK` — protected PFX path or secure certificate value
- `CSC_KEY_PASSWORD` — PFX password from the approved secret store

From PowerShell, in the `helper` folder (adjust the paths to the installation):

```powershell
$node = 'C:\CETMomentum\Node\node.exe'
$helper = 'C:\CETMomentum\helper'
Set-Location $helper

# CSC_LINK and CSC_KEY_PASSWORD must already be injected securely by IT/CI.
& $node '.\node_modules\electron-builder\cli.js' --win nsis --x64
if ($LASTEXITCODE -ne 0) { throw 'Signed CET Helper build failed.' }

& $node '.\publish.cjs'
if ($LASTEXITCODE -ne 0) { throw 'Publishing the helper installer failed.' }
```

This calls Electron Builder's JavaScript CLI directly, without relying on `npm.cmd` or another `.cmd`/`.bat` launcher. The helper's build dependencies must already be installed in `helper\node_modules`. If they are not, IT should install them through the approved build process before signing.

### Certificate installed in the Windows certificate store or HSM

IT can configure the certificate selector supported by the pinned Electron Builder version in `helper/package.json` under `build.win.sign`, for example:

```json
"sign": {
  "type": "signtool",
  "certificateSubjectName": "Exact corporate signing certificate subject"
}
```

Use the exact subject/substr specified by IT. Hardware-backed certificates may require an HSM provider or interactive signing authorization on the Windows build machine. Keep that key under the organization's signing controls; do not export it just to make this build simpler.

## Check the result before publishing

After a successful signed build, verify the installer and the packaged app executable, then verify the portal's published copy:

```powershell
Get-AuthenticodeSignature '.\dist\CET-Helper-Setup.exe' |
  Format-List Status, StatusMessage, SignerCertificate

Get-AuthenticodeSignature '.\dist\win-unpacked\CET Helper.exe' |
  Format-List Status, StatusMessage, SignerCertificate

Get-AuthenticodeSignature '..\downloads\CET-Helper-Setup.exe' |
  Format-List Status, StatusMessage, SignerCertificate
```

The signature status should be `Valid`, and the signer should be the expected corporate publisher. `publish.cjs` copies the final built installer to `downloads\CET-Helper-Setup.exe`; it must run only after signing. Uploading a new unsigned installer, rebuilding after signing, or changing a signed file invalidates the signature. Test the downloaded copy on a managed employee PC before rollout.

## Manual SignTool option

For a prebuilt installer, IT can use Microsoft's SignTool with the approved certificate and timestamp service, then verify it. The exact certificate selector and timestamp URL must come from IT:

```powershell
signtool sign /fd SHA256 /sha1 <CERTIFICATE_THUMBPRINT> /tr <APPROVED_RFC3161_TIMESTAMP_URL> /td SHA256 'C:\CETMomentum\helper\dist\CET-Helper-Setup.exe'
signtool verify /pa /v 'C:\CETMomentum\helper\dist\CET-Helper-Setup.exe'
```

This signs the outer installer only. It does not retroactively sign an unsigned `CET Helper.exe` already embedded inside. Prefer the Electron Builder signing build above so the app executable and installer are signed before publishing.

## Internal trust and SmartScreen

For an internal corporate certificate, client PCs need to trust the issuing CA chain and, where policy requires it, the publisher certificate. IT can distribute approved trust through Group Policy or endpoint management. A signature alone does not guarantee SmartScreen will stop warning for a new or uncommon installer; enterprise application control and SmartScreen policies can also affect execution. Have IT test against the actual managed desktop policies.

Keep signing identity consistent across releases. Use the approved timestamp service so a timestamped signature can remain verifiable after the signing certificate expires. Microsoft's SignTool requires a file digest and timestamp digest algorithm; SHA-256 is recommended.

## Official references

- Electron Builder Windows code signing: https://www.electron.build/docs/features/code-signing/code-signing-win/
- Microsoft SignTool: https://learn.microsoft.com/en-us/windows/win32/seccrypto/signtool
- Microsoft SmartScreen reputation: https://learn.microsoft.com/en-us/windows/apps/package-and-deploy/smartscreen-reputation
