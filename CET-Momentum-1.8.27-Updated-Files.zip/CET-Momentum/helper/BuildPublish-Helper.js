'use strict';

// Build and publish CET Helper without invoking npm.cmd, cmd.exe, or a .bat file.
// Run with node.exe on Windows, or Node + Wine on a Linux cross-build machine.

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const crypto = require('node:crypto');
const readline = require('node:readline/promises');

const helperDir = __dirname;
const builderCli = path.join(helperDir, 'node_modules', 'electron-builder', 'cli.js');
const electronExe = path.join(helperDir, 'node_modules', 'electron', 'dist', 'electron.exe');
const builtInstaller = path.join(helperDir, 'dist', 'CET-Helper-Setup.exe');
const publishScript = path.join(helperDir, 'publish.cjs');
const publishedInstaller = path.join(helperDir, '..', 'downloads', 'CET-Helper-Setup.exe');
const buildConfigFile = path.join(helperDir, 'build-config.json');
const defaultPortalUrl = 'https://dxb01-vwu-afna1.dibuat.ae/CETGamification';

function stop(message) {
  console.error(`\nERROR: ${message}`);
  process.exit(1);
}

function requireFile(file, description) {
  if (!fs.existsSync(file)) stop(`${description} not found:\n${file}\n\nInstall the helper dependencies on this Windows build machine, then run this script again.`);
}

function runNode(label, script, args = []) {
  console.log(`\n=== ${label} ===`);
  const result = spawnSync(process.execPath, [script, ...args], {
    cwd: helperDir,
    stdio: 'inherit',
    windowsHide: false,
    shell: false,
  });

  if (result.error) stop(`${label} could not start: ${result.error.message}`);
  if (result.status !== 0) stop(`${label} failed with exit code ${result.status ?? 'unknown'}.`);
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function setBuildVersion() {
  const arg = process.argv.indexOf('--version');
  if (arg < 0) return;
  const version = process.argv[arg + 1];
  if (!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(version || '')) stop('Pass a version such as 1.2.8 after --version.');
  const packageFile = path.join(helperDir, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(packageFile, 'utf8'));
  pkg.version = version;
  fs.writeFileSync(packageFile, JSON.stringify(pkg, null, 2) + '\n');
  const lockFile = path.join(helperDir, 'package-lock.json');
  if (fs.existsSync(lockFile)) {
    const lock = JSON.parse(fs.readFileSync(lockFile, 'utf8'));
    lock.version = version;
    if (lock.packages?.['']) lock.packages[''].version = version;
    fs.writeFileSync(lockFile, JSON.stringify(lock, null, 2) + '\n');
  }
  const legacyInstaller = path.join(helperDir, 'installer.nsi');
  if (fs.existsSync(legacyInstaller)) {
    const text = fs.readFileSync(legacyInstaller, 'utf8');
    fs.writeFileSync(legacyInstaller, text.replace(/("DisplayVersion"\s+")[^"]+("\s*)/g, (_match, before, after) => before + version + after));
  }
  console.log('Helper version for this build: ' + version);
}

function validatePortalUrl(value) {
  let u;
  try { u = new URL(value); } catch { stop(`Invalid portal URL: ${value}`); }
  if (u.username || u.password || u.search || u.hash || u.protocol !== 'https:' && !(u.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname))) {
    stop('Use an HTTPS portal FQDN (or HTTP localhost for local testing), without credentials, query or fragment.');
  }
  return u.toString().replace(/\/$/, '');
}

async function getPortalUrl() {
  const arg = process.argv.findIndex(x => x === '--portal-url');
  if (arg >= 0) {
    if (!process.argv[arg + 1]) stop('Pass a URL after --portal-url.');
    return validatePortalUrl(process.argv[arg + 1]);
  }
  const saved = fs.existsSync(buildConfigFile) ? require(buildConfigFile).portalUrl : defaultPortalUrl;
  if (!process.stdin.isTTY) return validatePortalUrl(saved || defaultPortalUrl);
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question(`Portal FQDN URL [${saved || defaultPortalUrl}]: `);
    return validatePortalUrl(answer.trim() || saved || defaultPortalUrl);
  } finally { rl.close(); }
}

async function main() {
if (!['win32', 'linux'].includes(process.platform)) {
  stop('Use a Windows build machine or a Linux build machine with Wine.');
}
if (process.platform === 'linux') {
  console.log('Cross-building Windows x64 on Linux with native NSIS uninstaller extraction.');
}

const portalUrl = await getPortalUrl();
fs.writeFileSync(buildConfigFile, JSON.stringify({ portalUrl }, null, 2) + '\n');
console.log(`Portal URL embedded in this build: ${portalUrl}`);

requireFile(builderCli, 'Electron Builder CLI');
if (process.platform === 'win32') requireFile(electronExe, 'Windows Electron runtime');
requireFile(publishScript, 'Local publish script');

setBuildVersion();

runNode('Build Windows installer', process.platform === 'linux' ? path.join(helperDir, 'build-linux.cjs') : builderCli,
  ['--win', 'nsis', '--x64', ...(process.platform === 'linux' ? ['-c.toolsets.wine=1.0.1'] : [])]);
requireFile(builtInstaller, 'Built installer');

runNode('Copy installer into portal downloads', publishScript);
requireFile(publishedInstaller, 'Published installer');

if (sha256(builtInstaller) !== sha256(publishedInstaller)) {
  stop('The published installer does not match the freshly built installer.');
}

const sizeMiB = (fs.statSync(publishedInstaller).size / (1024 * 1024)).toFixed(1);
console.log(`\nSUCCESS: CET-Helper-Setup.exe published (${sizeMiB} MiB).`);
console.log(`Portal download: ${publishedInstaller}`);
console.log(`Release metadata: ${path.join(path.dirname(publishedInstaller), 'helper-release.json')}`);
}

main().catch(error => stop(error.message));
