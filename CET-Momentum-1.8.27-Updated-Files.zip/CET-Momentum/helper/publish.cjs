'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const pkg = require('./package.json');

const source = path.join(__dirname, 'dist', 'CET-Helper-Setup.exe');
const downloads = path.join(__dirname, '..', 'downloads');
const installer = path.join(downloads, 'CET-Helper-Setup.exe');
const manifest = path.join(downloads, 'helper-release.json');
if (!fs.existsSync(source)) throw Error('Built installer not found. Run BuildPublish-Helper.js first.');
if (fs.statSync(source).size < 1048576) throw Error('Installer is incomplete. Rebuild before publishing; the Electron installer must contain the application payload.');
fs.mkdirSync(downloads, { recursive: true });
fs.copyFileSync(source, installer);
const stat = fs.statSync(installer);
const release = {
  version: pkg.version,
  file: 'CET-Helper-Setup.exe',
  size: stat.size,
  sha256: crypto.createHash('sha256').update(fs.readFileSync(installer)).digest('hex'),
  publishedAt: new Date().toISOString(),
};
const temp = manifest + '.tmp';
fs.writeFileSync(temp, JSON.stringify(release, null, 2) + '\n', { mode: 0o644 });
fs.renameSync(temp, manifest);
console.log(`Published CET Helper ${release.version} (${(stat.size / 1048576).toFixed(1)} MiB).`);
console.log(`Installer: ${installer}`);
console.log(`Release metadata: ${manifest}`);
