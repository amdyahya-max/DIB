'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const psQuote = value => "'" + String(value).replace(/'/g, "''") + "'";

async function launchPowerShellWorker({ scriptPath, ackFile, outputPath, errorPath, launcherOutputPath, log = () => {}, timeoutMs = 120000, hideLauncherWindow = true }) {
  if (process.platform !== 'win32') throw new Error('The PowerShell updater launcher requires Windows.');
  const executable = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  // Windows PowerShell 5.1 can exit 0 before executing code when libuv starts
  // it with DETACHED_PROCESS and CREATE_NO_WINDOW. Allocate a normal console
  // for this short-lived launcher; PowerShell hides it with WindowStyle.
  // Start-Process then starts a worker with its own console/lifetime. The
  // worker is a grandchild, so it survives the helper's process/job ending.
  // No cmd.exe, scheduled task, service, or elevation is involved.
  const command = `$ErrorActionPreference='Stop'
try {
 Write-Output ('launcher.started pid='+$PID)
 $workerArgs=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',${psQuote('"' + scriptPath + '"')})
 $worker=Start-Process -FilePath ${psQuote(executable)} -ArgumentList $workerArgs -WindowStyle Hidden -RedirectStandardOutput ${psQuote(outputPath)} -RedirectStandardError ${psQuote(errorPath)} -PassThru -ErrorAction Stop
 Write-Output ('launcher.worker-started pid='+$worker.Id)
 exit 0
} catch {
 Write-Output ('launcher.failed '+$_.Exception.Message)
 exit 1
}
`;
  const args = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', ...(hideLauncherWindow ? ['-WindowStyle', 'Hidden'] : []), '-EncodedCommand', Buffer.from(command, 'utf16le').toString('base64')];
  const scriptBytes = fs.statSync(scriptPath).size;
  fs.mkdirSync(path.dirname(launcherOutputPath), { recursive: true });
  for (const file of [outputPath, errorPath, launcherOutputPath]) fs.writeFileSync(file, '');
  try { fs.unlinkSync(ackFile); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  const outputFd = fs.openSync(launcherOutputPath, 'a');
  let closed = false;
  const closeOutput = () => { if (!closed) { closed = true; fs.closeSync(outputFd); } };
  log('update.handoff.launch-command', { executable, mode: 'PowerShell-StartProcess', detached: false, windowsHide: false, windowStyle: hideLauncherWindow ? 'Hidden' : 'Normal', scriptPath, scriptBytes, launcherOutputPath, powershellOutputPath: outputPath, powershellErrorPath: errorPath });
  let child;
  try {
    child = spawn(executable, args, { detached: false, windowsHide: false, shell: false, stdio: ['ignore', outputFd, outputFd] });
  } catch (e) { closeOutput(); throw e; }
  let spawnError = null, childExit = null;
  child.once('spawn', () => { closeOutput(); log('update.handoff.process-started', { pid: child.pid, role: 'launcher' }); });
  child.once('error', e => { closeOutput(); spawnError = e; log('update.handoff.spawn-error', { message: e.message, launcherOutputPath }); });
  child.once('exit', (code, signal) => { childExit = { code, signal }; log('update.handoff.process-exit', { role: 'launcher', code, signal, acknowledged: fs.existsSync(ackFile), launcherOutputPath }); });
  child.unref();
  const deadline = Date.now() + timeoutMs;
  while (!fs.existsSync(ackFile) && Date.now() < deadline) {
    if (spawnError) throw spawnError;
    // Exit 0 means the launcher handed work to Start-Process. The worker
    // may still be starting: keep waiting for ITS acknowledgement.
    if (childExit && (childExit.code !== 0 || childExit.signal)) {
      throw new Error(`PowerShell launcher failed (exit code ${childExit.code}; signal ${childExit.signal || 'none'}). Check ${launcherOutputPath}.`);
    }
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  if (!fs.existsSync(ackFile)) {
    if (!childExit) try { child.kill(); } catch {}
    throw new Error(`The updater worker did not acknowledge startup within ${Math.round(timeoutMs / 1000)} seconds. Check ${launcherOutputPath} and ${errorPath}.`);
  }
  log('update.handoff.acknowledged', { ackFile, launcherOutputPath, powershellOutputPath: outputPath, powershellErrorPath: errorPath });
  return { ackFile, launcherOutputPath, outputPath, errorPath };
}

module.exports = { launchPowerShellWorker, psQuote };
