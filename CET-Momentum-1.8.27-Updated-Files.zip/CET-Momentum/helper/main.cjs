const {app,BrowserWindow,Tray,Menu,ipcMain,nativeImage,Notification,shell,powerMonitor,net}=require('electron');
const fs=require('node:fs');const path=require('node:path');const http=require('node:http');const os=require('node:os');const crypto=require('node:crypto');const {execFileSync}=require('node:child_process');const {dueReminder}=require('./reminders.cjs');const {launchPowerShellWorker,psQuote}=require('./update-launcher.cjs');
app.setName('CET Helper');app.setAppUserModelId('com.cet.momentum.helper');if(!app.requestSingleInstanceLock())app.quit();
let config={},reminderState={date:'',fired:[],snoozeUntil:0},pending=null,settingsWindow=null,reminderWindow=null,tray=null,latest=null,activeAt=0,notifiedId='',lastError='',busy=false,upgrading=false;
const configFile=()=>path.join(app.getPath('userData'),'connection.json');const stateFile=()=>path.join(app.getPath('userData'),'reminders.json');
function read(p,fallback){try{return JSON.parse(fs.readFileSync(p,'utf8'));}catch{return fallback;}}
function write(p,value){fs.mkdirSync(path.dirname(p),{recursive:true});const tmp=p+'.tmp';fs.writeFileSync(tmp,JSON.stringify(value,null,2),{mode:0o600});fs.renameSync(tmp,p);}
const helperLogFile=()=>path.join(app.getPath('userData'),'logs','helper-update.log');
function log(event,details={}){try{const file=helperLogFile(),dir=path.dirname(file);fs.mkdirSync(dir,{recursive:true});if(fs.existsSync(file)&&fs.statSync(file).size>2*1024*1024)fs.renameSync(file,file+'.1');fs.appendFileSync(file,JSON.stringify({time:new Date().toISOString(),event,...details})+'\r\n',{encoding:'utf8',mode:0o600});}catch{}}
async function openHelperLog(){try{fs.mkdirSync(path.dirname(helperLogFile()),{recursive:true});if(!fs.existsSync(helperLogFile()))log('diagnostic-log.opened',{version:app.getVersion()});const error=await shell.openPath(helperLogFile());if(error)lastError='Could not open helper log: '+error;}catch(e){lastError='Could not open helper log: '+e.message;}}
const buildConfig=read(path.join(__dirname,'build-config.json'),{portalUrl:'https://dxb01-vwu-afna1.dibuat.ae/CETGamification'});
function portalUrl(){return config.portal||buildConfig.portalUrl||'https://dxb01-vwu-afna1.dibuat.ae/CETGamification';}
function versionCompare(a,b){const x=String(a).split('.').map(Number),y=String(b).split('.').map(Number);for(let i=0;i<Math.max(x.length,y.length);i++){if((x[i]||0)!==(y[i]||0))return (x[i]||0)-(y[i]||0);}return 0;}
function username(){return process.platform==='win32'?execFileSync('whoami.exe',[],{encoding:'utf8',windowsHide:true,timeout:5000}).trim().toLowerCase():os.userInfo().username.toLowerCase();}
function validateUrl(value){const u=new URL(value);if(u.username||u.password||u.search||u.hash)throw Error('Enter a plain portal URL without credentials, query or fragment.');if(u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)))throw Error('Use HTTPS, or HTTP localhost for local testing.');return u.toString().replace(/\/$/,'');}
async function request(p,body,base=portalUrl()){let r;try{const headers={'Content-Type':'application/json',...(config.secret?{Authorization:'Bearer '+config.secret}:{}),...(p==='/helper/release'||p==='/helper/version'?{'X-CET-Helper-Version':app.getVersion(),'X-CET-Helper-PC':os.hostname()}: {})};r=await net.fetch(base+'/api'+p,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(p==='/helper/release'?15000:10000)});}catch(e){const reason=e.cause?.code||e.cause?.message||e.message;throw new Error(`Could not connect to ${new URL(base).host}: ${reason}. Check the HTTPS certificate trust, portal address and network access.`);}const text=await r.text();let j;try{j=text?JSON.parse(text):{};}catch{throw new Error(`Portal returned a non-JSON response (HTTP ${r.status}). Check the IIS rewrite path and BASE_PATH.`);}if(!r.ok){const e=new Error(j.error||`Portal request failed (HTTP ${r.status}).`);e.status=r.status;throw e;}return j;}
let updateStage='idle';
async function upgradeHelper(target){
 if(upgrading)throw Error('Helper update is already running.');
 if(!app.isPackaged||process.platform!=='win32')throw Error('In-app helper updates are available for the installed Windows helper.');
 upgrading=true;updateStage='validate portal URL';
 try{
  const requested=target?validateUrl(target):portalUrl(),pinned=validateUrl(buildConfig.portalUrl||portalUrl());
  log('update.requested',{currentVersion:app.getVersion(),requestedPortal:requested,savedPortal:portalUrl(),embeddedPortal:pinned});
  if(requested!==pinned&&requested!==validateUrl(portalUrl()))throw Error('The update portal does not match a trusted address configured for this helper. Configure CET Helper for the same portal address before updating.');
  updateStage='fetch release metadata';
  const release=await request('/helper/release',undefined,requested);
  log('update.release.received',{stage:updateStage,currentVersion:app.getVersion(),releaseVersion:release.version,size:release.size});
  if(!/^\d+\.\d+\.\d+$/.test(String(release.version||''))||! /^[a-f0-9]{64}$/.test(String(release.sha256||''))||!Number.isSafeInteger(release.size)||release.size<1000000||release.size>300000000)throw Error('The portal release metadata is missing or invalid.');
  if(versionCompare(release.version,app.getVersion())<=0)throw Error(`This helper is already current (v${app.getVersion()}).`);
  updateStage='download installer';
  const base=requested.replace(/\/$/,''),response=await net.fetch(base+'/downloads/CET-Helper-Setup.exe?v='+encodeURIComponent(release.version),{signal:AbortSignal.timeout(120000)});
  if(!response.ok)throw Error(`Could not download the update (HTTP ${response.status}).`);
  const bytes=Buffer.from(await response.arrayBuffer());
  if(bytes.length!==release.size)throw Error(`Downloaded installer size mismatch: expected ${release.size} bytes, received ${bytes.length}.`);
  updateStage='verify installer SHA-256';
  const actualHash=crypto.createHash('sha256').update(bytes).digest('hex');
  if(actualHash!==release.sha256)throw Error('Downloaded installer SHA-256 verification failed. The update was not started.');
  log('update.download.verified',{releaseVersion:release.version,size:bytes.length,sha256:actualHash});
  const installer=path.join(app.getPath('temp'),`CET-Helper-Setup-${release.version}.exe`);
  fs.writeFileSync(installer,bytes,{mode:0o600});
  config={...config,portal:requested};write(configFile(),config);
  const psFile=path.join(app.getPath('temp'),`CET-Helper-Update-${release.version}.ps1`);
  const psOutput=path.join(path.dirname(helperLogFile()),'helper-update-powershell.log');
  const installerLog=path.join(path.dirname(helperLogFile()),`installer-${release.version}.log`);
  const ackFile=path.join(app.getPath('temp'),`CET-Helper-Update-${release.version}.started`);
  const psError=path.join(path.dirname(helperLogFile()),'helper-update-powershell-error.log');
  const launcherOutput=path.join(path.dirname(helperLogFile()),'helper-update-launcher.log');
  const psScript=`$ErrorActionPreference='Stop'
$log=${psQuote(helperLogFile())}
$installer=${psQuote(installer)}
$helperExe=${psQuote(process.execPath)}
$expectedVersion=${psQuote(release.version)}
$installerLog=${psQuote(installerLog)}
$ackFile=${psQuote(ackFile)}
function Write-UpdateLog($event,$detail){$line=@{time=(Get-Date).ToUniversalTime().ToString('o');event=$event;detail=[string]$detail}|ConvertTo-Json -Compress;Add-Content -LiteralPath $log -Value $line -Encoding UTF8}
try {
 Set-Content -LiteralPath $ackFile -Value ('started pid='+$PID+' '+(Get-Date).ToUniversalTime().ToString('o')) -NoNewline
 Write-UpdateLog 'handoff.script-started' ('pid='+$PID+'; installer='+$installer+'; helperExe='+$helperExe)
 try { Wait-Process -Id ${process.pid} -Timeout 180 -ErrorAction SilentlyContinue } catch {}
 Start-Sleep -Milliseconds 500
 if (Get-Process -Id ${process.pid} -ErrorAction SilentlyContinue) { throw 'The old helper process did not exit within 180 seconds.' }
 Write-UpdateLog 'handoff.parent-exited' 'The old helper exited; updater worker is still running.'
 if (-not (Test-Path -LiteralPath $installer)) { throw ('Downloaded installer not found: '+$installer) }
 Set-Content -LiteralPath $installerLog -Value ('Started '+(Get-Date).ToUniversalTime().ToString('o')+'; installer='+$installer+'; expectedVersion='+$expectedVersion) -Encoding UTF8
 Write-UpdateLog 'handoff.installer-start' ('path='+$installer+'; log='+$installerLog)
 $proc=Start-Process -FilePath $installer -ArgumentList @('/S') -PassThru -Wait -ErrorAction Stop
 Add-Content -LiteralPath $installerLog -Value ('Exited '+(Get-Date).ToUniversalTime().ToString('o')+'; exitCode='+$proc.ExitCode) -Encoding UTF8
 Write-UpdateLog 'handoff.installer-exit' ('exitCode='+$proc.ExitCode)
 if ($proc.ExitCode -ne 0) { throw ('Installer returned exit code '+$proc.ExitCode) }
 if (-not (Test-Path -LiteralPath $helperExe)) { throw ('Installed helper not found at its original executable path: '+$helperExe) }
 $installedVersion=(Get-Item -LiteralPath $helperExe).VersionInfo.ProductVersion
 $normalizedVersion=[regex]::Match([string]$installedVersion,'^\\d+\\.\\d+\\.\\d+').Value
 Add-Content -LiteralPath $installerLog -Value ('helperExe='+$helperExe+'; installedVersion='+$installedVersion) -Encoding UTF8
 if ($normalizedVersion -ne $expectedVersion) { throw ('Installed version '+$installedVersion+' does not match '+$expectedVersion) }
 Write-UpdateLog 'handoff.version-verified' ('installedVersion='+$installedVersion+'; expectedVersion='+$expectedVersion+'; helperExe='+$helperExe)
 $running=Get-Process -Name 'CET Helper' -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $helperExe }
 if ($running) {
  Write-UpdateLog 'handoff.helper-already-running' ('helperExe='+$helperExe)
 } else {
  $restarted=Start-Process -FilePath $helperExe -PassThru -ErrorAction Stop
  Write-UpdateLog 'handoff.helper-relaunched' ('pid='+$restarted.Id+'; helperExe='+$helperExe)
 }
 Write-UpdateLog 'handoff.install-completed' ('expectedVersion='+$expectedVersion+'; installerExitCode='+$proc.ExitCode)
} catch {
 $failure=$_.Exception.Message+'; line='+$_.InvocationInfo.ScriptLineNumber
 try { Write-UpdateLog 'handoff.failed' $failure } catch {}
 try { Add-Content -LiteralPath $installerLog -Value ('FAILED '+$failure) -Encoding UTF8 } catch {}
 [Console]::Error.WriteLine($failure)
 exit 1
}
`;
  fs.writeFileSync(psFile,'\ufeff'+psScript,{encoding:'utf8',mode:0o600});
  updateStage='launch updater';
  log('update.handoff.started',{releaseVersion:release.version,installerPath:installer,scriptPath:psFile,powershellOutputPath:psOutput,powershellErrorPath:psError,launcherOutputPath:launcherOutput,installerLogPath:installerLog,ackFile,installedExecutable:process.execPath,logPath:helperLogFile()});
  await launchPowerShellWorker({scriptPath:psFile,ackFile,outputPath:psOutput,errorPath:psError,launcherOutputPath:launcherOutput,log});
  setTimeout(()=>app.quit(),1000);
  return {ok:true,version:release.version,logPath:helperLogFile()};
 }catch(e){upgrading=false;lastError=e.message;log('update.failed',{stage:updateStage,currentVersion:app.getVersion(),portal:target||portalUrl(),message:e.message});throw e;}
}
let versionReportBusy=false,versionReportAt=0;
async function reportVersion(){if(!config.secret||versionReportBusy||Date.now()-versionReportAt<60000)return;versionReportBusy=true;versionReportAt=Date.now();try{const result=await request('/helper/version',{version:app.getVersion(),pcName:os.hostname()});log('version.reported',{version:app.getVersion(),pcName:os.hostname(),updateAvailable:!!result.updateAvailable,latestVersion:result.latestVersion||null});}catch(e){log('version.report.failed',{version:app.getVersion(),portal:portalUrl(),message:e.message});}finally{versionReportBusy=false;}}
function windowOptions(){return {width:520,height:740,resizable:false,autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}};}
function settings(){if(settingsWindow){settingsWindow.show();settingsWindow.focus();return;}settingsWindow=new BrowserWindow(windowOptions());settingsWindow.loadFile(path.join(__dirname,'settings.html'));settingsWindow.webContents.setWindowOpenHandler(()=>({action:'deny'}));settingsWindow.on('closed',()=>settingsWindow=null);}
async function openPortal(){try{if(!config.portal){settings();return;}if(config.secret){const launch=await request('/helper/launch',{});await shell.openExternal(config.portal+'/#ticket='+encodeURIComponent(launch.id)+'&secret='+encodeURIComponent(launch.secret));}else await shell.openExternal(config.portal+'/');}catch(e){lastError=e.message;settings();}}
function closeReminder(){if(reminderWindow){reminderWindow.close();reminderWindow=null;}}
async function reminderAction(action){if(action==='snooze'){reminderState.snoozeUntil=Date.now()+(latest?.settings.snoozeMinutes||15)*60000;}else if(action==='dismiss'){reminderState.snoozeUntil=0;}else if(action==='calendar'){await openPortal();}else if(action==='magnitude'){const u=latest?.settings.magnitudeUrl;if(u&&/^https?:\/\//.test(u))await shell.openExternal(u);return;}else throw Error('Invalid reminder action');pending=null;closeReminder();write(stateFile(),reminderState);}
function showReminder(){if(reminderWindow||!pending)return;notifiedId=pending.id;reminderWindow=new BrowserWindow({...windowOptions(),height:390,alwaysOnTop:false});reminderWindow.loadFile(path.join(__dirname,'reminder.html'));reminderWindow.webContents.setWindowOpenHandler(()=>({action:'deny'}));reminderWindow.on('closed',()=>{reminderWindow=null;});if(Notification.isSupported()){const n=new Notification({title:'CET timesheet reminder',body:'Log in Magnitude, then confirm your CET calendar.',silent:!latest?.settings.sound});n.on('click',()=>{if(reminderWindow)reminderWindow.show();else openPortal();});n.show();}}
async function tick(){if(busy)return;if(config.pending){await pollEnrollment();return;}if(!config.secret)return;busy=true;try{latest=await request('/helper/reminders');lastError='';if(reminderState.date!==latest.today.date){reminderState={date:latest.today.date,fired:[],snoozeUntil:0};pending=null;closeReminder();}if(latest.confirmed||!latest.eligible){pending=null;reminderState.snoozeUntil=0;closeReminder();}else if(!pending){const due=dueReminder(latest.today,reminderState,latest);if(due){pending=due;reminderState.fired.push(due.id);reminderState.snoozeUntil=0;if(Date.now()-activeAt>25000)showReminder();}}if(pending&&Date.now()-activeAt>25000&&notifiedId!==pending.id)showReminder();write(stateFile(),reminderState);}catch(e){lastError=e.message;if(e.status===401||e.status===403){pending=null;closeReminder();if(e.status===401){config={portal:config.portal};write(configFile(),config);lastError='Device access was revoked or is no longer valid. Request administrator approval again.';}}}finally{busy=false;}}
function trustedOrigin(req){try{const origin=req.headers.origin;return origin===new URL(portalUrl()).origin||origin===new URL(buildConfig.portalUrl).origin;}catch{return false;}}
function bridge(){const srv=http.createServer(async(req,res)=>{
 const origin=req.headers.origin;if(!trustedOrigin(req)){log('bridge.origin.rejected',{origin:origin||null,configuredPortal:portalUrl(),embeddedPortal:buildConfig.portalUrl});res.writeHead(403,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'This portal origin is not configured in CET Helper.'}));return;}
 res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Access-Control-Allow-Private-Network','true');res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','application/json');
 if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
 const host=req.headers.host;if(host!=='127.0.0.1:47831'){res.writeHead(403);res.end(JSON.stringify({error:'Invalid helper host.'}));return;}
 try{if(req.method==='GET'&&req.url==='/status'){let authorised=null;try{await request('/helper/eligibility',{username:username()});authorised=true;}catch(e){if(e.status===403)authorised=false;}res.end(JSON.stringify({enrolled:!!config.secret,enrollment:config.pending?{status:config.pending.status,reference:config.pending.reference}:null,pending,lastError,authorised,version:app.getVersion(),upgrading,updateStage,logPath:helperLogFile()}));return;}let body='',size=0;for await(const chunk of req){size+=chunk.length;if(size>8192)throw Error('Request too large');body+=chunk;}const data=JSON.parse(body||'{}');
 if(req.method==='POST'&&req.url==='/connect'){if(!config.secret){res.writeHead(401);res.end(JSON.stringify({error:'Open CET Helper and enter your enrollment code.'}));return;}await request('/helper/approve',{id:data.id,secret:data.secret});res.end(JSON.stringify({ok:true}));}
 else if(req.method==='POST'&&req.url==='/activity'){activeAt=Date.now();res.end(JSON.stringify({ok:true}));}
 else if(req.method==='POST'&&req.url==='/reminder'){await reminderAction(data.action);res.end(JSON.stringify({ok:true}));}
 else if(req.method==='POST'&&req.url==='/upgrade'){const result=await upgradeHelper(data.portalUrl);res.end(JSON.stringify(result));}
 else {res.writeHead(404);res.end(JSON.stringify({error:'Endpoint not found.'}));}
 }catch(e){log('bridge.request.failed',{method:req.method,path:req.url,stage:updateStage,message:e.message});res.writeHead(e.status||400);res.end(JSON.stringify({error:e.message}));}
 });srv.on('error',e=>{lastError='Helper connection port unavailable: '+e.message;settings();});srv.listen(47831,'127.0.0.1');}
ipcMain.handle('state',()=>({portal:portalUrl(),username:username(),enrolled:!!config.secret,enrollment:config.pending?{status:config.pending.status,reference:config.pending.reference}:null,lastError,settings:latest?.settings||{snoozeMinutes:15},pending}));
async function pollEnrollment(){if(busy||!config.pending||['rejected','expired','revoked'].includes(config.pending.status))return;busy=true;try{if(!config.pending.id){const created=await request('/helper/requests',{username:username(),pcName:os.hostname(),secret:config.pending.secret});config.pending={...config.pending,...created};write(configFile(),config);}const r=await request('/helper/requests/status',{id:config.pending.id,secret:config.pending.secret});config.pending.status=r.status;lastError='';if(r.status==='approved'){config={portal:config.portal,secret:config.pending.secret,id:r.id};write(configFile(),config);if(app.isPackaged)app.setLoginItemSettings({openAtLogin:true});await openPortal();}else write(configFile(),config);}catch(e){lastError=e.message;}finally{busy=false;}}
ipcMain.handle('request-enrollment',async(event,{portal})=>{try{if(config.secret)return {error:'This helper is already enrolled.'};if(config.pending&&['pending','submitting'].includes(config.pending.status))return {ok:true};const checked=validateUrl(portal);const previous={...config};const secret=require('node:crypto').randomBytes(32).toString('hex');config={portal:checked,pending:{secret,status:'submitting'}};write(configFile(),config);try{const r=await request('/helper/requests',{username:username(),pcName:os.hostname(),secret});config.pending={...r,secret};write(configFile(),config);if(app.isPackaged)app.setLoginItemSettings({openAtLogin:true});return {ok:true};}catch(e){if(e.status){config=previous;write(configFile(),config);}throw e;}}catch(e){return {error:e.message};}});
ipcMain.handle('enroll',async(event,{portal,code})=>{try{const checked=validateUrl(portal);const previous={...config};config={portal:checked};try{const reply=await request('/helper/enroll',{code:code.trim(),username:username()});config={portal:checked,secret:reply.secret,id:reply.id};write(configFile(),config);if(app.isPackaged)app.setLoginItemSettings({openAtLogin:true});await tick();return {ok:true,name:reply.user.name};}catch(e){config=previous;throw e;}}catch(e){return {error:e.message};}});
ipcMain.handle('action',async(event,action)=>{try{if(action==='portal')await openPortal();else if(action==='settings')settings();else await reminderAction(action);return {ok:true};}catch(e){return {error:e.message};}});
app.on('second-instance',()=>settings());app.on('window-all-closed',()=>{});
app.whenReady().then(()=>{config=read(configFile(),{});reminderState=read(stateFile(),reminderState);log('helper.started',{version:app.getVersion(),portal:portalUrl(),packaged:app.isPackaged});if(app.isPackaged&&process.platform==='win32'){try{const shortcut=path.join(app.getPath('appData'),'Microsoft','Windows','Start Menu','Programs','CET Helper.lnk');shell.writeShortcutLink(shortcut,'update',{target:process.execPath,appUserModelId:'com.cet.momentum.helper',description:'CET timesheet reminders'});}catch(e){log('shortcut.update.failed',{message:e.message});}}const icon=nativeImage.createFromPath(path.join(__dirname,'icon.png')).resize({width:24,height:24});tray=new Tray(icon);tray.setToolTip('CET Helper');tray.setContextMenu(Menu.buildFromTemplate([{label:'Open CET Calendar',click:openPortal},{label:'Connection & enrollment',click:settings},{label:'Show reminder',click:showReminder},{label:'Open helper diagnostic log',click:openHelperLog},{type:'separator'},{label:'Quit CET Helper',click:()=>app.quit()}]));tray.on('double-click',openPortal);bridge();if(!config.secret)settings();tick();reportVersion();setInterval(()=>{tick();reportVersion();},15000);powerMonitor.on('resume',()=>{tick();reportVersion();});});
