# CET Helper 1.2.9

This complete release already includes the Windows installer in `..\downloads\CET-Helper-Setup.exe` and matching `helper-release.json`. No build is needed to deploy it. Embedded default URL:

https://dxb01-vwu-afna1.dibuat.ae/CETGamification

Existing saved connections/enrollments are retained. Change a previous localhost connection in Helper Settings when moving to the server.

## Future Windows build

From PowerShell in `CET-Momentum\helper`:

```powershell
& '..\Node\node.exe' '.\BuildPublish-Helper.js' --portal-url 'https://dxb01-vwu-afna1.dibuat.ae/CETGamification' --version 1.2.10
```

The starter updates version metadata, builds the installer, publishes it and writes matching SHA-256, version and size. Publish installer and release JSON together. Editing version JSON alone does not update an installed EXE.

Build dependencies and Windows Electron 38.8.6 are included. Future builds may download missing Electron Builder NSIS/signing/resource tools. Normal deployment does not need those downloads. See `CODE-SIGNING.md` for corporate signing.

## Linux cross-build

Install Linux build dependencies using the lockfile, then run the same starter with Node. Do not use the Windows `node_modules` distribution directly on Linux. `build-linux.cjs` uses electron-builder's existing `UninstallerReader` for intermediate NSIS uninstaller generation, avoiding Wine execution for that step. Other build tasks may still require the managed Wine toolset. This release uses electron-builder 26.15.3. Windows builds use the standard builder entry point unchanged.

## Automatic updater

The helper verifies release metadata and download SHA-256, and accepts update requests only for its saved/embedded portal URL. The corrected PowerShell launcher uses `detached: false`, `windowsHide: false`, `-WindowStyle Hidden` and `Start-Process` to create an independent worker. It waits for startup acknowledgement before closing.

The worker waits for the old helper to exit, installs as the current user, checks installer exit code and executable version, then restarts the actual executable path. The running helper reports its version to the portal. Downloading alone does not mark the update successful. No CMD script, scheduled task, service or administrator elevation is used. A brief console flash is possible. This preserves the handoff already validated in your Windows test.

For a local test, build using `http://localhost:5000` and set that `PUBLIC_URL` with a blank `BASE_PATH` in the portal `.env`. Keep the installed helper version below the published version. Do not mix local test and server URL configurations.

## Harmless Windows launch probe

```powershell
& '..\Node\node.exe' '.\Test-Update-Launcher.js'
```

After five seconds:

```powershell
& '..\Node\node.exe' '.\Test-Update-Launcher.js' --results
```

Both corrected-launcher checks should show PASS. The probe neither installs nor stops the helper.

## Logs

| Location/file | Contents |
| --- | --- |
| `%APPDATA%\CET Helper\logs\helper-update.log` | Structured startup, download, acknowledgement, installation and version events. |
| `helper-update-launcher.log` in that folder | Launcher startup, worker PID or exception. |
| `helper-update-powershell.log` / `helper-update-powershell-error.log` | Worker output/errors; either can be empty on success. |
| `installer-VERSION.log` | Helper-written setup start/end, exit code, executable path/version or failure. This is not an NSIS internal trace. |
| Portal `data\logs\helper-update.log` | Release checks, installer downloads and version reports. |

Success includes `handoff.script-started`, `update.handoff.acknowledged`, `handoff.installer-exit` with `exitCode=0`, `handoff.version-verified`, `helper.started` with the new version, and `version.reported` with `updateAvailable=false`.
