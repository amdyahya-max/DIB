'use strict';

// Cross-build the same NSIS installer on Linux. electron-builder already ships
// a binary reader for generating its unsigned NSIS uninstaller without Wine.
// Apply that reader only to the intermediate uninstaller-generation step.
const path = require('node:path');
const { WineVmManager } = require('app-builder-lib/out/vm/WineVm.js');
const { UninstallerReader } = require('app-builder-lib/out/targets/nsis/nsisUtil.js');
if (process.platform !== 'linux') throw new Error('This build entry point is for Linux only.');
const original = WineVmManager.prototype.exec;
WineVmManager.prototype.exec = async function (file, args, options) {
  if (path.basename(file) === 'CET-Helper-Setup.exe' && args.length === 0 && options?.env?.__COMPAT_LAYER === 'RunAsInvoker') {
    console.log('Generating the NSIS uninstaller with electron-builder UninstallerReader.');
    return UninstallerReader.exec(file, file.replace(/\.exe$/, '.__uninstaller.exe'));
  }
  return original.call(this, file, args, options);
};
require('electron-builder/cli.js');
