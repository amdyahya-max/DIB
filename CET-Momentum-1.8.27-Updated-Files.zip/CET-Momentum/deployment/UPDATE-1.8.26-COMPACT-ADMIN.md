# CET Momentum 1.8.26 — compact Administration

Portal **1.8.26**, Helper **1.2.9** unchanged. Preserved base **1.8.12** remains intact.

## More space for the working lists

The layout covers every Administration section: **Users, Attendance Activity, Settings, Pen Fight, Records, Helpers and Audit**. The breadcrumb and active tab identify the section; the repeated large Administration heading is removed.

- **Users:** Excel sync status, Sync now, Add user and Upload Excel share one command row. The user count and column/search/status filters share a compact table heading. Selection and bulk controls sit directly above the table. User rows use name/account and compact icons rather than multiple metadata lines. Hover email/ID/weekend icons for details; those fields remain searchable and editable. Row actions have descriptive tooltips and accessible labels: key = Enrol; pen = Edit; calendar = Dates; calendar-plus = Extend expired account; bin = individual Delete. Self-access protection remains.
- **Add user / Upload Excel:** use their visible toolbar buttons to open focused dialogs. Closing or Escape returns to the list; Escape is blocked while a save/import is running. The existing SQLite/Excel write, expiry, import validation and duplicate handling remain.
- **Delete all non-admin users:** now under **More (⋯)** beside bulk controls. Permanent delete still requires confirmation and protects administrators. Delete selected stays in the bulk row; individual Delete retains history.
- **Attendance Activity:** heading/month/follow-up counts and search/selection/mail controls are compact. The information icon explains Outlook drafting and recipients without occupying a full instruction row. Counting rules expand below the table. Email drafts are still reviewed and sent by the administrator.
- **Settings:** reduced spacing and compact field groups. Reminder times, calendar workdays, holidays and saving behavior are unchanged.
- **Pen Fight:** compact Game settings / Player access tabs. Player policy and game state share one heading row, with search, filters and bulk enable/disable together beneath it on wide screens. Rules expand on demand. Selected-only policy and server enforcement remain as in 1.8.25.
- **Records:** month/load/export share the report heading; leave and correction fields use compact groups.
- **Helpers:** compact request/enrolment tables and optional approval guidance. Empty tables do not reserve an unnecessary tall list area. Approve/reject/revoke still operate as before.
- **Audit:** dense rows show a short visible detail line; expand a row’s details to read its complete JSON.

Every list measures its actual position and uses the remaining viewport height. Resizing the window, switching sections or loading data updates that space. Tables keep sticky column headers. On narrower screens, controls wrap as needed and wide tables scroll internally; labels and functions remain available.

With the same 205-user data at **1440×900**, the Users list starts around **239px** rather than **460px** and displays **12 complete user rows rather than 5**. Row height is approximately **47px rather than 68px**. Results depend on screen size, browser zoom and row content; no one-row promise is made for mobile.

## Deploy the prebuilt update

1. Stop the NSSM portal service and back up the application and data while stopped.
2. Copy updated code and replace the **entire dist folder** with the supplied build. No frontend rebuild is required to deploy this ZIP.
3. Keep production **.env**, **storage** (SQLite/WAL/SHM), **data** (Excel), **Node**, root **node_modules**, Helper settings and working IIS configuration. Do not overwrite production data with packaged blank templates. No dependency update is needed.
4. **Updated-Files** omits only `downloads/CET-Helper-Setup.exe`; keep your existing installer. **Complete** includes the unchanged installer. No Helper rebuild/reinstall is required.
5. Restart the service and refresh the browser. The footer and `/api/info` should report **1.8.26**.

No database migration is added by 1.8.26. Upgrades from earlier versions still perform the existing idempotent player-access migration. Game-access policy, roles, attendance, Excel import, permissions, game mechanics and sounds are retained.

Changed UI files: `src/main.jsx`, `src/AttendanceActivity.jsx`, `src/PenFightAccess.jsx`, `src/PenFightAccess.css`. New: `src/AdminCompact.css`, `src/admin-list-space.js`. Version metadata, tests/docs and built dist are updated. Backend business routes and Helper/download files are unchanged from 1.8.25; server/index.js only changes reported portal version.

Validation: **TEST-RESULTS-1.8.26.md**, **validation/1.8.26**. Windows deployment: **WINDOWS-SERVER-IIS.md**. Player policy guide: **UPDATE-1.8.25-PLAYER-ACCESS.md**.
