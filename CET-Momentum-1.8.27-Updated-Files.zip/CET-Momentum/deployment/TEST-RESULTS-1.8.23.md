# Validation — CET Momentum 1.8.23

Verified on Linux with Node 24.19.0 and headless Chromium 153.0.8010.0 on 11 October 2026.

- Production Vite build passed. The included dist has the current HTML and hashed frontend assets. Existing informational startup.js/startup.css build notices remain unchanged.
- **63 automated tests passed, zero failures.** Existing portal, roster, access control, actual Node/SQLite HTTP integrations, scoring, bot and physics tests remain passing. New tests cover all four gravity edges, exact half-overhang balance, inward recovery, independent local sound keys, storage denial, muted/no-context behavior, power-sensitive bounded audio, browser audio denial, quiet rolling, voice cleanup and slowing rolling cues.
- **34 built-browser checks passed, zero uncaught errors.** The actual production frontend uses a real Node/SQLite test server with synthetic users. Only the native Windows tray bridge is simulated.
- Real Web Audio OfflineAudioContext rendering gives nonzero strike signals, a stronger high-power strike and quieter rolling clicks. RMS values in browser-results.json are recorded evidence, not speaker measurements. UI tests verify actual AudioContext oscillator scheduling during enabled flick/bot motion and zero subsequent scheduling after muting.
- Sound is initially off without constructing an AudioContext, survives reload when enabled, stays off for the same user in a fresh browser profile, and can differ between two real colleague sessions. No autoplay-permission override is used.
- Full names appear beside unique initials; an extra-long name uses ellipsis with a full-name tooltip. The desktop desk and scorecard bottom edges align within two CSS pixels. Desktop, 620px and 390px layouts were checked for overflow and visually inspected.
- Off-centre pointer hits still reach the server and produce roll and spin; stronger barrel highlights and clips render. Half-overhang remains visible without scoring. A complete fall delays visible score/contest changes for the 3.2-second sequence.
- All preceding round-note, final popup, five-round/four-contest scoring, automatic solo bot, independent colleague turns, stable MY/MY2 tags, Admin settings, all pen pairs and open-game Continue/End regressions pass.
- All 20 Helper/download files are byte-for-byte unchanged from the recovered 1.8.22 package. Helper 1.2.9 and standalone base 1.8.12 are retained. No database-table migration or new dependency is needed.
- Both archives are CRC-checked, extracted and hash-compared with the packaged source. Complete includes the unchanged installer; Updated-Files excludes only downloads/CET-Helper-Setup.exe. Live production data, Node/node_modules and temporary browser QA screenshots are excluded.

Windows Server/IIS/NSSM and native Windows Helper behavior were not executed here. Physical speaker volume and Windows/browser audio permission must be checked on a client PC. The physics uses a uniform-centre approximation, not a full 3D mass simulation.

Deployment: UPDATE-1.8.23-SOUND-BALANCE.md. Evidence: validation/1.8.23. Older reports are historical.
