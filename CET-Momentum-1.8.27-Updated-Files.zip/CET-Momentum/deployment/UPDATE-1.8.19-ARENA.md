# CET Momentum 1.8.19 — compact Pen Fight and grouped rounds

## What changed

The arena combines its title, attendance status and match rules into one compact top bar. The separate portal breadcrumb and Helper connection status move to the bottom for this page. Compact player cards sit above the large table; a wooden round scorecard sits beside the board on desktop and below it on small screens. The old score table beneath the game and the table in the result popup are removed. Open tables, recent games and the leaderboard stay in the lounge, keeping the active game focused on its board. The gold scoring boundary, realistic pen pairs, aim lines, impacts, smooth motion and button controls are retained.

Players use first/last initials: **Muhammad Yahya → MY**. If another player has the same initials, their tag becomes **MY2**, then MY3, etc. Tags are unique across the portal, stored by user ID, and remain stable across refreshes, games and display-name edits. Full names stay in user management. The computer is **BOT**. Hidden leader visibility rules still apply.

## Raised table and falling pens

The tabletop now has a raised wooden side, a ground shadow and room around its edges. After a knockout the losing pen slides fully off the playing surface, rotates, drops, shrinks and fades. Both pens fall when both are knocked out. A pen leaving the far edge falls behind the tabletop, which naturally obscures it.

The visible score, round subtotal and next contest are held for **3.2 seconds** while the fall completes. The next pens then appear at their random positions; the bot waits for this animation before making its next move. The final result popup also waits for the fall. Browsers requesting reduced motion show the settled state immediately instead of playing the movement.

The gold boundary still determines a knockout. The server records the result immediately so both PCs share one authoritative score; the presentation waits until the fall is complete before revealing the points. Animation does not change collision rules or award an extra point.

## New match rules — colleague challenges and Solo vs BOT

- Default match: **5 rounds × 4 scoring contests** = 20 contests.
- A scoring contest ends when a pen crosses the gold line. The other player gets **1 point**. Both pens out in the same simulation step, or 40 scoreless flicks, draw that contest: **0 points each**.
- A draw still uses one of the round's contests, so a round can contain fewer than four awarded points. Four means four completed contests, not first-to-four or exactly four awarded points.
- Positions and angles reset randomly after every contest. Players alternate who takes the first flick. An even contest count gives both players the same number of starts per round.
- Each round's subtotal stays in the adjacent scorecard. Match totals are the sum of every round's points. All configured rounds are played, including when one player has a large lead.
- Only after the final contest of the final round does the large result popup announce the winner and show the summed totals. It closes after five seconds. Equal final totals produce a draw; there is no sudden death or early finish.

Example: round scores of 3:1, 2:2, 1:3, 4:0 and 2:2 produce a final **12:8** win. The number of round wins does not decide the winner.

Open **Administration → Pen Fight** to set **Rounds per match (1–15)** and **Scoring contests per round (even numbers 2–20)**. These settings apply to new matches. Access gating, pen pairs, start date and daily limit remain configurable there. Pen Fight is OFF by default on a fresh installation.

Colleague challenges use the same rules and authoritative server state on both PCs. Create a challenge, ask an eligible colleague to join Open tables, then take turns. A final win awards 30 separate fun points; the other player gets 10, or both get 10 for a draw. Nothing is awarded before the whole match finishes. Solo is practice and does not award competitive or attendance points.

## Existing data and migration

On service startup the portal adds `penfight_config.contests_per_round` (default 4) if missing, and creates `penfight_player_tags` for unique persistent player tags. Existing configuration, roster, attendance, helpers and saved matches are retained. Permanent user removal also removes their tag through the database's foreign-key cascade.

New match JSON snapshots contain the round count, even contest count, current contest, round subtotal and completed contest/round results. Existing games keep their original first-to or one-contest-per-round snapshots and prior results. Complete or cancel old games and start a **new match** to test this update. The obsolete `wins_to_win` column remains for compatibility; it does not control new games.

## Deploy the prebuilt update

1. Stop the NSSM portal service. Back up your current application and SQLite storage while it is stopped.
2. Extract into a staging folder. Keep your production **.env**, **data**, **storage**, **Node**, **node_modules**, and working IIS configuration.
3. Replace the updated **server**, **src**, **public**, and **dist** folders and package/documentation files. Replace `dist` as a whole folder so stale assets are removed. Dependencies have not changed.
4. Restart the NSSM service. Startup runs the additive migration. Check `/CETGamification/api/info` reports **1.8.19** and refresh with **Ctrl+F5**.
5. Open Admin → Pen Fight. Check 5 rounds and 4 contests, save, and start a new solo or colleague game. One knockout should update the subtotal while remaining in round 1; contest 4 should start round 2. Only the final contest should show the result popup.

No frontend rebuild or npm install is needed on the server if you retain your working Node 24 and root node_modules. Do not replace your production Excel or SQLite with the packaged blank template or storage README.

Both ZIPs contain current application/helper source, built frontend and verification reports. They exclude Node/node_modules and live production data. The Complete ZIP includes the unchanged Helper 1.2.9 installer. Updated-Files omits only that installer; keep your existing `downloads/CET-Helper-Setup.exe`. No helper rebuild or reinstall is required. Base 1.8.12 remains intact. Browser screenshots used during checks are not packaged.
