# CET Momentum 1.8.22 — paper score notes and pen box

After a complete scoring round, the arena presents an original keepsake layout: an orange metal pen tin with the current player pair, foam slots and round markers beside a torn, ruled notebook score sheet.

## Behavior

- A round note appears after all configured contests in a round finish, not after every pen knockout. The falling/motion animation finishes first.
- The note shows the round winner or tie, both players' round points, running match totals and rounds still to play. Encouragement changes for a win, loss or tie.
- A round is never announced as a match victory. Existing all-round scoring decides the final match winner. Round points do not create extra fun-point awards.
- Next round closes the note immediately. It also closes automatically after five seconds. Escape closes it. Focus stays on its action button while open.
- Your flick controls and local bot scheduling pause while a note is pending or open. Normal server refresh continues. This is a per-client presentation pause, not a shared server lock; another participant's note opens when their next refresh sees the completed round.
- Refreshing, resuming an old match or receiving the same state again does not replay old round notes. Only a newly observed completed round in the currently open game triggers a note. If multiple rounds were missed, it shows the latest newly completed round. Leaving the game clears it.
- The final match result uses the same paper-and-tin design, shows only final summed totals and existing fun-point information, and closes after five seconds. It replaces the round note for the last round; there are no two stacked announcements.
- Solo and colleague matches use the same notes. Pens come from each match's saved pen pair. Completed round markers are relative to the current player: tick = round won, cross = opponent won, equals = tied. A final tie retains the usual participation credit in colleague mode.
- Desktop uses a side-by-side box/note. Small screens use a compact box above the note. Long content scrolls within the popup. Reduced-motion preferences are respected.

The 1.8.21 wooden desk, full-fall support rules, spin/rolling physics and all 1.8.20 open-game controls remain. This release does not change the server game engine, database schema, scores, existing round settings, dependencies or Helper 1.2.9. Standalone base 1.8.12 remains preserved.

## Deploy

1. Stop the NSSM portal service and back up the production application/storage.
2. Extract the ZIP into staging. Preserve production .env, data, storage, Node, root node_modules and working IIS configuration. Never overwrite live SQLite or Excel with the blank packaged template.
3. Replace server, src, public and the complete dist folder with the supplied folders. Copy updated package files and documentation. The frontend is already built; dependencies are unchanged.
4. Restart the service. Check /CETGamification/api/info reports 1.8.22, then refresh with Ctrl+F5.
5. Complete all contests in a round. After motion finishes, verify the paper note's scores, Next round, five-second auto-close and final match note.

No dependency installation, database migration or Helper rebuild/reinstall is needed. Complete includes the unchanged Helper installer. Updated-Files contains the same files except downloads/CET-Helper-Setup.exe; retain your existing installer. Both exclude Node/node_modules and live production data.
