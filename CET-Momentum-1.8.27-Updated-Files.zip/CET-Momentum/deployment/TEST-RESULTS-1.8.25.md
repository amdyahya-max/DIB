# Validation — CET Momentum 1.8.25

Linux, Node 24.19.0, headless Chromium 153.0.8010.0, 11 October 2026.

- **71 automated tests passed**, zero failures. New real-HTTP access tests cover upgrade from the older schema, repeated initialization, policy validation, admin-only mutations, atomic bulk validation, newly added users, grant persistence during roster sync, active portal/attendance/master-switch checks, selected-only solo and duel gating, bot/shot rejection after revocation, opponent revocation, leader privacy, lobby/leaderboard filtering and ending a revoked player's own game without awards. Existing production-route bulk-delete test now verifies grant cleanup by cascade.
- **49 browser checks passed**, zero uncaught errors: 43 complete arena/access checks plus 6 focused final-build checks using a 205-user roster. Both use real Node/SQLite portal APIs and production assets; only the native Windows tray bridge is simulated.
- Access UI verified: separate subsection, case-insensitive email/Windows-account search, individual Enable/Disable, filter-scoped selection, bulk actions, own-admin menu disappearance/restoration while Admin remains visible, game/portal-status filters and readable hover states.
- 205-user table remains bounded and scrollable. Select-all applies to every filtered row, including offscreen rows. A separate non-admin session loses Arena entry while keeping Calendar/Race; individual re-enable restores the menu after reload.
- Final responsive CSS verified at 390px: heading stays within its container, policy follows without overlap, no horizontal page overflow; wide table columns scroll inside the table. Desktop and mobile access screenshots were visually inspected and are omitted from delivery.
- Prior arena regressions remain passing: pointer aiming, solo bot, real colleague turns, sound defaults/persistence/local independence and actual Web Audio rendering, spin/rolling/half-overhang/full falls, timed floor sounds, all-round scores, round/final popups, and open-game Continue/End.
- Production Vite build passed; dist is included. Existing startup.js/startup.css informational build notices remain; built startup files are present.
- All 20 Helper/download files, game engine and sound modules are byte-for-byte unchanged from 1.8.24. Helper remains 1.2.9. Dependency specifications and locks retain existing dependencies; only root version metadata changed. Original base 1.8.12 remains preserved separately.
- Automatic additive schema migration preserves existing users/settings/attendance and does not replace production SQLite or Excel. Existing access policy defaults to all; restriction is an explicit administrator action.
- Delivery ZIPs are closed, CRC-tested, extracted and hash-compared. Updated-Files omits only downloads/CET-Helper-Setup.exe. No Node/node_modules, production secrets/database or temporary QA captures are included.

Native Windows IIS/NSSM/Helper execution was not performed here. Deploy with UPDATE-1.8.25-PLAYER-ACCESS.md and retain production data/configuration/dependencies.

Evidence: validation/1.8.25/automated-tests.txt, build.txt, browser-results.json, access-browser-results.json.
