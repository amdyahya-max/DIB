# CET Momentum 1.8.17 — capped pens and Admin pair selection

## Choose your pair

Open **Administration → Pen Fight → Pen pair**, choose a design and click **Save game settings**. The live preview shows both full pens before saving.

| Pair | Player 1 | Player 2 |
|---|---|---|
| Classic blue & white (default) | Blue barrel, blue cover | White barrel, blue cover |
| Classic blue & red | White barrel, blue cover | White barrel, red cover |
| Premium navy & burgundy | Silver barrel, navy cover | Silver barrel, burgundy cover |
| Existing personalised pens | Original colour/model for the first user | Original colour/model for the opponent |

The capped designs are original CET artwork inspired by the supplied reference. They have a glossy cylindrical barrel, rounded opaque cover, pocket clip, collar and end plug. They play with the cover fitted: there is no exposed pencil-like nib. This release provides preset pairs, rather than arbitrary image uploads.

## How settings behave

The selected pair applies to new solo games and colleague duels. It is saved in SQLite and copied into each match by the server. Changing the setting does not recolour a running match. Games created before this release retain their original personalised designs. In a duel both players see the same seat assignments; the scoreboard identifies the pen belonging to each user. The lounge illustration previews the currently configured pair.

Every capped pair uses the same size, movement and collision physics. The gold-line scoring check includes the full width of the cover when rotated; old and personalised pen games retain the previous tapered nib footprint. Trails and aiming colours match the pens. First-to score, maximum rounds, daily quota, attendance eligibility, privacy, solo AI and the five-second result popup continue to work.

## Deploy safely

1. Stop the portal's NSSM service and back up the production folder, including its SQLite storage.
2. Extract to a staging folder. Keep production **.env**, **data**, **storage**, **Node**, **node_modules** and the working IIS configuration.
3. Copy the new **src**, **server**, **public**, **dist**, package files, tests and documentation into the production application. Replace `dist` as a folder so stale assets do not remain. Dependency versions have not changed.
4. Restart the service. The normal startup migration adds only `penfight_config.pen_pair`, preserving existing users, attendance, matches, points and settings.
5. Check `/CETGamification/api/info` reports **1.8.17**. Press **Ctrl+F5**, then save your choice in Administration → Pen Fight and start a new game.

The frontend is already built. You do not need to rebuild it to deploy this release. Node 24 and your existing root node_modules are required; they are intentionally excluded from these source ZIPs. The complete ZIP includes the unchanged CET Helper 1.2.9 source and installer. The smaller Updated-Files ZIP omits only that unchanged installer: keep your existing `downloads/CET-Helper-Setup.exe`. No helper update or helper rebuild is required.

The original 1.8.12 base ZIP remains intact. No production database, enrollment secrets or live logs are packaged. `data/CET_Users.xlsx` is a blank template; do not replace your populated production Excel file with it.
