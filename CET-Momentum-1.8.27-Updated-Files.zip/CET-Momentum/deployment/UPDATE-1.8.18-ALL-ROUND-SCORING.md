# CET Momentum 1.8.18 — random round layouts and total-point matches

## What players see

- A new match starts with pens at varied positions and independent angles. Each completed round resets to a different layout, rather than straight head-to-head pens.
- Pens start well inside the gold line, with enough separation to avoid overlap. Their centres are mirrored for equal distance to the table edges. Both players receive the same server-generated positions; refreshing or reopening a match does not reroll them.
- Each round win awards **1 match point**. Both pens crossing the line in the same simulation step draws the round for **0 points each**. Forty scoreless flicks also draw the round.
- **All configured rounds are played**, even when a player has a large lead. The higher final total wins; equal totals produce a draw. There is no sudden death or early first-to-score finish for new matches.
- The points table lists each round's points, outcome and running total. The current round is highlighted. The final total stays visible while scrolling long tables and appears in the victory/result popup. The permanent table remains in the saved match after the popup closes after five seconds.

Example: in a five-round game, player A wins rounds 1 and 2, and player B wins rounds 3, 4 and 5. All five rounds are played; player B wins **3:2**.

These rules apply to **both colleague challenges and Solo vs CET Bot**, at all bot difficulty levels. Players alternate the first turn each round. The first participant starts round 1. Colleague matches award the existing 30 fun points for the final match winner and 10 for the other player; drawn matches award 10 each. Round points are match scores, not extra leaderboard or attendance credits. Solo remains practice with no competitive points. No points are awarded before a colleague match finishes.

## Admin setting

Open **Administration → Pen Fight → Rounds per match**, choose a whole number from **1 to 15**, and save. This is the exact number of rounds played by new games. The former "Round wins needed" control is replaced by an explanation of the total-point policy. Your existing round count, access settings, daily limit and pen-pair choice remain saved. Pen Fight remains OFF by default for fresh installations.

## Existing matches and database

Start a **new match** to use the new layout and scoring. Previously created matches retain their saved first-to rules and original reset positions so their rules do not change partway through play. Their prior scores and fun points are preserved. Their round table is reconstructed from the saved shot history when needed.

New match state stores the server-selected layout seed, round layouts and completed-round summaries in the existing `penfight_matches.state` JSON column. Random layouts are repeatable for that match and round so computer trial shots cannot change the live board. Clients cannot choose the seed, scoring policy, winner or awarded points. No new database tables are required for this update. The old `wins_to_win` configuration column remains for compatibility with existing data and is not used for new matches.

## Deploy the prebuilt portal

1. Stop the NSSM portal service and back up your production folder, including SQLite storage.
2. Extract this ZIP to staging. Keep production **.env**, **data**, **storage**, **Node**, **node_modules** and the working IIS web.config.
3. Copy the updated **server**, **src**, **public**, **dist**, package files and documentation into your application folder. Replace `dist` as a whole folder to remove old assets. Dependencies have not changed.
4. Restart the NSSM service. Check `/CETGamification/api/info` shows **1.8.18**.
5. Press **Ctrl+F5**. Check Admin → Pen Fight → Rounds per match, then start a **new** solo game or colleague challenge. After a round ends, verify the table records its point and the next layout changes. Play the last round to check the final total and result popup.

The frontend is built, so no npm install or frontend rebuild is needed if you retain your working Node 24 and root node_modules. They are intentionally excluded from the source ZIPs. Do not overwrite production Excel or SQLite with the packaged blank template/storage README.

The Complete ZIP includes all application/helper source, built dist and the unchanged Helper 1.2.9 installer. The smaller Updated-Files ZIP omits only `downloads/CET-Helper-Setup.exe`; keep your existing installer. No helper update is required. Base 1.8.12 remains intact.
