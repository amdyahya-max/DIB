# CET Momentum 1.8.27 validation

Portal 1.8.27 / unchanged Helper 1.2.9. Preserved base 1.8.12 remains intact.

## Results

- **76 automated tests passed**, zero failures, skips or cancellations. Includes all previous business/physics/access tests plus five playback tests covering interpolation, rolling/fall timing, scheduler cancellation, timer fallback, bounded stalls and hidden-tab pause.
- **43 existing browser regressions passed**: real server shots, solo/BOT replies, two independent colleague sessions, opposite sound settings, game access, pen styles, rolling and impact-driven spin, knockout fall and synchronized sound, round notes, final winner and dismissal, cancellation/open games, mobile layout and hover readability.
- **7 focused animation browser checks passed**: automatic fall under reduced motion; persisted portal diagnostics; no-RAF timer fallback and SVG movement; 1.2-second delayed response; 1.4-second visible rendering stall; simulated hidden interval during a final fall with deferred score/winner; no replay on refresh.
- **Production build passed**. Existing notices for runtime startup.js/startup.css remain; both runtime files are included in dist.

Raw results: validation/1.8.27/automated-tests.txt, build.txt, browser-results.json and motion-browser-results.json. reduced-motion-before-fix.txt records the original missing-fall timeout under the same browser preference. The final focused run additionally checks DOM-observed movement, fall and floor contact are stored in the server log.

## Test boundaries

Used Linux Chromium 153, the real Node server and isolated SQLite/Excel synthetic data. Only the native Windows Helper identity bridge was mocked. Browser tests disabled GPU acceleration; the background-tab case controlled the document.hidden getter to reproduce scheduling behavior. These checks do not certify an actual Windows Server 2019/IIS, managed-browser policy or physical GPU display. Production diagnostics are included to identify the affected PC’s behavior without F12.

76 automated tests and the focused browser checks ran against the final build. The 43 broad browser regressions ran on the same functional fix before adding DOM-observation fields to diagnostics; the final focused run verifies those additional fields. No production data was used and no emails were sent.

## Preservation and delivery

No dependencies, database schema or scoring/physics rules changed. Helper sources, published installer and release metadata are byte-identical to 1.8.26. All server business files except diagnostic handling and reported version are unchanged. Compact Administration and all earlier features are retained.

Release ZIPs are checked for CRC integrity and every extracted file against SHA-256. Complete includes the unchanged Helper installer. Updated-Files omits that installer only. Node, node_modules, .env, live storage/database files and internal QA screenshots are excluded. Deployment and log interpretation: UPDATE-1.8.27-PEN-ANIMATION.md.
