# CET Momentum 1.8.23 — desk, sound and edge balance

Portal: **1.8.23**. Helper: **1.2.9**, unchanged. The original 1.8.12 base is preserved; all preceding portal and Pen Fight features remain.

## What users see

- A deeper raised desk, with the play-area container and wooden scorecard aligned at their lower edges on desktop. Instructions sit below both. On small screens the scorecard moves below the play area.
- Initials in the avatar, followed by the full name in the player card. Long names shorten with an ellipsis; hovering exposes the full name. Persistent unique tags (MY, MY2) still identify pens and score columns.
- A compact speaker icon in the arena header. **Sound starts OFF.** Clicking it enables power-sensitive flick/impact tones and soft rolling clicks. Click again to mute immediately.
- Brighter moving highlights, rotating barrel labels and cap clips make sideways rolling visible. Soft tak-tak clicks grow quieter and farther apart as motion slows. Axial movement slides, rather than inventing roll.

## Independent sound preference

The setting belongs to the current portal user in this browser profile on this PC. It is saved in localStorage using a user ID and portal-path key. It is never broadcast to the opponent or stored as a shared game setting. One player can hear sound while another is muted. The same user in another browser/profile or on another PC starts muted. Clearing browser site data resets the choice. Different origins keep separate preferences.

Audio is generated locally with Web Audio; it requires no downloads, remote sound library, Helper update or administrator rights. The first click enables browser audio. A saved ON preference unlocks again on the next pointer/keyboard interaction if the browser pauses audio. Browser/site audio permissions and system volume still apply. If storage is unavailable, the choice lasts only for the visit. Muting, leaving the arena or hiding the tab stops active tones; hidden tabs do not schedule new tones.

## Why a heavily overhanging pen used to stand

The prior rule kept a pen supported while any part touched the tabletop. It allowed half-overhangs but also allowed an unrealistic almost-complete overhang. There was no gravity trick: it was a simplified contact rule.

This release separates **balance** from **complete loss of contact**. A uniform-barrel mass-centre approximation keeps an exact half-overhang playable. Once the centre crosses an edge, outward gravity and visible tilt make the pen tip during the shot simulation. A small inward nudge can recover it before complete loss of support. A point is still awarded only after the entire rotated pen footprint leaves the desk; the 3.2-second fall animation finishes before visible scores change.

This is a lightweight game model, not a full three-dimensional rigid-body simulation. Real caps and different pen weights have different centres of mass; this version gives both players the same uniform-centre rule. Existing saved overhangs are evaluated on the next shot, and completed games are never rescored. Solo and colleague matches share this physics. Round counts, contests per round, paper notes and open-game controls are unchanged.

## Upgrade an existing Windows/IIS installation

1. Stop the portal's NSSM service and back up the existing application and data.
2. Copy the package's `server`, `src`, `dist`, `public`, `scripts`, deployment notes and root code/build files into the application. Replace the complete `dist` directory so its HTML and hashed assets belong to the same build.
3. **Keep production `.env`, `storage` (including SQLite/WAL/SHM), `data` (Excel), `Node`, root `node_modules`, Helper configuration, and working IIS configuration. Do not overwrite them with packaged templates.** No new dependency or database-table migration is required.
4. The Complete ZIP includes the unchanged Helper installer. Updated-Files excludes only `downloads/CET-Helper-Setup.exe`; keep the current installer. No Helper rebuild/reinstallation is needed.
5. Restart NSSM, open the portal and refresh once. API info and the footer should report portal 1.8.23, Helper 1.2.9. Open the arena; the speaker is muted for users without a saved preference.

The built frontend is already included. Node and node_modules are excluded from both ZIPs; retain existing Node 24 and root dependencies for an upgrade. Fresh-install instructions remain in `WINDOWS-SERVER-IIS.md` and README.
