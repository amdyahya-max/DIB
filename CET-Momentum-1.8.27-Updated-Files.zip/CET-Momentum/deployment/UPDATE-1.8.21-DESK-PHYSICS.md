# CET Momentum 1.8.21 — wooden desk and full-fall physics

## What changed

- The arena now has a perspective wooden desk, grain, scratches, a cup mark, a visible front edge, dark legs, a desk shadow and tiled floor, inspired by the supplied reference. The original pen artwork and compact scorecard are retained.
- The gold scoring rectangle is removed. The actual tabletop edge is the support boundary. The visible surface and simulation share the same coordinates; pointer aiming is mapped back from the perspective view.
- A pen stays in play while any part of its body/cap/nib touches or overlaps the tabletop. Half-overhang, a nib crossing the edge and exact edge contact do not award a point. A convex polygon support test handles rotation and corners, avoiding false scores from rectangular bounding-box approximations.
- Only a completely unsupported pen starts the falling animation and awards its opponent one contest point. Both pens completely off gives a draw. Visible scores and the next contest remain held through the existing 3.2-second sequence. Winning the entire match still depends on summed scores across all configured rounds.
- Cylinder rolling uses lateral travel divided by barrel radius. Rolling phase changes the pen's glint and profile as it travels. Axial sliding and sideways rolling have different friction; both lose energy over time.
- Grabbing near a pen's end produces angular momentum from the off-centre impulse; a centre flick has no artificial initial spin. Collisions transfer linear and angular momentum. Fall animation carries spin into a gravity-shaped drop beneath the table. Motion frames are interpolated for smoother playback.
- Solo and colleague games use the same server simulation. Expert bot trials also consider off-centre hits. Button controls flick from the centre. The pointer's hit position is validated on the server.
- New support physics applies to subsequent shots in existing open games. Scores, history, random layouts and each game's saved round rules remain. Old completed results are not recalculated. Old pens without a rolling field default to zero phase.
- My open games, Continue/End controls, independent challenges and the Admin daily limit from 1.8.20 remain.

This is a deterministic tabletop gameplay model, not a full 3D rigid-body engine. It deliberately allows any remaining support, including half-overhang, as requested; it does not tip a supported pen merely because its centre of mass crosses an edge.

## Deploy on the existing Windows server

1. Stop the NSSM portal service and back up the production application and storage.
2. Extract into staging. Preserve production `.env`, `data`, `storage`, `Node`, root `node_modules`, and your working IIS configuration. Do not replace live SQLite or Excel with the blank packaged template.
3. Replace `server`, `src`, `public` and `dist` with the supplied folders. Replace `dist` as a complete folder so old hashed assets do not remain. Copy updated package files and documentation. Dependencies are unchanged and the frontend is already built.
4. Restart the service. Check `/CETGamification/api/info` reports **1.8.21**, then refresh with Ctrl+F5.
5. Open a solo or colleague game. Check the wooden desk has no gold line, a half-overhanging pen remains in play, and a complete fall pauses before score/next contest. Drag from an end and sideways to see spin and roll.

No new database tables or columns, dependency installation, or Helper rebuild/reinstall are needed. Helper 1.2.9 source, installer and release metadata are unchanged. The standalone base 1.8.12 is preserved.

Complete contains source, the prebuilt frontend and the unchanged Helper installer. Updated-Files has the same contents except `downloads/CET-Helper-Setup.exe`; keep the existing installer. Node/node_modules and production data are excluded.
