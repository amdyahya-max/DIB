# Validation — CET Momentum 1.8.22

Verified on Linux with Node 24.19.0 and headless Chromium 153 on 11 October 2026.

- Production Vite build passed; the new built frontend is included. Existing informational startup.js/startup.css notices are unchanged.
- **56 automated tests passed, zero failures.** Existing portal/roster/access tests, actual Node/SQLite HTTP integration, scoring, support geometry, full-fall/rolling/spin and bot regressions remain passing. The server game engine is unchanged from 1.8.21.
- **25 built-browser checks passed, zero uncaught errors.** A real fourth-contest shot completes a round. After the falling sequence, the new pen box and paper note show the correct 3:1 round points, running totals and four remaining rounds. Flick controls are disabled while the note is pending/open. Next round closes it; a repeated refresh does not replay it. The box shows the current pen designs and one round marker.
- A 2:2 tied round shows a tied note, closes automatically and leaves the match playing. An opponent-winning 1:3 round shows encouragement with accurate totals and no premature final-match or fun-point announcement.
- The final twentieth contest shows a single You won the match dialog in the paper/box style, with 12:8 summed totals, no detailed score table, a five-second lifetime and no replay on refresh. No intermediate round note is stacked over it.
- The desktop round/final note and 390px mobile note were visually inspected. The mobile dialog fits the viewport width without horizontal page overflow. Temporary browser screenshots are not included as deliverables.
- All prior browser checks pass: Admin pen settings, original/capped pens, compact desk and scorecard, 620/390px arena layouts, perspective pointer and button flicks, off-centre rolling/spin, half-overhang without scoring, complete fall before visible scores, automatic solo bot, independent colleague turns, unique/stable MY/MY2 tags, grouped scoring, old open games and Continue/End behavior.
- All 20 helper/download files are byte-for-byte unchanged from 1.8.21. Helper 1.2.9 and preserved standalone base 1.8.12 are unchanged. No new database schema or dependency is needed.
- Both archives are closed, CRC-checked, extracted and compared with source hashes. Complete contains the unchanged installer; Updated-Files omits only downloads/CET-Helper-Setup.exe. Source and prebuilt frontend are included; Node/node_modules and live production data are excluded.

Windows IIS/NSSM and the native Windows Helper were not executed here. Browser tests simulate only the Windows tray bridge; portal APIs use a real Node/SQLite test server with synthetic users. Deployment instructions: UPDATE-1.8.22-ROUND-NOTES.md. Logs/results: validation/1.8.22. Older validation reports are historical.
