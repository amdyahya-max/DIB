# CET Momentum 1.8.16 — scoring boundary, match rules and user pens

Complete source and freshly built portal. The original no-game 1.8.12 base is untouched. CET Helper remains 1.2.9; no helper upgrade is needed.

## New in this release

- A bright continuous gold scoring rectangle replaces the faint dashed line. The renderer and server share the same boundary coordinates. The pen's barrel/cap and nib envelope, including rotation, must stay inside this line. Crossing it loses the round and gives the other player one round point; both out on the same simulation step draws the round. Shadows do not count.
- Large result dialog after the final movement: trophy, final score, winner/draw/completion message, fun credits, five-second countdown and automatic closure. Close early with the button or Escape. It does not replay on polling or reopening completed history. Reduced-motion users still get the timed result without decorative animation.
- Administration → Pen Fight → **Maximum rounds** (1–15) and **Round wins needed** (1–maximum rounds). Default remains 5 rounds / first to 3. Examples: 3/2 for a short game; 7/4 for a longer game. At the round limit the higher score wins; a tie draws. Forty scoreless flicks still draw a round.
- Settings are saved in SQLite and copied into each new match. Existing matches retain the rules they started with; older records without rules keep the original 5/3 defaults. Changing settings cannot move the goalposts during a match.
- Original ballpoint/gel pens replace the pencil-like artwork: clear barrel/ink core, clips, metal cones, rounded ballpoint tips and grips. Four CET designs (Glide, Click, Chrome, Flow), with a stable colour/model derived from each user ID. The bot has its own chrome/gold pen. Scorecard accents, aiming halos and trails identify that user's pen. Artwork is bundled locally and is not copied from another game.

## How colleague challenges work

1. Both users open the portal on their own enrolled PCs and complete required attendance through yesterday. Pen Fight must be enabled by Admin.
2. Player A chooses **Challenge a colleague → Create a challenge**. The match appears in **Open tables** for eligible visible colleagues. Ask Player B to open Pen Fight Arena; no invitation email/notification is sent automatically.
3. Player B clicks **Join**. The first colleague to join fills the only opponent seat. A waiting challenge can be cancelled by its creator.
4. The creator takes the first turn; each player pulls their own pen backwards and releases. Normal shots alternate turns, and the opening player alternates across rounds. The server calculates motion, out-of-bounds results and scores. The other browser refreshes approximately every four seconds while the arena is open.
5. Play until the saved winning target or round limit. Winner gets 30 fun points; the other player gets 10. A drawn match gives 10 each. Rewards are recorded once. Race/attendance credits stay unchanged.
6. Resume an ongoing game from **Recent games**. **Back to lounge** leaves only the view and does not forfeit the game. Cancel is available for unjoined challenges; solo practice has End practice.

Solo vs CET Bot requires no second person and offers Easy/Balanced/Expert. Solo does not award leaderboard points. Both modes use the administrator's daily creation limit; cancelled games also count. Joining another user's challenge does not consume the joining user's creation quota. Leader privacy and participant-only match access remain enforced. Group/squad games and tournaments are not included.

## Deploy on the existing server

1. Stop the NSSM portal service. Back up the production application, Excel data and complete SQLite storage while stopped.
2. Extract this ZIP to staging. Preserve production **.env**, **data**, **storage**, **Node**, **node_modules**, and the working IIS web.config. Never overwrite production data with packaged examples.
3. Update **server**, **src**, **public**, **tests**, package files and documentation. Replace the **entire dist** folder with the included new build. No frontend build is needed on the server. Node 24 and the existing root dependencies are required; dependency versions are unchanged.
4. Start the portal service. Startup adds two defaulted settings columns to penfight_config if missing, preserving existing feature settings, matches, points and all CET tables. Do not replace the SQLite database. Repeat startup is safe.
5. Verify `/CETGamification/api/info` reports **1.8.16**, then press **Ctrl+F5** in the browser.
6. In **Administration → Pen Fight**, set maximum rounds and round wins needed, then Save. Start a new game to test new rules. Existing matches continue their original rules.
7. Check the gold line, different pens, result popup, solo and a two-account colleague challenge in your managed Windows browser before rollout.

Helper source and published downloads are included unchanged for completeness. Node/node_modules are excluded; keep your working copies. No live production database or secrets are included.
