# CET Momentum 1.8.14 - Pen Fight integration

This is a separate Pen Fight edition. The 1.8.12 base ZIP remains unchanged and available without the game. CET Helper remains 1.2.9; its source and published installer are unchanged.

## Included

- Colourful Quick Duel for two enrolled CET users, server-calculated flicks and animated motion, match history and separate fun leaderboard.
- Admin-only feature controls, initially OFF. Disabled hides the menu and immediately blocks gameplay requests. Other open portals refresh the menu within their normal 30-second polling interval.
- Required attendance through the previous Dubai day. Checks start at the administrator's configured policy start date or the user's later joining date. Existing working-day, weekend, holiday, leave and self-absence rules apply.
- Up to five rounds, first to three wins. A round with forty scoreless flicks ends as a draw; after round five the higher score wins, or the match is a draw.
- Winner receives 30 fun points; the other player receives 10. A drawn match awards 10 each. Server scoring is awarded once and does not change attendance or CET Race credits.
- Daily limit applies to challenges created by each player, counted from Dubai midnight. Cancelled challenges still count. Joining a colleague's challenge does not use the creation quota.
- Waiting challenges can be cancelled by their creator. Leaders are hidden from normal-user lobby and rankings; cross-group challenges cannot expose a hidden leader. Existing matches mask hidden participant names.
- Permanent roster deletion cleans up Pen Fight references, preventing SQLite foreign-key errors. Individual roster removal continues to retain history.

Quick Duel is the implemented mode. Squad Clash and Tournament are not included.

## Deploy this built package

1. Stop the existing NSSM portal service and back up the application, production Excel roster and entire SQLite storage folder.
2. Extract this ZIP into a separate staging folder. Keep your preserved 1.8.12 base ZIP.
3. Preserve your production `.env`, `data/CET_Users.xlsx`, entire `storage` folder, `Node`, `node_modules`, and working IIS configuration. Do not replace live data with the packaged roster. The helper and downloads are identical to 1.2.9 and need no upgrade.
4. Update `server`, `src`, `public`, `tests`, `package.json`, `package-lock.json`, `index.html`, `vite.config.js`, and documentation. Replace the entire portal `dist` folder with this ZIP's freshly built `dist`; do not mix assets from old and new builds.
5. Existing portal dependency requirements are unchanged. Node.js 24 is required. If dependencies are absent, restore them using the package lock before starting; they are excluded from this source ZIP.
6. Restart the portal service. Startup creates the additive `penfight_config`, `penfight_matches` and `penfight_points` tables; it preserves existing CET tables and rows. No production database is included in this ZIP.
7. Confirm `/CETGamification/api/info` reports `1.8.14`, then refresh with Ctrl+F5.
8. Open Administration. Set the Pen Fight attendance start date and daily challenge limit, tick Enabled, and Save. The default start date is the first day of the deployment month; adjust it to your agreed policy before enabling. The start date cannot be in the future.
9. Use two separately enrolled CET accounts to create/join a duel. Verify a missing-attendance account is locked. Disable the feature and confirm the user menu disappears and play stops.

For a fresh installation, use `Start-Portal.js` with Node 24. The launcher creates `.env` from `.env.example` when absent. The example uses the production FQDN and `/CETGamification` path; configure it for local testing if needed.

The frontend has already been built. A rebuild is required only after future frontend source changes.
