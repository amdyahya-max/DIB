# CET Momentum 1.8.25 — selected-player Pen Fight access

Portal **1.8.25**, Helper **1.2.9** unchanged. Base **1.8.12** remains preserved separately.

## Choose your players

1. Open **Administration → Pen Fight → Player access**. Game settings remains a separate subsection, including the global ON/OFF switch, rounds and pen pairs.
2. Search by name, Windows username, email or company. Use Enabled/Disabled and portal-status filters as needed.
3. Use a row’s **Enable** button, or tick several players and click **Enable selected**. The header checkbox selects all rows matching the current filters, including rows below the scroll area, up to 1,000 per action. Changing filters clears selection; the count makes the action scope visible.
4. Choose **Selected players only** and click **Save access policy**. You may prepare the enabled-player list before switching. Only enabled players with active portal accounts and completed required attendance may play.
5. **Disable** or **Disable selected** removes game permission. Calendar and CET Race access, attendance, saved games and past scores remain. Re-enable later to restore game permission.

**Important:** existing installations and fresh installs use **All eligible users** until an administrator switches policy. In All eligible users mode, row Enable/Disable edits the saved selected-player list; it does not restrict effective access. The policy banner explains this. Switching back to Selected players only restores those choices. In selected mode, newly imported/added users start without game permission. Administrators also require game permission to play, but can always manage the policy with their administrator role.

When the global switch is OFF, nobody can play; selected-player choices remain saved. Enabling game access never enables a blocked, disabled, removed or expired portal account and does not waive required attendance.

## Enforcement and visibility

The server checks permission on every create, join, shot, bot-turn and game-read request, and on lobby/leaderboard requests. A revoked opponent cannot be joined or hit by a still-enabled player. Leader privacy filtering remains. Unselected players are hidden from the open lobby and competitive leaderboard while scores stay stored.

The Arena menu requires the global switch plus player permission. The active arena checks status every four seconds and stops showing play controls after revocation. Other open portal tabs refresh menu visibility on their existing 30-second refresh, or immediately on page reload. Stale tabs cannot bypass server checks. A participant may still retrieve their open-game summaries and end their own unfinished game without game permission while the master switch is ON; ending does not award points. No automatic ending or score deletion occurs.

Player choices live in SQLite and survive ordinary Excel sync, user edits and uploads. They are not new Excel columns. Game policy and permission changes are recorded in Admin Audit. Individual user removal retains historical records; permanent bulk user deletion also removes that user’s game grant by foreign-key cascade.

## Upgrade without replacing production data

1. Stop the NSSM portal service. Back up the application and production data while the service is stopped.
2. Copy application code from this release and replace the entire **dist** folder with the supplied prebuilt dist.
3. Keep production **.env**, **storage** (SQLite, WAL and SHM), **data** (Excel), **Node**, root **node_modules**, current Helper settings and working IIS configuration. Do not overwrite the roster with the blank template in this source package. No dependency change is required.
4. Complete includes the unchanged Helper installer. Updated-Files omits only `downloads/CET-Helper-Setup.exe`; retain your existing installer. No Helper reinstall/rebuild is needed.
5. Restart the service. Startup adds `penfight_config.access_mode` and `penfight_user_access` idempotently; it preserves existing settings, users, attendance and matches. Portal footer and `/api/info` should report **1.8.25**.
6. Open Player access, enable chosen players, switch to Selected players only and save. Check an enabled player and an unselected player in separate browser sessions.

New source: `server/penfight-access.js`, `src/PenFightAccess.jsx`, `src/PenFightAccess.css`. Updated route/UI wiring: `server/penfight.js`, `src/PenFight.jsx`, `src/main.jsx`. Version metadata, tests, documentation and built dist are updated. Physics and sound are unchanged.

Validation: **TEST-RESULTS-1.8.25.md** and **validation/1.8.25**. NSSM/IIS: **WINDOWS-SERVER-IIS.md**.
