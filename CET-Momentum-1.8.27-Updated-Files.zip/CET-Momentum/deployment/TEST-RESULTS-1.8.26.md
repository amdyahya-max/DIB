# CET Momentum 1.8.26 validation

Tested 11 October 2026. Portal 1.8.26; unchanged Helper 1.2.9; preserved base 1.8.12.

## Results

- **71 automated tests passed**, zero failures, skips or cancellations. Coverage includes permissions, attendance, SQLite/Excel import and expiry handling, user edit/delete protections, player access, and Pen Fight physics/scoring.
- **70 browser checks passed**, no uncaught browser errors: 43 arena/access regressions, 6 focused access checks with 205 users, and 21 compact-Administration checks across every section.
- **Production build passed** using existing dependencies. Prebuilt dist is included. Existing Vite notices for runtime startup.js/startup.css are retained; both runtime files are included.

Raw results: validation/1.8.26/automated-tests.txt, build.txt, browser-results.json, access-browser-results.json and admin-browser-results.json.

## Administration checks

Used the real Node/SQLite application with isolated synthetic data. The native Helper bridge was mocked for browser identity; no production data was used. Checked Users, Attendance Activity, Settings, Pen Fight, Records, Helpers and Audit at desktop, 1280px and 390px widths. Wide columns scroll within the list instead of overflowing the page.

Verified Add user writes SQLite/Excel including Never expiry; uploading an existing user updates without duplication; dialog Escape; column search, clear, sort; Edit persistence, Dates and Enrol actions; history-preserving individual deletion; bulk weekend enable/disable; self-disable protection; and the More-menu delete-all confirmation. Delete-all was cancelled during visual testing; permanent-delete protection and behavior are covered by automated tests. Reminder/calendar settings saved successfully. Attendance selection enabled the Outlook draft control; no draft was opened and no email was sent.

## Same-screen comparison

Same 205-user fixture and 1440×900 viewport:

| Measurement | 1.8.25 | 1.8.26 |
| --- | ---: | ---: |
| Users table top | 460.5px | 239px |
| List viewport height | 480px | 619px |
| User row height | 68px | 47px |
| Fully visible user rows | 5 | 12 |

The Player access list begins at 232px, has a 626px viewport and 45px rows, showing 13 complete player rows. Measurements vary with screen size, zoom and row content.

## Preserved behavior and packaging

Dependencies are unchanged. All Helper/download files are byte-identical to 1.8.25. Backend business files are unchanged; server/index.js changes only the portal version. No database migration is added. Existing game, sound, scoring and access checks passed.

Release ZIPs are checked for CRC integrity and every extracted file is checked against the source SHA-256 manifest. Complete includes the unchanged Windows Helper installer. Updated-Files omits that installer only. Neither package includes Node, node_modules, production .env, storage databases or internal QA screenshots.

## Scope

Browser checks ran in Linux Chromium 153. Native Windows installation, IIS/NSSM hosting and Windows notification UI were not executed in this run. Those components are unchanged in this release.
