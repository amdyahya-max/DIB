# CET Momentum 1.8.15 — Solo and the Momentum Desk

Separate release built from 1.8.14; the original 1.8.12 base ZIP is preserved untouched. CET Helper remains 1.2.9. Its source, installer and release metadata are unchanged, so this portal update requires no helper rebuild or reinstallation.

## What changed

- Admin → **Pen Fight** is now the dedicated settings tab. The control panel no longer sits above every administration section.
- Game buttons preserve their background and readable labels on hover. Admin selected tabs, enable toggles and user action hover colours remain readable.
- The original CET Momentum Desk has a centred large wood table, glossy blue/pink pens, compact scoreboard, turn indicators, pull-back aiming lines, power gauge, moving trails, spin and collision bursts. Visuals and icons are bundled locally; no online game assets or fonts are needed.
- **Solo vs CET Bot** works without a colleague. Choose Easy, Balanced or Expert. The server selects the bot's flick using simulated legal moves; the browser requests it automatically after the previous animation. Continue an active practice from Recent games, or End practice.
- **Colleague duels** retain their separate fun leaderboard and existing access rules. Solo is practice and awards no competitive points, wins or CET Race credits. No fake bot account is created.
- Pointer/mouse aiming: grab your pen, pull backwards, then release. A longer pull increases strength. A short pull cancels. The expandable direction/power controls also support keyboard use.
- Accessibility: reduced-motion preferences show final pen positions immediately and still allow automatic computer turns.

The match ends at three wins, or after five rounds with the higher score winning. Tied scores produce a draw. Forty scoreless flicks end the round as a draw. The administrator's daily creation limit covers both solo games and challenges, including cancelled games; joining a colleague's challenge does not use that quota.

## Update an existing production installation

1. Stop the NSSM portal service. Back up your complete production application, Excel data and SQLite storage while it is stopped.
2. Extract this ZIP into a separate staging folder. Keep the original 1.8.12 base archive.
3. Retain the production **.env**, **data**, **storage**, **Node**, **node_modules** and working IIS configuration. Do not replace live databases or the live Excel roster with packaged examples.
4. Replace **server**, **src**, **public**, **tests** and the **entire dist folder** with this release. Copy the package files and updated documentation. Do not mix old and new dist assets. The helper/downloads are included for completeness; their bytes are unchanged.
5. Restart the Node/NSSM service. Node.js 24 is required; dependency requirements are unchanged from 1.8.14. Keep your working root node_modules. It is intentionally excluded from this ZIP.
6. Confirm `/CETGamification/api/info` reports **1.8.15**. Reload the browser with **Ctrl+F5**.
7. Open **Administration → Pen Fight**. Check the attendance start date and daily limit, enable the game if desired, and select **Save game settings**. Existing feature settings are retained; a fresh database defaults to disabled.
8. Open **Pen Fight Arena → Start solo game**. Pull the blue pen backwards and release. The computer should respond after the movement completes. Use Recent games to continue.
9. Validate a colleague duel with a second enrolled account. Verify missing attendance locks the arena, and disabling Pen Fight blocks both modes and hides the menu.

For a new local installation, use your Node 24 executable to run `Start-Portal.js`. Set local PUBLIC_URL/BASE_PATH in .env as appropriate. The launcher creates .env from .env.example only if it is missing. The frontend is already built.

## Data compatibility

No new schema migration is required over 1.8.14: solo mode and difficulty are stored in the existing match JSON. Old records without a mode are treated as colleague duels. Existing Pen Fight tables, settings and points remain intact. Upgrading from the no-game base creates the additive Pen Fight tables at startup and preserves existing CET rows. Active matches continue with the improved pen physics after deployment; deploy during a quiet period.

Attendance, roster edits/uploads, account expiry, leader visibility, reminders, helper enrollment, IIS subpath support and CET Race retain their existing behavior. Check the included test report and actual interface captures in validation/1.8.15.
