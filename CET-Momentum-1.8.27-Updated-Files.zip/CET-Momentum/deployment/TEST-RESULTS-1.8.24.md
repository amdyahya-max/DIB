# Validation — CET Momentum 1.8.24

Linux, Node 24.19.0, headless Chromium 153.0.8010.0, 11 October 2026.

- Production Vite build passed; current dist is included. Existing startup.js/startup.css informational build notices are unchanged.
- **66 automated tests passed, zero failures.** New tests cover filtered falling noise, plastic knock/tile resonance, softer bounce levels, source cleanup on mute, shared floor-contact timing, simultaneous falls, and acceleration/bounce/rest visual positions. Existing portal, access, roster, database, scoring, gravity and bot tests remain passing.
- **36 browser checks passed, zero uncaught errors.** Real Node/SQLite test server and built frontend; only the native Windows tray bridge is mocked.
- Actual Web Audio offline rendering produces nonzero falling noise and floor impact. The softer bounce has less than one quarter the main impact's RMS. Values are saved in browser-results.json. These are rendered signal checks, not physical speaker measurements.
- With sound enabled, a real knockout produces one falling noise, then a main floor impact when visible drop progress reaches 0.72, then two bounce taps. Browser instrumentation records actual audio buffer starts alongside the visible falling pen pose. Score/contest changes still wait for the complete 3.2-second fall sequence. Refresh does not replay sounds.
- Desktop floor contact, fall, paper round note and mobile layout were visually inspected. Temporary QA screenshots are omitted from delivery.
- All preceding browser regressions pass: default mute, local user/PC independence, preference persistence, actual enabled oscillator scheduling and muting, full-name ellipsis, desk/scorecard alignment, pointer flicks and off-centre rolling, half-overhang/full fall, solo bot, real colleague turns, grouped scoring, paper round/final popups, and open-game Continue/End.
- Helper/download files and server/penfight-engine.js are byte-for-byte unchanged from 1.8.23. Helper remains 1.2.9. No dependency or database change; original base 1.8.12 remains preserved separately.
- ZIPs are closed, CRC-tested, extracted and hash-compared. Updated-Files excludes only downloads/CET-Helper-Setup.exe. Source/prebuilt frontend included; Node/node_modules and live production data excluded.

Windows IIS/NSSM/native Helper and physical PC speaker playback were not executed here. Browser permissions and system volume apply. The sound is a local synthesised pen-on-tile effect.

Deployment: UPDATE-1.8.24-FLOOR-SOUND.md. Evidence: validation/1.8.24.
