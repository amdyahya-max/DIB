# Validation — CET Momentum 1.8.15

10 October 2026. Linux, Node 24.19.0, Vite 7.3.6. Existing locked portal dependencies used.

- Production frontend build passed, including bundled icons, updated styles and startup resources.
- All 35 automated tests passed, zero failures/skips. Includes roster/SQLite synchronization, duplicate-email reconciliation, expiry, deletion, role protections, attendance, absences, activity, enrolled-session authentication, leader privacy and IIS subpath assets.
- Actual Node/SQLite HTTP Pen Fight checks passed: disabled by default; admin-only settings; origin enforcement; attendance cutoff/policy; quota and cancellation; participant privacy; authoritative turns and scoring; duplicate reward prevention; deletion cleanup.
- Solo HTTP checks passed: invalid mode rejection; missing-attendance lock; no lobby exposure or colleague join; owner-only computer requests; stale-shot rejection; bot turn enforcement; legal bot response; single active practice; shared limits; cancellation; no competitive points or synthetic users.
- Physics checks passed: finite capsule contacts, angular spin, motion frames/impact positions, best-of-five scoring, forty-shot round cap, legal non-mutating computer choice at all three difficulty levels.
- Actual headless Chromium used the built portal against the real Node/SQLite server. Only the Windows localhost tray bridge was simulated. Admin settings are isolated in their tab, save hover retains white text on a dark gradient, drag aiming submits shots, the computer replies automatically, optional button controls submit shots, active games resume, mobile layout fits without horizontal scrolling, reduced-motion computer play works, and two independent browser sessions can join and flick in a colleague duel. No uncaught browser errors.
- Original 1.8.12 archive hash verified unchanged. Helper 1.2.9 source/download files verified identical to the preserved base. Installer SHA-256 matches helper-release.json. ZIP integrity verified.

Evidence: validation/1.8.15/browser-results.json, actual UI captures and automated-tests.txt. Optional repeat UI test: tests/penfight-browser.mjs. It requires Playwright and Chromium supplied by the test environment, and is separate from the standard server test suite; production has no new dependency. Set CET_PLAYWRIGHT_MODULE and CET_CHROMIUM_PATH if they are installed outside the project. CET_UI_OUTPUT_DIR optionally chooses the evidence folder. Run the built source with `node tests/penfight-browser.mjs`.

This release was not executed on Windows Server/IIS or the organization's managed Windows browser. Stage it and verify the deployment checklist before rollout. The unchanged helper installer was not rebuilt or newly tested on Windows as part of this portal-only update.
