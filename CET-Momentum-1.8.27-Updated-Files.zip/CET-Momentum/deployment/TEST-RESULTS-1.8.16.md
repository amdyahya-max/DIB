# Validation — CET Momentum 1.8.16

10 October 2026. Linux / Node 24.19.0 / Vite 7.3.6 / headless Chromium.

- Production build passed. All 38 automated tests passed, zero failures/skips.
- All prior roster, auth, attendance, privacy, deletion, expiry, activity and subpath regressions passed.
- Pen bounds: exactly touching is in; small tip/barrel/rotated-envelope crossings are out; a pen whose centre remains inside can still lose; one out awards the other player a round point; two out on the same step draws.
- Configured victory threshold, final round cap/tied result, one-round match, legacy 5/3 fallback and server-controlled points passed.
- An old-schema Pen Fight settings table was migrated at actual server startup. Existing enabled flag/date/daily limit and CET rows were preserved, new round settings defaulted to 5/3. Invalid round/target values rejected. New match rules snapshotted; later settings edits did not alter that match.
- Stable user pen assignment checked across 200 IDs; next users have distinct colours, all four model indices valid, bot has a separate design.
- Actual built portal against actual Node/SQLite HTTP server: Admin settings saved 7/4, new matches used those rules, bright line coordinates/stroke verified, human/bot pen models differed, pointer and button flicks worked, automatic solo responses worked, history resumed, mobile fit, reduced-motion play worked and two independent browser sessions played a colleague duel.
- A controlled near-edge fixture was completed through the pointer UI. The fourth winning point was recorded; the large "You won the match!" dialog appeared after motion, remained visible at three seconds, disappeared after five seconds and did not recur on refresh. No uncaught browser errors.
- Only the Windows helper localhost bridge was simulated for browser tests. Windows Server/IIS execution and the organization's browser policies remain staging checks.
- Original base archive and helper source/download checksums verified unchanged; installer matches its release metadata. ZIP tested for integrity and excludes dependencies, live database and .env secrets.

Evidence: validation/1.8.16 contains the actual captures, browser-results.json and automated-tests.txt. The optional tests/penfight-browser.mjs can rerun UI checks with a test-environment Playwright/Chromium installation. Production requires no new dependencies. Set CET_PLAYWRIGHT_MODULE, CET_CHROMIUM_PATH and optionally CET_UI_OUTPUT_DIR when those are outside the project.
