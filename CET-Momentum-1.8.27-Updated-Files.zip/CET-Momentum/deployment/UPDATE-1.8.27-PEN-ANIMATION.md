# CET Momentum 1.8.27 — automatic Pen Fight motion and diagnostics

Portal 1.8.27 includes all changes through 1.8.26, including compact Administration. Helper 1.2.9 and preserved base 1.8.12 are unchanged. No dependencies or schema migration are added.

## Why the effect could disappear

Pen Fight previously checked the browser’s prefers-reduced-motion setting and immediately displayed the server’s final pen positions. That skipped interpolation, rolling, the fall and its landing presentation. CET Race already overrides that preference for automatic animation; Pen Fight now follows the same behavior. We reproduced the skipped fall with reduced motion enabled and verified the new build plays it.

This is an identified application cause, not a claim that the screenshot proves the production PC has that setting. The new logs show whether it applies on that PC. Browser settings and rendering run on the viewing PC/browser, even when the Node application is hosted on Windows Server.

## Changes

- Movement, rolling, edge fall and floor contact play automatically even when reduced motion is reported. No replay/Animate button is needed.
- A timer provides a fallback when requestAnimationFrame callbacks are missing or delayed. Both share one timeline, so a frame is not advanced twice.
- Long visible stalls advance by at most 80ms per tick, preventing a jump across the whole fall. Hidden-tab playback pauses and resumes instead of consuming background time.
- The score and next positions stay held during the fall. The final winner popup waits for actual playback completion instead of a fixed wall-clock delay; its existing five-second dismissal remains.
- Existing physics, tipping/overhang rules, server scoring, sounds, user roles, player access and Excel/attendance behavior are retained. Sound remains off by default.

## Deploy

1. Stop the NSSM service and back up the application and production data.
2. Copy the updated application code, including the complete server folder. Replace the entire dist folder with the supplied build. The changed source and prebuilt frontend are included; no server-side frontend rebuild is needed.
3. Preserve .env, storage, data, Node, root node_modules and working IIS web.config. Never overwrite production SQLite or the Excel roster with blank package templates.
4. Keep the existing Helper installer if using Updated-Files. The Complete ZIP includes the same installer and metadata. Helper does not need rebuilding/reinstalling.
5. Restart NSSM. Refresh the browser with Ctrl+F5; the footer and /api/info must show 1.8.27.
6. Play one solo flick and a shot that knocks the other pen off the desk. If still affected, collect the log entries below from the viewing PC’s session.

## Logs without F12

Open storage/logs/portal.log on the server in Notepad (or the logs folder inside your configured STORAGE_DIR). Look for event penfight.diagnostics.

Each entry’s message contains a JSON object. Common statuses:

| Status / field | Meaning |
| --- | --- |
| arena_ready | New arena view loaded; records client version, reduced-motion setting and available frame count. |
| playback_started | A new shot’s animation frames arrived and playback began. |
| playback_completed | Animation completed; includes computed movement plus DOM observations. |
| motion_data_missing | New shot had no frame data; final positions were displayed. |
| playback_cancelled | Playback was interrupted, for example by leaving the game or a newer shot. |
| reducedMotion: true, automaticMotion: true | Browser requested reduced motion; game animation still runs. |
| frames / samples | Frame data received / playback ticks processed. |
| domMoved / domRolled | SVG pen transform / rolling attributes changed during playback. |
| domFallSeen / domFloorSeen | Falling pen element and its floor-contact phase were observed in the page. |
| timerFrames | Number of playback ticks delivered by the timer fallback. |
| clampedGaps / maxGapMs | Render delays were bounded; longest observed gap in milliseconds. |
| hiddenTicks | Playback checked the hidden tab without advancing it. |
| version / css / browser | Client release, stylesheet filename and browser identity for stale-asset diagnosis. |

Normal knockout: playback_started followed by playback_completed with fall:true, domFallSeen:true and domFloorSeen:true. DOM observations verify element updates, not physical screen/GPU output. A sliding shot can legitimately have domRolled:false; a non-knockout has fall:false. An initially loaded old shot is not replayed.

If no new entries appear, confirm the browser footer shows 1.8.27, Ctrl+F5 was used, updated server/portal-diagnostics.js is deployed, and the NSSM account can write STORAGE_DIR. A mismatched client release or old JS/CSS assets indicates an incomplete dist replacement or stale intermediary cache. Existing startup diagnostics remain available for asset failures.

Share only the penfight.diagnostics entries for the affected attempt, with the PC/browser and time. Do not send .env, tokens or production SQLite files.

## Changed files

src/PenFight.jsx; new src/penfight-playback.js and src/penfight-diagnostics.js; server/portal-diagnostics.js; reported version in server/index.js and src/main.jsx; package version metadata, tests, release documentation and prebuilt dist. Helper/download files and server game physics/business routes are unchanged from 1.8.26.
