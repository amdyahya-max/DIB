# Validation — portal 1.8.17

Verified on Linux with Node 24.19.0 on 10 October 2026.

- Production Vite build completed. Public startup recovery assets were copied into dist; the existing Vite informational startup-script notices are unchanged.
- **40 automated tests passed, zero failures.** Actual Node/SQLite HTTP tests cover additive pen-pair migration from the legacy schema, preserving prior settings, admin-only settings, invalid pair rejection, server-selected match designs, in-progress match stability, solo privacy, quotas, eligibility and scoring. The full existing portal suite also passed.
- Capped covers crossing the gold line at an angle count as out; original games retain their tapered nib scoring footprint. All capped pair options share one scoring size.
- **13 built-browser checks passed, zero uncaught browser errors.** All four Admin previews render; saved pair/round settings persist; solo and a two-session colleague duel use the correct pair; current matches retain their pair; pointer shots, CPU responses, mobile layout, reduced motion, history resume, visible hover states, gold boundary and five-second victory popup work.
- Screenshots and machine-readable results are in `validation/1.8.17`. Browser tests run the actual Node portal and SQLite backend. Only the Windows tray identity bridge was simulated. Browser rendering was checked in headless Chromium; no new Windows Helper installer was built or needed for this portal-only change.
- Original 1.8.12 base SHA-256 matches BASELINE-PRESERVATION.json. The 20 helper/download files match the base byte-for-byte, including published Helper 1.2.9.
- Both ZIPs were closed, integrity-tested and extracted; every archived file was compared to source SHA-256 before publication. Node/node_modules and live production data are intentionally excluded. The smaller package omits only the unchanged installer and includes a retain-installer note.

Run automated checks with `node --test tests/*.test.js`. The optional built-browser harness is `tests/penfight-browser.mjs`; set CET_PLAYWRIGHT_MODULE and CET_CHROMIUM_PATH to your local Playwright module and Chromium executable, then run it with Node. Test databases and roster fixtures are temporary and do not use production storage.
