# CET Momentum 1.8.24 — falling and floor impact sound

Portal **1.8.24**, Helper **1.2.9** (unchanged).

## New experience

With the arena speaker ON, a pen leaving the raised desk produces a brief soft air sound. The first floor contact produces a crisp plastic barrel tap with a short, brighter tile resonance. Two light bounce taps fade in strength. Impact strength responds to the falling pen's motion. The visible drop accelerates to the floor, makes two small bounces and fades; the sound and floor pose use the same timing constants.

The sound is synthesised locally from a filtered noise transient, a low plastic knock and a short tile resonance. It needs no online audio files, extra dependencies, Helper update or administrator permission. This is a designed pen-on-tile effect, not a recording of the user's physical floor.

**Sound remains OFF by default.** Use the speaker icon at the top of Pen Fight Arena to switch it on. The existing preference remains local to this portal user/browser profile on this PC. The opponent's sound setting is independent. Turning sound off, hiding the page or leaving the arena stops active sound. Missed floor cues are discarded rather than played together after a paused/hidden tab returns.

A simultaneous two-pen fall uses one combined contact sequence to avoid doubled loudness. Opening an old game or refreshing does not replay its old landing. Reduced-motion users receive one short floor impact when a new fall result arrives, without a delayed drop/bounce sequence. Browser audio permission and PC volume still apply.

Scoring, gravity, grouped rounds, bot difficulty and the existing 3.2-second fall/score delay are retained. The change is frontend presentation and audio only; no new database tables or migrations are needed.

## Deploy the prebuilt update

1. Stop the NSSM portal service and back up the current installation.
2. Copy updated application code and replace the complete `dist` folder with this build. Frontend source is included for future builds; no rebuild is needed to deploy the provided dist.
3. Keep production `.env`, `storage` (SQLite/WAL/SHM), `data` (Excel), `Node`, root `node_modules`, existing Helper settings and working IIS configuration. Do not replace production data with the blank packaged templates. No dependency change is required.
4. Updated-Files omits only `downloads/CET-Helper-Setup.exe`; retain the existing installer. Complete includes the unchanged installer.
5. Restart the portal service and refresh the browser. The portal should report 1.8.24. Enable the arena speaker and play a new shot that knocks a pen off the desk. Listen for air, contact, then two quieter taps before the score updates.

All earlier features, preserved base 1.8.12 and Helper 1.2.9 remain available. Validation: `TEST-RESULTS-1.8.24.md` and `validation/1.8.24`. Windows deployment instructions remain in `WINDOWS-SERVER-IIS.md`.
