# Validation — CET Momentum 1.8.20

Verified on Linux with Node 24.19.0 and headless Chromium 153 on 11 October 2026.

- Production Vite build passed; the new built dist is included. Existing informational startup.js/startup.css notices are unchanged.
- **53 automated tests passed; zero failures.** All prior portal and Pen Fight tests pass. Actual Node/SQLite HTTP integration tests now verify two waiting challenges can be created, multiple solo games can coexist, the daily limit still applies and ended games still count against their creation day.
- Open-game summaries include old active matches outside the 20-match history cap, omit physics/shot history, exclude ended/completed games and do not expose other users' games. Unauthenticated access is rejected. A user with incomplete attendance can view/end their own open games but cannot start or continue play.
- Either participant can end a joined game. Outsiders cannot end it. Cancellation retains its score/shot history and records endedBy/endedAt, without changing attendance or fun points. Repeated End and subsequent shots are rejected. Completed matches retain their awarded points. Joining checks that a waiting match is still playing.
- **21 built-browser checks passed; zero uncaught errors.** Continue loads the full game from a compact summary. A second waiting challenge creates while the first remains open. Lounge End can be dismissed or confirmed. A joined duel is ended in the arena and the other independent browser session observes Game ended on polling. No competitive points or winner popup result from ending it.
- Seven old open games remained visible via Show all even after 25 newer ended games buried them in recent history. The oldest one could be ended from the list. Open-game controls fit a 390px viewport without horizontal overflow.
- All 1.8.19 browser checks remain covered: unique initials MY/MY2, preserved tags after display-name changes, compact desktop/mobile arena and ledger, pen settings, pointer/button input, automatic bot play, alternating colleague turns, grouped round scoring, 3.2-second falling sequence with delayed visible scores, and the final five-second winner popup with summed totals only.
- Browser screenshots were inspected as temporary QA files and are not packaged. Test logs/results are in validation/1.8.20. Older reports are historical and their screenshot files are omitted from these ZIPs.
- All **20 helper/download files** match 1.8.19 byte-for-byte, including unchanged Helper 1.2.9 installer and release metadata. Base 1.8.12 is preserved. No new database tables or columns, dependencies or Helper build are required.
- Both archives were closed, CRC-checked, extracted and compared with file hashes. The Complete archive includes the unchanged installer; Updated-Files omits only downloads/CET-Helper-Setup.exe. Both include source and prebuilt frontend and exclude Node/node_modules and production data.

Windows IIS/NSSM deployment and the native Windows Helper were not executed here. Preserve production data/storage, root dependencies and deployment configuration as described in UPDATE-1.8.20-OPEN-GAMES.md.

Automated checks: node --test tests/*.test.js. Optional browser harness: provide CET_PLAYWRIGHT_MODULE and CET_CHROMIUM_PATH for local Playwright/Chromium, then run node tests/penfight-browser.mjs. Tests use temporary databases and synthetic users.
