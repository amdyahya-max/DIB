# CET Momentum complete source — automatic game motion edition

Portal **1.8.27**, Helper **1.2.9** unchanged. The preserved **1.8.12** base remains intact.

Complete includes portal/helper source, package locks, tests, prebuilt frontend, Excel template, existing Helper installer/release metadata, launch/build tools, IIS/NSSM documentation and employee quick-start PDF.

Start with **deployment/UPDATE-1.8.27-PEN-ANIMATION.md**. All seven Admin sections have compact controls, icon actions, on-demand guidance and tables sized to the available window. Add-user and Excel-upload forms open in dialogs, retaining their existing save/import behavior. Administration → Pen Fight has separate Game settings and Player access subsections. Search by name, account, email or company; enable/disable a player or multiple selected players. Choose Selected players only and save the policy to restrict entry. Existing installations keep All eligible users until the policy is changed. The global switch, required attendance, portal status and leader privacy still apply. Solo, colleague games, scoring, physics, round notes and local sounds are retained.

The frontend is built. Use your working **Node 24** and root **node_modules**, excluded from the ZIP. No new dependency or Helper rebuild is required. For a fresh install, install root dependencies as documented. Helper/node_modules is only needed to rebuild the Helper; the included installer runs independently.

No production SQLite, enrollment secrets or live logs are included. Keep production .env, Excel, storage, Node/dependencies and working IIS configuration. Automatic additive migration retains production data; never replace it with packaged blank templates.

Updated-Files contains the same source/build files, omitting only the unchanged `downloads/CET-Helper-Setup.exe`. Retain that existing installer.
