PowerCard V2/V3 Reconciliation V0.19
===================================

New in V0.19:
- Local login authentication.
- First-time administrator setup.
- /admin user management.
- Enable/disable users.
- Local SQLite auth database with PBKDF2-SHA256 password hashing.
- Password reset + forced change.
- Login lockout and admin audit log.
- IIS reverse-proxy deployment guide.

Start without BAT:
  python\python.exe run_api.py

First run:
  http://127.0.0.1:8000/
  -> redirects to /setup if no local users exist.

Important guides:
- LOCAL_AUTH_GUIDE.txt
- IIS_DEPLOYMENT_GUIDE.txt
- DEPLOY_ORACLE_STEPS.txt

Do not commit:
- .env
- data/auth.db
- Oracle credentials


IIS SUB-PATH DEPLOYMENT (V0.19)
--------------------------------
V0.19 supports publishing below IIS Default Web Site, for example:
  https://SERVER-NAME/PowerCard/
Set APP_BASE_PATH=/PowerCard and AUTH_COOKIE_SECURE=true in .env.
See IIS_DEFAULT_SITE_HTTPS_DEPLOYMENT.txt and iis\web.config.
