PowerCard V2/V3 Reconciliation - V0.7

V0.7 adds configurable python-oracledb Thin/Thick mode support for older Oracle V2 databases.

Quick local SQLite test:
1. Copy .env.example to .env
2. Set DATA_SOURCE=sqlite
3. Ensure python\python.exe exists
4. Run start.bat

Oracle test:
1. Install requirements-oracle.txt
2. Set DATA_SOURCE=oracle
3. For older V2 DBs set ORACLE_MODE=thick
4. Set ORACLE_CLIENT_LIB_DIR to the Instant Client folder containing oci.dll
5. Set TNS_ADMIN to the folder containing tnsnames.ora
6. Fill the Oracle usernames/passwords in .env
7. Run start.bat
8. Open /api/v1/oracle-health/PWCORE and /api/v1/oracle-health/PCMOCK

Read DEPLOY_ORACLE_STEPS.txt for the full procedure.

V0.11 UI / EXPORT ENHANCEMENTS
-----------------------------
- More compact, colorful business-question selector tiles.
- Active question and environment are clearly highlighted.
- Result statistics moved to a right-side summary rail on wide screens.
- Results table appears immediately below the selection area to reduce scrolling.
- Excel export added. It creates a real .xlsx workbook with four sheets:
  Summary, Available in Both, V2 Not in V3, and V3 Not in V2.
- Excel generation uses only the Python standard library; no new package is required.

V0.11 matching export behavior
-----------------------------
- Copy Cards copies only records in "Available in Both".
- If the matched table is filtered, Copy Cards copies only the filtered matched rows.
- Export Excel exports only records in "Available in Both".
- If the matched table is filtered, Excel contains only the filtered matched rows.
- V2-only and V3-only records remain visible for investigation but are excluded from Copy/Export.

V0.11: Question tiles now trigger reconciliation immediately; no Search/Fetch/Compare button is required. Environment changes also refresh the selected question automatically.

V0.11 connection UX
--------------------
When PWCORE or PCMOCK is selected in Oracle mode, the UI first checks both the V2 and V3 database connections. If either side fails, the environment is not switched and a modal shows a friendly connection message, per-database status, retry action, and expandable technical details. Common Oracle login, TNS, listener, timeout, client-library and Thin/Thick compatibility errors are translated into clearer guidance.
