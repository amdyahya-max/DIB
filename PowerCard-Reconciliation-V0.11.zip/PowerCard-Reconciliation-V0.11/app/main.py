from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .config import data_source
from .database import ensure_database
from .reconciliation import reconcile_environment
from .excel_export import build_reconciliation_xlsx
from .scenarios import SCENARIOS, list_scenarios

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
app = FastAPI(title="PowerCard V2/V3 Reconciliation API", version="0.11.0",
              description="Question-driven reconciliation with switchable SQLite mock or parameterized Oracle V2/V3 repositories.")

class ReconcileRequest(BaseModel):
    environment: str
    scenario: str

class ExportFilteredRequest(BaseModel):
    environment: str
    scenario: str
    records: list[dict] = Field(default_factory=list)
    filterText: str = ""

@app.on_event("startup")
def startup_event():
    if data_source() == "sqlite":
        ensure_database()

@app.get("/api/v1/health")
def health():
    return {"status":"UP","version":"0.11.0","dataSource":data_source()}

@app.get("/api/v1/environments")
def environments():
    return {"environments":[{"id":"PWCORE","name":"PWCORE"},{"id":"PCMOCK","name":"PCMOCK"}]}

@app.get("/api/v1/scenarios")
def scenarios():
    return {"scenarios":list_scenarios()}

@app.get("/api/v1/oracle-health/{environment}")
def oracle_health(environment: str):
    env = environment.strip().upper()
    if env not in {"PWCORE","PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if data_source() != "oracle":
        return {"environment":env,"dataSource":data_source(),"message":"Oracle health check is available when DATA_SOURCE=oracle."}
    try:
        from .oracle_repository import connection_health
        return connection_health(env)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@app.post("/api/v1/reconcile")
def reconcile(request: ReconcileRequest):
    environment = request.environment.strip().upper()
    scenario_id = request.scenario.strip().upper()
    if environment not in {"PWCORE","PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if scenario_id not in SCENARIOS:
        raise HTTPException(status_code=400, detail="Unsupported question/scenario.")
    try:
        return reconcile_environment(environment, scenario_id)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/v1/export-excel")
def export_excel(request: ExportFilteredRequest):
    environment = request.environment.strip().upper()
    scenario_id = request.scenario.strip().upper()
    if environment not in {"PWCORE","PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if scenario_id not in SCENARIOS:
        raise HTTPException(status_code=400, detail="Unsupported question/scenario.")
    if SCENARIOS[scenario_id]["mode"] == "guidance":
        raise HTTPException(status_code=400, detail="Guidance scenarios do not have reconciliation data to export.")
    if not request.records:
        raise HTTPException(status_code=400, detail="There are no matched records to export.")
    try:
        result = {
            "environment": environment,
            "dataSource": data_source(),
            "scenario": {"id": scenario_id, "label": SCENARIOS[scenario_id]["label"]},
            "summary": {"matchedCount": len(request.records)},
            "matched": request.records,
            "filterText": request.filterText,
        }
        content = build_reconciliation_xlsx(result, matched_only=True)
        safe_scenario = scenario_id.lower()
        filename = f"PowerCard_{environment}_{safe_scenario}_matched.xlsx"
        return Response(
            content=content,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'}
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")
@app.get("/")
def home():
    return FileResponse(WEB_DIR / "index.html")
