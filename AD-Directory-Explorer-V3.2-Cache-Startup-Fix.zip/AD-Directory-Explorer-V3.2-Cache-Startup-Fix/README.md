# Directory Intelligence V3.2 – Startup / Browser Cache Fix

## Root cause addressed

The V3.1 HTML changed the Status control from a `<select>` to status chips.

Because the local Node server previously allowed browser caching for `app.js` and
`styles.css`, Edge/Chrome could retain an older JavaScript file while loading the
new V3.1 HTML. That mismatch can stop frontend startup before `/api/health` is called,
leaving the screen permanently at:

```text
Magnitude: loading...
AD: connecting...
```

## Fixes

- `app.js` and `styles.css` now use a V3.2 cache-busting URL.
- The Node static-file server sends `Cache-Control: no-store`.
- Major frontend bindings are defensive if a control is missing.
- Startup now catches frontend errors and displays `AD: frontend error` rather than
  remaining at `AD: connecting...`.

No AD query logic or Status-chip logic was removed.


# Directory Intelligence V3.1 – Status Chips & Collapsible Panels

## Multi-select Status chips

The old Status dropdown is replaced by compact selectable chips:

- Enabled
- Expired
- Disabled

Default selection is:

```text
Enabled  = ON
Expired  = ON
Disabled = OFF
```

Any combination can be selected. Manager counts, workforce mix and title analytics follow the selected statuses.

## Collapsible sections

Round colored collapse buttons are added to the major dashboard areas:

- Directory Search
- Directory Results
- Manager Distribution
- Title Statistics remains collapsible with an upgraded colored round indicator

Collapse state for button-controlled sections is remembered in the browser.

# Directory Intelligence V3.0 – Workforce Mix

## FTE / Consultant logic

Workforce type is derived from Employee ID:

```text
Employee ID starts with CT  -> Consultant
Otherwise                   -> FTE / Staff
```

This classification is applied to the currently filtered manager analytics population.

## New top-right workforce KPIs

The Manager Distribution header now includes two compact KPI cards:

- **FTE / Staff**
- **Consultants**

These counts follow the current Status, Expiry, Magnitude and text filters, consistent with the Manager tile statistics.

## Manager tile workforce breakdown

Each Manager tile now shows:

- Total users
- FTE count
- CT / Consultant count
- Percentage of filtered users

Example:

```text
Naveed Rashid
42% of filtered users
FTE 70   CT 26                     96 USERS
```


# Directory Intelligence V2.9 – Search Alignment

The Search Directory control is now aligned using an explicit three-row grid:

```text
Label
[ Search input ]   [ Search Directory ]
Helper text
```

The helper text no longer affects the vertical position of the button.

On desktop:
- Input height: 46px
- Search button height: 46px
- Top and bottom edges align exactly

Responsive behaviour is retained for narrower screens.


# Directory Intelligence V2.8 – Search Clear Control

A clear **X** is now available at the right side of the main search and filter text fields whenever text is entered.

Applied to:

- Department search
- AD Group search
- User search
- AD Group finder
- Current-result filter
- Magnitude reconciliation filter

Clicking the X immediately clears the field. The current-result filter and reconciliation filter refresh immediately after clearing.


# Directory Intelligence V2.7 – Alignment Fix

## Manager tile layout fix

The manager tile layout is now collision-proof:

- Manager name has a dedicated two-line area
- Percentage/share has its own fixed row underneath
- User count stays isolated in a right-side column
- Full names remain readable without overlapping the percentage
- Manager tiles remain rectangular
- Manager names are larger than V2.6
- Dense layouts receive more minimum tile width

## Search Directory alignment

The search area now uses a grid-based layout so the **Search Directory** button aligns
exactly with the search input box rather than appearing lower because of the helper text.

The button height now matches the input height.


# Directory Intelligence V2.6 – Relative Bar Analytics

## Title Statistics returned to horizontal bars

The Title Statistics section is again a horizontal bar chart, with a more polished executive design.

### Outlier-balanced visual scaling

Actual numeric counts are never changed.

Bar width uses square-root scaling, so a very large outlier does not make all smaller titles look almost empty.

Example:

```text
Actual counts:
80
20
10
5
```

The numeric labels remain 80, 20, 10 and 5, but the visual bar lengths are compressed so the smaller categories remain readable.

A subtle marker inside the track also represents the raw linear position, while the main colored bar uses the balanced visual scale.

The highest outlier is visually highlighted and identified as using compressed visual scaling.

## Manager tiles

Manager cards remain rectangular, but manager names are larger again.

- Full manager names can wrap across two lines
- Ellipsis truncation is removed
- Long names are allowed to break naturally when necessary
- Font size still adapts to the number of manager tiles
- Status-based Manager counts remain unchanged


# Directory Intelligence V2.5 – Executive Analytics

## Manager tiles now follow Status

Manager counts now recalculate immediately when Status changes:

- All statuses
- Enabled
- Disabled
- Expired

They also respect Expiry, Magnitude and text filters. The selected manager itself is excluded from the tile-count calculation so every manager tile remains available for switching.

## Rectangular Manager tiles

Manager tiles have been redesigned as compact horizontal cards rather than square blocks.

Each card precisely fits:

- Manager initial
- Manager name
- Filtered user percentage
- User count

Manager-name font size still adjusts automatically as the number of managers grows.

## New Title Statistics design

The long scrolling title-bar list has been replaced with a compact executive analytics layout:

- Unique Titles
- Top Title
- Top 5 Coverage
- Visible Users
- Ranked colorful title cards
- Mini proportional bars
- Top 8 titles shown by default
- **Show all titles** only when deeper detail is required

This keeps the dashboard visually compact even when many titles exist.


# Directory Intelligence V2.4 – Manager & Title Analytics

## Manager tiles

A colorful **Users by Manager** section is now shown directly above the result list.

- Each tile shows manager name, user count and percentage of the loaded AD result.
- Clicking a tile filters the main user list to that manager.
- Clicking the active tile again removes the manager filter.
- A **Clear manager filter** action is also provided.
- Manager name font size dynamically shrinks or grows based on the number of manager tiles.
- Tile colors rotate automatically across managers.

## Title statistics

A collapsible **Title Statistics** section is now shown below the result list.

- Each title displays user count and percentage.
- A proportional horizontal bar provides a quick visual comparison.
- Bars use a professional rotating color palette.
- Title statistics react to the current visible list, including manager, status, expiry, Magnitude and text filters.


# Directory Intelligence V2.3 – Scoped Magnitude Comparison

## Logic changed

The **Magnitude Outside Department** function no longer asks whether the Magnitude
users exist somewhere in Active Directory.

It compares the Magnitude reference only against the AD users already loaded by
the current portal search.

Example:

```text
Search Department A
        ↓
130 users loaded from AD
        ↓
Compare MagnitudeUsers.xlsx against those 130 users
        ↓
Magnitude users not among the 130
        =
Magnitude users outside Department A
```

The same mechanism also works if the current search is an AD Group or User search;
the popup clearly identifies the current search scope.

Matching priority:

1. Username
2. Email ID
3. Employee ID
4. Name

The comparison count is recalculated automatically after each AD search, and the
top button remains disabled until a search has loaded users.


# Directory Intelligence V2.2 – Magnitude Reconciliation Fix

## Fixed

The **Magnitude Missing in AD** button in V2.1 called the endpoint correctly, but
the backend function `getMagnitudeUnmatchedUsers()` was missing from `server.js`.

V2.2 adds the missing backend reconciliation implementation.

The comparison now:

- Reads the Magnitude Excel/CSV reference already loaded by the application
- Checks all reference users against Active Directory
- Matches by Username, Email ID, Employee ID, then Name
- Checks Employee ID against `employeeID`, `description`, `comment`, and `employeeNumber`
- Runs LDAP checks in batches to avoid oversized filters
- Shows only Magnitude reference users that are not found in AD
- Supports search and CSV export in the reconciliation popup


# Directory Intelligence V2.1 – Reconciliation UI Fix

## Fix

V2.0 accidentally inserted the Magnitude reconciliation functions inside `setMode()`.
That meant the page stopped with a browser-side JavaScript `ReferenceError` before the
startup health calls ran, leaving the header permanently at:

- `Magnitude: loading...`
- `AD: connecting...`

V2.1 moves those functions back to top-level scope. No AD/backend logic was changed.

# Directory Intelligence V2.0 – Magnitude Reconciliation

## New reconciliation button

A highlighted **Magnitude Missing in AD** button is shown in the top header.

When clicked, the application compares all records in the Magnitude reference file against Active Directory using:

1. Username
2. Email ID
3. Employee ID
4. Name

This comparison is global against Active Directory, so it is not limited to the currently selected department or group.

The result window shows:
- Excel records checked
- Users matched in AD
- Users not found in AD
- Search/filter within missing users
- Export missing users to CSV
- Re-run comparison


# AD Directory Explorer V1.8 — Node

## Fix in V1.8

V1.7 contained Markdown-style backtick characters inside the embedded PowerShell text in `server.js`.
Because that PowerShell text is itself stored inside a JavaScript template literal, the backticks prematurely ended the JavaScript string and Node reported:

```text
SyntaxError: Unexpected identifier 'net'
```

V1.8 removes those conflicting backticks. The Employee ID logic remains:

```text
employeeID -> description -> comment -> employeeNumber
```

Run:

```text
node server.js
```

Then open:

```text
http://localhost:8085
```

## Employee ID fix in V1.7

The Windows command:

```text
net user <username> /domain
```

shows a field labelled **Comment**. In Active Directory this value is commonly stored in LDAP attribute:

```text
description
```

rather than LDAP attribute:

```text
comment
```

Therefore V1.7 resolves Employee ID in this order:

```text
1. employeeID
2. description   ← corresponds to the "Comment" shown by net user in your environment
3. comment
4. employeeNumber
```

The user detail panel continues to show the source used.

Run:

```text
node server.js
```

Open:

```text
http://localhost:8085
```
## Fix in V1.6

V1.5 introduced a PowerShell parser error in the Employee ID fallback logic. The fallback was written as an inline `if/elseif` expression inside the `PSCustomObject`, which Windows PowerShell 5.1 does not parse in that form.

V1.6 resolves Employee ID into normal variables **before** building the result object.

Employee ID priority remains:

```text
1. employeeID
2. comment
3. employeeNumber
```

All V1.5 UI features remain:
- Company column
- Default 8 columns
- Multi-select Columns menu
- Searchable department typing field
- Dynamic CSV/Excel export based on visible columns

Run:

```text
node server.js
```

Open:

```text
http://localhost:8085
```
## Enhancements in V1.5

1. **Company** is now included in the default user list.
2. Added a **Columns** multi-select. Exactly eight business columns are shown by default:
   - Employee ID
   - Name
   - Username
   - Email
   - Department
   - Company
   - Title
   - Manager

   Additional fields can be enabled or removed at any time. The user's selection is retained in the browser.
3. **Department** is now a searchable typing field backed by the AD department list. Start typing and select the matching department instead of scrolling through a long dropdown.
4. CSV and Excel export now follow the currently selected visible columns.

Start:

```text
node server.js
```

Open:

```text
http://localhost:8085
```

## Employee ID fallback improvement

The application now resolves Employee ID in this order:

```text
1. employeeID
2. comment
3. employeeNumber
```

This covers users where the corporate employee ID is stored in the AD `comment` field (for example values such as `CT2178`) instead of `employeeID`.

The detail panel also shows which AD attribute supplied the displayed Employee ID.

Start as before:

```text
node server.js
```

Then open:

```text
http://localhost:8085
```

## Fix in V1.3

V1.2 used a PowerShell helper function named `FT`. On Windows PowerShell, `ft` is a built-in alias for `Format-Table`. Because aliases take precedence over functions, account-expiry values were accidentally being sent to `Format-Table`, producing an error similar to:

```text
FT : Cannot convert System.Int64...
FullyQualifiedErrorId : DictionaryKeyUnknownType,Microsoft.PowerShell.Commands.FormatTableCommand
```

V1.3 renames the helper to `Convert-FileTimeIso` and also makes manager lookup more defensive.

Start as before:

```text
node server.js
```

Then browse to:

```text
http://localhost:8085
```

This version is designed for corporate Windows environments where:

- `.ps1` execution is blocked
- `.cmd` files are blocked
- Node.js itself is permitted
- NPM installation is restricted

The application runs with:

```text
node server.js
```

No NPM packages are required.

## Start

1. Extract the ZIP.
2. Open PowerShell or Command Prompt in the extracted folder.
3. Run:

```text
node server.js
```

4. Open:

```text
http://localhost:8085
```

5. Stop with `Ctrl+C`.

## How it works

Node hosts the local web application. For each read-only AD request, Node calls:

```text
powershell.exe -NoProfile -NonInteractive -Command <inline command>
```

The PowerShell commands use `System.DirectoryServices`, the same technique already proven to work on your PC.

No `.ps1` script is executed.

## Security

- Binds only to `127.0.0.1`
- Read-only directory searches
- Uses your current Windows identity
- No stored AD password
- No database
- No arbitrary LDAP endpoint exposed