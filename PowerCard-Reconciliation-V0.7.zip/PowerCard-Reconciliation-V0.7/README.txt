PowerCard V2/V3 Reconciliation - V0.7

V0.7 adds configurable python-oracledb Thin/Thick mode support for older Oracle V2 databases.

Quick local SQLite test:
1. Copy .env.example to .env
2. Set DATA_SOURCE=sqlite
3. Ensure python\python.exe exists
4. Run start.bat

Oracle test:
1. Install requirements-oracle.txt
2. Set DATA_SOURCE=oracle
3. For older V2 DBs set ORACLE_MODE=thick
4. Set ORACLE_CLIENT_LIB_DIR to the Instant Client folder containing oci.dll
5. Set TNS_ADMIN to the folder containing tnsnames.ora
6. Fill the Oracle usernames/passwords in .env
7. Run start.bat
8. Open /api/v1/oracle-health/PWCORE and /api/v1/oracle-health/PCMOCK

Read DEPLOY_ORACLE_STEPS.txt for the full procedure.
