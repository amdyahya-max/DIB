from __future__ import annotations

from io import BytesIO
from zipfile import ZipFile, ZIP_DEFLATED
from xml.sax.saxutils import escape


def _col_letter(n: int) -> str:
    out = ""
    while n:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


def _cell(ref: str, value, style: int = 0) -> str:
    text = "" if value is None else str(value)
    text = escape(text)
    style_attr = f' s="{style}"' if style else ""
    return f'<c r="{ref}" t="inlineStr"{style_attr}><is><t>{text}</t></is></c>'


def _sheet_xml(headers, rows, widths=None) -> str:
    widths = widths or [18] * len(headers)
    cols = "".join(
        f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>'
        for i, w in enumerate(widths, start=1)
    )
    lines = []
    # Header row uses style 1
    header_cells = "".join(_cell(f"{_col_letter(i)}1", h, 1) for i, h in enumerate(headers, 1))
    lines.append(f'<row r="1">{header_cells}</row>')
    for r_idx, row in enumerate(rows, start=2):
        cells = "".join(_cell(f"{_col_letter(c_idx)}{r_idx}", value) for c_idx, value in enumerate(row, 1))
        lines.append(f'<row r="{r_idx}">{cells}</row>')
    last_col = _col_letter(len(headers))
    last_row = max(1, len(rows) + 1)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:{last_col}{last_row}"/>
  <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
  <cols>{cols}</cols>
  <sheetData>{''.join(lines)}</sheetData>
  <autoFilter ref="A1:{last_col}{last_row}"/>
</worksheet>'''



def _status_label(value) -> str:
    raw = "" if value is None else str(value).strip()
    return "Active" if raw.upper() == "N" else raw


def build_reconciliation_xlsx(result: dict, matched_only: bool = False) -> bytes:
    s = result.get("summary", {})
    scenario = result.get("scenario", {})
    summary_rows = [
        ["Environment", result.get("environment", "")],
        ["Question", scenario.get("label", "")],
        ["Data Source", result.get("dataSource", "")],
    ]
    if matched_only:
        summary_rows.extend([
            ["Export Scope", "Matched records only"],
            ["Filter", result.get("filterText", "") or "None"],
            ["Exported Matched Records", s.get("matchedCount", len(result.get("matched", [])))],
        ])
    else:
        summary_rows.extend([
            ["V2 Fetched", s.get("v2Count", 0)],
            ["V3 Fetched", s.get("v3Count", 0)],
            ["Available in Both", s.get("matchedCount", 0)],
            ["V2 Not in V3", s.get("v2OnlyCount", 0)],
            ["V3 Not in V2", s.get("v3OnlyCount", 0)],
        ])
    matched_rows = [[
        r.get("cardNumber", ""), r.get("clientCode", ""), _status_label(r.get("v2Status", "")),
        _status_label(r.get("v3Status", "")), r.get("productType", ""), r.get("primaryCard", "")
    ] for r in result.get("matched", [])]
    v2_rows = [[r.get("cardNumber", ""), r.get("clientCode", ""), _status_label(r.get("status", "")), r.get("productType", ""), r.get("primaryCard", "")] for r in result.get("v2Only", [])]
    v3_rows = [[r.get("cardNumber", ""), r.get("clientCode", ""), _status_label(r.get("status", "")), r.get("productType", ""), r.get("primaryCard", "")] for r in result.get("v3Only", [])]

    sheets = [
        ("Summary", ["Metric", "Value"], summary_rows, [28, 42]),
        ("Available in Both", ["Card Number", "Client / CIF", "V2 Status", "V3 Status", "Type", "Primary Card"], matched_rows, [24, 20, 14, 14, 14, 24]),
    ]
    if not matched_only:
        sheets.extend([
            ("V2 Not in V3", ["Card Number", "Client / CIF", "Status", "Type", "Primary Card"], v2_rows, [24, 20, 14, 14, 24]),
            ("V3 Not in V2", ["Card Number", "Client / CIF", "Status", "Type", "Primary Card"], v3_rows, [24, 20, 14, 14, 24]),
        ])

    workbook_sheets = "".join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i, (name, *_rest) in enumerate(sheets, 1))
    workbook_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>{workbook_sheets}</sheets></workbook>'''
    workbook_rels = "".join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1, len(sheets)+1))
    workbook_rels += '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
    workbook_rels_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{workbook_rels}</Relationships>'''
    content_overrides = ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(sheets)+1))
    content_types = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
{content_overrides}</Types>'''
    root_rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'''
    styles = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF006B4F"/><bgColor indexed="64"/></patternFill></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="2"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1" applyNumberFormat="1"/></cellXfs>
</styleSheet>'''

    out = BytesIO()
    with ZipFile(out, 'w', ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', content_types)
        z.writestr('_rels/.rels', root_rels)
        z.writestr('xl/workbook.xml', workbook_xml)
        z.writestr('xl/_rels/workbook.xml.rels', workbook_rels_xml)
        z.writestr('xl/styles.xml', styles)
        for i, (_name, headers, rows, widths) in enumerate(sheets, 1):
            z.writestr(f'xl/worksheets/sheet{i}.xml', _sheet_xml(headers, rows, widths))
    return out.getvalue()
