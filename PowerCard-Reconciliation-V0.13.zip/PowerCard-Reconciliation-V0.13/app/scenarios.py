SCENARIOS = {
    "ACTIVE_CREDIT_CARDS": {
        "id": "ACTIVE_CREDIT_CARDS", "label": "Active Credit Cards",
        "description": "Run the Active Credit Cards V2 business query, then look up the resulting card numbers in V3 and reconcile.",
        "mode": "compare", "implemented": True, "v2_query_file": "active_credit_v2.sql",
        "sqlite_where": "status_code='N' AND delivery_card_flag='Y' AND product_type='CR' AND date_create_days_ago<=180 AND status_reason_code='SN' AND unpaid_status='0' AND administrative_status='0'",
    },
    "ACTIVE_DEBIT_CARDS": {
        "id": "ACTIVE_DEBIT_CARDS", "label": "Active Debit Cards",
        "description": "Run the Active Debit Cards V2 business query, then look up the resulting card numbers in V3 and reconcile.",
        "mode": "compare", "implemented": True, "v2_query_file": "active_debit_v2.sql",
        "sqlite_where": "status_code='N' AND delivery_card_flag='Y' AND product_type='DC' AND date_create_days_ago<=180",
    },
    "PRIMARY_NO_SUPP": {
        "id": "PRIMARY_NO_SUPP", "label": "CIF with Primary Card & No Supplementary Card",
        "description": "Run the supplied primary-card-only V2 query, then look up its card numbers in V3 and reconcile.",
        "mode": "compare", "implemented": True, "v2_query_file": "primary_no_supp_v2.sql", "custom_sqlite_query": "PRIMARY_NO_SUPP",
    },
    "CIF_WITH_SUPP": {
        "id": "CIF_WITH_SUPP", "label": "CIF with Primary + Supplementary Cards",
        "description": "Run the supplied primary-plus-supplementary V2 query, then look up its card numbers in V3 and reconcile.",
        "mode": "compare", "implemented": True, "v2_query_file": "cif_with_supp_v2.sql", "custom_sqlite_query": "CIF_WITH_SUPP",
    },
    "CREATE_NEW_CARD": {
        "id": "CREATE_NEW_CARD", "label": "Create New Debit or Credit Card",
        "description": "Guidance only. No database SQL or reconciliation is executed.",
        "mode": "guidance", "implemented": True,
        "guidance": {
            "title": "Create New Debit or Credit Card",
            "credit": [
                "FINNONE — Create a new covered/credit-card application, create CIF and account number, create the application ID, and generate the LOS requestor file.",
                "OA job — Move the requestor file to PowerCard.",
                "PowerCard — Execute the required batches and generate the card. Coordinate with the Cards GBO team as required."
            ],
            "debit": [
                "T24 — Create a new debit-card request (with or without cheque book), including CIF and account number.",
                "Execute the ETL job — Load customer/account data and generate the debit-card requestor file for UAT.",
                "OA job — Move the requestor file to PowerCard.",
                "PowerCard — Execute the required batches and generate the card. Coordinate with the Cards GBO team as required."
            ],
            "note": "Guidance only; no V2/V3 SQL is executed."
        }
    },
}


def list_scenarios():
    return [{k: item[k] for k in ("id", "label", "description", "implemented", "mode")} for item in SCENARIOS.values()]
