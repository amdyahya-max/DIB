from functools import lru_cache
from pathlib import Path
import os

from .config import (
    load_query,
    oracle_batch_size,
    oracle_client_lib_dir,
    oracle_mode,
    oracle_setting,
    tns_admin,
)


def _oracledb():
    try:
        import oracledb
        return oracledb
    except ImportError as exc:
        raise RuntimeError(
            "Oracle mode requires python-oracledb. Install requirements-oracle.txt first."
        ) from exc


@lru_cache(maxsize=1)
def initialize_oracle_client():
    """Initialize python-oracledb once.

    Thin mode needs no Oracle Client libraries.
    Thick mode loads Oracle Instant Client/Oracle Client from ORACLE_CLIENT_LIB_DIR.
    """
    oracledb = _oracledb()
    mode = oracle_mode()

    if mode == "thin":
        return {
            "mode": "thin",
            "clientLibDir": None,
            "tnsAdmin": tns_admin() or None,
        }

    lib_dir = oracle_client_lib_dir()
    if not lib_dir:
        raise RuntimeError(
            "ORACLE_MODE=thick but ORACLE_CLIENT_LIB_DIR is empty. "
            "Set it in the project-root .env file to the folder containing oci.dll."
        )

    lib_path = Path(lib_dir)
    if not lib_path.exists() or not lib_path.is_dir():
        raise RuntimeError(
            f"Oracle Client folder does not exist: {lib_dir}"
        )

    # On Windows, oci.dll is the key Instant Client/Oracle Client library.
    if os.name == "nt" and not (lib_path / "oci.dll").exists():
        raise RuntimeError(
            f"oci.dll was not found in ORACLE_CLIENT_LIB_DIR: {lib_dir}. "
            "Point ORACLE_CLIENT_LIB_DIR to the Instant Client folder itself."
        )

    kwargs = {"lib_dir": str(lib_path)}
    config_dir = tns_admin()
    if config_dir:
        config_path = Path(config_dir)
        if not config_path.exists() or not config_path.is_dir():
            raise RuntimeError(f"TNS_ADMIN folder does not exist: {config_dir}")
        kwargs["config_dir"] = str(config_path)

    try:
        oracledb.init_oracle_client(**kwargs)
    except Exception as exc:
        raise RuntimeError(
            "Failed to initialize Oracle Client in Thick mode. "
            f"Check ORACLE_CLIENT_LIB_DIR and client architecture. Original error: {exc}"
        ) from exc

    return {
        "mode": "thick",
        "clientLibDir": str(lib_path),
        "tnsAdmin": config_dir or None,
    }


@lru_cache(maxsize=8)
def _pool(environment: str, version: str):
    # Must happen before the first Oracle connection/pool is created.
    initialize_oracle_client()

    oracledb = _oracledb()
    cfg = oracle_setting(environment, version)
    min_pool = int(os.getenv("ORACLE_POOL_MIN", "1"))
    max_pool = int(os.getenv("ORACLE_POOL_MAX", "4"))
    increment = int(os.getenv("ORACLE_POOL_INCREMENT", "1"))
    return oracledb.create_pool(
        user=cfg["username"],
        password=cfg["password"],
        dsn=cfg["dsn"],
        min=min_pool,
        max=max_pool,
        increment=increment,
    )


def _normalize_rows(cursor):
    cols = [d[0].lower() for d in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


def fetch_v2(environment: str, query_file: str):
    sql = load_query(query_file)
    with _pool(environment, "v2").acquire() as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            return _normalize_rows(cur)


def fetch_v3_by_cards(environment: str, card_numbers):
    cards = list(dict.fromkeys(str(x) for x in card_numbers if x is not None))
    if not cards:
        return []

    template = load_query("lookup_v3.sql")
    batch_size = oracle_batch_size()
    output = []
    with _pool(environment, "v3").acquire() as conn:
        with conn.cursor() as cur:
            for offset in range(0, len(cards), batch_size):
                batch = cards[offset:offset + batch_size]
                binds = {f"card{i}": card for i, card in enumerate(batch)}
                placeholders = ", ".join(f":card{i}" for i in range(len(batch)))
                sql = template.replace("/*CARD_BINDS*/", placeholders)
                cur.execute(sql, binds)
                output.extend(_normalize_rows(cur))
    return output


def connection_health(environment: str):
    init = initialize_oracle_client()
    result = {
        "environment": environment,
        "oracleMode": init["mode"],
        "clientLibDir": init["clientLibDir"],
        "tnsAdmin": init["tnsAdmin"],
        "v2": False,
        "v3": False,
    }

    for version in ("v2", "v3"):
        try:
            with _pool(environment, version).acquire() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1 FROM dual")
                    cur.fetchone()
            result[version] = True
        except Exception as exc:
            result[f"{version}Error"] = str(exc)
    return result
