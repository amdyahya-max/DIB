SELECT a.card_number, a.client_code, a.basic_card_number AS primary_card
FROM card a
WHERE a.status_code = 'N'
  AND a.delivery_card_flag = 'Y'
  AND a.card_product_code IN (
      SELECT product_code FROM card_product WHERE product_type = 'CR'
  )
  AND a.client_code IN (
      SELECT d.client_code
      FROM shadow_account d
      WHERE d.primary_shadow_account_nbr IS NOT NULL
        AND d.date_create > SYSDATE - 500
        AND d.status_reason_code = 'SN'
        AND d.unpaid_status = '0'
        AND d.administrative_status = '0'
  )
  AND a.date_create > SYSDATE - 180
GROUP BY a.basic_card_number, a.client_code, a.card_number
ORDER BY a.client_code DESC
