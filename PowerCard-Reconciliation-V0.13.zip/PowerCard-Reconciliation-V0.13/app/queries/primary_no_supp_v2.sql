SELECT a.card_number, a.client_code, a.status_code
FROM card a
WHERE a.status_code = 'N'
  AND a.delivery_card_flag = 'Y'
  AND a.card_product_code IN (
      SELECT product_code FROM card_product WHERE product_type = 'CR'
  )
  AND a.client_code IN (
      SELECT d.client_code
      FROM shadow_account d
      WHERE d.primary_shadow_account_nbr IS NULL
        AND d.date_create > SYSDATE - 300
        AND d.status_reason_code = 'SN'
        AND d.unpaid_status = '0'
        AND d.administrative_status = '0'
        AND d.client_code IN (
            SELECT e.client_code
            FROM card e
            GROUP BY e.client_code
            HAVING COUNT(*) < 2
        )
  )
  AND a.date_create > SYSDATE - 180
ORDER BY a.client_code ASC
