SELECT a.card_number, a.client_code, a.status_code
FROM card a
INNER JOIN accounts_link b ON a.card_number = b.entity_id
INNER JOIN shadow_account c ON c.shadow_account_nbr = b.account_number
WHERE a.client_code IN (SELECT client_code FROM client)
  AND a.status_code = 'N'
  AND a.delivery_card_flag = 'Y'
  AND a.card_product_code IN (
      SELECT product_code FROM card_product WHERE product_type = 'CR'
  )
  AND c.status_reason_code = 'SN'
  AND c.unpaid_status = '0'
  AND c.administrative_status = '0'
  AND a.date_create > SYSDATE - 180
ORDER BY a.client_code, c.shadow_account_nbr ASC
