SELECT a.card_number, a.client_code, a.status_code
FROM card a
WHERE a.client_code IN (SELECT client_code FROM client)
  AND a.status_code = 'N'
  AND a.delivery_card_flag = 'Y'
  AND a.card_product_code IN (
      SELECT product_code FROM card_product WHERE product_type = 'DC'
  )
  AND a.date_create > SYSDATE - 180
ORDER BY a.client_code ASC
