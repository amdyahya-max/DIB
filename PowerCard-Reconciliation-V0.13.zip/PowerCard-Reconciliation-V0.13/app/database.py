from pathlib import Path
import sqlite3

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "sample.db"

# SQLite simulation of the Oracle data needed by the supplied business queries.
# date_create_days_ago = 10 means SYSDATE - 10 for local testing.
# primary_shadow_account_nbr=None simulates a primary card account; a populated
# value simulates a supplementary-card relationship.
# basic_card_number identifies the related primary card for supplementary cards.
SAMPLE_DATA = {
    "PWCORE": {
        "V2": [
            # card, cif, status, delivered, type, age, reason, unpaid, admin, primary_shadow, basic_card
            ("41110001", "CIF001", "N", "Y", "CR", 30, "SN", "0", "0", None, None),
            ("41110002", "CIF002", "N", "Y", "CR", 90, "SN", "0", "0", None, None),
            ("41110003", "CIF003", "N", "Y", "CR", 45, "SN", "0", "0", None, None),
            # CIF011 has primary + supplementary card
            ("41110110", "CIF011", "N", "Y", "CR", 40, "SN", "0", "0", None, None),
            ("41110111", "CIF011", "N", "Y", "CR", 35, "SN", "0", "0", "SHD-P-011", "41110110"),
            # debit cards
            ("51110001", "CIF101", "N", "Y", "DC", 20, None, None, None, None, None),
            ("51110002", "CIF102", "N", "Y", "DC", 120, None, None, None, None, None),
            ("51110003", "CIF103", "N", "Y", "DC", 40, None, None, None, None, None),
            # excluded by active examples
            ("49990001", "CIF090", "A", "Y", "CR", 20, "SN", "0", "0", None, None),
            ("59990001", "CIF190", "N", "Y", "DC", 250, None, None, None, None, None),
        ],
        "V3": [
            ("41110001", "CIF001", "N", "Y", "CR", 25, "SN", "0", "0", None, None),
            ("41110002", "CIF002", "N", "Y", "CR", 85, "SN", "0", "0", None, None),
            ("41110004", "CIF004", "N", "Y", "CR", 15, "SN", "0", "0", None, None),
            # same primary/supp pair plus one additional supplementary card
            ("41110110", "CIF011", "N", "Y", "CR", 38, "SN", "0", "0", None, None),
            ("41110111", "CIF011", "N", "Y", "CR", 33, "SN", "0", "0", "SHD-P-011", "41110110"),
            ("41110112", "CIF011", "N", "Y", "CR", 28, "SN", "0", "0", "SHD-P-011", "41110110"),
            ("51110001", "CIF101", "N", "Y", "DC", 18, None, None, None, None, None),
            ("51110003", "CIF103", "N", "Y", "DC", 38, None, None, None, None, None),
            ("51110004", "CIF104", "N", "Y", "DC", 10, None, None, None, None, None),
        ],
    },
    "PCMOCK": {
        "V2": [
            ("42220001", "CIF201", "N", "Y", "CR", 10, "SN", "0", "0", None, None),
            ("42220002", "CIF202", "N", "Y", "CR", 70, "SN", "0", "0", None, None),
            ("42220110", "CIF211", "N", "Y", "CR", 44, "SN", "0", "0", None, None),
            ("42220111", "CIF211", "N", "Y", "CR", 42, "SN", "0", "0", "SHD-P-211", "42220110"),
            ("52220001", "CIF301", "N", "Y", "DC", 35, None, None, None, None, None),
            ("52220002", "CIF302", "N", "Y", "DC", 75, None, None, None, None, None),
        ],
        "V3": [
            ("42220001", "CIF201", "N", "Y", "CR", 9, "SN", "0", "0", None, None),
            ("42220003", "CIF203", "N", "Y", "CR", 20, "SN", "0", "0", None, None),
            ("42220110", "CIF211", "N", "Y", "CR", 41, "SN", "0", "0", None, None),
            ("42220111", "CIF211", "N", "Y", "CR", 39, "SN", "0", "0", "SHD-P-211", "42220110"),
            ("52220001", "CIF301", "N", "Y", "DC", 30, None, None, None, None, None),
            ("52220003", "CIF303", "N", "Y", "DC", 60, None, None, None, None, None),
        ],
    },
}


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_database():
    with get_connection() as conn:
        conn.execute("DROP TABLE IF EXISTS cards")
        conn.execute("""
            CREATE TABLE cards (
                environment TEXT NOT NULL,
                version TEXT NOT NULL,
                card_number TEXT NOT NULL,
                client_code TEXT NOT NULL,
                status_code TEXT NOT NULL,
                delivery_card_flag TEXT NOT NULL,
                product_type TEXT NOT NULL,
                date_create_days_ago INTEGER NOT NULL,
                status_reason_code TEXT,
                unpaid_status TEXT,
                administrative_status TEXT,
                primary_shadow_account_nbr TEXT,
                basic_card_number TEXT
            )
        """)
        conn.execute("""
            CREATE INDEX idx_cards_env_ver_card
            ON cards(environment, version, card_number)
        """)
        conn.execute("""
            CREATE INDEX idx_cards_env_ver_cif
            ON cards(environment, version, client_code)
        """)
        for environment, versions in SAMPLE_DATA.items():
            for version, rows in versions.items():
                conn.executemany(
                    """
                    INSERT INTO cards(
                        environment, version, card_number, client_code, status_code,
                        delivery_card_flag, product_type, date_create_days_ago,
                        status_reason_code, unpaid_status, administrative_status,
                        primary_shadow_account_nbr, basic_card_number
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [(environment, version, *row) for row in rows],
                )
        conn.commit()
