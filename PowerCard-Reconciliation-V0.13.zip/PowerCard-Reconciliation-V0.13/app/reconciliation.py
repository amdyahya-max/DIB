from .config import data_source
from .database import get_connection
from .scenarios import SCENARIOS


def _sqlite_row_to_item(row):
    return {
        "cardNumber": row["card_number"], "clientCode": row["client_code"],
        "status": row["status_code"], "productType": row["product_type"],
        "primaryCard": row["basic_card_number"] if "basic_card_number" in row.keys() else None,
    }


def _fetch_sqlite_v2(environment, scenario):
    custom = scenario.get("custom_sqlite_query")
    if custom == "PRIMARY_NO_SUPP":
        sql = """
        SELECT c.card_number,c.client_code,c.status_code,c.product_type,c.basic_card_number FROM cards c
        WHERE c.environment=? AND c.version='V2' AND c.status_code='N' AND c.delivery_card_flag='Y'
          AND c.product_type='CR' AND c.date_create_days_ago<=180 AND c.status_reason_code='SN'
          AND c.unpaid_status='0' AND c.administrative_status='0' AND c.primary_shadow_account_nbr IS NULL
          AND c.client_code IN (SELECT x.client_code FROM cards x WHERE x.environment=? AND x.version='V2' GROUP BY x.client_code HAVING COUNT(*)<2)
        ORDER BY c.client_code,c.card_number"""
        params = (environment, environment)
    elif custom == "CIF_WITH_SUPP":
        sql = """
        SELECT c.card_number,c.client_code,c.status_code,c.product_type,c.basic_card_number FROM cards c
        WHERE c.environment=? AND c.version='V2' AND c.status_code='N' AND c.delivery_card_flag='Y' AND c.product_type='CR'
          AND c.date_create_days_ago<=180 AND c.client_code IN (
            SELECT DISTINCT x.client_code FROM cards x WHERE x.environment=? AND x.version='V2'
              AND x.primary_shadow_account_nbr IS NOT NULL AND x.date_create_days_ago<=500
              AND x.status_reason_code='SN' AND x.unpaid_status='0' AND x.administrative_status='0')
        ORDER BY c.client_code DESC,c.card_number"""
        params = (environment, environment)
    else:
        sql = f"SELECT card_number,client_code,status_code,product_type,basic_card_number FROM cards WHERE environment=? AND version='V2' AND {scenario['sqlite_where']} ORDER BY client_code,card_number"
        params = (environment,)
    with get_connection() as conn:
        return [_sqlite_row_to_item(r) for r in conn.execute(sql, params).fetchall()]


def _fetch_sqlite_v3_lookup(environment, card_numbers):
    cards = list(dict.fromkeys(card_numbers))
    if not cards:
        return []
    placeholders = ",".join("?" for _ in cards)
    sql = f"SELECT card_number,client_code,status_code,product_type,basic_card_number FROM cards WHERE environment=? AND version='V3' AND status_code='N' AND delivery_card_flag='Y' AND card_number IN ({placeholders})"
    with get_connection() as conn:
        return [_sqlite_row_to_item(r) for r in conn.execute(sql, (environment, *cards)).fetchall()]


def _oracle_item(row):
    return {
        "cardNumber": str(row.get("card_number")),
        "clientCode": row.get("client_code"),
        "status": row.get("status_code", "N"),
        "productType": row.get("product_type"),
        "primaryCard": row.get("primary_card") or row.get("basic_card_number"),
    }


def _dedupe(items):
    return {x["cardNumber"]: x for x in items if x.get("cardNumber")}


def reconcile_environment(environment: str, scenario_id: str):
    scenario = SCENARIOS[scenario_id]
    if scenario["mode"] == "guidance":
        return {"environment": environment, "dataSource": data_source(), "scenario": {k: scenario[k] for k in ("id","label","description","mode")},
                "configured": True, "mode": "guidance", "guidance": scenario["guidance"],
                "summary": {"v2Count":0,"v3Count":0,"matchedCount":0,"v2OnlyCount":0,"v3OnlyCount":0}, "matched":[],"v2Only":[],"v3Only":[]}

    if data_source() == "oracle":
        from .oracle_repository import fetch_v2, fetch_v3_by_cards
        v2_items = [_oracle_item(r) for r in fetch_v2(environment, scenario["v2_query_file"])]
        v3_items = [_oracle_item(r) for r in fetch_v3_by_cards(environment, [x["cardNumber"] for x in v2_items])]
    else:
        v2_items = _fetch_sqlite_v2(environment, scenario)
        v3_items = _fetch_sqlite_v3_lookup(environment, [x["cardNumber"] for x in v2_items])

    v2, v3 = _dedupe(v2_items), _dedupe(v3_items)
    v2_keys, v3_keys = set(v2), set(v3)
    matched_keys = sorted(v2_keys & v3_keys)
    v2_only_keys = sorted(v2_keys - v3_keys)
    # In V3 lookup mode, v3-only should normally be empty because V3 receives only the V2 population.
    v3_only_keys = sorted(v3_keys - v2_keys)
    matched = [{"cardNumber":k,"clientCode":v2[k].get("clientCode"),"v2Status":v2[k].get("status"),"v3Status":v3[k].get("status"),
                "productType":v2[k].get("productType"),"primaryCard":v2[k].get("primaryCard") or v3[k].get("primaryCard")} for k in matched_keys]
    return {"environment":environment,"dataSource":data_source(),"scenario":{k:scenario[k] for k in ("id","label","description","mode")},"configured":True,"mode":"compare",
            "summary":{"v2Count":len(v2),"v3Count":len(v3),"matchedCount":len(matched),"v2OnlyCount":len(v2_only_keys),"v3OnlyCount":len(v3_only_keys)},
            "matched":matched,"v2Only":[v2[k] for k in v2_only_keys],"v3Only":[v3[k] for k in v3_only_keys]}
