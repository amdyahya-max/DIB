
const state={mode:"department",users:[],filtered:[],sortKey:"name",sortDir:1,departments:[],magnitude:{},magnitudeReference:[],unmatchedMagnitude:[],unmatchedMeta:null,lastSearchLabel:"",managerFilter:"",showAllTitles:false};const $=id=>document.getElementById(id);
const COLS=[{key:"employeeId",label:"Employee ID",d:true},{key:"name",label:"Name",d:true,wrap:true},{key:"username",label:"Username",d:true},{key:"email",label:"Email",d:true},{key:"department",label:"Department",d:true,wrap:true},{key:"company",label:"Company",d:true,wrap:true},{key:"title",label:"Title",d:true,wrap:true},{key:"magnitudeUser",label:"Magnitude User",d:true},{key:"manager",label:"Manager",d:false,wrap:true},{key:"status",label:"Status",d:false},{key:"accountExpiry",label:"Account Expiry",d:false},{key:"passwordExpiry",label:"Password Expiry",d:false},{key:"lastLogon",label:"Last Logon",d:false},{key:"office",label:"Office",d:false},{key:"telephone",label:"Telephone",d:false},{key:"mobile",label:"Mobile",d:false},{key:"managerEmail",label:"Manager Email",d:false},{key:"upn",label:"UPN",d:false},{key:"employeeNumber",label:"Employee Number",d:false},{key:"whenCreated",label:"Created",d:false},{key:"whenChanged",label:"Last AD Change",d:false},{key:"homeDirectory",label:"Home Directory",d:false,wrap:true}];
let visible=new Set(JSON.parse(localStorage.getItem("diColumns")||"null")||COLS.filter(c=>c.d).map(c=>c.key));
function esc(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}function toast(m){const e=$("toast");e.textContent=m;e.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove("show"),2600)}async function api(p){const r=await fetch(p,{cache:"no-store"}),d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||`Request failed (${r.status})`);return d}function fmt(v,time=false){if(!v)return"—";const d=new Date(v);if(isNaN(d))return esc(v);return d.toLocaleString(undefined,time?{year:"numeric",month:"short",day:"2-digit",hour:"2-digit",minute:"2-digit"}:{year:"numeric",month:"short",day:"2-digit"})}function days(v){if(!v)return null;const d=new Date(v);return isNaN(d)?null:Math.ceil((d-Date.now())/86400000)}function expiry(v){if(!v)return'<span class="badge">Never</span>';const n=days(v);if(n<0)return`<span class="badge Expired">${fmt(v)}</span>`;if(n<=30)return`<span class="badge warning">${fmt(v)}</span>`;return fmt(v)}function mag(v){return v==="Yes"?'<span class="badge magYes">Yes</span>':'<span class="badge magNA">N/A</span>'}function text(v){return esc(v||"—")}
function setMode(m){state.mode=m;
document.querySelectorAll(".mode-tab").forEach(b=>b.classList.toggle("active",b.dataset.mode===m));$("departmentField").classList.toggle("hidden",m!=="department");$("groupField").classList.toggle("hidden",m!=="group");$("userField").classList.toggle("hidden",m!=="user");$("recursiveField").classList.toggle("hidden",m!=="group")}
async function health(){try{const h=await api("/api/health");$("healthPill").className="source-pill good";$("healthPill").textContent=`AD: ${h.user}`;updateMagnitudePill(h.magnitude)}catch(e){$("healthPill").className="source-pill warn";$("healthPill").textContent="AD: connection issue"}}
function updateMagnitudePill(s){state.magnitude=s||{};const p=$("magnitudeSourcePill");if(s&&s.loaded){p.className="source-pill good";p.textContent=`Magnitude: ${s.records} • ${s.source}`;p.title=`${s.sourceFile||""}${s.error?" | "+s.error:""}`}else{p.className="source-pill warn";p.textContent="Magnitude: not loaded";p.title=s?.error||""}}
async function loadDepts(){const d=await api("/api/departments");state.departments=d.items||[];$("departmentOptions").innerHTML=state.departments.map(x=>`<option value="${esc(x)}"></option>`).join("")}
async function refreshMagnitude(){
  const b=$("refreshMagnitudeBtn");
  b.disabled=true;
  b.textContent="Refreshing…";

  try{
    const s=await api("/api/magnitude/refresh");
    updateMagnitudePill(s);
    state.magnitudeReference=[];
    await ensureMagnitudeReference();

    if(state.users.length){
      computeScopedMagnitudeComparison();
    }else{
      updateScopedComparisonButton();
    }

    toast(`Magnitude data refreshed: ${s.records} records`);
  }catch(e){
    toast(e.message);
  }finally{
    b.disabled=false;
    b.textContent="↻ Refresh Magnitude Data";
  }
}
function departmentValue(){const v=$("departmentInput").value.trim();if(!v)return"";const exact=state.departments.find(d=>d.toLowerCase()===v.toLowerCase());if(exact)return exact;const matches=state.departments.filter(d=>d.toLowerCase().includes(v.toLowerCase()));if(matches.length===1)return matches[0];if(matches.length>1){toast("Multiple departments match. Please select one suggestion.");return""}return v}
async function search(){
  let value=state.mode==="department"
    ? departmentValue()
    : state.mode==="group"
      ? $("groupInput").value.trim()
      : $("userInput").value.trim();

  if(!value) return toast("Enter or select a search value.");

  const b=$("searchBtn");
  b.disabled=true;
  b.textContent="Searching…";

  try{
    const q=new URLSearchParams({
      mode:state.mode,
      value,
      recursive:String($("recursiveCheckbox").checked)
    });

    const d=await api(`/api/users?${q}`);
    state.users=d.items||[];
    updateMagnitudePill(d.magnitude);

    state.lastSearchLabel=state.mode==="department"
      ? `Department: ${value}`
      : state.mode==="group"
        ? `AD Group: ${value}`
        : `User search: ${value}`;

    state.unmatchedMagnitude=[];
    state.unmatchedMeta=null;
    state.managerFilter="";
    state.showAllTitles=false;

    applyFilters();
    updateScopedComparisonButton();

    // Pre-calculate the count after every AD search so the top button is immediately useful.
    try{
      await ensureMagnitudeReference();
      computeScopedMagnitudeComparison();
    }catch(_e){}

    toast(`${d.count} users found`);
  }catch(e){
    state.users=[];
    state.unmatchedMagnitude=[];
    state.unmatchedMeta=null;
    applyFilters();
    updateScopedComparisonButton();
    toast(e.message);
  }finally{
    b.disabled=false;
    b.textContent="Search Directory";
  }
}

function managerDisplayName(value){
  const v=String(value??"").trim();
  return v || "No Manager";
}
function titleDisplayName(value){
  const v=String(value??"").trim();
  return v || "No Title";
}
function getManagerStatsSource(){
  const q=$("filterInput").value.trim().toLowerCase();
  const status=$("statusFilter").value;
  const ex=$("expiryFilter").value;
  const mf=$("magnitudeFilter").value;

  // Manager counts follow all list filters except the manager selection itself.
  // This keeps every manager visible so the user can switch between managers.
  return (state.users||[]).filter(u=>{
    if(q&&!([u.employeeId,u.name,u.username,u.email,u.department,u.company,u.title,u.manager,u.managerEmail,u.office,u.magnitudeUser].join(" ").toLowerCase().includes(q)))return false;
    if(status&&u.status!==status)return false;
    if(mf&&u.magnitudeUser!==mf)return false;

    const n=days(u.accountExpiry);
    if(ex==="expired"&&!(n!==null&&n<0))return false;
    if(ex==="30"&&!(n!==null&&n>=0&&n<=30))return false;
    if(ex==="60"&&!(n!==null&&n>=0&&n<=60))return false;
    if(ex==="never"&&u.accountExpiry)return false;

    return true;
  });
}

function renderManagerTiles(){
  const box=$("managerTiles");
  if(!box)return;

  const source=getManagerStatsSource();
  const counts=new Map();

  source.forEach(u=>{
    const manager=managerDisplayName(u.manager);
    counts.set(manager,(counts.get(manager)||0)+1);
  });

  const entries=[...counts.entries()]
    .sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));

  if(!entries.length){
    box.innerHTML='<div class="analytics-empty">No manager statistics for the current filters.</div>';
    $("clearManagerFilterBtn").classList.add("hidden");
    $("managerFilterCaption").textContent="";
    return;
  }

  const total=source.length||1;
  const n=entries.length;
  const sizeClass=n>=14?"manager-xs":n>=10?"manager-sm":n<=4?"manager-lg":"manager-md";
  box.className=`manager-tiles ${sizeClass}`;

  box.innerHTML=entries.map(([name,count],i)=>{
    const pct=Math.round((count/total)*100);
    const active=state.managerFilter===name;

    return `<button class="manager-tile manager-tone-${i%10} ${active?"active":""}"
                   data-manager="${esc(name)}"
                   type="button"
                   title="Filter users managed by ${esc(name)}">
      <span class="manager-accent"></span>
      <span class="manager-avatar">${esc(name==="No Manager"?"?":name.charAt(0).toUpperCase())}</span>
      <span class="manager-copy">
        <span class="manager-name">${esc(name)}</span>
        <span class="manager-share">${pct}% of filtered users</span>
      </span>
      <span class="manager-count-wrap">
        <span class="manager-count">${count}</span>
        <span class="manager-users-label">users</span>
      </span>
    </button>`;
  }).join("");

  $("clearManagerFilterBtn").classList.toggle("hidden",!state.managerFilter);

  const statusText=$("statusFilter").value||"All statuses";
  $("managerFilterCaption").textContent=state.managerFilter
    ? `Filtering: ${state.managerFilter} • ${statusText}`
    : `${entries.length} manager${entries.length===1?"":"s"} • ${source.length} users • ${statusText}`;
}

function renderTitleStats(){
  const box=$("titleBars");
  if(!box)return;

  const source=state.filtered||[];
  const counts=new Map();

  source.forEach(u=>{
    const title=titleDisplayName(u.title);
    counts.set(title,(counts.get(title)||0)+1);
  });

  const entries=[...counts.entries()]
    .sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));

  $("titleStatsCaption").textContent=entries.length
    ? `${entries.length} title${entries.length===1?"":"s"} • ${source.length} users`
    : "No title statistics";

  $("uniqueTitleCount").textContent=entries.length;
  $("titleVisibleUsers").textContent=source.length;

  if(!entries.length){
    $("topTitleName").textContent="—";
    $("topTitleCount").textContent="0 users";
    $("topFiveCoverage").textContent="0%";
    $("toggleAllTitlesBtn").classList.add("hidden");
    box.innerHTML='<div class="analytics-empty">No title statistics available for the current result.</div>';
    return;
  }

  const topTitle=entries[0];
  $("topTitleName").textContent=topTitle[0];
  $("topTitleCount").textContent=`${topTitle[1]} user${topTitle[1]===1?"":"s"}`;

  const topFive=entries.slice(0,5).reduce((sum,item)=>sum+item[1],0);
  $("topFiveCoverage").textContent=`${Math.round((topFive/(source.length||1))*100)}%`;

  const DISPLAY_LIMIT=8;
  const shown=state.showAllTitles?entries:entries.slice(0,DISPLAY_LIMIT);
  const max=Math.max(...entries.map(x=>x[1]),1);
  const total=source.length||1;

  box.innerHTML=shown.map(([title,count],i)=>{
    const width=Math.max(5,Math.round((count/max)*100));
    const pct=Math.round((count/total)*100);

    return `<article class="title-stat-card title-card-tone-${i%8}">
      <div class="title-card-top">
        <span class="title-rank">#${i+1}</span>
        <span class="title-card-count">${count}</span>
      </div>
      <div class="title-card-name" title="${esc(title)}">${esc(title)}</div>
      <div class="title-card-meta">${pct}% of visible users</div>
      <div class="title-mini-track">
        <div class="title-mini-fill" style="width:${width}%"></div>
      </div>
    </article>`;
  }).join("");

  const toggle=$("toggleAllTitlesBtn");
  toggle.classList.toggle("hidden",entries.length<=DISPLAY_LIMIT);
  toggle.textContent=state.showAllTitles
    ? "Show top 8"
    : `Show all ${entries.length} titles`;
}

function setManagerFilter(manager){
  state.managerFilter=state.managerFilter===manager?"":manager;
  applyFilters();
}
function applyFilters(){
  const q=$("filterInput").value.trim().toLowerCase();
  const status=$("statusFilter").value;
  const ex=$("expiryFilter").value;
  const mf=$("magnitudeFilter").value;

  state.filtered=state.users.filter(u=>{
    if(q&&!([u.employeeId,u.name,u.username,u.email,u.department,u.company,u.title,u.manager,u.managerEmail,u.office,u.magnitudeUser].join(" ").toLowerCase().includes(q)))return false;
    if(status&&u.status!==status)return false;
    if(mf&&u.magnitudeUser!==mf)return false;

    if(state.managerFilter){
      const manager=managerDisplayName(u.manager);
      if(manager!==state.managerFilter)return false;
    }

    const n=days(u.accountExpiry);
    if(ex==="expired"&&!(n!==null&&n<0))return false;
    if(ex==="30"&&!(n!==null&&n>=0&&n<=30))return false;
    if(ex==="60"&&!(n!==null&&n>=0&&n<=60))return false;
    if(ex==="never"&&u.accountExpiry)return false;
    return true;
  });

  render();
  stats();
  renderManagerTiles();
  renderTitleStats();
}
function val(u,c){if(c.key==="name")return`<span class="linkish" data-user="${esc(u.username)}">${text(u.name)}</span>`;if(c.key==="status")return`<span class="badge ${esc(u.status)}">${text(u.status)}</span>`;if(c.key==="magnitudeUser")return mag(u.magnitudeUser);if(c.key==="accountExpiry")return expiry(u.accountExpiry);if(["passwordExpiry","whenCreated","whenChanged"].includes(c.key))return fmt(u[c.key],c.key!=="passwordExpiry");if(c.key==="lastLogon")return fmt(u.lastLogon,true);return text(u[c.key])}
function shown(){return COLS.filter(c=>visible.has(c.key))}function render(){const cs=shown();$("usersThead").innerHTML=`<tr>${cs.map(c=>`<th data-key="${c.key}">${esc(c.label)} ↕</th>`).join("")}<th>Details</th></tr>`;const rows=[...state.filtered].sort((a,b)=>String(a[state.sortKey]??"").localeCompare(String(b[state.sortKey]??""),undefined,{numeric:true,sensitivity:"base"})*state.sortDir);$("usersTbody").innerHTML=rows.length?rows.map(u=>`<tr>${cs.map(c=>`<td class="${c.wrap?"wrap":""}">${val(u,c)}</td>`).join("")}<td><button class="detail-btn" data-user="${esc(u.username)}">Open</button></td></tr>`).join(""):`<tr><td colspan="${cs.length+1}"><div class="empty-state"><strong>No users to display</strong><span>Run a search or adjust the filters.</span></div></td></tr>`;$("csvBtn").disabled=!rows.length;$("excelBtn").disabled=!rows.length;$("columnCountBadge").textContent=`(${visible.size})`;$("resultMeta").textContent=`Showing ${rows.length} of ${state.users.length} users • Magnitude matched: ${rows.filter(x=>x.magnitudeUser==="Yes").length}`}
function stats(){$("userCount").textContent=state.filtered.length;$("enabledCount").textContent=state.filtered.filter(x=>x.enabled).length;$("magnitudeCount").textContent=state.filtered.filter(x=>x.magnitudeUser==="Yes").length;$("expiringCount").textContent=state.filtered.filter(x=>{const n=days(x.accountExpiry);return n!==null&&n>=0&&n<=30}).length}
function buildColumns(){$("columnPickerMenu").innerHTML=`<div class="column-picker-title"><strong>Visible columns</strong><button id="resetColumnsBtn">Reset</button></div><div class="column-picker-list">${COLS.map(c=>`<label class="column-option"><input type="checkbox" data-col="${c.key}" ${visible.has(c.key)?"checked":""}><span>${esc(c.label)}</span></label>`).join("")}</div>`;$("columnPickerMenu").querySelectorAll("[data-col]").forEach(cb=>cb.onchange=()=>{if(cb.checked)visible.add(cb.dataset.col);else visible.delete(cb.dataset.col);if(!visible.size){visible.add("name");buildColumns();toast("At least one column must remain visible.")}localStorage.setItem("diColumns",JSON.stringify([...visible]));render()});$("resetColumnsBtn").onclick=()=>{visible=new Set(COLS.filter(c=>c.d).map(c=>c.key));localStorage.setItem("diColumns",JSON.stringify([...visible]));buildColumns();render();toast("Default columns restored")}}
async function openUser(username){$("drawerBackdrop").classList.remove("hidden");$("detailDrawer").classList.remove("hidden");$("drawerTitle").textContent="Loading…";$("drawerSub").textContent=username;$("drawerBody").innerHTML='<div class="empty-state">Retrieving user profile…</div>';try{const u=await api(`/api/user?username=${encodeURIComponent(username)}`);$("drawerTitle").textContent=u.name||u.username;$("drawerSub").textContent=`${u.username||""}${u.email?" • "+u.email:""}`;const item=(l,v)=>`<div class="detail-item"><span>${esc(l)}</span><strong>${esc(v||"—")}</strong></div>`;$("drawerBody").innerHTML=`<div class="magnitude-card"><div class="mag-head"><h4>Magnitude User</h4>${mag(u.magnitudeUser)}</div><p>${u.magnitudeUser==="Yes"?`Matched by ${esc(u.magnitudeMatchedBy)}${u.magnitudeReferenceUsername?" • "+esc(u.magnitudeReferenceUsername):""}`:"No match found in the Magnitude reference file."}</p></div><div class="detail-section"><h4>Identity</h4><div class="detail-grid">${item("Employee ID",u.employeeId)}${item("Employee ID source",u.employeeIdSource)}${item("Username",u.username)}${item("Full name",u.name)}${item("Email",u.email)}${item("UPN",u.upn)}${item("Company",u.company)}${item("Department",u.department)}${item("Title",u.title)}</div></div><div class="detail-section"><h4>Manager & Contact</h4><div class="detail-grid">${item("Manager",u.manager)}${item("Manager email",u.managerEmail)}${item("Office",u.office)}${item("Telephone",u.telephone)}${item("Mobile",u.mobile)}${item("Home directory",u.homeDirectory)}</div></div><div class="detail-section"><h4>Account</h4><div class="detail-grid">${item("Status",u.status)}${item("Account expiry",u.accountExpiry?fmt(u.accountExpiry):"Never")}${item("Created",fmt(u.whenCreated,true))}${item("Last AD change",fmt(u.whenChanged,true))}${item("Last logon",fmt(u.lastLogon,true))}${item("Password last set",fmt(u.passwordLastSet,true))}${item("Password expiry",u.passwordExpiry?fmt(u.passwordExpiry,true):(u.passwordNeverExpires?"Never":"Not available"))}${item("Password required",u.passwordRequired?"Yes":"No")}</div></div><div class="detail-section"><h4>Directory</h4><div class="detail-grid">${item("Description",u.description)}${item("Comment",u.comment)}${item("Distinguished name",u.distinguishedName)}</div></div><div class="detail-section"><h4>Direct group memberships (${(u.groups||[]).length})</h4><div class="group-chips">${(u.groups||[]).length?u.groups.map(g=>`<span class="group-chip">${esc(g)}</span>`).join(""):'<span class="muted">No direct groups returned.</span>'}</div></div>`}catch(e){$("drawerTitle").textContent="Unable to load user";$("drawerBody").innerHTML=`<div class="empty-state">${esc(e.message)}</div>`}}
function closeDrawer(){$("drawerBackdrop").classList.add("hidden");$("detailDrawer").classList.add("hidden")}async function findGroups(){const box=$("groupLookupResults");box.innerHTML="Searching…";try{const d=await api(`/api/groups?query=${encodeURIComponent($("groupLookupInput").value.trim())}`);box.innerHTML=d.items.length?d.items.slice(0,100).map(g=>`<div class="group-result"><div><strong>${esc(g.name||g.samAccountName)}</strong><small>${esc(g.description||g.samAccountName||"")}</small></div><button class="btn ghost use-group" data-group="${esc(g.name||g.samAccountName)}">Use</button></div>`).join(""):"No groups found."}catch(e){box.innerHTML=esc(e.message)}}function csvCell(v){return`"${String(v??"").replaceAll('"','""')}"`}function exportCsv(){const cs=shown(),rows=[cs.map(c=>csvCell(c.label)).join(","),...state.filtered.map(u=>cs.map(c=>csvCell(u[c.key])).join(","))];download(new Blob(["\uFEFF"+rows.join("\r\n")],{type:"text/csv;charset=utf-8"}),"Directory-Users.csv")}function exportExcel(){const cs=shown(),h=cs.map(c=>`<th>${esc(c.label)}</th>`).join(""),r=state.filtered.map(u=>`<tr>${cs.map(c=>`<td>${esc(u[c.key]??"")}</td>`).join("")}</tr>`).join("");download(new Blob([`<html><meta charset="utf-8"><table border="1"><tr>${h}</tr>${r}</table></html>`],{type:"application/vnd.ms-excel"}),"Directory-Users.xls")}function download(blob,name){const a=document.createElement("a"),url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),500)}

async function ensureMagnitudeReference(){
  if(state.magnitudeReference.length) return state.magnitudeReference;
  const d=await api("/api/magnitude/reference");
  state.magnitudeReference=d.items||[];
  updateMagnitudePill(d.source);
  return state.magnitudeReference;
}

function normalizeCompare(v){
  return String(v??"").trim().toLowerCase();
}

function computeScopedMagnitudeComparison(){
  const refs=state.magnitudeReference||[];
  const loaded=state.users||[];

  const usernames=new Set();
  const emails=new Set();
  const employeeIds=new Set();
  const names=new Set();

  loaded.forEach(u=>{
    const username=normalizeCompare(u.username);
    const email=normalizeCompare(u.email);
    const employeeId=normalizeCompare(u.employeeId);
    const name=normalizeCompare(u.name);
    if(username) usernames.add(username);
    if(email) emails.add(email);
    if(employeeId) employeeIds.add(employeeId);
    if(name) names.add(name);
  });

  const unmatched=[];
  let matched=0;

  refs.forEach(r=>{
    const username=normalizeCompare(r.username);
    const email=normalizeCompare(r.email);
    const employeeId=normalizeCompare(r.employeeId);
    const name=normalizeCompare(r.name);

    const found=
      (username && usernames.has(username)) ||
      (email && emails.has(email)) ||
      (employeeId && employeeIds.has(employeeId)) ||
      (name && names.has(name));

    if(found) matched++;
    else unmatched.push(r);
  });

  state.unmatchedMagnitude=unmatched;
  state.unmatchedMeta={
    checked:refs.length,
    matched,
    unmatchedCount:unmatched.length,
    scopeCount:loaded.length,
    scopeLabel:state.lastSearchLabel||"Current AD search result",
    checkedAt:new Date().toISOString()
  };

  updateScopedComparisonButton();
  renderUnmatched();
  return state.unmatchedMeta;
}

function updateScopedComparisonButton(){
  const b=$("unmatchedMagnitudeBtn");
  if(!b) return;

  if(!state.users.length){
    b.disabled=true;
    b.classList.remove("ok");
    $("unmatchedMagnitudeCount").textContent="—";
    b.title="Run an AD search first. Comparison uses only users loaded by that search.";
    return;
  }

  b.disabled=false;
  const count=state.unmatchedMeta?.unmatchedCount;
  $("unmatchedMagnitudeCount").textContent=(count===undefined||count===null)?"?":count;
  b.classList.toggle("ok",count===0);
  b.title=`Magnitude users outside ${state.lastSearchLabel||"the current AD search result"}`;
}

async function runMagnitudeReconciliation(openAfter=true){
  if(!state.users.length){
    toast("Run an AD search first.");
    return;
  }

  const topBtn=$("unmatchedMagnitudeBtn");
  const rerunBtn=$("refreshUnmatchedBtn");
  topBtn.disabled=true;
  if(rerunBtn) rerunBtn.disabled=true;

  try{
    await ensureMagnitudeReference();
    const d=computeScopedMagnitudeComparison();
    if(openAfter) openUnmatchedModal();
    toast(`${d.unmatchedCount} Magnitude users are outside the loaded AD result`);
  }catch(e){
    toast(e.message);
  }finally{
    topBtn.disabled=false;
    if(rerunBtn) rerunBtn.disabled=false;
  }
}

function openUnmatchedModal(){
  $("unmatchedModalBackdrop").classList.remove("hidden");
  $("unmatchedModal").classList.remove("hidden");
  $("unmatchedModal").setAttribute("aria-hidden","false");
}

function closeUnmatchedModal(){
  $("unmatchedModalBackdrop").classList.add("hidden");
  $("unmatchedModal").classList.add("hidden");
  $("unmatchedModal").setAttribute("aria-hidden","true");
}

function renderUnmatched(){
  const meta=state.unmatchedMeta||{};
  const q=($("unmatchedSearch")?.value||"").trim().toLowerCase();
  const list=(state.unmatchedMagnitude||[]).filter(r=>{
    if(!q) return true;
    return [r.username,r.email,r.name,r.employeeId].join(" ").toLowerCase().includes(q);
  });

  $("reconcileChecked").textContent=meta.checked??0;
  $("reconcileMatched").textContent=meta.matched??0;
  $("reconcileMissing").textContent=meta.unmatchedCount??0;

  $("unmatchedModalSub").textContent=meta.checkedAt
    ? `Compared ${meta.checked||0} Magnitude users against ${meta.scopeCount||0} users loaded from ${meta.scopeLabel||"the current AD search"}.`
    : "Run an AD search first, then compare Magnitude users against the loaded result.";

  $("unmatchedTbody").innerHTML=list.length
    ? list.map(r=>`<tr><td>${text(r.username)}</td><td>${text(r.email)}</td><td>${text(r.name)}</td><td>${text(r.employeeId)}</td></tr>`).join("")
    : `<tr><td colspan="4"><div class="empty-state">${meta.checkedAt?"All Magnitude users are present in the loaded AD result.":"No comparison results yet."}</div></td></tr>`;

  $("exportUnmatchedBtn").disabled=!list.length;
}

function exportUnmatchedCsv(){
  const rows=[
    ["Username","Email ID","Name","Employee ID"],
    ...(state.unmatchedMagnitude||[]).map(r=>[r.username,r.email,r.name,r.employeeId])
  ];
  const csv=rows.map(row=>row.map(csvCell).join(",")).join("\r\n");
  download(new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8"}),"Magnitude-Users-Outside-Current-AD-Search.csv");
}

document.querySelectorAll(".mode-tab").forEach(b=>b.onclick=()=>setMode(b.dataset.mode));$("searchBtn").onclick=search;

$("toggleAllTitlesBtn").onclick=()=>{
  state.showAllTitles=!state.showAllTitles;
  renderTitleStats();
};
$("managerTiles").onclick=e=>{
  const tile=e.target.closest("[data-manager]");
  if(tile)setManagerFilter(tile.dataset.manager);
};
$("clearManagerFilterBtn").onclick=()=>{
  state.managerFilter="";
  applyFilters();
};


$("unmatchedMagnitudeBtn").onclick=()=>runMagnitudeReconciliation(true);
$("refreshUnmatchedBtn").onclick=()=>runMagnitudeReconciliation(false);
$("unmatchedModalClose").onclick=closeUnmatchedModal;
$("unmatchedModalBackdrop").onclick=closeUnmatchedModal;
$("unmatchedSearch").oninput=renderUnmatched;
$("exportUnmatchedBtn").onclick=exportUnmatchedCsv;
$("refreshLookupsBtn").onclick=async()=>{await Promise.all([health(),loadDepts()]);toast("AD lookups refreshed")};$("refreshMagnitudeBtn").onclick=refreshMagnitude;$("filterInput").oninput=applyFilters;["statusFilter","expiryFilter","magnitudeFilter"].forEach(id=>$(id).onchange=applyFilters);$("groupLookupBtn").onclick=findGroups;$("csvBtn").onclick=exportCsv;$("excelBtn").onclick=exportExcel;$("drawerClose").onclick=closeDrawer;$("drawerBackdrop").onclick=closeDrawer;$("columnPickerBtn").onclick=e=>{e.stopPropagation();$("columnPickerMenu").classList.toggle("hidden")};document.addEventListener("click",e=>{if(!document.querySelector(".column-picker").contains(e.target))$("columnPickerMenu").classList.add("hidden")});$("groupLookupResults").onclick=e=>{const b=e.target.closest(".use-group");if(b){setMode("group");$("groupInput").value=b.dataset.group;toast("Group selected")}};$("usersTbody").onclick=e=>{const x=e.target.closest("[data-user]");if(x)openUser(x.dataset.user)};$("usersThead").onclick=e=>{const th=e.target.closest("[data-key]");if(!th)return;state.sortDir=state.sortKey===th.dataset.key?-state.sortDir:1;state.sortKey=th.dataset.key;render()};["departmentInput","groupInput","userInput","groupLookupInput"].forEach(id=>$(id).onkeydown=e=>{if(e.key==="Enter")id==="groupLookupInput"?findGroups():search()});(async()=>{setMode("department");buildColumns();render();renderManagerTiles();renderTitleStats();updateScopedComparisonButton();await Promise.all([health(),loadDepts()])})();
