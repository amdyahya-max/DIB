PowerCard V2/V3 Reconciliation V0.6
===================================

Modes
-----
1. SQLite demo: DATA_SOURCE=sqlite (default)
2. Oracle: DATA_SOURCE=oracle

Question flow
-------------
For reconciliation questions, the selected V2 business SQL runs first. Its CARD_NUMBER result is used as the input population for the parameterized V3 lookup query, then the application compares the results.

Create New Debit or Credit Card is guidance-only and runs no SQL.

Oracle setup
------------
Read DEPLOY_ORACLE_STEPS.txt before switching to Oracle.
Real credentials are intentionally NOT included in this project.

Run local demo
--------------
start.bat
Then open http://127.0.0.1:8000


V0.6 CHANGE: The project-root .env file is now loaded automatically using python-dotenv. Windows/system environment variables override .env values.
