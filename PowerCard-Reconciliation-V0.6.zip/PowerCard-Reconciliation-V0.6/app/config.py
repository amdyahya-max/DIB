import json
import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT_DIR / "config"
QUERY_DIR = Path(__file__).resolve().parent / "queries"
ENV_FILE = ROOT_DIR / ".env"

# Load project-root .env automatically. Existing Windows/system environment variables
# take precedence over values in .env.
load_dotenv(dotenv_path=ENV_FILE, override=False)


def data_source() -> str:
    return os.getenv("DATA_SOURCE", "sqlite").strip().lower()


@lru_cache(maxsize=1)
def database_config():
    with (CONFIG_DIR / "databases.json").open("r", encoding="utf-8") as f:
        return json.load(f)


def oracle_setting(environment: str, version: str):
    env_cfg = database_config()[environment.upper()]
    cfg = env_cfg[version.lower()]
    username = os.getenv(cfg["username_env"])
    password = os.getenv(cfg["password_env"])
    if not username or not password:
        missing = [name for name, value in ((cfg["username_env"], username), (cfg["password_env"], password)) if not value]
        raise RuntimeError("Missing Oracle environment variable(s): " + ", ".join(missing))
    return {"dsn": cfg["dsn_alias"], "username": username, "password": password}


def load_query(filename: str) -> str:
    return (QUERY_DIR / filename).read_text(encoding="utf-8").strip()


def oracle_batch_size() -> int:
    try:
        return max(1, min(int(os.getenv("ORACLE_V3_BATCH_SIZE", "500")), 900))
    except ValueError:
        return 500
