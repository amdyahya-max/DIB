import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createCore,hash} from '../server/core.js';
import {newRoster,mergeWorkbook,readRoster} from '../server/roster-workbook.js';
import {filterSortUsers} from '../src/admin-users.js';

const make=(username,name,status='Enabled')=>({username,name,status,email:username.split('\\').at(-1)+'@example.test',company:'CET'});
async function bytes(rows){const book=newRoster();mergeWorkbook(book,rows);return Buffer.from(await book.workbook.xlsx.writeBuffer());}

test('admin add writes Excel and SQLite, preserves access flags, and stays synced',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-write-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice')]));await core.sync();
  core.db.prepare('UPDATE users SET admin=1,special=1 WHERE username=?').run('dib\\alice');
  const result=await core.addUser(make('DIB\\BOB','Bob'),'dib\\alice');
  assert.equal(result.created,1);assert.equal(result.count,2);
  assert.equal(core.db.prepare('SELECT name FROM users WHERE username=?').get('dib\\bob').name,'Bob');
  const book=await readRoster(fs.readFileSync(filename));assert.deepEqual(book.rows.map(u=>u.username),['dib\\alice','dib\\bob']);
  assert.equal(core.db.prepare('SELECT special FROM users WHERE username=?').get('dib\\alice').special,1);
  assert.equal((await core.sync()).error,null);
  assert.equal((await core.sync()).hash,hash(fs.readFileSync(filename)));
  await assert.rejects(core.addUser(make('dib\\bob','Another Bob'),'dib\\alice'),/already exists/);
  assert.equal((await readRoster(fs.readFileSync(filename))).rows.length,2);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('Excel upload merges by username, leaves other users and history intact, rejects self lockout and bad files',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-upload-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice'),make('dib\\charlie','Charlie')]));await core.sync();
  core.db.prepare('UPDATE users SET admin=1 WHERE username=?').run('dib\\alice');
  const charlie=core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\charlie');
  core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(charlie.id,'2026-10-01','2026-10-01T10:00:00Z');
  const upload=await bytes([make('DIB\\CHARLIE','Charles','Disabled'),make('DIB\\DAVID','David')]);
  const result=await core.uploadRoster(upload,'dib\\alice');assert.deepEqual([result.created,result.updated,result.count],[1,1,3]);
  assert.equal(core.db.prepare('SELECT name FROM users WHERE id=?').get(charlie.id).name,'Charles');
  assert.equal(core.db.prepare('SELECT excel_enabled FROM users WHERE id=?').get(charlie.id).excel_enabled,0);
  assert.equal(core.db.prepare('SELECT count(*) n FROM attendance WHERE user_id=?').get(charlie.id).n,1);
  assert.equal(core.db.prepare('SELECT admin FROM users WHERE username=?').get('dib\\alice').admin,1);
  const saved=fs.readFileSync(filename),digest=hash(saved);
  await assert.rejects(core.uploadRoster(await bytes([make('dib\\alice','Alice','Disabled')]),'dib\\alice'),/own portal access/);
  await assert.rejects(core.uploadRoster(Buffer.from('not a workbook'),'dib\\alice'));
  const duplicate=newRoster();duplicate.sheet.addRow(['','David','dib\\david','','','','','Enabled']);duplicate.sheet.addRow(['','David 2','DIB\\DAVID','','','','','Enabled']);
  await assert.rejects(core.uploadRoster(Buffer.from(await duplicate.workbook.xlsx.writeBuffer()),'dib\\alice'),/Duplicate/);
  assert.equal(hash(fs.readFileSync(filename)),digest);
  assert.equal(core.syncState().hash,digest);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('upload prefixes Windows usernames and updates an existing email without creating another identity',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-email-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice'),make('dib\\bob','Bob')]));await core.sync();
  const bob=core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\bob');
  core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(bob.id,'2026-10-01','2026-10-01T10:00:00Z');
  const update=await core.uploadRoster(await bytes([{...make('otherbob','Robert'),email:' BOB@EXAMPLE.TEST '},make('carol','Carol')]),'dib\\alice');
  assert.deepEqual([update.created,update.updated,update.count],[1,1,3]);
  assert.equal(core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\bob').id,bob.id);
  assert.equal(core.db.prepare('SELECT name FROM users WHERE id=?').get(bob.id).name,'Robert');
  assert.equal(core.db.prepare('SELECT count(*) n FROM users WHERE lower(email)=?').get('bob@example.test').n,1);
  assert.equal(core.db.prepare('SELECT count(*) n FROM users WHERE username=?').get('dib\\otherbob').n,0);
  assert.equal(core.db.prepare('SELECT name FROM users WHERE username=?').get('dib\\carol').name,'Carol');
  assert.equal(core.db.prepare('SELECT count(*) n FROM attendance WHERE user_id=?').get(bob.id).n,1);
  const book=await readRoster(fs.readFileSync(filename));assert.deepEqual(book.rows.map(u=>u.username),['dib\\alice','dib\\bob','dib\\carol']);
  const stable=hash(fs.readFileSync(filename));
  const duplicateEmail=newRoster();duplicateEmail.sheet.addRow(['','Bob','bob','bob@example.test','','','','Enabled']);duplicateEmail.sheet.addRow(['','D','different','BOB@EXAMPLE.TEST','','','','Enabled']);
  await assert.rejects(core.uploadRoster(Buffer.from(await duplicateEmail.workbook.xlsx.writeBuffer()),'dib\\alice'),/Duplicate Email/);
  await assert.rejects(core.uploadRoster(await bytes([{...make('alice','Alice'),email:'bob@example.test'}]),'dib\\alice'),/different users/);
  assert.equal(hash(fs.readFileSync(filename)),stable);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('bulk deletion purges selected users, associated records and audit while individual deletion keeps history',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-purge-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice'),make('bob','Bob'),make('dib\\charlie','Charlie')]));await core.sync();
  const alice=core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\alice'),bob=core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\bob'),charlie=core.db.prepare('SELECT id FROM users WHERE username=?').get('dib\\charlie');
  core.db.prepare('UPDATE users SET admin=1 WHERE id=?').run(alice.id);
  core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(bob.id,'2026-10-01','2026-10-01T10:00:00Z');
  core.db.prepare('INSERT INTO self_absences VALUES(?,?,?)').run(bob.id,'2026-10-02','2026-10-02T10:00:00Z');
  core.db.prepare('INSERT INTO leave_days VALUES(?,?)').run(bob.id,'2026-10-03');
  core.db.prepare('INSERT INTO devices VALUES(?,?,?,?,0)').run('bob-device',bob.id,'secret','2026-10-01T10:00:00Z');
  core.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run('session',bob.id,'bob-device',Date.now()+10000);
  core.db.exec('CREATE TABLE device_labels(device_id TEXT PRIMARY KEY REFERENCES devices(id),pc_name TEXT); CREATE TABLE device_requests(id TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id),secret_hash TEXT,status TEXT);');
  core.db.prepare('INSERT INTO device_labels VALUES(?,?)').run('bob-device','BOB-PC');
  core.db.prepare('INSERT INTO device_requests(id,user_id,secret_hash,status) VALUES(?,?,?,?)').run('bob-request',bob.id,'request','pending');
  core.audit('dib\\bob','attendance.confirm',{date:'2026-10-01'});
  core.audit('dib\\alice','user.update',{id:bob.id});
  const auditBefore=core.db.prepare('SELECT count(*) n FROM audit').get().n;
  await assert.rejects(core.bulkDeleteUsers([alice.id],'dib\\alice'),/own portal access/);
  assert.equal(core.db.prepare('SELECT count(*) n FROM audit').get().n,auditBefore);
  const result=await core.bulkDeleteUsers([bob.id],'dib\\alice');assert.equal(result.deleted,1);
  assert.equal(core.user(bob.id),undefined);
  for(const table of ['attendance','self_absences','leave_days','devices','sessions','device_requests'])assert.equal(core.db.prepare(`SELECT count(*) n FROM ${table} WHERE user_id=?`).get(bob.id).n,0);
  assert.equal(core.db.prepare('SELECT count(*) n FROM device_labels WHERE device_id=?').get('bob-device').n,0);
  assert.equal(core.db.prepare('SELECT count(*) n FROM audit WHERE actor=? OR detail LIKE ?').get('dib\\bob','%"id":'+bob.id+'%').n,0);
  assert.equal((await readRoster(fs.readFileSync(filename))).rows.some(u=>u.username==='dib\\bob'),false);
  assert.equal(core.user(charlie.id).roster_active,1);
  await core.deleteUser(charlie.id,'dib\\alice');
  assert.equal(core.user(charlie.id).roster_active,0);
  assert.equal(core.db.prepare('SELECT count(*) n FROM audit WHERE action=?').get('roster.delete').n,1);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('Never, blank and dated expiry survive Excel import and enforce access correctly',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-expiry-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  const source=newRoster();
  source.sheet.addRow(['','Alice','dib\\alice','alice@example.test','CET','','','Enabled','Never']);
  source.sheet.addRow(['','Bob','dib\\bob','bob@example.test','CET','','','Enabled','']);
  source.sheet.addRow(['','Old','dib\\old','old@example.test','CET','','','Enabled','2020-01-01T00:00:00']);
  source.sheet.addRow(['','Future','dib\\future','future@example.test','CET','','','Enabled','2027-01-01T00:00:00']);
  fs.writeFileSync(filename,Buffer.from(await source.workbook.xlsx.writeBuffer()));
  const state=await core.sync();assert.equal(state.error,null);
  const alice=core.db.prepare('SELECT * FROM users WHERE username=?').get('dib\\alice');
  const bob=core.db.prepare('SELECT * FROM users WHERE username=?').get('dib\\bob');
  const old=core.db.prepare('SELECT * FROM users WHERE username=?').get('dib\\old');
  assert.equal(alice.account_expiry,'Never');assert.equal(bob.account_expiry,null);
  assert.equal(core.active(alice),true);assert.equal(core.active(bob),true);assert.equal(core.active(old),false);
  assert.equal(old.account_expiry,'2020-01-01');assert.equal(core.db.prepare('SELECT account_expiry FROM users WHERE username=?').get('dib\\future').account_expiry,'2027-01-01');
  core.db.prepare('UPDATE users SET admin=1 WHERE id=?').run(alice.id);
  await core.addUser({...make('dib\\new','New'),account_expiry:'Never'},'dib\\alice');
  const saved=await readRoster(fs.readFileSync(filename));assert.equal(saved.rows.find(r=>r.username==='dib\\new').account_expiry,'Never');
  await core.uploadRoster(await bytes([{...make('dib\\alice','Alice'),account_expiry:'NEVER'},{...make('dib\\new','New'),account_expiry:''}]),'dib\\alice');
  assert.equal(core.active(core.user(alice.id)),true);
  assert.equal(core.db.prepare('SELECT account_expiry FROM users WHERE username=?').get('dib\\new').account_expiry,null);
  assert.equal((await core.sync(true)).error,null);
  assert.equal(core.active(core.user(alice.id)),true);
  const timestampUpload=newRoster();timestampUpload.sheet.addRow(['','New','dib\\new','new@example.test','CET','','','Enabled','2099-12-31T23:59:59']);
  await core.uploadRoster(Buffer.from(await timestampUpload.workbook.xlsx.writeBuffer()),'dib\\alice');
  assert.equal(core.db.prepare('SELECT account_expiry FROM users WHERE username=?').get('dib\\new').account_expiry,'2099-12-31');
  assert.equal((await readRoster(fs.readFileSync(filename))).rows.find(r=>r.username==='dib\\new').account_expiry,'2099-12-31');
  await assert.rejects(core.uploadRoster(await bytes([{...make('dib\\alice','Alice'),account_expiry:'2020-01-01'}]),'dib\\alice'),/own portal access/);
  const invalid=newRoster();invalid.sheet.addRow(['','Alice','dib\\alice','','','','','Enabled','Someday']);
  await assert.rejects(core.uploadRoster(Buffer.from(await invalid.workbook.xlsx.writeBuffer()),'dib\\alice'),/Invalid Account Expiry/);
  const invalidTime=newRoster();invalidTime.sheet.addRow(['','New','dib\\new','','','','','Enabled','2027-01-01T25:00:00']);
  await assert.rejects(core.uploadRoster(Buffer.from(await invalidTime.workbook.xlsx.writeBuffer()),'dib\\alice'),/Invalid Account Expiry/);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('admin user list searches selected columns, filters status, and sorts visible values',()=>{
 const users=[
  {id:1,name:'Alice',username:'dib\\alice',employee_id:'002',email:'alice@example.test',company:'CET',status:'Enabled',roster_active:1,excel_enabled:1,account_expiry:'Never',admin:1,special:0,admin_blocked:0},
  {id:2,name:'Bob',username:'dib\\bob',employee_id:'001',email:'bob@example.test',company:'Other',status:'Disabled',roster_active:1,excel_enabled:0,account_expiry:null,admin:0,special:0,admin_blocked:0},
  {id:3,name:'Clara',username:'dib\\clara',employee_id:'003',email:'clara@example.test',company:'CET',status:'Enabled',roster_active:1,excel_enabled:1,account_expiry:'2026-11-01',admin:0,special:1,admin_blocked:0}
 ];
 assert.deepEqual(filterSortUsers(users,{search:'NEVER',searchField:'account_expiry'}).map(u=>u.name),['Alice']);
 assert.deepEqual(filterSortUsers(users,{search:'example.test',searchField:'email',status:'Enabled'}).map(u=>u.name),['Alice','Clara']);
 assert.deepEqual(filterSortUsers(users,{search:'001',searchField:'employee_id'}).map(u=>u.name),['Bob']);
 assert.deepEqual(filterSortUsers(users,{sortKey:'employee_id',sortDirection:'desc'}).map(u=>u.name),['Clara','Alice','Bob']);
 assert.deepEqual(filterSortUsers(users,{status:'Disabled'}).map(u=>u.name),['Bob']);
});

test('edit and extend retain user history; delete removes Excel row and revokes helper access',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-roster-edit-')),filename=path.join(dir,'CET_Users.xlsx'),core=createCore({storage:dir,data:dir});
 try{
  fs.writeFileSync(filename,await bytes([make('dib\\alice','Alice'),{...make('dib\\bob','Bob'),account_expiry:'2020-01-01'}]));await core.sync();
  const alice=core.db.prepare('SELECT * FROM users WHERE username=?').get('dib\\alice'),bob=core.db.prepare('SELECT * FROM users WHERE username=?').get('dib\\bob');
  core.db.prepare('UPDATE users SET admin=1 WHERE id=?').run(alice.id);
  core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(bob.id,'2026-10-01','2026-10-01T10:00:00Z');
  core.db.prepare('INSERT INTO devices VALUES(?,?,?,?,0)').run('device-bob',bob.id,'secret-bob','2026-10-01T10:00:00Z');
  core.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run('session-bob',bob.id,'device-bob',Date.now()+3600000);
  assert.equal(core.accessStatus(bob),'Expired');
  await core.editUser(bob.id,{...make('dib\\bob','Robert'),account_expiry:'2099-12-31'},'dib\\alice');
  assert.equal(core.user(bob.id).name,'Robert');assert.equal(core.accessStatus(core.user(bob.id)),'Active');
  assert.equal((await readRoster(fs.readFileSync(filename))).rows.find(r=>r.username==='dib\\bob').account_expiry,'2099-12-31');
  assert.equal(core.db.prepare('SELECT count(*) n FROM attendance WHERE user_id=?').get(bob.id).n,1);
  await assert.rejects(core.editUser(bob.id,{...make('dib\\other','Wrong')},'dib\\alice'),/username cannot be changed/);
  await assert.rejects(core.editUser(alice.id,{...make('dib\\alice','Alice','Disabled')},'dib\\alice'),/own portal access/);
  await assert.rejects(core.deleteUser(alice.id,'dib\\alice'),/own portal access/);
  const result=await core.deleteUser(bob.id,'dib\\alice');assert.equal(result.deleted,1);
  assert.equal((await readRoster(fs.readFileSync(filename))).rows.some(r=>r.username==='dib\\bob'),false);
  assert.equal(core.accessStatus(core.user(bob.id)),'Removed');
  assert.equal(core.active(core.user(bob.id)),false);
  assert.equal(core.db.prepare('SELECT revoked FROM devices WHERE id=?').get('device-bob').revoked,1);
  assert.equal(core.db.prepare('SELECT count(*) n FROM sessions WHERE user_id=?').get(bob.id).n,0);
  assert.equal(core.db.prepare('SELECT count(*) n FROM attendance WHERE user_id=?').get(bob.id).n,1);
  assert.deepEqual(filterSortUsers([core.user(alice.id),{...core.user(bob.id),portal_status:'Removed'}],{}).map(u=>u.username),['dib\\alice']);
  assert.deepEqual(filterSortUsers([{...core.user(bob.id),portal_status:'Removed'}],{status:'Removed'}).map(u=>u.username),['dib\\bob']);
  assert.equal((await core.sync(true)).error,null);
 }finally{core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
});
