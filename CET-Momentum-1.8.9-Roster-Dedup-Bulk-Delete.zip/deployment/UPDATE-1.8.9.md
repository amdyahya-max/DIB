# Deploy CET Momentum 1.8.9

## Roster behavior

- An Excel username without a domain, such as `yahya`, becomes `dib\yahya` when imported. Existing explicit domains are retained.
- Uploads match Windows username first and email case insensitively. An existing email updates its existing Excel and SQLite user, preserving that user's Windows username, ID, attendance, role settings, and helper enrollment. Rows with a username belonging to one user and an email belonging to another are rejected. Multiple uploaded rows for one email are rejected. If the existing workbook already has multiple rows with one email, remove the unwanted rows first.
- **Permanently delete selected** in Administration → Users removes those users from the Excel workbook and SQLite, along with attendance, leave, self absences, helper devices, sessions, enrollment, and linked audit entries. It does not create a Removed record or a bulk deletion audit item. The administrator cannot delete their own account. A confirmation dialog lists the impact. Individual **Delete** continues to leave the historical Removed record.
- SQLite journal files, application log files, and any backups remain outside this cleanup; normal database operation can retain recoverable copies. This action is intended for initial roster alignment. Keep backups according to your organization's data policies.

## Install

1. Stop the CET Momentum NSSM service. Back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder.
2. Extract this ZIP separately. Copy its `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` into their matching folders. Replace the **entire** deployed `dist` with the ready-built `dist` in the ZIP.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`. Do not leave the Excel workbook open while updating it.
4. Restart the service and confirm `/CETGamification/api/info` reports `"version":"1.8.9"`. Refresh the browser with Ctrl+F5 and test an Excel upload with a single known user before a larger file.

No SQLite schema migration, npm install, npm build, or helper update is required.
