import {DatabaseSync} from 'node:sqlite';
import {randomBytes,createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {validateRoster,readRoster,newRoster,mergeWorkbook,expiryAllowsAccess} from './roster-workbook.js';
export const token=()=>randomBytes(32).toString('base64url');
export const hash=x=>createHash('sha256').update(Buffer.isBuffer(x)?x:String(x)).digest('hex');
export const normalize=x=>String(x||'').trim().toLowerCase();
export function dubaiNow(now=new Date()) {const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Dubai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));return {date:`${p.year}-${p.month}-${p.day}`,month:`${p.year}-${p.month}`,time:`${p.hour}:${p.minute}`};}
export function attendanceCredits(date,confirmedAt){if(!confirmedAt)return 0;const time=new Date(confirmedAt);return !isNaN(time)&&dubaiNow(time).date===date?2:1;}
export function validDate(x){return typeof x==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(x)&&!isNaN(Date.parse(x))&&new Date(x+'T12:00:00Z').toISOString().slice(0,10)===x;}
export function monthDates(month){if(!/^\d{4}-\d{2}$/.test(month)||+month.slice(5)<1||+month.slice(5)>12)throw Error('Invalid month');const n=new Date(Date.UTC(+month.slice(0,4),+month.slice(5),0)).getUTCDate();return Array.from({length:n},(_,i)=>`${month}-${String(i+1).padStart(2,'0')}`);}
const defaults={workdays:[1,2,3,4,5],holidays:[],reminderTimes:['16:00','17:00'],snoozeMinutes:15,graceMinutes:120,sound:true,magnitudeUrl:'',previousMonth:true};
export function createCore(options={}){
 const storage=path.resolve(options.storage||process.env.STORAGE_DIR||'storage');fs.mkdirSync(storage,{recursive:true});
 const db=new DatabaseSync(path.join(storage,'cet.sqlite'));db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, employee_id TEXT, email TEXT, company TEXT,title TEXT,manager TEXT,status TEXT,account_expiry TEXT,password_expiry TEXT,telephone TEXT,mobile TEXT,excel_enabled INTEGER DEFAULT 0,roster_active INTEGER DEFAULT 1,admin_blocked INTEGER DEFAULT 0,special INTEGER DEFAULT 0,admin INTEGER DEFAULT 0,joining_date TEXT,leaving_date TEXT,last_synced_at TEXT);
 CREATE TABLE IF NOT EXISTS attendance(user_id INTEGER REFERENCES users(id),date TEXT,confirmed_at TEXT,PRIMARY KEY(user_id,date));
 CREATE TABLE IF NOT EXISTS leave_days(user_id INTEGER REFERENCES users(id),date TEXT,PRIMARY KEY(user_id,date));
 CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),value TEXT);
 CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id),secret_hash TEXT UNIQUE,created_at TEXT,revoked INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS enrollment(code_hash TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id),expires INTEGER,used INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS sessions(secret_hash TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id),device_id TEXT REFERENCES devices(id),expires INTEGER);
 CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY,secret_hash TEXT,expires INTEGER,user_id INTEGER,device_id TEXT);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,at TEXT,actor TEXT,action TEXT,detail TEXT);
 CREATE TABLE IF NOT EXISTS sync_state(id INTEGER PRIMARY KEY CHECK(id=1),value TEXT);`);
 if(!db.prepare('PRAGMA table_info(users)').all().some(c=>c.name==='weekend_enabled'))db.exec('ALTER TABLE users ADD COLUMN weekend_enabled INTEGER NOT NULL DEFAULT 0');
 db.exec('CREATE TABLE IF NOT EXISTS self_absences(user_id INTEGER REFERENCES users(id),date TEXT,created_at TEXT,PRIMARY KEY(user_id,date))');
 db.prepare('INSERT OR IGNORE INTO settings VALUES(1,?)').run(JSON.stringify(defaults));
 const settings=()=>({...defaults,...JSON.parse(db.prepare('SELECT value FROM settings WHERE id=1').get().value)});
 const audit=(actor,action,detail)=>db.prepare('INSERT INTO audit(at,actor,action,detail) VALUES(?,?,?,?)').run(new Date().toISOString(),String(actor),action,JSON.stringify(detail));
 const user=id=>db.prepare('SELECT * FROM users WHERE id=?').get(id);
 const active=u=>!!(u&&u.roster_active&&u.excel_enabled&&!u.admin_blocked&&expiryAllowsAccess(u.account_expiry,dubaiNow().date));
 const accessStatus=u=>!u.roster_active?'Removed':u.status==='Disabled'?'Disabled':u.status==='Expired'||!expiryAllowsAccess(u.account_expiry,dubaiNow().date)?'Expired':u.admin_blocked?'Blocked':!u.excel_enabled?'Disabled':'Active';
 const syncState=()=>JSON.parse(db.prepare('SELECT value FROM sync_state WHERE id=1').get()?.value||'{}');
 function setSync(value){db.prepare('INSERT INTO sync_state VALUES(1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').run(JSON.stringify(value));}
 function scheduled(u,date){const s=settings();return validDate(date)&&(s.workdays.includes(new Date(date+'T12:00:00Z').getUTCDay())||!!u.weekend_enabled)&&!s.holidays.includes(date)&&(!u.joining_date||date>=u.joining_date)&&(!u.leaving_date||date<=u.leaving_date);}
 function eligible(u,date){return scheduled(u,date)&&!db.prepare('SELECT 1 FROM leave_days WHERE user_id=? AND date=?').get(u.id,date)&&!db.prepare('SELECT 1 FROM self_absences WHERE user_id=? AND date=?').get(u.id,date);}
 function calendar(u,month){const records=new Map(db.prepare('SELECT date,confirmed_at FROM attendance WHERE user_id=? AND date LIKE ?').all(u.id,month+'-%').map(r=>[r.date,r.confirmed_at]));const own=new Set(db.prepare('SELECT date FROM self_absences WHERE user_id=? AND date LIKE ?').all(u.id,month+'-%').map(r=>r.date));const leave=new Set(db.prepare('SELECT date FROM leave_days WHERE user_id=? AND date LIKE ?').all(u.id,month+'-%').map(r=>r.date));const today=dubaiNow().date;return monthDates(month).map(date=>({date,eligible:eligible(u,date),scheduled:scheduled(u,date),absence:own.has(date)?'self':leave.has(date)?'admin':null,future:date>today,confirmedAt:records.get(date)||null,credits:attendanceCredits(date,records.get(date))}));}
 function markAbsence(u,dates,remove=false){const now=dubaiNow();const prev=new Date(now.month+'-01T12:00:00Z');prev.setUTCMonth(prev.getUTCMonth()-1);const months=[now.month];if(settings().previousMonth)months.push(prev.toISOString().slice(0,7));if(!active(u))throw Error('Only authorised users may update absence.');if(!Array.isArray(dates)||!dates.length||dates.length>62||dates.some(d=>!validDate(d)||!months.includes(d.slice(0,7))))throw Error('Select dates in the current or permitted previous month.');const unique=[...new Set(dates)];if(!remove&&unique.some(d=>!eligible(u,d)||db.prepare('SELECT 1 FROM attendance WHERE user_id=? AND date=?').get(u.id,d)))throw Error('Select scheduled, unconfirmed dates without existing leave or absence.');db.exec('BEGIN IMMEDIATE');try{for(const date of unique){if(remove)db.prepare('DELETE FROM self_absences WHERE user_id=? AND date=?').run(u.id,date);else db.prepare('INSERT INTO self_absences VALUES(?,?,?)').run(u.id,date,new Date().toISOString());}audit(u.username,remove?'absence.remove':'absence.add',{dates:unique});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}return {ok:true};}
 function confirm(u,date){const now=dubaiNow();const prev=new Date(now.month+'-01T12:00:00Z');prev.setUTCMonth(prev.getUTCMonth()-1);const allowed=[now.month];if(settings().previousMonth)allowed.push(prev.toISOString().slice(0,7));if(!active(u))throw Error('Only authorised CET users may use this portal.');if(!validDate(date)||date>now.date||!allowed.includes(date.slice(0,7))||!eligible(u,date))throw Error('This date is not eligible for confirmation.');const r=db.prepare('INSERT OR IGNORE INTO attendance VALUES(?,?,?)').run(u.id,date,new Date().toISOString());if(r.changes)audit(u.username,'attendance.confirm',{date});return !!r.changes;}
 function race(viewer,month){return db.prepare('SELECT * FROM users WHERE roster_active=1 AND excel_enabled=1 AND admin_blocked=0').all().filter(u=>active(u)&&(viewer.special||!u.special)).map(u=>{const days=calendar(u,month).filter(d=>d.eligible);const due=days.filter(d=>!d.future);const points=due.filter(d=>d.confirmedAt).length;const credits=due.reduce((sum,d)=>sum+d.credits,0),sameDay=due.filter(d=>d.credits===2).length;const rate=due.length?points/due.length:0,score=due.length?credits/(due.length*2):0;let streak=0;for(const d of [...due].reverse()){if(!d.confirmedAt)break;streak++;}return {id:u.id,name:u.name,special:!!u.special,points,credits,sameDay,score,target:days.length,due:due.length,rate,progress:days.length?points/days.length:0,streak};}).sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name)).map((u,i,list)=>({...u,rank:i&&u.score===list[i-1].score?list.findIndex(x=>x.score===u.score)+1:i+1}));}
 function purgeUserData(users){
  const optional=name=>!!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name);
  const linked=(detail,u)=>{try{const value=JSON.parse(detail);const match=(item)=>{if(!item||typeof item!=='object')return false;if(Array.isArray(item))return item.some(match);return Object.entries(item).some(([key,v])=>['username','actor'].includes(key)&&String(v).toLowerCase()===u.username||['userId','user_id','id'].includes(key)&&Number(v)===u.id||key==='userIds'&&Array.isArray(v)&&v.includes(u.id)||typeof v==='object'&&match(v));};return match(value);}catch{return false;}};
  for(const u of users){
   const devices=db.prepare('SELECT id FROM devices WHERE user_id=?').all(u.id).map(d=>d.id);
   db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
   db.prepare('DELETE FROM enrollment WHERE user_id=?').run(u.id);
   db.prepare('DELETE FROM tickets WHERE user_id=?').run(u.id);
   if(optional('device_requests'))db.prepare('DELETE FROM device_requests WHERE user_id=?').run(u.id);
   if(optional('device_labels'))for(const id of devices)db.prepare('DELETE FROM device_labels WHERE device_id=?').run(id);
   for(const id of devices)db.prepare('DELETE FROM tickets WHERE device_id=?').run(id);
   db.prepare('DELETE FROM devices WHERE user_id=?').run(u.id);
   for(const table of ['attendance','leave_days','self_absences'])db.prepare(`DELETE FROM ${table} WHERE user_id=?`).run(u.id);
   for(const entry of db.prepare('SELECT id,actor,detail FROM audit').all())if(entry.actor?.toLowerCase()===u.username||linked(entry.detail,u))db.prepare('DELETE FROM audit WHERE id=?').run(entry.id);
   db.prepare('DELETE FROM users WHERE id=?').run(u.id);
  }
 }
 function applyRoster(rows,fileHash='manual',revokeUserId=null,purgeUsers=[]){
  validateRoster(rows);
  db.exec('BEGIN IMMEDIATE');try{if(purgeUsers.length)purgeUserData(purgeUsers);db.exec('UPDATE users SET roster_active=0');const cols=['username','name','employee_id','email','company','title','manager','status','account_expiry','password_expiry','telephone','mobile','excel_enabled','roster_active','last_synced_at'];const q=db.prepare(`INSERT INTO users(${cols.join(',')}) VALUES(${cols.map(()=>'?').join(',')}) ON CONFLICT(username) DO UPDATE SET ${cols.slice(1).map(c=>c+'=excluded.'+c).join(',')}`);for(const r of rows)q.run(...cols.map(c=>c==='excel_enabled'?+(r.status==='Enabled'):c==='roster_active'?1:c==='last_synced_at'?new Date().toISOString():r[c]||null));if(revokeUserId!==null){db.prepare('UPDATE devices SET revoked=1 WHERE user_id=?').run(revokeUserId);db.prepare('DELETE FROM sessions WHERE user_id=?').run(revokeUserId);db.prepare('DELETE FROM enrollment WHERE user_id=?').run(revokeUserId);}setSync({at:new Date().toISOString(),count:rows.length,hash:fileHash,error:null});if(!purgeUsers.length)audit('sync','roster.sync',{count:rows.length});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
 }
 const rosterFile=()=>path.resolve(options.data||process.env.DATA_DIR||'data',process.env.ROSTER_FILE||'CET_Users.xlsx');
 let syncing=false,writing=false;
 async function sync(force=false){if(syncing||writing)return syncState();syncing=true;try{const bytes=fs.readFileSync(rosterFile());const digest=hash(bytes);if(!force&&syncState().hash===digest&&!syncState().error)return syncState();const {rows}=await readRoster(bytes);applyRoster(rows,digest);}catch(e){setSync({...syncState(),checkedAt:new Date().toISOString(),error:e.message});}finally{syncing=false;}return syncState();}
 async function writeRoster(incoming,actor,{mode='add',target=null,targets=[]}={}){
  if(syncing||writing)throw Error('Roster is being updated. Please retry in a moment.');
  writing=true;let filename,temp,previous=null,replaced=false;
  try{
   if(!['delete','bulkDelete'].includes(mode))validateRoster(incoming);
   filename=rosterFile();fs.mkdirSync(path.dirname(filename),{recursive:true});
   if(fs.existsSync(filename))previous=fs.readFileSync(filename);
   const current=previous?await readRoster(previous):newRoster();
   if(mode==='add'&&current.rows.some(row=>row.username===incoming[0].username))throw Error('Username already exists in the Excel roster. Use Edit to update existing users.');
   if(mode==='add'&&incoming[0].email&&current.rows.some(row=>normalize(row.email)===normalize(incoming[0].email)))throw Error('Email already exists in the Excel roster. Use Edit to update the existing user.');
   if(['edit','delete'].includes(mode)&&(!target||!current.rows.some(row=>row.username===target.username)))throw Error('User is not in the active Excel roster.');
   if(mode==='bulkDelete'&&targets.some(u=>u.roster_active&&!current.rows.some(row=>row.username===u.username)))throw Error('User is not in the active Excel roster.');
   if(mode==='edit'&&incoming[0].username!==target.username)throw Error('Windows username cannot be changed after enrollment.');
   if(mode==='delete'&&target.username===normalize(actor))throw Error('You cannot delete your own portal access.');
   if(mode==='bulkDelete'&&targets.some(u=>u.username===normalize(actor)))throw Error('You cannot delete your own portal access.');
   let created=0,updated=0;
   if(mode==='bulkDelete'){
    const names=new Set(targets.map(u=>u.username));const indexes=[];
    current.sheet.eachRow((row,i)=>{if(i>1&&names.has(row.getCell(current.map.username).text.includes('\\')?normalize(row.getCell(current.map.username).text):'dib\\'+normalize(row.getCell(current.map.username).text)))indexes.push(i);});
    for(const index of indexes.reverse())current.sheet.spliceRows(index,1);
   }else if(mode==='delete'){
    let index=0;current.sheet.eachRow((row,i)=>{if(i>1&&normalize(row.getCell(current.map.username).text)===target.username)index=i;});
    if(!index)throw Error('User is not in the active Excel roster.');
    current.sheet.spliceRows(index,1);
   }else ({created,updated}=mergeWorkbook(current,incoming));
   const bytes=Buffer.from(await current.workbook.xlsx.writeBuffer());
   const {rows}=await readRoster(bytes);
   const self=rows.find(row=>row.username===normalize(actor));
   if(!self||self.status!=='Enabled'||!expiryAllowsAccess(self.account_expiry,dubaiNow().date))throw Error('The upload cannot remove or disable your own portal access.');
   const before=db.prepare('SELECT username FROM users WHERE admin=1 AND admin_blocked=0 AND roster_active=1').all();
   if(before.length&&!before.some(u=>rows.some(row=>row.username===u.username&&row.status==='Enabled'&&expiryAllowsAccess(row.account_expiry,dubaiNow().date))))throw Error('Keep at least one active administrator in the roster.');
   if(previous&&hash(fs.readFileSync(filename))!==hash(previous))throw Error('Excel roster changed during the update. Please retry.');
   temp=filename+'.'+randomBytes(8).toString('hex')+'.tmp';
   fs.writeFileSync(temp,bytes,{flag:'wx'});
   fs.renameSync(temp,filename);temp=null;replaced=true;
   try{applyRoster(rows,hash(bytes),mode==='delete'?target.id:null,mode==='bulkDelete'?targets:[]);}catch(error){
    if(previous){temp=filename+'.'+randomBytes(8).toString('hex')+'.tmp';fs.writeFileSync(temp,previous,{flag:'wx'});fs.renameSync(temp,filename);temp=null;}
    else fs.unlinkSync(filename);
    replaced=false;throw error;
   }
   if(mode!=='bulkDelete')audit(actor,'roster.'+mode,{username:target?.username||incoming[0]?.username,created,updated,count:rows.length});
   return {created,updated,deleted:mode==='delete'?1:mode==='bulkDelete'?targets.length:0,count:rows.length,...syncState()};
  }catch(error){if(replaced)error.message+=' Check the Excel roster and SQLite records before retrying.';throw error;}
  finally{if(temp)try{fs.unlinkSync(temp);}catch{}writing=false;}
 }
 async function addUser(record,actor){return writeRoster([record],actor);}
 async function uploadRoster(bytes,actor){if(!Buffer.isBuffer(bytes)||!bytes.length||bytes.length>5*1024*1024)throw Error('Choose an Excel .xlsx file smaller than 5 MB.');const {rows}=await readRoster(bytes);return writeRoster(rows,actor,{mode:'upload'});}
 async function editUser(id,record,actor){const target=user(id);if(!target)throw Error('User not found.');if(!target.roster_active)throw Error('Removed users must be re-added through Excel import.');if(record.username!==undefined&&normalize(record.username)!==target.username)throw Error('Windows username cannot be changed after enrollment.');return writeRoster([{...record,username:target.username}],actor,{mode:'edit',target});}
 async function deleteUser(id,actor){const target=user(id);if(!target||!target.roster_active)throw Error('User is not in the active roster.');return writeRoster([],actor,{mode:'delete',target});}
 async function bulkDeleteUsers(ids,actor){if(!Array.isArray(ids)||!ids.length||ids.length>1000||ids.some(id=>!Number.isSafeInteger(id)||id<1)||new Set(ids).size!==ids.length)throw Error('Select up to 1,000 distinct valid users.');const targets=ids.map(user);if(targets.some(u=>!u))throw Error('A selected user no longer exists. Refresh the list.');return writeRoster([],actor,{mode:'bulkDelete',targets});}
 function enrollCode(username){const u=db.prepare('SELECT * FROM users WHERE username=?').get(normalize(username));if(!active(u))throw Error('User must exist in the enabled roster before enrollment.');const code=token();db.prepare('INSERT INTO enrollment VALUES(?,?,?,0)').run(hash(code),u.id,Date.now()+86400000);audit('admin-cli','enrollment.issue',{username:u.username});return code;}
 function enroll(code,username){const e=db.prepare('SELECT * FROM enrollment WHERE code_hash=? AND used=0 AND expires>?').get(hash(code),Date.now());if(!e)throw Error('Enrollment code is invalid, expired or already used.');const u=user(e.user_id);if(!active(u)||normalize(username)!==u.username)throw Error('Only authorised CET users may use this portal. The Windows account does not match this enrollment code.');const secret=token(),id=token();db.exec('BEGIN');try{db.prepare('UPDATE enrollment SET used=1 WHERE code_hash=?').run(hash(code));db.prepare('INSERT INTO devices VALUES(?,?,?,?,0)').run(id,u.id,hash(secret),new Date().toISOString());db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}audit(u.username,'device.enroll',{id});return {secret,id,user:{id:u.id,name:u.name,username:u.username}};}
 const publicUser=u=>({id:u.id,name:u.name,username:u.username,special:!!u.special,admin:!!u.admin,weekendEnabled:!!u.weekend_enabled});
 return {db,settings,audit,user,active,accessStatus,eligible,scheduled,markAbsence,calendar,confirm,race,applyRoster,sync,syncState,addUser,editUser,deleteUser,bulkDeleteUsers,uploadRoster,enrollCode,enroll,publicUser};
}
