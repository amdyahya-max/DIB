# CET Momentum 1.8.28 — dotted aim circle

Includes all changes through 1.8.27; Helper 1.2.9 and preserved base 1.8.12 unchanged. No new dependencies or database migration.

The dotted circle marks your pen when you can aim. Its dashes circulate around the ellipse in a four-second loop; the pen itself does not rotate with this indicator. The ring disappears during playback or when it is not your turn.

## Fix

1.8.27 restored JavaScript pen movement/falling under reduced motion, but the aim indicator was still disabled by the global/Pen Fight CSS reduced-motion rules. 1.8.28 gives only the aim circle a specific animation override. Pen physics, shots, scoring, sounds, access policy, attendance, Admin layout and car race retain their existing behavior.

Chrome working and Edge stationary points toward a browser-specific preference, policy or stale asset. This code fixes the identified reduced-motion suppression; it cannot establish the affected Edge policy from a still screenshot. Tests cover normal/reduced motion in Chromium, not the actual managed Edge installation. Both browsers must load the new build to compare.

## Deploy

- Stop NSSM and back up.
- Update application code including server, package/version files and replace the entire dist folder. Prebuilt frontend included; no frontend rebuild needed on the server.
- Preserve production .env, storage, data, Node, root node_modules, current Helper installer and working IIS web.config. Never overwrite production Excel/SQLite with the package template.
- Restart NSSM. In Edge, press Ctrl+F5 and confirm footer/API version 1.8.28.
- Open a solo game. Before flicking, the dots should move around your active pen. Play a flick and knockout to check the 1.8.27 motion/fall fix remains active. No animation/replay button is required.

If Chrome works but Edge does not, compare the same portal URL, game state and version in both browsers. The indicator only appears while you can aim.

## Logs without F12

After leaving the circle visible for at least one second, open storage/logs/portal.log on the server (or logs inside configured STORAGE_DIR). Find event penfight.diagnostics with message status aim_halo.

- animation: pf-halo; duration: 4s; moved: true means the observed CSS dash offset changed.
- animation: none or moved: false with reducedMotion: true points to remaining motion suppression or another browser policy.
- version and css identify the client build and stylesheet; browser identifies Chrome/Edge.
- No entry can mean the ring was removed before the 700ms probe, old assets are loaded, or diagnostic reporting failed. Check version 1.8.28 and keep the ring visible before collecting logs.

Movement/fall entries from 1.8.27 remain: playback_started/playback_completed, domMoved/domRolled/domFallSeen/domFloorSeen, timerFrames and clampedGaps. CSS/DOM observations do not prove physical GPU-screen output.

Changed functional files: src/PenFight.css (specific ring override); src/PenFight.jsx and src/penfight-diagnostics.js (ring probe). Version metadata, prebuilt dist, tests and release documentation updated. Server business logic and Helper are unchanged; server/index.js and server/portal-diagnostics.js change reported version only.

Validation: TEST-RESULTS-1.8.28.md and validation/1.8.28.
