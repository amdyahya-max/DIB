# CET Momentum 1.8.28 validation

12 October 2026. All 76 automated tests passed with no failures/skips/cancellations. Production build passed. Existing startup.js/startup.css runtime build notices remain; files included.

10 focused production-browser checks passed with no uncaught errors: circle dash offset changes under both normal and reduced motion; server records observed aim_halo movement; automatic falling under reduced motion; DOM-observed movement/fall/floor logs; no-RAF timer fallback; delayed server response; bounded long rendering stall; simulated hidden-tab pause and deferred final scores/winner; no replay on refresh.

Tests used Chromium 153 on Linux with GPU disabled, real Node/SQLite APIs and isolated synthetic data. Native Helper identity bridge mocked. The hidden-tab test controlled document.hidden. The actual managed Edge installation, Windows Server 2019/IIS and physical GPU output were not tested. Deploy and compare Edge’s aim_halo log to Chrome if still affected.

Validation files: validation/1.8.28/automated-tests.txt, build.txt and motion-browser-results.json. Previous validation and game/access tests retained. Backend business logic, game physics/scoring, dependencies and all 20 Helper/download files are unchanged from 1.8.27. Reported server version and client diagnostics are updated. Preserved base 1.8.12 unchanged.

Both ZIPs pass CRC checks and extracted-file SHA-256 comparisons. Complete includes the unchanged Helper installer; Updated-Files omits it only. Node/node_modules, .env, live database/storage/logs and internal QA screenshots are excluded. Deploy using UPDATE-1.8.28-AIM-CIRCLE.md.
