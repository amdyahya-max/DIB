## Latest update — 1.8.28

The dotted aim circle now keeps its four-second dash movement under reduced-motion preferences. The existing automatic pen/fall fix is retained. CSS movement is recorded as aim_halo in portal.log. See deployment/UPDATE-1.8.28-AIM-CIRCLE.md. All previous features and unchanged Helper 1.2.9 remain included.

## Latest update — 1.8.27

Automatic Pen Fight movement/falling now overrides reduced-motion suppression, uses a timer fallback, pauses while hidden and waits for playback before showing final results. Client diagnostics are written to storage/logs/portal.log. Read deployment/UPDATE-1.8.27-PEN-ANIMATION.md. All 1.8.26 compact-Administration changes are retained; Helper 1.2.9 is unchanged.

> **Latest release: portal 1.8.26 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.26-COMPACT-ADMIN.md`. Every Administration section uses a compact layout: combined roster actions, icon controls, denser rows, on-demand forms/help and tables sized to the available window. In the 205-user comparison at 1440×900, Users shows 12 full rows instead of 5.

> **Historical release: portal 1.8.25 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.25-PLAYER-ACCESS.md`. Administration → Pen Fight → Player access provides search, individual and bulk Enable/Disable, and a Selected players only policy. The existing global switch and attendance rules remain.

> **Historical release: portal 1.8.24 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.24-FLOOR-SOUND.md`. Falling pens have a brief air sound, a crisp plastic-on-tile landing and two softer bounce taps. Audio and visible floor contact share one timeline. The existing local speaker icon defaults off.

> **Historical release: portal 1.8.23 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.23-SOUND-BALANCE.md`. The taller desk aligns with the scorecard. Player cards show initials and full names. A local sound icon defaults off: power-sensitive hit sounds and slowing rolling clicks. More visible barrel rolling; pens tip when their mass centre moves beyond the edge, while points still require a complete fall.

> **Historical release: portal 1.8.22 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.22-ROUND-NOTES.md`. Completed rounds show an original pen tin beside a torn paper score note, with round points and running totals. Next round or a five-second timeout closes it. Final totals use the same style; gameplay, rolling and full-fall rules remain.

> **Historical release: portal 1.8.21 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.21-DESK-PHYSICS.md`. A perspective wooden desk replaces the scoring line. Partial overhang stays in play; only a complete fall scores. Off-centre hits spin the pen; sideways travel drives rolling. Solo and colleague games share the same physics. All existing round scoring and open-game controls remain.

> **Historical release: portal 1.8.20 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.20-OPEN-GAMES.md`. New challenges no longer depend on closing an existing game. My open games lists unfinished games with Continue and End controls; either player can end a joined duel. The Admin daily limit remains.

> **Historical release: portal 1.8.19 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.19-ARENA.md`. The compact arena has a raised table with a wooden scorecard beside it; losing pens fall for 3.2 seconds before visible scores and the next contest appear. Default: 5 rounds, 4 scoring contests per round; an even contest count is configurable. All round points decide the final winner. Player tags use unique first/last initials (MY, MY2). The final popup has only total scores and closes after five seconds. Start a new game to use the new rules.

> **Historical release: portal 1.8.18 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.18-ALL-ROUND-SCORING.md`. New solo and colleague matches have random round layouts and play every configured round. The highest final total wins; equal totals draw. Round and final score tables are included. Start a new match after updating. Earlier notes below are historical.

> **Historical release: portal 1.8.17 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.17-PEN-PAIRS.md`. Admin can select a capped pen pair with live previews or retain the original personalised pens. Existing games retain their designs. Earlier release notes below are historical.

> **Historical release: portal 1.8.16 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.16-PENFIGHT.md` for scoring boundaries, user pens, round settings and colleague challenge instructions. Earlier release notes below are historical.

> **Historical release: portal 1.8.15 / Helper 1.2.9.** Read `deployment/UPDATE-1.8.15-PENFIGHT.md`. Pen Fight has a dedicated Admin tab, redesigned Momentum Desk and solo computer play. The original 1.8.12 base is preserved. Older edition notes below are historical.

> Pen Fight edition: portal 1.8.14 / Helper 1.2.9. Deployment instructions and validation: deployment/UPDATE-1.8.14-PENFIGHT.md and deployment/TEST-RESULTS-1.8.14.md.

# CET Momentum 1.8.12 portal update

My Calendar now shows the signed-in user's **Account expires on** and **Password expiry** in the compact top position bar. Dates from Excel timestamps appear as calendar dates; `Never` and missing values remain distinct. Individual **Delete** still handles duplicate usernames and retains the selected user's history. **Delete selected non-admins** and **Delete all non-admin users** continue to protect administrator accounts. Follow [deployment/UPDATE-1.8.12.md](deployment/UPDATE-1.8.12.md) to deploy it.

Excel upload updates existing users by email (case insensitive) when a supplied username differs, preserving the existing Windows username and enrolled helper identity. Usernames without a domain receive `dib\` automatically.

Account Expiry accepts dates, ISO timestamps such as `2027-01-01T00:00:00`, `Never`, and blank cells.

The CET Helper remains at 1.2.9. Keep the existing production `.env`, `data`, `storage`, `downloads`, `helper`, `Node`, and `node_modules` folders. Attendance and enrollment data are not included in this ZIP.

The animation runs in the browser. On the Windows Server session, the captured diagnostic reported `reducedMotion: true`, `animation: "none"`, and confirmed that the CSS keyframes were present. CET Race now shows **Animate cars** when the browser asks for reduced motion. Clicking it enables race-car motion for this portal in that browser; **Reduce motion** restores the system preference. Replay restarts the animation.

The portal logs one diagnostic per race view or replay in `STORAGE_DIR/logs/portal.log`, under the `race.diagnostics` event. It reports the browser motion preference, car animation style, keyframe availability, browser visibility, and observed animation activity. Open CET Race with its tab visible and leave it open for about five seconds before checking the log.
