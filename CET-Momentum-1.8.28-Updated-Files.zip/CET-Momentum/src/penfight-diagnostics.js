// Recorded in storage/logs/portal.log; no F12 or browser console is needed.
export function penFightDiagnostic(status,details={}){
 const payload={status,version:'1.8.28',...details,visibility:document.visibilityState,
  reducedMotion:window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  automaticMotion:true,css:[...document.querySelectorAll('link[rel="stylesheet"]')].map(l=>new URL(l.href).pathname.split('/').pop()).slice(0,2),browser:navigator.userAgent.slice(0,100)};
 const path=location.pathname.replace(/\/$/,'')+'/api/client-errors';
 fetch(path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({event:'penfight.diagnostics',page:location.pathname,message:JSON.stringify(payload)})}).catch(()=>{});
}

export function observeAimHalo(svg){
 const halo=svg.current?.querySelector('.pf-aim-halo');if(!halo)return undefined;
 const first=getComputedStyle(halo),initial=parseFloat(first.strokeDashoffset)||0;
 const timer=setTimeout(()=>{
  if(!halo.isConnected)return;const current=getComputedStyle(halo),offset=parseFloat(current.strokeDashoffset)||0;
  penFightDiagnostic('aim_halo',{animation:current.animationName,duration:current.animationDuration,
   playState:current.animationPlayState,moved:Math.abs(offset-initial)>.1,initialOffset:Math.round(initial*10)/10,finalOffset:Math.round(offset*10)/10});
 },700);
 return ()=>clearTimeout(timer);
}
