import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';
import {createCore,hash,dubaiNow} from '../server/core.js';import {initialState,shot} from '../server/penfight-engine.js';import {newRoster,mergeWorkbook} from '../server/roster-workbook.js';
const require=createRequire(import.meta.url),{chromium}=require(process.env.CET_PLAYWRIGHT_MODULE||'playwright');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cet-arena-ui-')),root=fileURLToPath(new URL('../',import.meta.url)),core=createCore({storage:dir,data:dir});
let child,browser;const checks=[],shots=[];const push=checks.push.bind(checks);checks.push=(...items)=>{console.log(...items);return push(...items);};try{
const rows=[{username:'dib\\yahya',name:'Muhammad Yahya',email:'yahya@example.test',status:'Enabled'},{username:'dib\\colleague',name:'Mariam Yousuf',email:'colleague@example.test',status:'Enabled'}];core.applyRoster(rows);core.db.exec('UPDATE users SET admin=1 WHERE id=1');
const b=newRoster();mergeWorkbook(b,rows);fs.writeFileSync(path.join(dir,'CET_Users.xlsx'),Buffer.from(await b.workbook.xlsx.writeBuffer()));
const day=dubaiNow().date,d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-1);const previous=d.toISOString().slice(0,10),settings=core.settings();settings.workdays=[0,1,2,3,4,5,6];core.db.prepare('UPDATE settings SET value=?').run(JSON.stringify(settings));for(const id of [1,2])core.db.prepare('INSERT INTO attendance VALUES(?,?,?)').run(id,previous,previous+'T10:00:00Z');
const token='browser-test-session',device='browser-device';core.db.prepare('INSERT INTO devices VALUES(?,?,?,?,0)').run(device,1,hash('test-helper'),new Date().toISOString());core.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(hash(token),1,device,Date.now()+3600000);
const port=Number(process.env.CET_UI_TEST_PORT)||7800+Math.floor(Math.random()*500),origin=`http://localhost:${port}`,url=origin+'/CETGamification';child=spawn(process.execPath,['server/index.js'],{cwd:root,env:{...process.env,HOST:'127.0.0.1',PORT:String(port),BASE_PATH:'/CETGamification',PUBLIC_URL:url,DATA_DIR:dir,STORAGE_DIR:dir},stdio:'pipe'});let log='';child.stderr.on('data',x=>log+=x);child.stdout.on('data',x=>log+=x);
let ready=false;for(let i=0;i<100;i++){try{if((await fetch(url+'/api/info')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}assert.ok(ready,log);
async function api(p,method='GET',data){const r=await fetch(url+'/api'+p,{method,headers:{Cookie:'cet_session='+token,Origin:origin,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});assert.ok(r.ok,await r.clone().text());return r.json();}
await api('/penfight/admin','PUT',{enabled:true,startDate:previous,dailyLimit:30});
browser=await chromium.launch({...(process.env.CET_CHROMIUM_PATH?{executablePath:process.env.CET_CHROMIUM_PATH}:{}),headless:true,args:['--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-zygote','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const context=await browser.newContext({viewport:{width:1440,height:1100},reducedMotion:"reduce"});await context.addInitScript(()=>{window.__audioStarts=0;window.__audioContexts=0;window.__audioNoise=[];const C=window.AudioContext;window.AudioContext=class extends C{constructor(...args){super(...args);window.__audioContexts++;}createBufferSource(){const n=super.createBufferSource(),start=n.start.bind(n);n.start=(...args)=>{const f=document.querySelector('.pf-falling-pen');window.__audioNoise.push({time:performance.now(),duration:n.buffer?.duration,progress:Number(f?.dataset.fallProgress||0),height:Number(f?.dataset.fallHeight||0)});return start(...args);};return n;}createOscillator(){const o=super.createOscillator(),start=o.start.bind(o);o.start=(...args)=>{window.__audioStarts++;return start(...args);};return o;}};});await context.addCookies([{name:'cet_session',value:token,url:origin}]);const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
// Only the Windows tray bridge is simulated; portal APIs use the actual Node/SQLite server.
await page.route('http://127.0.0.1:47831/**',r=>r.fulfill({json:{version:'1.2.9',enrolled:true}}));
const out=process.env.CET_UI_OUTPUT_DIR||fs.mkdtempSync(path.join(os.tmpdir(),'cet-arena-ui-output-'));fs.mkdirSync(out,{recursive:true});
await page.route(url+'/penfight-fall.js',r=>r.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'src/penfight-fall.js'),'utf8')}));
await page.route(url+'/sound-test.js',r=>r.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'src/penfight-sound.js'),'utf8')}));
await page.goto(url+'/');

await page.getByRole('button',{name:'Pen Fight Arena',exact:true}).click();
await page.getByRole('button',{name:'Start solo game',exact:true}).click();
await page.locator('.pf-board').waitFor();
let game=(await api('/penfight/my-matches'))[0];
let state={...initialState({maxRounds:5,scoringMode:'round-contests',contestsPerRound:4},123),mode:'solo',penPair:'classic-blue-white',difficulty:'balanced'};
state.turn=0;state.pens[0].x=600;state.pens[1].x=742;state.pens[1].angle=0;
core.db.prepare('UPDATE penfight_matches SET state=? WHERE id=?').run(JSON.stringify(state),game.id);
await page.getByRole('button',{name:'Back to lounge'}).click();await page.getByRole('button',{name:'Refresh arena',exact:true}).click();
await page.locator('.pf-open-game[data-game-id="'+game.id+'"]').getByRole('button',{name:'Continue',exact:true}).click();
await page.locator('.pf-table-wrap.can-aim').waitFor();

for(const preference of ['no-preference','reduce']){
 await page.emulateMedia({reducedMotion:preference});
 const first=await page.locator('.pf-aim-halo').evaluate(e=>{const s=getComputedStyle(e);return {name:s.animationName,duration:s.animationDuration,offset:parseFloat(s.strokeDashoffset)||0};});
 assert.equal(first.name,'pf-halo');assert.equal(first.duration,'4s');await page.waitForTimeout(300);
 const next=await page.locator('.pf-aim-halo').evaluate(e=>parseFloat(getComputedStyle(e).strokeDashoffset)||0);assert.ok(Math.abs(next-first.offset)>1);
 checks.push('Dotted aim circle dashes move with '+preference+' motion preference in the production CSS');
}
await page.waitForTimeout(250);
const haloLog=fs.readFileSync(path.join(dir,'logs','portal.log'),'utf8').trim().split(/\r?\n/).map(x=>JSON.parse(x)).filter(x=>x.event==='penfight.diagnostics').map(x=>JSON.parse(x.message)).find(x=>x.status==='aim_halo');
assert.ok(haloLog?.moved&&haloLog.animation==='pf-halo');checks.push('Server log records observed dotted-circle CSS movement without browser developer tools');
await page.locator('.pf-accessible-controls summary').click();await page.getByRole('slider',{name:'Flick direction',exact:true}).fill('0');await page.getByRole('slider',{name:'Flick power',exact:true}).fill('85');
await page.getByRole('button',{name:'Flick pen',exact:true}).click();
await page.locator('.pf-falling-pen').waitFor({timeout:6500});
checks.push('Automatic pen fall plays even when the browser reports reduced motion');

await page.waitForFunction(()=>document.querySelector('.pf-contest-progress>span')?.textContent.includes('1 / 4'));
let diagnostics=fs.readFileSync(path.join(dir,'logs','portal.log'),'utf8').trim().split(/\r?\n/).map(x=>JSON.parse(x)).filter(x=>x.event==='penfight.diagnostics');
let detail=diagnostics.map(x=>JSON.parse(x.message)).find(x=>x.status==='playback_completed');
assert.ok(detail.reducedMotion&&detail.automaticMotion&&detail.fallSeen&&detail.floorSeen&&detail.moved&&detail.domMoved&&detail.domFallSeen&&detail.domFloorSeen);
checks.push('Portal log records completed movement, fall and floor contact with reduced-motion override');
async function prepare(next){
 await page.getByRole('button',{name:'Back to lounge'}).click();
 core.db.prepare('UPDATE penfight_matches SET player1=2,state=?,awarded=0 WHERE id=?').run(JSON.stringify({...next,mode:'duel'}),game.id);
 await page.getByRole('button',{name:'Refresh arena',exact:true}).click();
 await page.locator('.pf-open-game[data-game-id="'+game.id+'"]').getByRole('button',{name:'Continue',exact:true}).click();await page.locator('.pf-table-wrap.can-aim').waitFor();
 await page.evaluate(()=>{window.__transforms=new Set();window.__motionObserver?.disconnect();window.__motionObserver=new MutationObserver(()=>{const p=document.querySelector('.pf-table-pen');if(p)window.__transforms.add(p.getAttribute('transform'));});window.__motionObserver.observe(document.querySelector('.pf-board'),{subtree:true,attributes:true,childList:true});});
}
async function hit(){await page.locator('.pf-accessible-controls summary').click();await page.getByRole('slider',{name:'Flick direction',exact:true}).fill('0');await page.getByRole('slider',{name:'Flick power',exact:true}).fill('85');await page.getByRole('button',{name:'Flick pen',exact:true}).click();}
await prepare(state);
await page.evaluate(()=>{window.__savedRAF=window.requestAnimationFrame;window.requestAnimationFrame=()=>987654;});
await hit();await page.locator('.pf-falling-pen').waitFor();assert.equal(await page.locator('.pf-score-centre strong').textContent(),'0:0');
await page.waitForFunction(()=>document.querySelector('.pf-contest-progress>span')?.textContent.includes('1 / 4'));
assert.ok(await page.evaluate(()=>window.__transforms.size>5));
await page.evaluate(()=>window.requestAnimationFrame=window.__savedRAF);
diagnostics=fs.readFileSync(path.join(dir,'logs','portal.log'),'utf8').trim().split(/\r?\n/).map(x=>JSON.parse(x)).filter(x=>x.event==='penfight.diagnostics');
detail=diagnostics.map(x=>JSON.parse(x.message)).filter(x=>x.status==='playback_completed').at(-1);assert.ok(detail.timerFrames>0&&detail.fallSeen&&detail.floorSeen);
checks.push('Timer fallback animates real SVG movement and landing when RAF never calls back; score stays held');
await prepare(state);
await page.route('**/api/penfight/matches/*/shot',async route=>{const response=await route.fetch();await new Promise(r=>setTimeout(r,1200));await route.fulfill({response});});
await hit();await page.locator('.pf-falling-pen').waitFor();assert.ok(await page.evaluate(()=>window.__transforms.size>10));
await page.waitForFunction(()=>document.querySelector('.pf-contest-progress>span')?.textContent.includes('1 / 4'));
await page.unroute('**/api/penfight/matches/*/shot');
checks.push('A delayed server shot response still plays the full interpolated trajectory and fall');
let finalState={...initialState({maxRounds:1,scoringMode:'round-contests',contestsPerRound:2},123),mode:'duel',penPair:'classic-blue-white'};
finalState.pens[1].y=15;finalState=shot(finalState,finalState.turn,0,.1);
finalState.turn=0;finalState.pens=initialState().pens;finalState.pens[0].x=600;finalState.pens[1].x=742;finalState.pens[1].angle=0;
await prepare(finalState);await hit();await page.locator('.pf-falling-pen').waitFor();
const before=await page.locator('.pf-falling-pen').getAttribute('data-fall-progress');
await page.evaluate(()=>{const start=performance.now();while(performance.now()-start<1400){}});
await page.waitForTimeout(35);
const after=Number(await page.locator('.pf-falling-pen').getAttribute('data-fall-progress'));assert.ok(after-Number(before)<.25,{before,after});
assert.equal(await page.getByRole('dialog',{name:'You won the match!'}).count(),0);
checks.push('A 1.4-second rendering stall does not jump directly to the next positions or winning popup');
await page.evaluate(()=>{window.__testHidden=true;Object.defineProperty(document,'hidden',{configurable:true,get:()=>window.__testHidden});document.dispatchEvent(new Event('visibilitychange'));});
await page.waitForTimeout(3600);
assert.equal(await page.getByRole('dialog',{name:'You won the match!'}).count(),0);assert.equal(await page.locator('.pf-score-centre strong').textContent(),'1:0');
await page.evaluate(()=>{window.__testHidden=false;document.dispatchEvent(new Event('visibilitychange'));});
await page.getByRole('dialog',{name:'You won the match!'}).waitFor();assert.equal(await page.locator('.pf-score-centre strong').textContent(),'2:0');
diagnostics=fs.readFileSync(path.join(dir,'logs','portal.log'),'utf8').trim().split(/\r?\n/).map(x=>JSON.parse(x)).filter(x=>x.event==='penfight.diagnostics');
detail=diagnostics.map(x=>JSON.parse(x.message)).filter(x=>x.status==='playback_completed').at(-1);assert.ok(detail.hiddenTicks>0&&detail.clampedGaps>0);
checks.push('Simulated hidden-tab interval pauses the final fall; winner and scores appear only after resumed landing');
await page.getByRole('dialog',{name:'You won the match!'}).waitFor({state:'detached'});
await page.getByRole('button',{name:'Refresh arena',exact:true}).click();await page.waitForTimeout(300);
assert.equal(await page.getByRole('dialog').count(),0);
checks.push('Completed fall and final result are not replayed on refresh');
assert.deepEqual(errors,[]);
fs.writeFileSync(out+'/motion-browser-results.json',JSON.stringify({passed:checks,errors},null,2));
console.log(JSON.stringify({passed:checks,errors},null,2));
}finally{await browser?.close();if(child){child.kill();await new Promise(r=>child.exitCode!==null?r():child.once('exit',r));}core.db.close();fs.rmSync(dir,{recursive:true,force:true});}
