@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Use the Node installation from your existing BMC integration.
  pause
  exit /b 1
)
node server.js --open
pause
