'use strict';
const $ = id => document.getElementById(id);
let result = null, page = 0, running = false;
const pageSize = 50;
function filtered() { return (result?.names || []).filter(name => name.toLowerCase().includes($('search').value.toLowerCase())); }
function render() {
  const names = filtered();
  const pages = Math.ceil(names.length / pageSize);
  page = Math.max(0, Math.min(page, pages - 1));
  $('rows').replaceChildren();
  names.slice(page * pageSize, (page + 1) * pageSize).forEach((name, i) => {
    const row = document.createElement('tr');
    [String(page * pageSize + i + 1), name].forEach(value => { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); });
    $('rows').append(row);
  });
  $('empty').hidden = names.length > 0;
  $('empty').textContent = result ? 'No matching form names. Review the test result or raw JSON.' : 'Your Dev form list will appear here.';
  $('counts').textContent = result ? `${names.length} matching / ${result.names.length} unique forms · ${result.rowCount} metadata rows` : 'No results loaded';
  $('page').textContent = pages ? `Page ${page + 1} of ${pages}` : '—';
  $('previous').disabled = running || page === 0;
  $('next').disabled = running || page + 1 >= pages;
  $('csv').disabled = running || !names.length;
  $('json').disabled = running || !result;
  $('search').disabled = running || !result;
}
function status(message, kind = '') { $('status').textContent = message; $('status').className = kind; }
async function test(action) {
  if (running || !$('connection').reportValidity()) return;
  running = true; result = null; page = 0; render();
  ['login','load','clear','username','password'].forEach(id => $(id).disabled = true);
  $('stages').replaceChildren();
  status(action === 'forms' ? 'Logging in and reading form metadata… This may take a few minutes.' : 'Testing Dev login…');
  try {
    const response = await fetch(action === 'forms' ? '/api/forms' : '/api/login-test', { method:'POST',
      headers: { 'Content-Type':'application/json', 'X-CSRF-Token':document.querySelector('meta[name="csrf-token"]').content },
      body:JSON.stringify({username:$('username').value,password:$('password').value}) });
    const data = await response.json();
    (data.stages || []).forEach(message => { const li = document.createElement('li'); li.textContent = message; $('stages').append(li); });
    if (!response.ok) throw new Error(data.error || 'Request failed.');
    if (action === 'forms') result = data;
    status(data.message, 'success');
  } catch (error) { status(error.message, 'error'); }
  finally {
    running = false;
    ['login','load','clear','username','password'].forEach(id => $(id).disabled = false);
    if (action === 'forms') $('password').value = '';
    render();
  }
}
function download(name, data, type) {
  const url = URL.createObjectURL(new Blob([data], {type}));
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('connection').onsubmit = event => { event.preventDefault(); test('forms'); };
$('login').onclick = () => test('login');
$('search').oninput = () => { page = 0; render(); };
$('previous').onclick = () => { page--; render(); };
$('next').onclick = () => { page++; render(); };
$('csv').onclick = () => download('BMC-Dev-Forms.csv', '\uFEFFForm Name\r\n' + filtered().map(name => '"' + (/^[=+@-]/.test(name) ? "'" : '') + name.replace(/"/g,'""') + '"').join('\r\n'), 'text/csv');
$('json').onclick = () => download('BMC-Dev-Forms-Raw.json', JSON.stringify(result.raw,null,2), 'application/json');
$('clear').onclick = () => { result = null; $('connection').reset(); $('search').value = ''; $('stages').replaceChildren(); status('Session data cleared. Ready to connect.'); render(); };
fetch('/api/config').then(r => { if (!r.ok) throw new Error(); return r.json(); }).then(c => {
  $('host').textContent = c.baseUrl;
  $('network').textContent = c.mode === 'PROXY' ? `Proxy · ${c.proxy}` : 'Direct connection';
}).catch(() => status('Unable to load configuration. Restart the app and refresh this page.', 'error'));
render();
