BMC DEV FORM EXPLORER - LOCAL WEB APPLICATION

1. Extract the ZIP to a separate folder on your Windows work PC.
2. Double-click Start-Web-App.bat. The browser opens after startup.
3. Enter your Dev BMC username/password in the web page.
4. Click Test login, then Load forms (or Load forms directly).
5. Search forms and download CSV or Raw JSON.

Requires Node.js, as used by the earlier integration. No npm install required.
Keep the server window open. Browser address: http://localhost:3000
If port 3000 is occupied, stop the previous BMC test service first.

config.json contains your Dev host and fp-proxy.dib.ae:8080 proxy.
Set connectionMode to DIRECT only where appropriate.
Login uses POST /api/jwt/login with URL-encoded username/password.
Form loading reads all pages from the AR System Metadata: arschema form via
/api/arsys/v1/entry/ using AR-JWT authorization. It depends on metadata access
and form availability in Dev. Login success does not imply metadata permission.
AR Definition Administrator is documented as granting metadata read access.
Empty results do not prove that no forms exist. Overlay names are deduplicated.
CSV follows the search filter; Raw JSON contains all returned metadata rows.
Repeated pages or more than 100,000 rows produce an error, not a partial export.

Credentials/tokens are not saved to files or browser storage. Test login keeps
the password in the input for your next action; Load forms clears it afterward.
Clear session data clears inputs and results. Each action attempts BMC logout.
Tokens stay on the local server for the request and are never sent to the page.
Closing the browser does not cancel an active request; it will finish and logout.
The server binds to 127.0.0.1 only and validates Host, Origin and a request token.
Do not expose this test server on a public/shared network interface.

Proxy 407: this transport supports unauthenticated HTTP CONNECT. Your approved
proxy authentication method would need to be added if the proxy requires it.
TLS error: configure NODE_EXTRA_CA_CERTS with the approved enterprise PEM CA.
TLS validation stays enabled.
Login 401: check credentials/authentication. Metadata 403 or BMC permission
errors: check metadata role/access. BMC 303: form missing or not visible.
The page shows stages, HTTP status and BMC error codes without tokens/passwords.

This is a standalone web version of the preceding test package, not a patch to
your original incident application. Source uses only Node.js built-ins.
Local mocked checks cover the flow; the private Dev connection needs your test.

BMC references:
https://docs.bmc.com/docs/display/ars221/Overview%2Bof%2Bthe%2BREST%2BAPI
https://docs.bmc.com/docs/innovationsuite/251/using-aggregate-functions-groupby-clauses-and-having-clauses-1438723949.html
