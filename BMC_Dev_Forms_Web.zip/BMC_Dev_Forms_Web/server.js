'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { request, check, collectForms, namesFrom } = require('./app');
const config = require('./config.json');
const csrf = crypto.randomBytes(32).toString('hex');
const port = 3000;
let busy = false;
function respond(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}
async function run(action, credentials) {
  let token;
  const stages = [];
  try {
    const login = await request('POST', '/api/jwt/login', new URLSearchParams(credentials).toString(),
      { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'text/plain' });
    check(login, 'Login');
    token = login.text.trim();
    if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token)) {
      token = undefined; throw new Error('Login did not return a recognizable JWT. Check the Dev URL or proxy.');
    }
    stages.push('Username/password login successful.');
    if (action === 'login') return { stages, message: 'Dev login successful. You can now test form discovery.' };
    const entries = await collectForms(async offset => {
      const query = new URLSearchParams({ limit: String(config.pageSize), offset: String(offset), sort: '1.asc' });
      const response = await request('GET', `/api/arsys/v1/entry/${encodeURIComponent(config.metadataForm)}?${query}`, '',
        { Authorization: `AR-JWT ${token}` });
      check(response, 'Read metadata');
      let data;
      try { data = JSON.parse(response.text); } catch { throw new Error('Metadata response was not JSON.'); }
      if (offset + (data.entries?.length || 0) > 100000) throw new Error('More than 100,000 rows; stopped without claiming a complete export.');
      return data;
    });
    const names = namesFrom(entries);
    stages.push(`Metadata read completed: ${entries.length} rows.`);
    return { stages, names, rowCount: entries.length,
      message: names.length ? `${names.length} unique form names returned.` : 'No form names returned. This does not confirm that no forms exist; check metadata visibility and raw JSON.',
      raw: { server: config.baseUrl, metadataForm: config.metadataForm, fetchedAt: new Date().toISOString(), entries } };
  } catch (error) {
    error.stages = stages;
    throw error;
  } finally {
    if (token) {
      try {
        const logout = await request('POST', '/api/jwt/logout', '', { Authorization: `AR-JWT ${token}` });
        stages.push(logout.status >= 200 && logout.status < 300 ? 'BMC session logged out.' : 'Logout not confirmed; session will expire under BMC policy.');
      } catch { stages.push('Logout could not be confirmed.'); }
    }
  }
}
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  if (!['localhost:3000', '127.0.0.1:3000'].includes(req.headers.host)) return respond(res, 403, { error: 'Invalid host.' });
  const assets = { '/': ['index.html', 'text/html'], '/ui.js': ['ui.js', 'text/javascript'], '/style.css': ['style.css', 'text/css'] };
  if (req.method === 'GET' && assets[req.url]) {
    const [name, type] = assets[req.url];
    let content = fs.readFileSync(path.join(__dirname, name), 'utf8');
    if (name === 'index.html') content = content.replace('__CSRF__', csrf);
    res.writeHead(200, { 'Content-Type': type + '; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(content);
  }
  if (req.method === 'GET' && req.url === '/api/config') return respond(res, 200, {
    baseUrl: config.baseUrl, mode: config.connectionMode,
    proxy: `${config.proxyHost}:${config.proxyPort}`, metadataForm: config.metadataForm
  });
  if (req.method !== 'POST' || !['/api/login-test', '/api/forms'].includes(req.url)) return respond(res, 404, { error: 'Not found.' });
  if (req.headers['x-csrf-token'] !== csrf || (req.headers.origin && !['http://localhost:3000', 'http://127.0.0.1:3000'].includes(req.headers.origin))) return respond(res, 403, { error: 'Refresh this page and retry.' });
  if (!req.headers['content-type']?.startsWith('application/json')) return respond(res, 415, { error: 'JSON required.' });
  if (busy) return respond(res, 409, { error: 'Another test is running. Please wait.' });
  busy = true;
  try {
    let body = '';
    for await (const chunk of req) {
      body += chunk;
      if (Buffer.byteLength(body) > 16384) throw new Error('Request too large.');
    }
    let data;
    try { data = JSON.parse(body); } catch { throw new Error('Invalid request.'); }
    if (typeof data.username !== 'string' || typeof data.password !== 'string' || !data.username.trim() || !data.password) throw new Error('Enter your Dev username and password.');
    const result = await run(req.url === '/api/forms' ? 'forms' : 'login', { username: data.username.trim(), password: data.password });
    data.password = ''; body = '';
    respond(res, 200, result);
  } catch (error) { respond(res, 400, { error: error.message, stages: error.stages || [] }); }
  finally { busy = false; }
});
server.requestTimeout = 30000;
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? 'Port 3000 is in use. Stop the existing BMC service before starting this test app.' : error.message);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log('BMC Dev Forms: http://localhost:3000');
  console.log('Keep this window open while using the web app.');
  if (process.platform === 'win32' && process.argv.includes('--open')) require('child_process').spawn('explorer.exe', ['http://localhost:3000'], { stdio: 'ignore' }).on('error', () => console.log('Open http://localhost:3000 in your browser.'));
});
