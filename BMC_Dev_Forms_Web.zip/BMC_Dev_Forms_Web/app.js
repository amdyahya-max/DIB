'use strict';
// Standalone Dev diagnostic. Node built-ins only; no npm install required.
const http = require('http');
const https = require('https');
const tls = require('tls');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');
const base = new URL(config.baseUrl);
if (base.protocol !== 'https:' || base.username || base.password) throw new Error('Use an HTTPS baseUrl without credentials.');
if (!['DIRECT', 'PROXY'].includes(config.connectionMode)) throw new Error('connectionMode must be DIRECT or PROXY.');
if (!Number.isInteger(config.pageSize) || config.pageSize < 1) throw new Error('Invalid pageSize.');

function request(method, endpoint, body = '', headers = {}) {
  return new Promise((resolve, reject) => {
    let req, connectReq, socket, agent;
    let done = false;
    const timer = setTimeout(() => finish(new Error('Request timed out. Check proxy/VPN and BMC connectivity.')), config.timeoutMs);
    function finish(error, result) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (error) { req?.destroy(); connectReq?.destroy(); socket?.destroy(); }
      agent?.destroy();
      error ? reject(error) : resolve(result);
    }
    function send() {
      req = https.request({
        hostname: base.hostname, port: base.port || 443,
        path: endpoint, method, agent: agent || false,
        headers: { Accept: 'application/json', ...headers,
          ...(body ? { 'Content-Length': Buffer.byteLength(body) } : {}) }
      }, res => {
        const chunks = []; let size = 0;
        res.on('data', chunk => {
          size += chunk.length;
          if (size > 20 * 1024 * 1024) finish(new Error('Response exceeds 20 MB. Reduce pageSize.'));
          else chunks.push(chunk);
        });
        res.on('error', finish);
        res.on('aborted', () => finish(new Error('Response interrupted.')));
        res.on('end', () => finish(null, { status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', finish);
      req.end(body);
    }
    if (config.connectionMode === 'DIRECT') return send();
    const target = `${base.hostname}:${base.port || 443}`;
    connectReq = http.request({ hostname: config.proxyHost, port: config.proxyPort,
      method: 'CONNECT', path: target, headers: { Host: target } });
    connectReq.on('error', finish);
    connectReq.on('connect', (res, tunnel, head) => {
      socket = tunnel;
      if (res.statusCode !== 200) return finish(new Error(`Proxy CONNECT HTTP ${res.statusCode}. 407 means proxy authentication is required.`));
      if (head.length) tunnel.unshift(head);
      socket = tls.connect({ socket: tunnel, servername: base.hostname, rejectUnauthorized: true });
      socket.on('error', finish);
      socket.once('secureConnect', () => {
        agent = new https.Agent({ keepAlive: false });
        agent.createConnection = () => socket;
        send();
      });
    });
    connectReq.end();
  });
}

function check(response, stage) {
  if (response.status >= 200 && response.status < 300) return;
  // Only structured BMC error codes are logged; no token/password or response body.
  let codes = '';
  try {
    const errors = JSON.parse(response.text);
    if (Array.isArray(errors)) codes = errors.map(e => e.messageNumber).filter(Number.isFinite).join(', ');
  } catch {}
  throw new Error(`${stage}: HTTP ${response.status}${codes ? `; BMC error code(s): ${codes}` : ''}. ` +
    (stage === 'Login' ? 'Check Dev credentials and authentication configuration.' :
      'Check access to AR System Metadata: arschema. Authentication success does not grant metadata permissions.'));
}

async function collectForms(getPage) {
  const entries = []; const signatures = new Set();
  for (let page = 0; page < 10000; page++) {
    const data = await getPage(entries.length);
    if (!Array.isArray(data.entries)) throw new Error('Unexpected response: entries array missing.');
    if (!data.entries.length) return entries;
    const signature = JSON.stringify(data.entries);
    if (signatures.has(signature)) throw new Error('BMC repeated a page; stopped to avoid an incomplete export.');
    signatures.add(signature);
    entries.push(...data.entries);
    // Continue until an empty page, including when the server caps page size.
  }
  throw new Error('Pagination safety limit reached; no complete export written.');
}

function namesFrom(entries) {
  const names = entries.map(entry => {
    const values = entry.values || {};
    const key = Object.keys(values).find(k => k.toLowerCase() === 'name');
    return key && typeof values[key] === 'string' ? values[key] : null;
  }).filter(Boolean);
  return [...new Set(names)].sort();
}

async function main() {
  const username = process.env.BMC_USERNAME;
  const password = process.env.BMC_PASSWORD;
  delete process.env.BMC_USERNAME; delete process.env.BMC_PASSWORD;
  if (!username || !password) throw new Error('Run start.ps1 to enter your Dev username and password.');
  console.log(`Dev server: ${base.origin} | Mode: ${config.connectionMode}`);
  let token;
  try {
    const login = await request('POST', '/api/jwt/login', new URLSearchParams({ username, password }).toString(),
      { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'text/plain' });
    check(login, 'Login');
    token = login.text.trim();
    if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token)) {
      token = undefined; throw new Error('Login returned no recognizable JWT; check server/proxy redirects.');
    }
    console.log('Login successful. Reading metadata form...');
    const entries = await collectForms(async offset => {
      const query = new URLSearchParams({ limit: String(config.pageSize), offset: String(offset), sort: '1.asc' });
      const endpoint = `/api/arsys/v1/entry/${encodeURIComponent(config.metadataForm)}?${query}`;
      const response = await request('GET', endpoint, '', { Authorization: `AR-JWT ${token}` });
      check(response, 'Read metadata');
      let data;
      try { data = JSON.parse(response.text); } catch { throw new Error('Metadata response is not JSON.'); }
      console.log(`Offset ${offset}: ${Array.isArray(data.entries) ? data.entries.length : '?'} rows`);
      return data;
    });
    const names = namesFrom(entries);
    const out = path.join(__dirname, 'output', new Date().toISOString().replace(/[:.]/g, '-'));
    fs.mkdirSync(out, { recursive: true });
    fs.writeFileSync(path.join(out, 'forms-raw.json'), JSON.stringify({ server: base.origin, metadataForm: config.metadataForm,
      fetchedAt: new Date().toISOString(), rowCount: entries.length, entries }, null, 2));
    if (names.length) {
      fs.writeFileSync(path.join(out, 'forms.txt'), names.join('\r\n') + '\r\n');
      const csv = ['Form Name', ...names.map(n => '"' + (/^[=+@-]/.test(n) ? "'" : '') + n.replace(/"/g, '""') + '"')].join('\r\n');
      fs.writeFileSync(path.join(out, 'forms.csv'), '\uFEFF' + csv);
      console.log(`Exported ${names.length} unique form names from ${entries.length} metadata rows.`);
    } else console.log('No name values found. Inspect forms-raw.json; this is not a confirmed complete form list.');
    console.log(`Output: ${out}`);
    console.log('Results reflect metadata visibility; overlays can produce duplicate names.');
  } finally {
    if (token) {
      try {
        const logout = await request('POST', '/api/jwt/logout', '', { Authorization: `AR-JWT ${token}` });
        if (logout.status < 200 || logout.status >= 300) console.log('Logout was not confirmed; token will expire according to server policy.');
      } catch { console.log('Logout could not be confirmed.'); }
      token = undefined;
    }
  }
}
if (require.main === module) main().catch(error => { console.error('ERROR:', error.message); process.exitCode = 1; });
module.exports = { collectForms, namesFrom, request, check };
