const fs=require('node:fs'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
fs.mkdirSync(path.join(__dirname,'data'),{recursive:true});
const db=new DatabaseSync(path.join(__dirname,'data','intake.sqlite'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
const schema="CREATE TABLE registrations(id TEXT PRIMARY KEY, issue_key TEXT NOT NULL UNIQUE, registered_at TEXT NOT NULL, registered_by TEXT NOT NULL, fitment_state TEXT NOT NULL DEFAULT 'Pending fitment')";
const columns=db.prepare('PRAGMA table_info(registrations)').all();
if(columns.some(c=>c.name==='snapshot')){
 const backup=path.join(__dirname,'data','intake-before-lean-'+Date.now()+'.sqlite');
 db.exec("VACUUM INTO '"+backup.replace(/'/g,"''")+"'");
 db.exec('BEGIN IMMEDIATE');try{db.exec('ALTER TABLE registrations RENAME TO registrations_legacy');db.exec(schema);db.exec('INSERT INTO registrations(id,issue_key,registered_at,registered_by,fitment_state) SELECT id,issue_key,registered_at,registered_by,fitment_state FROM registrations_legacy');db.exec('DROP TABLE registrations_legacy');db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
 db.exec('VACUUM');
}else if(!columns.length)db.exec(schema);
db.exec('CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, issue_id TEXT NOT NULL, at TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL)');
db.exec('CREATE TABLE IF NOT EXISTS jira_cache(issue_id TEXT PRIMARY KEY REFERENCES registrations(id),payload TEXT NOT NULL,refreshed_at TEXT NOT NULL)');
exports.list=()=>db.prepare('SELECT r.*,c.payload,c.refreshed_at FROM registrations r LEFT JOIN jira_cache c ON c.issue_id=r.id WHERE r.active=1 ORDER BY r.registered_at DESC').all().map(r=>{const {payload,...record}=r;return {...record,cached_data:payload?JSON.parse(payload):null};});
for(const [table,column,definition] of [['registrations','active','INTEGER NOT NULL DEFAULT 1'],['audit','details',"TEXT NOT NULL DEFAULT '{}'" ]])if(!db.prepare('PRAGMA table_info('+table+')').all().some(c=>c.name===column))db.exec('ALTER TABLE '+table+' ADD COLUMN '+column+' '+definition);
db.exec("UPDATE registrations SET fitment_state='Pending Fitment' WHERE fitment_state='Pending fitment'");
const fitmentStates=['Pending Fitment','Fitment in Progress','Awaiting Information','Accepted for Assessment','Queued for Assessment Capacity','Returned to DAG','Redirected','Merged with Existing Demand'];
exports.fitmentStates=fitmentStates;
function audit(id,user,action,details){db.prepare('INSERT INTO audit(issue_id,at,actor,action,details) VALUES(?,?,?,?,?)').run(id,new Date().toISOString(),user,action,JSON.stringify(details));}
exports.history=id=>db.prepare('SELECT at,actor,action,details FROM audit WHERE issue_id=? ORDER BY id DESC').all(id).map(r=>({...r,details:JSON.parse(r.details)}));
exports.deregister=(id,user,reason,registeredAt)=>{db.exec('BEGIN IMMEDIATE');try{let r=db.prepare('SELECT * FROM registrations WHERE id=? AND active=1').get(id);if(!r || r.registered_at!==registeredAt)throw Error('CONFLICT');db.prepare('UPDATE registrations SET active=0 WHERE id=?').run(id);audit(id,user,'DEREGISTER',{reason,previousState:r.fitment_state});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}};
exports.setFitment=(id,user,state,previous,reason,checklist)=>{if(!fitmentStates.includes(state))throw Error('INVALID');if(!reason.trim())throw Error('REASON');if(['Accepted for Assessment','Queued for Assessment Capacity'].includes(state)){const required=['Clear objective','Known owner','Right platform','Minimum information','Not duplicate'];if(!required.every(k=>checklist[k]===true))throw Error('CHECKLIST');if(state==='Accepted for Assessment' && checklist['Assessment capacity']!==true)throw Error('CHECKLIST');}db.exec('BEGIN IMMEDIATE');try{let r=db.prepare('SELECT * FROM registrations WHERE id=? AND active=1').get(id);if(!r || r.fitment_state!==previous)throw Error('CONFLICT');db.prepare('UPDATE registrations SET fitment_state=? WHERE id=?').run(state,id);audit(id,user,'FITMENT_CHANGE',{from:previous,to:state,reason,checklist});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}};
function cache(issue,now){db.prepare('INSERT INTO jira_cache(issue_id,payload,refreshed_at) VALUES(?,?,?) ON CONFLICT(issue_id) DO UPDATE SET payload=excluded.payload,refreshed_at=excluded.refreshed_at').run(issue.id,JSON.stringify(issue),now);}

exports.register=(issue,user)=>{const now=new Date().toISOString();db.exec('BEGIN IMMEDIATE');try{let existing=db.prepare('SELECT active FROM registrations WHERE id=?').get(issue.id);if(existing){if(existing.active)throw Error('UNIQUE');db.prepare("UPDATE registrations SET active=1,registered_at=?,registered_by=?,fitment_state='Pending Fitment' WHERE id=?").run(now,user,issue.id);}else db.prepare("INSERT INTO registrations(id,issue_key,registered_at,registered_by,fitment_state) VALUES(?,?,?,?,'Pending Fitment')").run(issue.id,issue.key,now,user);audit(issue.id,user,existing?'REREGISTER':'REGISTER',{});cache(issue,now);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}};
exports.sync=(issues)=>{const now=new Date().toISOString();db.exec('BEGIN IMMEDIATE');try{for(const issue of issues)if(db.prepare('SELECT id FROM registrations WHERE id=? AND active=1').get(issue.id))cache(issue,now);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}};
