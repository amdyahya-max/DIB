from __future__ import annotations

import base64
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import HTTPException, Request, status

ROOT_DIR = Path(__file__).resolve().parents[1]
DEFAULT_DB = ROOT_DIR / "data" / "auth.db"
COOKIE_NAME = "pc_session"
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,50}$")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value)


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def auth_db_path() -> Path:
    raw = os.getenv("AUTH_DB_PATH", str(DEFAULT_DB)).strip()
    p = Path(raw)
    if not p.is_absolute():
        p = ROOT_DIR / p
    return p.resolve()


def session_hours() -> int:
    try:
        return max(1, min(168, int(os.getenv("AUTH_SESSION_HOURS", "8"))))
    except ValueError:
        return 8


def max_failed_attempts() -> int:
    try:
        return max(3, min(20, int(os.getenv("AUTH_MAX_FAILED_ATTEMPTS", "5"))))
    except ValueError:
        return 5


def lock_minutes() -> int:
    try:
        return max(1, min(1440, int(os.getenv("AUTH_LOCK_MINUTES", "15"))))
    except ValueError:
        return 15


def cookie_secure() -> bool:
    return _bool_env("AUTH_COOKIE_SECURE", False)


def _connect() -> sqlite3.Connection:
    path = auth_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    return con


def ensure_auth_database() -> None:
    with _connect() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                display_name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
                enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
                must_change_password INTEGER NOT NULL DEFAULT 0 CHECK(must_change_password IN (0,1)),
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                locked_until TEXT,
                last_login TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor_user_id INTEGER,
                actor_username TEXT,
                action TEXT NOT NULL,
                target_user_id INTEGER,
                target_username TEXT,
                detail TEXT,
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS ix_sessions_user ON sessions(user_id);
            CREATE INDEX IF NOT EXISTS ix_sessions_expiry ON sessions(expires_at);
            CREATE INDEX IF NOT EXISTS ix_audit_created ON audit_log(created_at DESC);
            """
        )
        con.execute("DELETE FROM sessions WHERE expires_at <= ?", (_iso(_utcnow()),))


def user_count() -> int:
    ensure_auth_database()
    with _connect() as con:
        return int(con.execute("SELECT COUNT(*) FROM users").fetchone()[0])


def validate_username(username: str) -> str:
    value = (username or "").strip()
    if not USERNAME_RE.fullmatch(value):
        raise ValueError("Username must be 3-50 characters using letters, numbers, dot, underscore or hyphen.")
    return value


def validate_password(password: str) -> None:
    value = password or ""
    if len(value) < 10:
        raise ValueError("Password must contain at least 10 characters.")
    if not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
        raise ValueError("Password must contain at least one letter and one number.")


def _hash_password(password: str, iterations: int = 310_000) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256${}${}${}".format(
        iterations,
        base64.urlsafe_b64encode(salt).decode("ascii"),
        base64.urlsafe_b64encode(digest).decode("ascii"),
    )


def _verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        salt = base64.urlsafe_b64decode(salt_b64.encode("ascii"))
        expected = base64.urlsafe_b64decode(digest_b64.encode("ascii"))
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _row_user(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "username": row["username"],
        "displayName": row["display_name"],
        "role": row["role"],
        "enabled": bool(row["enabled"]),
        "mustChangePassword": bool(row["must_change_password"]),
        "lastLogin": row["last_login"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def audit(actor: Optional[dict], action: str, target: Optional[dict] = None, detail: str = "") -> None:
    with _connect() as con:
        con.execute(
            "INSERT INTO audit_log(actor_user_id, actor_username, action, target_user_id, target_username, detail, created_at) VALUES(?,?,?,?,?,?,?)",
            (
                actor.get("id") if actor else None,
                actor.get("username") if actor else None,
                action,
                target.get("id") if target else None,
                target.get("username") if target else None,
                detail,
                _iso(_utcnow()),
            ),
        )


def create_user(username: str, display_name: str, password: str, role: str = "user", enabled: bool = True,
                must_change_password: bool = True, actor: Optional[dict] = None) -> dict:
    ensure_auth_database()
    username = validate_username(username)
    display_name = (display_name or username).strip()[:100]
    validate_password(password)
    if role not in {"admin", "user"}:
        raise ValueError("Role must be admin or user.")
    now = _iso(_utcnow())
    try:
        with _connect() as con:
            cur = con.execute(
                """INSERT INTO users(username,display_name,password_hash,role,enabled,must_change_password,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (username, display_name, _hash_password(password), role, int(enabled), int(must_change_password), now, now),
            )
            row = con.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    except sqlite3.IntegrityError as exc:
        raise ValueError("Username already exists.") from exc
    user = _row_user(row)
    audit(actor, "USER_CREATED", user, f"role={role}; enabled={enabled}")
    return user


def setup_initial_admin(username: str, display_name: str, password: str) -> dict:
    ensure_auth_database()
    with _connect() as con:
        con.execute("BEGIN IMMEDIATE")
        count = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if count:
            raise ValueError("Initial setup is already complete.")
    user = create_user(username, display_name, password, role="admin", enabled=True, must_change_password=False, actor=None)
    audit(None, "INITIAL_ADMIN_CREATED", user)
    return user


def authenticate(username: str, password: str) -> dict:
    ensure_auth_database()
    uname = (username or "").strip()
    now = _utcnow()
    with _connect() as con:
        row = con.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (uname,)).fetchone()
        if row is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password.")
        if not row["enabled"]:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This account is disabled. Contact an administrator.")
        if row["locked_until"]:
            locked_until = _parse_iso(row["locked_until"])
            if locked_until > now:
                raise HTTPException(status_code=status.HTTP_423_LOCKED, detail=f"Account temporarily locked until {locked_until.astimezone(timezone.utc).strftime('%H:%M UTC')}.")
        if not _verify_password(password or "", row["password_hash"]):
            failed = int(row["failed_attempts"] or 0) + 1
            locked_until = None
            if failed >= max_failed_attempts():
                locked_until = _iso(now + timedelta(minutes=lock_minutes()))
                failed = 0
            con.execute("UPDATE users SET failed_attempts=?, locked_until=?, updated_at=? WHERE id=?",
                        (failed, locked_until, _iso(now), row["id"]))
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password.")
        con.execute("UPDATE users SET failed_attempts=0, locked_until=NULL, last_login=?, updated_at=? WHERE id=?",
                    (_iso(now), _iso(now), row["id"]))
        row = con.execute("SELECT * FROM users WHERE id=?", (row["id"],)).fetchone()
    user = _row_user(row)
    audit(user, "LOGIN_SUCCESS", user)
    return user


def create_session(user_id: int) -> tuple[str, datetime]:
    token = secrets.token_urlsafe(48)
    expires = _utcnow() + timedelta(hours=session_hours())
    with _connect() as con:
        con.execute("INSERT INTO sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)",
                    (_token_hash(token), user_id, _iso(_utcnow()), _iso(expires)))
    return token, expires


def delete_session(token: Optional[str]) -> None:
    if not token:
        return
    with _connect() as con:
        con.execute("DELETE FROM sessions WHERE token_hash=?", (_token_hash(token),))


def get_user_from_token(token: Optional[str]) -> Optional[dict]:
    if not token:
        return None
    now = _iso(_utcnow())
    with _connect() as con:
        row = con.execute(
            """SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
               WHERE s.token_hash=? AND s.expires_at>?""",
            (_token_hash(token), now),
        ).fetchone()
        if row is None:
            return None
        if not row["enabled"]:
            con.execute("DELETE FROM sessions WHERE user_id=?", (row["id"],))
            return None
        return _row_user(row)


def current_user_optional(request: Request) -> Optional[dict]:
    return get_user_from_token(request.cookies.get(COOKIE_NAME))


def require_user(request: Request) -> dict:
    user = current_user_optional(request)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required.")
    if user.get("mustChangePassword"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="PASSWORD_CHANGE_REQUIRED")
    return user


def require_admin(request: Request) -> dict:
    user = require_user(request)
    if user.get("role") != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator access required.")
    return user


def list_users() -> list[dict]:
    with _connect() as con:
        rows = con.execute("SELECT * FROM users ORDER BY enabled DESC, role ASC, username COLLATE NOCASE").fetchall()
    return [_row_user(r) for r in rows]


def get_user(user_id: int) -> Optional[dict]:
    with _connect() as con:
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    return _row_user(row) if row else None


def enabled_admin_count() -> int:
    with _connect() as con:
        return int(con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND enabled=1").fetchone()[0])


def update_user(user_id: int, *, display_name: Optional[str] = None, role: Optional[str] = None,
                enabled: Optional[bool] = None, actor: dict) -> dict:
    target = get_user(user_id)
    if not target:
        raise ValueError("User not found.")
    if role is not None and role not in {"admin", "user"}:
        raise ValueError("Role must be admin or user.")
    if actor["id"] == user_id and enabled is False:
        raise ValueError("You cannot disable your own account.")
    if target["role"] == "admin" and target["enabled"] and ((role == "user") or (enabled is False)) and enabled_admin_count() <= 1:
        raise ValueError("At least one enabled administrator must remain.")
    fields = []
    params = []
    if display_name is not None:
        fields.append("display_name=?")
        params.append((display_name.strip() or target["username"])[:100])
    if role is not None:
        fields.append("role=?")
        params.append(role)
    if enabled is not None:
        fields.append("enabled=?")
        params.append(int(enabled))
    if not fields:
        return target
    fields.append("updated_at=?")
    params.append(_iso(_utcnow()))
    params.append(user_id)
    with _connect() as con:
        con.execute(f"UPDATE users SET {', '.join(fields)} WHERE id=?", params)
        if enabled is False:
            con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    updated = _row_user(row)
    audit(actor, "USER_UPDATED", updated, f"role={updated['role']}; enabled={updated['enabled']}")
    return updated


def reset_password(user_id: int, new_password: str, actor: dict, force_change: bool = True) -> dict:
    validate_password(new_password)
    target = get_user(user_id)
    if not target:
        raise ValueError("User not found.")
    with _connect() as con:
        con.execute("UPDATE users SET password_hash=?, must_change_password=?, failed_attempts=0, locked_until=NULL, updated_at=? WHERE id=?",
                    (_hash_password(new_password), int(force_change), _iso(_utcnow()), user_id))
        con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    updated = _row_user(row)
    audit(actor, "PASSWORD_RESET", updated, f"force_change={force_change}")
    return updated


def change_own_password(user_id: int, current_password: str, new_password: str) -> dict:
    validate_password(new_password)
    with _connect() as con:
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if row is None or not _verify_password(current_password or "", row["password_hash"]):
            raise ValueError("Current password is incorrect.")
        con.execute("UPDATE users SET password_hash=?, must_change_password=0, failed_attempts=0, locked_until=NULL, updated_at=? WHERE id=?",
                    (_hash_password(new_password), _iso(_utcnow()), user_id))
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    user = _row_user(row)
    audit(user, "PASSWORD_CHANGED", user)
    return user


def list_audit(limit: int = 100) -> list[dict]:
    limit = max(1, min(500, limit))
    with _connect() as con:
        rows = con.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]
