PowerCard V2/V3 Reconciliation V0.14
===================================

New in V0.14:
- Local login authentication.
- First-time administrator setup.
- /admin user management.
- Enable/disable users.
- Local SQLite auth database with PBKDF2-SHA256 password hashing.
- Password reset + forced change.
- Login lockout and admin audit log.
- IIS reverse-proxy deployment guide.

Start without BAT:
  python\python.exe run_api.py

First run:
  http://127.0.0.1:8000/
  -> redirects to /setup if no local users exist.

Important guides:
- LOCAL_AUTH_GUIDE.txt
- IIS_DEPLOYMENT_GUIDE.txt
- DEPLOY_ORACLE_STEPS.txt

Do not commit:
- .env
- data/auth.db
- Oracle credentials
