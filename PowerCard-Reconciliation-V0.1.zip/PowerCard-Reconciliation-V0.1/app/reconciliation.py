from .database import get_connection

def _fetch(environment: str, version: str):
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT card_number, client_code, status
            FROM cards
            WHERE environment = ? AND version = ?
            ORDER BY card_number
            """,
            (environment, version),
        ).fetchall()

    # Defensive de-duplication by CARD_NUMBER.
    unique = {}
    for row in rows:
        unique[row["card_number"]] = {
            "cardNumber": row["card_number"],
            "clientCode": row["client_code"],
            "status": row["status"],
        }
    return unique

def reconcile_environment(environment: str):
    v2 = _fetch(environment, "V2")
    v3 = _fetch(environment, "V3")

    v2_keys = set(v2)
    v3_keys = set(v3)

    matched_keys = sorted(v2_keys & v3_keys)
    v2_only_keys = sorted(v2_keys - v3_keys)
    v3_only_keys = sorted(v3_keys - v2_keys)

    matched = []
    for card in matched_keys:
        matched.append({
            "cardNumber": card,
            "clientCode": v2[card]["clientCode"],
            "v2Status": v2[card]["status"],
            "v3Status": v3[card]["status"],
        })

    v2_only = [v2[k] for k in v2_only_keys]
    v3_only = [v3[k] for k in v3_only_keys]

    return {
        "environment": environment,
        "summary": {
            "v2Count": len(v2),
            "v3Count": len(v3),
            "matchedCount": len(matched),
            "v2OnlyCount": len(v2_only),
            "v3OnlyCount": len(v3_only),
        },
        "matched": matched,
        "v2Only": v2_only,
        "v3Only": v3_only,
    }
