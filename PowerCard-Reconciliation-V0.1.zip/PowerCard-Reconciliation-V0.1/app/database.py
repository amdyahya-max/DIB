from pathlib import Path
import sqlite3

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "sample.db"

SAMPLE_DATA = {
    "PWCORE": {
        "v2": [
            ("1001", "CIF001", "N"),
            ("1002", "CIF002", "N"),
            ("1003", "CIF003", "N"),
            ("1004", "CIF004", "N"),
        ],
        "v3": [
            ("1001", "CIF001", "N"),
            ("1002", "CIF002", "N"),
            ("1004", "CIF004", "N"),
            ("1005", "CIF005", "N"),
        ],
    },
    "PCMOCK": {
        "v2": [
            ("2001", "CIF101", "N"),
            ("2002", "CIF102", "N"),
            ("2003", "CIF103", "N"),
            ("2004", "CIF104", "N"),
        ],
        "v3": [
            ("2001", "CIF101", "N"),
            ("2003", "CIF103", "N"),
            ("2004", "CIF104", "N"),
            ("2006", "CIF106", "N"),
        ],
    },
}

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def ensure_database():
    first_time = not DB_PATH.exists()

    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cards (
                environment TEXT NOT NULL,
                version TEXT NOT NULL,
                card_number TEXT NOT NULL,
                client_code TEXT NOT NULL,
                status TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_cards_env_ver_card
            ON cards(environment, version, card_number)
        """)

        if first_time or conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0] == 0:
            conn.execute("DELETE FROM cards")
            for environment, versions in SAMPLE_DATA.items():
                for version, rows in versions.items():
                    conn.executemany(
                        """
                        INSERT INTO cards(environment, version, card_number, client_code, status)
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        [(environment, version.upper(), *row) for row in rows],
                    )
            conn.commit()
