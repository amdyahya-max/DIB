
POWERCARD RECONCILIATION V0.1
==============================

PURPOSE
-------
Local Windows prototype that simulates two environments:
1. PWCORE
2. PCMOCK

Each environment has V2 and V3 sample card data.
The application displays:
- V2 total records
- records available in both V2 and V3
- V2 records missing from V3

DUMMY DATA
----------
PWCORE V2: 1001,1002,1003,1004
PWCORE V3: 1001,1002,1004,1005
Expected:
- matched = 3
- V2-only = 1 (1003)

PCMOCK V2: 2001,2002,2003,2004
PCMOCK V3: 2001,2003,2004,2006
Expected:
- matched = 3
- V2-only = 1 (2002)

FOLDER SETUP
------------
The ZIP deliberately does NOT contain Python itself.

Final structure should be:

PowerCard-Reconciliation-V0.1\
  python\
    python.exe
    ...
  app\
    main.py
    database.py
    reconciliation.py
    web\
  start.bat

Copy your portable Python folder into this project so that:
python\python.exe
exists.

VERIFY PACKAGES
---------------
From Command Prompt in the project folder:

python\python.exe -c "import fastapi, uvicorn; print('FastAPI OK'); print('Uvicorn OK')"

RUN
---
Double-click:
start.bat

or run:

python\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000

Open:
http://127.0.0.1:8000

Swagger:
http://127.0.0.1:8000/docs

DATABASE
--------
sample.db is automatically created inside the app folder at first startup.
No SQLite installation is required.

RESET SAMPLE DATA
-----------------
Stop the application and delete:
app\sample.db

Start again. The sample database will be recreated.

IMPORTANT FOR REAL ORACLE VERSION
---------------------------------
Do not place Oracle usernames/passwords inside HTML, JavaScript, or source code.
The next version should use protected environment/configuration settings and a
dedicated Oracle repository layer.
