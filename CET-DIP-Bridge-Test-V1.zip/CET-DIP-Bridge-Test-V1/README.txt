CET DIP BRIDGE TEST V1
Portal: https://dxb01-vwu-afna1.dibuat.ae/DIP/
Confluence: https://connectjira.dib.ae/collaboration
Jira: https://connectjira.dib.ae/planner

1. IIS STATIC HOSTING
Place index.html in the physical folder served by the DIP application or virtual directory. Enable Static Content and index.html as a default document. No Node or npm is needed for this static test.
If DIP already reverse-proxies to Node, serve index.html through that application instead; placing it in an IIS directory will not override a rewrite rule. Do not overwrite another working application.

2. CONFLUENCE
Paste the complete contents of Confluence-Bridge-Macro.html into the existing HTML macro mechanism used by your dashboard. Use only one copy on a page. The project defaults to DMGT and can be changed in the input field.

3. TEST
Open the portal URL directly; it must load without a certificate warning. Log into Jira in the same browser. Open the Confluence page, wait for 'Portal bridge connected', and click 'Fetch and send 5 issues'. Success: the iframe lists issues and Confluence acknowledges delivery.

4. FRAMING / POLICY
The portal must permit the Confluence origin in its response policy:
Content-Security-Policy: frame-ancestors https://connectjira.dib.ae
A conflicting X-Frame-Options DENY or SAMEORIGIN prevents this cross-origin embedding. Adjust only the DIP route with your IIS administrator. Confluence must also permit the portal in its frame-src policy. No web.config is supplied because existing IIS reverse-proxy and inherited headers vary.

5. DIAGNOSTICS
No iframe: check portal reachability, HTTPS certificate trust, framing policy and Confluence policy.
Iframe loads but handshake fails: check exact URL/origin, redirects, whether macro scripts execute, and iframe sandbox restrictions.
Jira HTTP 401: sign into Jira in the same browser.
Jira HTTP 403: verify project permissions and applicable Jira security controls.
Zero issues: request succeeded but project has no issues visible to this user.
Jira succeeds but no acknowledgement: check iframe message handling and portal version.

6. SCOPE
Jira calls execute in the user's browser, not the Confluence or Windows server. Existing browser cookies are used only for Jira. No passwords or PATs are configured. Data passes to the iframe via postMessage, with exact origin/window checks and text-only rendering.
This is not portal authentication, trusted server synchronization, or approval validation. Data supplied by browsers must be treated as untrusted. Domain identity and portal roles will require separately verified SSO before production use.
