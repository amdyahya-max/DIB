@echo off
cd /d "%~dp0helper"
if not exist node_modules (
  call npm ci --no-audit --no-fund
  if errorlevel 1 goto failed
)
call npm start
:failed
pause
