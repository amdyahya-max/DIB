# Validation — CET Momentum v1.0

Checked on 1 October 2026 using Node 24 on Linux.

## Automated tests: 9 passed

- Excel sync preserves admin blocks and leader tags. Removed users retain history.
- Duplicate, invalid and empty rosters do not replace a valid roster.
- Enrolment is account-bound and single-use; blocked accounts cannot enrol.
- Confirmations are idempotent; future and out-of-window dates are rejected.
- Server-side race filtering removes leader identities, counts and ranks from regular views.
- Holidays, approved leave and joining/leaving dates affect targets correctly.
- Disabled and expired accounts fail access.
- Reminder scheduling handles deduplication, confirmation, grace and snooze.
- Actual Excel/HTTP integration validates helper sessions, single-use launch links, unauthorised requests, immediate access blocking, CSRF rejection and IIS subpath redirects.

## Browser checks

Headless Chromium checks used a simulated local helper transport and an actual running backend/database. They covered automatic calendar opening, current/previous month selection, submission through the confirmation dialog, animated race rendering, leader hiding, Admin settings/navigation and responsive layout. No JavaScript page errors occurred. A single-use helper launch link opened the calendar with browser-to-localhost communication blocked.

Screenshots contain fictional demonstration users. They are not imported into the supplied workbook/database.

## Windows installer

The Windows x64 Electron helper was packaged. The packaged main script was compared with the delivered source. A per-user NSIS installer was compiled from `helper/installer.nsi`. Its manifest contains `asInvoker`, and the script uses current-user registry entries and `%LOCALAPPDATA%` installation. The installer is unsigned.

## Windows acceptance checks still required

This environment cannot execute Windows binaries. Test standard-user installation, tray/startup behaviour, account recognition, reminder windows/toasts, browser local-network permissions and the IIS/Windows-service configuration on the target PC/server. The reminder logic and server protocol were tested independently; those tests do not establish native Windows behaviour.

Recommended first acceptance test: add your own enabled account, enrol your helper, configure a reminder a few minutes ahead, confirm today, block/unblock your account in Admin, and check that the same behaviour works after a helper restart. Then test with one regular participant and one leader before wider deployment.
