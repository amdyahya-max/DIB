@echo off
cd /d "%~dp0helper"
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed
call npm run dist:win
if errorlevel 1 goto failed
call npm run publish:local
echo Installer published. The portal now offers Download CET Helper.
:failed
pause
