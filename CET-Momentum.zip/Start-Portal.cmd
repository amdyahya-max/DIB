@echo off
setlocal
cd /d "%~dp0"
set "CET_NODE_DIR=%~dp0Node"
if not exist "%CET_NODE_DIR%\node.exe" (
  echo Node.js was not found at "%CET_NODE_DIR%\node.exe".
  echo Extract the complete Node.js 24 Windows ZIP into the Node folder.
  echo The Node folder must directly contain node.exe and npm.cmd.
  goto failed
)
if not exist "%CET_NODE_DIR%\npm.cmd" (
  echo npm.cmd was not found in "%CET_NODE_DIR%".
  echo Extract the complete Node.js distribution, including its node_modules folder.
  goto failed
)
set "PATH=%CET_NODE_DIR%;%PATH%"
"%CET_NODE_DIR%\node.exe" -e "process.exit(Number(process.versions.node.split('.')[0]) === 24 ? 0 : 1)"
if errorlevel 1 (
  echo CET Momentum requires Node.js 24. The bundled version is:
  "%CET_NODE_DIR%\node.exe" --version
  goto failed
)
if not exist .env (
  copy /y .env.example .env >nul
  if errorlevel 1 goto failed
)
if not exist node_modules (
  call "%CET_NODE_DIR%\npm.cmd" ci --no-audit --no-fund
  if errorlevel 1 goto failed
)
if not exist dist\index.html (
  call "%CET_NODE_DIR%\npm.cmd" run build
  if errorlevel 1 goto failed
)
echo Using Node.js from "%CET_NODE_DIR%"
echo Open the PUBLIC_URL configured in .env, default http://localhost:5000
call "%CET_NODE_DIR%\npm.cmd" start
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Portal startup failed. See the message above.
pause
exit /b 1
