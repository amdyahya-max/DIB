const http=require('node:http');
const https=require('node:https');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const csrf=crypto.randomBytes(32).toString('hex');
let token='';
const origin='http://localhost:4000';
const files={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/style.css':'style.css'};
function json(res,status,obj){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj));}
function jiraGet(api,pat){return new Promise(resolve=>{
 const req=https.get({hostname:'connectjira.dib.ae',path:'/planner/rest/api/2/'+api,headers:{Authorization:'Bearer '+pat,Accept:'application/json'},timeout:15000},r=>{
 let body='';r.setEncoding('utf8');
 r.on('data',c=>{body+=c;if(body.length>2e6){req.destroy(Object.assign(new Error('Response too large'),{code:'RESPONSE_TOO_LARGE'}));}});
 r.on('end',()=>{let data;try{data=JSON.parse(body);}catch{} resolve({status:r.statusCode,type:r.headers['content-type']||'',data,redirect:r.statusCode>=300&&r.statusCode<400});});
 });
 req.on('timeout',()=>req.destroy(Object.assign(new Error('Timeout'),{code:'ETIMEDOUT'})));
 req.on('error',e=>resolve({error:e.code||'CONNECTION_ERROR'}));
});}
const server=http.createServer(async(req,res)=>{
 if(req.headers.host!=='localhost:4000'){return json(res,403,{message:'Use http://localhost:4000'});}
 const url=new URL(req.url,origin);
 if(url.pathname==='/api/config'&&req.method==='GET')return json(res,200,{csrf});
 if(url.pathname.startsWith('/api/')){
  if(req.method!=='POST'||req.headers.origin!==origin||req.headers['x-cet-csrf']!==csrf)return json(res,403,{message:'Request rejected. Reload the localhost page.'});
  if(url.pathname==='/api/disconnect'){token='';return json(res,200,{message:'Token cleared from server memory.'});}
  if(!['/api/connect','/api/issues'].includes(url.pathname))return json(res,404,{message:'Unknown endpoint'});
  if(!String(req.headers['content-type']||'').startsWith('application/json'))return json(res,415,{message:'JSON required'});
  let body='';let exceeded=false;
  try{for await(const c of req){body+=c;if(body.length>8192){exceeded=true;break;}}}catch{return json(res,400,{message:'Invalid request'});}
  if(exceeded)return json(res,413,{message:'Request too large'});
  let input;try{input=JSON.parse(body);}catch{return json(res,400,{message:'Invalid JSON'});}
  const connecting=url.pathname==='/api/connect';
  if(connecting)token='';
  const pat=connecting?(typeof input.token==='string'?input.token.trim():''):token;
  if(!pat||pat.length>4096||/[\r\n]/.test(pat))return json(res,400,{message:'Enter a valid PAT.'});
  const start=Date.now();
  const result=await jiraGet(connecting?'myself':'search?jql='+encodeURIComponent('ORDER BY updated DESC')+'&maxResults=5&fields=summary,status',pat);
  const diagnostic={time:new Date().toISOString(),transport:'Node HTTPS to Jira',endpoint:connecting?'myself':'search (latest five visible issues)',durationMs:Date.now()-start,httpStatus:result.status,errorCode:result.error,contentType:result.type};
  if(result.error)return json(res,502,{message:'Node could not connect to Jira. Check DNS, network, proxy and certificate trust. TLS verification remains enabled.',diagnostic});
  if(result.status!==200)return json(res,502,{message:result.status===401?'Jira rejected the PAT. Check expiry or revocation.':result.status===403?'Jira returned forbidden. Check account permissions and server security policy.':result.redirect?'Jira redirected the request. An SSO or proxy rule may be intercepting API access.':'Jira returned HTTP '+result.status,diagnostic});
  if(!result.data)return json(res,502,{message:'Jira returned non-JSON content, possibly a sign-in page.',diagnostic});
  if(connecting){
   const u=result.data;if(typeof u.displayName!=='string'||!(u.name||u.key))return json(res,502,{message:'Unexpected identity response.',diagnostic});
   token=pat;return json(res,200,{message:'Connected to Jira using your PAT.',user:{displayName:u.displayName,name:u.name||u.key},diagnostic});
  }
  if(!Array.isArray(result.data.issues))return json(res,502,{message:'Unexpected issue search response.',diagnostic});
  json(res,200,{message:'Read-only issue search succeeded.',issues:result.data.issues.map(i=>({key:i.key,summary:i.fields?.summary,status:i.fields?.status?.name})),diagnostic});return;
 }
 const file=files[url.pathname];if(!file||!['GET','HEAD'].includes(req.method)){res.writeHead(404);return res.end('Not found');}
 fs.readFile(path.join(__dirname,file),(e,data)=>{if(e){res.writeHead(500);return res.end();}res.writeHead(200,{'Content-Type':file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"});res.end(req.method==='HEAD'?undefined:data);});
});
server.requestTimeout=20000;
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Port 4000 is busy. Stop the previous test server first.':e.code);process.exitCode=1;});
server.listen(4000,'127.0.0.1',()=>console.log('CET PAT test: http://localhost:4000 | Node '+process.version+' | Ctrl+C to stop'));
