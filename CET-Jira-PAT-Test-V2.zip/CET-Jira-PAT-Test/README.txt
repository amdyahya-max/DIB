CET Jira PAT Test V2

1. Stop the previous localhost test server with Ctrl+C.
2. Extract this ZIP and open a terminal in CET-Jira-PAT-Test.
3. Run: node server.js
4. Open http://localhost:4000 (use this exact hostname).
5. Paste your Jira PAT and click Connect and verify identity.
6. Click Fetch 5 visible issues to verify a subsequent API call.
7. Download diagnostics if needed. Click Disconnect when finished.

No npm install required. Uses only built-in Node modules.
An organisation-approved supported Node.js version is recommended.
Start-Portal.cmd is optional where command files are allowed.
Token is held only in server memory; restarting clears it.
The single-user server binds to loopback and validates origin and CSRF.
Do not use this local test as a shared production service.
Jira requests use HTTPS with certificate verification enabled.
If corporate CA trust is needed, use the organisation-approved PEM file:
PowerShell: $env:NODE_EXTRA_CA_CERTS="C:\certs\corporate-ca.pem"
Then launch node server.js from that same terminal.
Do not set NODE_TLS_REJECT_UNAUTHORIZED=0.
DNS, firewall and corporate proxy policies can affect Node independently
of the browser. This package connects directly and does not configure a proxy.
No Jira browser login is required for this PAT test.
Diagnostics omit PAT, password, user profile and issue content.
