from functools import lru_cache
import os

from .config import load_query, oracle_batch_size, oracle_setting


def _oracledb():
    try:
        import oracledb
        return oracledb
    except ImportError as exc:
        raise RuntimeError(
            "Oracle mode requires python-oracledb. Install requirements-oracle.txt first."
        ) from exc


@lru_cache(maxsize=8)
def _pool(environment: str, version: str):
    oracledb = _oracledb()
    cfg = oracle_setting(environment, version)
    min_pool = int(os.getenv("ORACLE_POOL_MIN", "1"))
    max_pool = int(os.getenv("ORACLE_POOL_MAX", "4"))
    increment = int(os.getenv("ORACLE_POOL_INCREMENT", "1"))
    return oracledb.create_pool(
        user=cfg["username"], password=cfg["password"], dsn=cfg["dsn"],
        min=min_pool, max=max_pool, increment=increment
    )


def _normalize_rows(cursor):
    cols = [d[0].lower() for d in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


def fetch_v2(environment: str, query_file: str):
    sql = load_query(query_file)
    with _pool(environment, "v2").acquire() as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            return _normalize_rows(cur)


def fetch_v3_by_cards(environment: str, card_numbers):
    cards = list(dict.fromkeys(str(x) for x in card_numbers if x is not None))
    if not cards:
        return []
    template = load_query("lookup_v3.sql")
    batch_size = oracle_batch_size()
    output = []
    with _pool(environment, "v3").acquire() as conn:
        with conn.cursor() as cur:
            for offset in range(0, len(cards), batch_size):
                batch = cards[offset:offset + batch_size]
                binds = {f"card{i}": card for i, card in enumerate(batch)}
                placeholders = ", ".join(f":card{i}" for i in range(len(batch)))
                sql = template.replace("/*CARD_BINDS*/", placeholders)
                cur.execute(sql, binds)
                output.extend(_normalize_rows(cur))
    return output


def connection_health(environment: str):
    result = {"environment": environment, "v2": False, "v3": False}
    for version in ("v2", "v3"):
        try:
            with _pool(environment, version).acquire() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1 FROM dual")
                    cur.fetchone()
            result[version] = True
        except Exception as exc:
            result[f"{version}Error"] = str(exc)
    return result
