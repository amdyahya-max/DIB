PowerCard V2 <-> V3 Reconciliation - V0.12
==========================================

V0.12 keeps the working V0.11 Oracle Thick-mode reconciliation and UI behavior,
and adds a BAT-free, service-friendly startup model.

START WITHOUT A BAT FILE
------------------------
From the project root:

python\python.exe run_api.py

Configuration is read automatically from the project-root .env file.

WINDOWS SERVICE
---------------
See:

SERVICE_DEPLOYMENT_WINDOWS.txt

The recommended service process is:

Executable: <PROJECT>\python\python.exe
Arguments : run_api.py
Working dir: <PROJECT>

V0.12 service improvements
--------------------------
- No .BAT file is required or included.
- run_api.py sets the project working directory automatically.
- API host/port/workers/log level are parameterized in .env.
- Works when launched by Windows Service Control Manager.
- Compatible with NSSM or another organization-approved service wrapper.
- logs/ folder included for service stdout/stderr redirection.
- Oracle Thin/Thick mode behavior from V0.11 is retained.
- Database connectivity popup, dynamic question selection, matched-only
  copy/export, and filtered copy/export behavior are retained.

Default API settings
--------------------
API_HOST=127.0.0.1
API_PORT=8000
API_WORKERS=1
API_LOG_LEVEL=info

Keep API_HOST=127.0.0.1 for local-only access.
Use API_HOST=0.0.0.0 only after network/security approval.
