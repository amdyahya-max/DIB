; Per-user installer. Does not request elevation or write HKLM.
Unicode true
!include "MUI2.nsh"
Name "CET Helper"
OutFile "dist/CET-Helper-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\CET Helper"
RequestExecutionLevel user
SetCompressor /SOLID lzma
Icon "icon.ico"
UninstallIcon "icon.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\CET Helper.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Start CET Helper and connect your account"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
Section "Install"
 SetShellVarContext current
 SetOutPath "$INSTDIR"
 File /r "dist/win-unpacked/*"
 WriteUninstaller "$INSTDIR\Uninstall.exe"
 CreateShortcut "$SMPROGRAMS\CET Helper.lnk" "$INSTDIR\CET Helper.exe"
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "DisplayName" "CET Helper"
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "DisplayVersion" "1.1.1"
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "UninstallString" '"$INSTDIR\Uninstall.exe"'
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "InstallLocation" "$INSTDIR"
 WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "DisplayIcon" "$INSTDIR\CET Helper.exe"
 WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "NoModify" 1
 WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper" "NoRepair" 1
SectionEnd
Section "Uninstall"
 SetShellVarContext current
 MessageBox MB_OK "Please quit CET Helper from its tray menu before continuing."
 Delete "$SMPROGRAMS\CET Helper.lnk"
 DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "CET Helper"
 DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\CETHelper"
 RMDir /r "$INSTDIR"
SectionEnd
