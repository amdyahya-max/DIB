V5.8 — Compact queue buttons
============================
Includes all V5.7 features. UI-only change from V5.7.
Replace the Confluence macro with Confluence-DIP-V5.8-Macro.html.
For direct portal, replace public/index.html and public/style.css (or public folder).
No service restart needed when upgrading from V5.7.
Queue buttons size to their labels, all 46px tall; label/count stay on one line.
Registered Demand retains the small Fitment subtitle.
Very narrow containers use horizontal navigation scrolling instead of wrapping.
Preserve existing data and config.json if copying the complete package.

CET DIP V5.7 — Direct Portal Administration
==========================================
Includes all V5.6 workflow, scheduling, reporting and previous UI features.

UPGRADE
Stop CET-DIP. Back up the complete data folder and config.json while stopped.
Copy V5.7 application files into E:\DIP, preserving data and config.json.
Start CET-DIP and replace the macro with Confluence-DIP-V5.7-Macro.html.
Open the DIRECT portal and sign in as Administrator. Click Administration.
The Admin page is not exposed in the Confluence interface.
Existing users retain their passwords, roles and enabled state. Existing users
are NOT automatically forced to change password by this migration.

ADMIN PAGE — TWO SEPARATE MANAGEMENT AREAS
Portal Management:
- Users & access: create, edit role/enabled state, delete login accounts.
- Set/reset password with confirmation. New/reset accounts default to requiring
  the user to set their own password at next login. Admin may untick this option.
- Management history: actor, timestamp and changes, including process parameters.
Demand Intake Process:
- Responsible Owners: configurable routing/assignment roster.
- Sizing durations: assessment working days by type/size.
- Scheduling & calendar: start-date month window, weekends and holidays.
Process parameters remain in the SQLite database; UI updates use version checks.
Parameter editing now takes place in direct portal Administration.

PASSWORD FLOW
Passwords must have 12–256 characters; salted scrypt hashes are stored.
Required-change users see a password form immediately after login, in either
entry point, and cannot access workspace APIs until the change succeeds.
They enter their current temporary password and confirm a different new password.
After changing password, sign in again. All previous sessions are revoked.
Other users can use Change password in the direct portal header.
No password, salt or hash is shown in user listings/audit history.
Passwords are set manually; this release does not send credentials/email links.

USER SAFEGUARDS AND IDENTITY
Usernames are immutable after creation, preserving historical identity.
Edit changes role and Enabled/Disabled state. Delete removes the login account;
existing demand records and audit events remain.
An Administrator cannot delete, disable or demote their own current account.
The last enabled Administrator cannot be removed.
Disabling, deleting, resetting a password or changing a role invalidates existing
sessions. Concurrent stale edits return a conflict and require a user-list reload.
User administration APIs require Administrator permission and reject the Confluence
origin. The Admin UI is visible only in direct portal mode.
RO names are process assignment references, not automatically created logins;
user deletion does not erase historical assignments or edit the RO roster.
New installations still use manage-users.js for the initial Administrator bootstrap.

VERIFIED
JavaScript syntax and V5.6 scheduling regressions passed.
Live localhost API tests passed for create/edit/delete/reset, first-login access
blocking, successful password change, stale updates, administrator permissions,
Confluence-origin rejection, session revocation and self/last-admin protection.
User audit entries contain no passwords. Migration adds a default-off password-change
flag and preserves accounts, registrations and other data.
No Chromium executable is available here; live browser layout in IIS/Confluence
still requires verification in your environment.

V5.6 PROCESS RULES BELOW (configuration entry point replaced above)
-----------------------------------------------------------------
CET DIP V5.6 — Owner assignment, capacity planning and schedule history
======================================================================
BASELINE: V5.5, with its Jira cache, shared interfaces and UI changes retained.

UPGRADE
1. Stop CET-DIP. Back up the entire data folder and config.json while stopped.
2. Copy all V5.6 application files to E:\DIP, preserving data and config.json.
3. Start CET-DIP. SQLite migrations run automatically, preserving existing users,
   registrations, Jira cache, audit events and queue/status intervals.
4. Replace the Confluence macro with Confluence-DIP-V5.6-Macro.html.
5. Sign in as Administrator and click Assessment settings. Add Responsible
   Owners before registering/moving any demand. Review the calendar defaults.
Existing records with no RO remain visible. Their next update requires selection.
Existing assessment statuses are retained; new acceptances enter Capacity Assessment.
Node 22.13+ or Node 24 with built-in node:sqlite remains required. No npm dependencies.

CONFIGURATION (SQLite portal_settings; Administrator-only UI/API)
Start window: 1 calendar month by default; configurable 1–12 months.
Service Request 2 working days; XS 5; S 5; M 10; L 15; XL 15.
Service Request demand type takes precedence over Jira size.
Grouped Jira sizes XS/S and L/XL are supported; unknown/missing sizes are rejected.
Responsible Owners: unique names, one per line. Names are assignment references;
adding one does not create a login or grant permissions.
Weekends default to Saturday/Sunday (6,0); configure to your bank's calendar.
Holidays: YYYY-MM-DD, one per line. No bank holiday list is assumed.
Settings changes are audited, and concurrent settings edits are rejected.
Changing parameters does not rewrite existing due dates.

WORKFLOW
Registration and every queue movement require an RO from the configured list.
Route by choosing Fitment in Progress and an RO under Update Fitment.
Acceptance readiness checklist excludes assessment capacity: capacity is checked
in Assessment Queue, initially Capacity Assessment, with entry timestamp and RO.
No Capacity -> In Backlog, requiring planned assessment start.
Capacity Available -> Ready for Assessment, requiring planned assessment start.
Assessment in Progress records actual start. Assessment Completed records actual end.
Completion requires recorded actual start. Completed records cannot be rescheduled
or reopened through this control.
RO changes, status transitions, schedule changes and reasons are audited.
Returned to DAG removes active registration without changing Jira. DAG visibility
still depends on live Jira filter/status eligibility. Historical data is retained.
Merged/Redirected are recorded dispositions; this release records the destination
in the rationale and does not merge Jira issues or alter Jira statuses.
Administrator-only deregistration remains a correction distinct from a return decision.

SCHEDULING RULES
Dates use Asia/Dubai; the valid new start range is today through today's date plus
configured calendar months, inclusive. Month ends clamp to the last day of the
next month. The selected start must be a working day.
Start day counts as working day one. Completion skips configured weekends/holidays.
The latest request constrains START to the next-month window. Completion is based
on sizing working days and may extend beyond that start-selection window.
No additional absolute completion-window restriction is imposed.
Any new start date replaces the latest plan, requiring a reason and an audit record.
Reached/expired starts can be revised to a permitted new date. Original plan,
assessment entry, queue timers and previous revisions remain intact.
Revisions use the current configuration and cached Jira size/type. Jira refresh
alone never changes a commitment. Identical dates do not increment the count.
Due-date breach begins the day after planned completion; due today is not overdue.
A reached start with no actual start is highlighted separately.
The audit records whether the previous due date had already breached at revision.

REPORTING
Export workflow report downloads JSON for Administrators/Assessors.
GET /api/workflow-report includes queue/status intervals, elapsed calendar seconds,
per-demand owner, dates, reschedule counts and return/merge events, including
inactive registrations. Historical events remain after re-registration.
completedFirstPlanUnchanged: completed, original plan known, zero recorded reschedules.
completedFirstPlanOnTime: above, and actual completion <= original due date.
rescheduledDemands: at least one reschedule; repeatedlyRescheduled: more than one.
returnEvents/mergeEvents count decisions; corresponding demand counts are unique.
History shows actor/date, status/owner changes and old/new start/due dates.
Schedule rules/calendar used for each plan are retained in schedule_changes.
Historical unrecorded plans cannot be reconstructed. These metrics begin when
V5.6 scheduling is used; older V5.5 intervals retain their source labels.
Re-registration starts a new current plan, retaining lifetime events/revision counts.
This is a reporting foundation, not a complete analytics dashboard.

VALIDATION
Passed: JavaScript syntax; start-window inclusivity/month-end/leap-year boundaries;
working day/holiday calculation; expired start rescheduling; original-date retention;
RO enforcement; settings/workflow optimistic concurrency; queue timer continuity;
Jira refresh commitment preservation; return and re-registration report counts;
V5.5 database migration; live localhost API admin/viewer authorization checks.
Browser rendering could not be executed in this environment (no Chromium binary).
Live Confluence, IIS and Jira retrieval/layout must be checked in your environment.
Actual documents remain in Jira; the portal stores metadata/links, not file bytes.
