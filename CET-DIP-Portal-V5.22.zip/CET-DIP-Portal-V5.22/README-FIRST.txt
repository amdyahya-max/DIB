V5.22 — Registration and Jira refresh highlighted facts
========================================================
Registered date (with Registered by) and Jira refresh now appear as compact
highlighted cards in the RO/Assessment entered strip. Removed the two wide bars.
Green registration and amber refresh cards wrap naturally on narrower screens.
Includes all V5.21 features. Replace public, update Confluence macro to V5.22,
and refresh. No restart from V5.21. Preserve data and config.json.

V5.21 — Compact executive initials chips
=========================================
Removed AE Lead label and helper text. Smaller chips show name initials and
adjacent counts; All includes the queue total. Other remains for empty values.
Full names remain in tooltips and accessible labels; multi-select unchanged.
Includes all V5.20 features. Replace public and update Confluence macro to V5.21;
refresh the browser. No restart from V5.20. Preserve data and config.json.

V5.20 — Accountable Executive Lead multi-select chips
======================================================
Compact name chips below Search filter the current demand queue by AE Lead.
Select multiple chips to include any selected lead; combines with text search.
Blank AE Lead is Other. Chips shorten names to first/last, remove display suffixes
and show full names in tooltips/accessibility labels. Full names remain identities.
Counts reflect the current queue before search/name filters. All resets selection.
Switching queues or signing out clears the selection.
Available in Confluence and direct portal using its cached demand fields.
Includes all V5.19 features. Replace public and update Confluence macro to V5.20.
From V5.19 no restart needed; from V5.18 also update rules.json and restart.
Preserve data, config.json and any customized rules.json entries.

V5.19 — Additional Fast Track status spelling
==============================================
Added ADDL INFO REQUIRED _ FAST TRACK to underDiscussion in rules.json,
including spaces before and after the underscore. Earlier variants remain.
Includes all V5.18 features. From V5.18, replace only rules.json and restart
CET-DIP. No UI or Confluence macro change required; matching V5.19 macro included.
Restart requires users to sign in again because server sessions are in memory.
If your rules.json has local customizations, add the new entry to your existing
underDiscussion array instead of replacing it. Preserve data and config.json.

V5.18 — Retain login across page refreshes
==========================================
Both Confluence and direct portal save only the opaque session token in
sessionStorage, scoped by API URL. No passwords or user profiles are stored.
On refresh, /api/session validates the token and returns the current user/role
before workspace access. Required password-change routing is preserved.
Sign-out, invalid/expired sessions and password changes clear the saved token.
Closing the tab normally clears sessionStorage; browser session restoration may
restore it, but server validation and expiry still apply.
Storage restrictions fall back to the previous page-memory login behavior.
Existing server limits remain: 30-minute idle and 8-hour maximum session duration.
Service restarts invalidate existing server-memory sessions.
Includes all V5.17 features. UI-only upgrade: replace public and refresh; replace
Confluence macro with Confluence-DIP-V5.18-Macro.html. No restart from V5.17.
Preserve data and config.json when replacing the full package.

V5.17 — Comments as the last demand detail tab
==============================================
Comments now appears after History, using the existing tab styling.
Removed comments from below the Overview content.
Confluence loads the latest five Jira comments when the Comments tab opens;
five-minute cache, author/time cards, empty/error states and Retry remain.
Direct portal retains its guidance to view live comments in Confluence or Jira.
Includes all V5.16 features. From V5.16, replace public and refresh; update the
Confluence macro to Confluence-DIP-V5.17-Macro.html. No restart required.
Preserve data and config.json when replacing the full package.

V5.16 — Overview title only when collapsed
===========================================
Collapsed: document icon and Overview title at the left, round toggle at right.
Expanded: title and icon hidden; fields and round toggle shown inside the box.
Rounded box, smooth animation and remembered state remain unchanged.
Includes all V5.15 features. UI-only upgrade: replace public and refresh;
replace the Confluence macro with Confluence-DIP-V5.16-Macro.html.
No service restart needed from V5.15. Preserve data and config.json.

V5.15 — Rounded Overview box restored
======================================
Overview has a rounded rectangular box matching Requirement: same background,
border, corner radius and padding. Only the round right-aligned chevron is shown;
no Overview details heading. Smooth expand/collapse remains unchanged.
Includes all V5.14 features.
From V5.14: replace public/style.css, refresh the browser, and replace the
Confluence macro with Confluence-DIP-V5.15-Macro.html. No restart required.
Preserve data and config.json when replacing the full package.

V5.14 — Minimal round Overview toggle
======================================
Includes all V5.13/V5.12 features.
Removed Overview details heading, heading icon, text hints and surrounding box.
Only a small round chevron button remains at the right above the Overview fields.
Smooth expand/collapse, keyboard access, accessible labels and remembered state
remain available. Reduced-motion preferences skip animation.
UI-only upgrade: replace public, refresh, and update the Confluence HTML macro
to Confluence-DIP-V5.14-Macro.html. No service restart required from V5.13.
Preserve data and config.json when replacing the full package.

V5.13 — Collapsible Overview details
====================================
Includes all V5.12 features, including Excel/PDF/JSON workflow reports.
Overview fields are grouped in a box matching the Requirement section.
Click its header or use keyboard Enter/Space to expand or collapse smoothly.
The group starts expanded; each demand retains its choice while switching tabs
within the current session. Reduced-motion preferences skip the animation.
Requirement and other tabs retain their existing behavior.
UI-only upgrade from V5.12: replace public and refresh the browser.
For Confluence, replace the HTML macro with Confluence-DIP-V5.13-Macro.html.
No service restart is needed for this UI-only update.
If replacing the full package, preserve data and config.json.

V5.12 — Workflow report Excel, PDF and JSON exports
===================================================
Includes all V5.11 features and all earlier changes in this package.
Export Workflow Report now offers Excel (.xlsx), PDF (.pdf) and JSON (.json).
Excel has five worksheets: Summary, Demands, Queue and status periods,
Transitions, and Reschedule history, with filters and frozen headers.
PDF provides the same sections in a printable landscape report.
All formats include inactive registrations, date revisions and workflow history.
Times display in GST; elapsed hours are calendar hours, not working-day durations.
Exports remain restricted to Administrator and Assessor roles.
The server generates the files without additional npm packages or Office software.
The bundled DejaVu Sans font and its license must remain in report-assets.

UPGRADE FROM V5.11 OR EARLIER
Stop CET-DIP and back up your data folder and customized config.json.
Replace application files, including reports.js, report-assets and public.
Preserve the existing data folder and config.json; restart CET-DIP.
Replace the Confluence HTML macro with Confluence-DIP-V5.12-Macro.html.
Refresh the browser. Existing accounts, configuration and history are retained.

V5.11 — Jira full size label mapping fix
=======================================
Includes all V5.10 features. Medium now maps to M and uses the configurable M days.
Extra Small/Small/Medium/Large/Extra Large and XS/S/M/L/XL are supported.
Whitespace/case, Extra-Large and matching labels such as Medium (M) are handled.
Jira's displayed values are preserved; only the calculation normalizes the labels.
Missing sizes and unknown values now produce separate, specific messages.

UPGRADE FROM V5.10
Stop CET-DIP, replace scheduling.js, then restart CET-DIP. No database changes.
The UI/macro is unchanged; matching Confluence-DIP-V5.11-Macro.html is included.
If replacing the full package, preserve data and config.json.
Tests cover full labels, short codes, custom M duration and planned date calculation.

V5.10 — Full-screen direct portal login
=======================================
Includes all V5.9 features. UI-only update from V5.9.
Replace the public folder and refresh the browser. No service restart required.
The direct portal background fills the viewport; the login card centers within it,
with fluid padding, responsive card width and a single-column layout on mobile.
Short screens scroll naturally so form controls remain accessible.
Confluence layout is unchanged; the matching V5.10 macro is included.
CSS selectors are limited to the direct portal; sign-in/sign-out toggles login layout.
Syntax and generated-file checks passed; live browser layout needs verification.
Preserve data and config.json when copying the full package.

V5.9 — Portal user profiles and linked Responsible Owners
=========================================================
Includes all V5.8 features and compact queue design.
Backend upgrade required: stop CET-DIP, back up data/config while stopped, copy
updated code preserving data and config.json, restart, and replace the macro
with Confluence-DIP-V5.9-Macro.html. Update the public folder for direct portal.

SETUP
1. Direct portal > Administration > Portal Management > Users & access.
2. Create/edit users with full name and Email ID. Department, job title and phone
   are optional. Username stays immutable. Email is unique ignoring case.
3. Demand Intake Process > Responsible Owners > ADD RO.
4. Search/select multiple enabled users, then Add selected. Missing name/email
   prevents selection; complete those profiles in Users & access first.
5. Remove RO removes future assignment eligibility; it does not delete the user
   or change existing demand assignments/history.
RO records reference portal usernames. Picker labels use current name/username/email;
profile edits update the RO page/dropdown automatically. RO membership does not
change a user's role or permissions.
Disabled users stay listed as unavailable; deleted accounts leave the roster.
Existing assignments retain their username even if the account is disabled/deleted.
Editing your own account may require signing in again after session invalidation.

MIGRATION OF OLD MANUAL NAMES
Earlier free-text owner names remain under Earlier unlinked RO names. They are
preserved in existing assignments/history and are NOT automatically guessed or
mapped to portal users. They cannot be selected for new assignments.
Add the correct user through ADD RO and optionally remove the old unlinked entry.
The next workflow update on an old assignment requires selecting a linked active RO.
No existing accounts are assigned invented emails or personal details.

DATA AND VALIDATION
SQLite portal_users gains name/email/department/job-title/phone fields.
ro_members stores username, membership added date and administrator.
Adding/removing ROs is audited and version-checked; batch adds are atomic.
Profile/user changes preserve password safeguards, self/last-admin protection,
first-login reset and existing demand timing history.
Verified: linked batch add/remove, duplicate-email rejection/rollback, profile
consistency, disabled-user exclusion, stale roster conflicts, legacy migration,
historical assignment preservation, API role enforcement and V5.8 regressions.
Live browser layout still requires verification in your IIS/Confluence environment.

Previous-version notes below; this RO procedure replaces the manual-name editor.
-------------------------------------------------------------------------------
V5.8 — Compact queue buttons
============================
Includes all V5.7 features. UI-only change from V5.7.
Replace the Confluence macro with Confluence-DIP-V5.8-Macro.html.
For direct portal, replace public/index.html and public/style.css (or public folder).
No service restart needed when upgrading from V5.7.
Queue buttons size to their labels, all 46px tall; label/count stay on one line.
Registered Demand retains the small Fitment subtitle.
Very narrow containers use horizontal navigation scrolling instead of wrapping.
Preserve existing data and config.json if copying the complete package.

CET DIP V5.7 — Direct Portal Administration
==========================================
Includes all V5.6 workflow, scheduling, reporting and previous UI features.

UPGRADE
Stop CET-DIP. Back up the complete data folder and config.json while stopped.
Copy V5.7 application files into E:\DIP, preserving data and config.json.
Start CET-DIP and replace the macro with Confluence-DIP-V5.7-Macro.html.
Open the DIRECT portal and sign in as Administrator. Click Administration.
The Admin page is not exposed in the Confluence interface.
Existing users retain their passwords, roles and enabled state. Existing users
are NOT automatically forced to change password by this migration.

ADMIN PAGE — TWO SEPARATE MANAGEMENT AREAS
Portal Management:
- Users & access: create, edit role/enabled state, delete login accounts.
- Set/reset password with confirmation. New/reset accounts default to requiring
  the user to set their own password at next login. Admin may untick this option.
- Management history: actor, timestamp and changes, including process parameters.
Demand Intake Process:
- Responsible Owners: configurable routing/assignment roster.
- Sizing durations: assessment working days by type/size.
- Scheduling & calendar: start-date month window, weekends and holidays.
Process parameters remain in the SQLite database; UI updates use version checks.
Parameter editing now takes place in direct portal Administration.

PASSWORD FLOW
Passwords must have 12–256 characters; salted scrypt hashes are stored.
Required-change users see a password form immediately after login, in either
entry point, and cannot access workspace APIs until the change succeeds.
They enter their current temporary password and confirm a different new password.
After changing password, sign in again. All previous sessions are revoked.
Other users can use Change password in the direct portal header.
No password, salt or hash is shown in user listings/audit history.
Passwords are set manually; this release does not send credentials/email links.

USER SAFEGUARDS AND IDENTITY
Usernames are immutable after creation, preserving historical identity.
Edit changes role and Enabled/Disabled state. Delete removes the login account;
existing demand records and audit events remain.
An Administrator cannot delete, disable or demote their own current account.
The last enabled Administrator cannot be removed.
Disabling, deleting, resetting a password or changing a role invalidates existing
sessions. Concurrent stale edits return a conflict and require a user-list reload.
User administration APIs require Administrator permission and reject the Confluence
origin. The Admin UI is visible only in direct portal mode.
RO names are process assignment references, not automatically created logins;
user deletion does not erase historical assignments or edit the RO roster.
New installations still use manage-users.js for the initial Administrator bootstrap.

VERIFIED
JavaScript syntax and V5.6 scheduling regressions passed.
Live localhost API tests passed for create/edit/delete/reset, first-login access
blocking, successful password change, stale updates, administrator permissions,
Confluence-origin rejection, session revocation and self/last-admin protection.
User audit entries contain no passwords. Migration adds a default-off password-change
flag and preserves accounts, registrations and other data.
No Chromium executable is available here; live browser layout in IIS/Confluence
still requires verification in your environment.

V5.6 PROCESS RULES BELOW (configuration entry point replaced above)
-----------------------------------------------------------------
CET DIP V5.6 — Owner assignment, capacity planning and schedule history
======================================================================
BASELINE: V5.5, with its Jira cache, shared interfaces and UI changes retained.

UPGRADE
1. Stop CET-DIP. Back up the entire data folder and config.json while stopped.
2. Copy all V5.6 application files to E:\DIP, preserving data and config.json.
3. Start CET-DIP. SQLite migrations run automatically, preserving existing users,
   registrations, Jira cache, audit events and queue/status intervals.
4. Replace the Confluence macro with Confluence-DIP-V5.6-Macro.html.
5. Sign in as Administrator and click Assessment settings. Add Responsible
   Owners before registering/moving any demand. Review the calendar defaults.
Existing records with no RO remain visible. Their next update requires selection.
Existing assessment statuses are retained; new acceptances enter Capacity Assessment.
Node 22.13+ or Node 24 with built-in node:sqlite remains required. No npm dependencies.

CONFIGURATION (SQLite portal_settings; Administrator-only UI/API)
Start window: 1 calendar month by default; configurable 1–12 months.
Service Request 2 working days; XS 5; S 5; M 10; L 15; XL 15.
Service Request demand type takes precedence over Jira size.
Grouped Jira sizes XS/S and L/XL are supported; unknown/missing sizes are rejected.
Responsible Owners: unique names, one per line. Names are assignment references;
adding one does not create a login or grant permissions.
Weekends default to Saturday/Sunday (6,0); configure to your bank's calendar.
Holidays: YYYY-MM-DD, one per line. No bank holiday list is assumed.
Settings changes are audited, and concurrent settings edits are rejected.
Changing parameters does not rewrite existing due dates.

WORKFLOW
Registration and every queue movement require an RO from the configured list.
Route by choosing Fitment in Progress and an RO under Update Fitment.
Acceptance readiness checklist excludes assessment capacity: capacity is checked
in Assessment Queue, initially Capacity Assessment, with entry timestamp and RO.
No Capacity -> In Backlog, requiring planned assessment start.
Capacity Available -> Ready for Assessment, requiring planned assessment start.
Assessment in Progress records actual start. Assessment Completed records actual end.
Completion requires recorded actual start. Completed records cannot be rescheduled
or reopened through this control.
RO changes, status transitions, schedule changes and reasons are audited.
Returned to DAG removes active registration without changing Jira. DAG visibility
still depends on live Jira filter/status eligibility. Historical data is retained.
Merged/Redirected are recorded dispositions; this release records the destination
in the rationale and does not merge Jira issues or alter Jira statuses.
Administrator-only deregistration remains a correction distinct from a return decision.

SCHEDULING RULES
Dates use Asia/Dubai; the valid new start range is today through today's date plus
configured calendar months, inclusive. Month ends clamp to the last day of the
next month. The selected start must be a working day.
Start day counts as working day one. Completion skips configured weekends/holidays.
The latest request constrains START to the next-month window. Completion is based
on sizing working days and may extend beyond that start-selection window.
No additional absolute completion-window restriction is imposed.
Any new start date replaces the latest plan, requiring a reason and an audit record.
Reached/expired starts can be revised to a permitted new date. Original plan,
assessment entry, queue timers and previous revisions remain intact.
Revisions use the current configuration and cached Jira size/type. Jira refresh
alone never changes a commitment. Identical dates do not increment the count.
Due-date breach begins the day after planned completion; due today is not overdue.
A reached start with no actual start is highlighted separately.
The audit records whether the previous due date had already breached at revision.

REPORTING
Export workflow report downloads JSON for Administrators/Assessors.
GET /api/workflow-report includes queue/status intervals, elapsed calendar seconds,
per-demand owner, dates, reschedule counts and return/merge events, including
inactive registrations. Historical events remain after re-registration.
completedFirstPlanUnchanged: completed, original plan known, zero recorded reschedules.
completedFirstPlanOnTime: above, and actual completion <= original due date.
rescheduledDemands: at least one reschedule; repeatedlyRescheduled: more than one.
returnEvents/mergeEvents count decisions; corresponding demand counts are unique.
History shows actor/date, status/owner changes and old/new start/due dates.
Schedule rules/calendar used for each plan are retained in schedule_changes.
Historical unrecorded plans cannot be reconstructed. These metrics begin when
V5.6 scheduling is used; older V5.5 intervals retain their source labels.
Re-registration starts a new current plan, retaining lifetime events/revision counts.
This is a reporting foundation, not a complete analytics dashboard.

VALIDATION
Passed: JavaScript syntax; start-window inclusivity/month-end/leap-year boundaries;
working day/holiday calculation; expired start rescheduling; original-date retention;
RO enforcement; settings/workflow optimistic concurrency; queue timer continuity;
Jira refresh commitment preservation; return and re-registration report counts;
V5.5 database migration; live localhost API admin/viewer authorization checks.
Browser rendering could not be executed in this environment (no Chromium binary).
Live Confluence, IIS and Jira retrieval/layout must be checked in your environment.
Actual documents remain in Jira; the portal stores metadata/links, not file bytes.
