<%@ WebHandler Language="C#" Class="DipIdentity" %>
using System;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;
using System.Security.Principal;
using System.Collections.Generic;
public class DipIdentity : IHttpHandler {
 public bool IsReusable { get { return false; } }
 public class UserEntry { public bool enabled {get;set;} public string[] roles {get;set;} }
 public void ProcessRequest(HttpContext c) {
  c.Response.ContentType="application/json";
  c.Response.Cache.SetCacheability(HttpCacheability.NoCache);
  c.Response.Cache.SetNoStore();
  c.Response.TrySkipIisCustomErrors=true;
  c.Response.SuppressFormsAuthenticationRedirect=true;
  var serializer=new JavaScriptSerializer();
  var identity=c.User == null ? null : c.User.Identity as WindowsIdentity;
  if(identity == null || !identity.IsAuthenticated) {
   c.Response.StatusCode=401;
   c.Response.Write(serializer.Serialize(new {allowed=false,identity="",roles=new string[0],error="Verified Windows authentication is required."})); return;
  }
  string name=identity.Name;
  try {
   var entries=serializer.Deserialize<Dictionary<string,UserEntry>>(File.ReadAllText(c.Server.MapPath("~/App_Data/users.json")));
   var users=new Dictionary<string,UserEntry>(entries,StringComparer.OrdinalIgnoreCase);
   UserEntry user;
   bool allowed=users.TryGetValue(name,out user) && user != null && user.enabled && user.roles != null && user.roles.Length>0;
   c.Response.StatusCode=allowed?200:403;
   c.Response.Write(serializer.Serialize(new {allowed=allowed,identity=name,roles=allowed?user.roles:new string[0],error=allowed?"":"Verified user is not enabled in portal configuration."}));
  } catch {
   c.Response.StatusCode=500;
   c.Response.Write(serializer.Serialize(new {allowed=false,identity=name,roles=new string[0],error="Portal user configuration could not be loaded."}));
  }
 }
}
