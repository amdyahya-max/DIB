CET DIP BRIDGE V2 — IIS WINDOWS IDENTITY TEST

Purpose: preserve the working Confluence/Jira bridge and independently verify portal users through IIS. This is an authentication proof of concept, not the full intake application.

REQUIRES
IIS Static Content, Windows Authentication, ASP.NET 4.x/.NET Extensibility 4.x and their ISAPI components. Application pool: .NET CLR v4.0, Integrated pipeline. No Node, npm or database needed for this test.

DEPLOYMENT
1. Back up the working DIP V1 folder and IIS settings.
2. Use a dedicated DIP IIS application (Convert to Application if currently only a virtual directory), pointing to the extracted folder. Do not copy into the Confluence server.
3. Set its application pool to CLR v4.0 / Integrated. Ensure the pool can read the folder and App_Data/users.json; no write access is needed.
4. In IIS Manager select ONLY DIP > Authentication: disable Anonymous; enable Windows Authentication. Keep the standard Negotiate/NTLM providers unless your administrators direct otherwise. Do not enable Basic authentication.
5. index.html must be a default document. Preserve the working HTTPS and iframe settings from V1. Preserve/add CSP frame-ancestors https://connectjira.dib.ae and resolve conflicting X-Frame-Options only for DIP. The included web.config does not change IIS authentication sections because they may be locked centrally.
6. If a parent rewrite sends DIP to Node, exempt this dedicated IIS application from that rewrite. The .ashx endpoint must execute in ASP.NET, never be served as source text. If its source appears, stop and correct IIS handler installation before proceeding.
7. Open https://dxb01-vwu-afna1.dibuat.ae/DIP/Identity.ashx directly FIRST. Successful identity verification returns JSON. Log in with your DIB user if the browser prompts. Do not enter credentials into Confluence macro code.
8. The default allowlist enables dib\muhammad.yahya as Administrator. Confirm your real IIS identity matches. If response is HTTP 403, it reports your verified identity but grants no roles: use that exact domain\username in App_Data/users.json, subject to intended access policy. Do not enable the server service/admin account merely because it appears.
9. Open DIP/ directly, then open Confluence and use the same macro (included). Once authorized the portal displays five Jira issues.

USER CONFIGURATION
Edit App_Data/users.json on the server. Example additional entry:
"dib\\another.user": {"enabled": true, "roles": ["Assessor"]}
JSON uses two backslashes to represent one. Exact verified domain-qualified identity is matched case-insensitively. Disabled or unknown users receive HTTP 403 and no roles. Changing this file affects the next identity request. The file must not be downloadable; verify /DIP/App_Data/users.json is blocked.
The Administrator label is a test mapping; this package has no admin panel or privileged business operations.

EXPECTED RESULTS
200 Identity.ashx: Windows identity verified and enabled.
403 JSON with identity: Windows login succeeded; account not in enabled allowlist.
401/repeated login prompt: authentication, domain trust, browser intranet policy or credentials issue. DIB and DIBUAT domain compatibility is not assumed. Ask AD/IIS administrators to verify trust/access.
404.3 / handler error: install/configure ASP.NET 4.x IIS components.
500.19: IIS configuration conflict/locked section; inspect server-side error and application scope.
500 JSON: check users.json syntax and read permissions.
Iframe login may be restricted by browser policy; first open the portal directly. Automatic Windows login may require centrally managed intranet/Integrated Authentication allowlists. Do not weaken browser settings globally.

SECURITY BOUNDARIES
Identity is taken exclusively from IIS WindowsIdentity, not username query parameters, browser messages or request headers. Confluence/Jira browser identity is separate and may differ from the Windows identity; this test does not assert they are identical. The portal displays its own verified identity.
No Confluence or Jira passwords/tokens are copied. Bridge data remains browser-supplied and untrusted. It is not stored and cannot authorize approvals. Future protected backend operations must re-check identity/roles on every request; client gating is only UI behavior. Persistent sessions, revocation, audit history, workflow and database are outside V2.

VALIDATION
HTML JavaScript syntax, JSON/XML syntax, ZIP integrity checked locally. ASP.NET handler execution, Windows authentication and cross-domain trust require live Windows IIS testing and have not been executed here.
