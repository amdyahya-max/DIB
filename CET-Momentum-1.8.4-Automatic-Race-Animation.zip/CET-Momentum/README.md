# CET Momentum 1.8.4 portal update

This ZIP makes the race cars animate automatically on opening CET Race, including on devices that report reduced motion. The Animate cars button is removed and Replay remains available. It also retains the IIS subpath asset fix from 1.8.3. Follow [deployment/UPDATE-1.8.4.md](deployment/UPDATE-1.8.4.md) to deploy it.

The CET Helper remains at 1.2.9. Keep the existing production `.env`, `data`, `storage`, `downloads`, `helper`, `Node`, and `node_modules` folders. Attendance and enrollment data are not included in this ZIP.

The animation runs in the browser. On the Windows Server session, the captured diagnostic reported `reducedMotion: true`, `animation: "none"`, and confirmed that the CSS keyframes were present. CET Race now shows **Animate cars** when the browser asks for reduced motion. Clicking it enables race-car motion for this portal in that browser; **Reduce motion** restores the system preference. Replay restarts the animation.

The portal logs one diagnostic per race view or replay in `STORAGE_DIR/logs/portal.log`, under the `race.diagnostics` event. It reports the browser motion preference, car animation style, keyframe availability, browser visibility, and observed animation activity. Open CET Race with its tab visible and leave it open for about five seconds before checking the log.
