V5.3 includes all V5.2 changes. Fitment Queue tab removed. Registered Queue defaults Needs fitment; filter offers All registered and individual fitment statuses. Tab shows compact Fitment subtitle as supplied reference, updating to selected filter; long labels wrap with smaller font. Registered tab count is total active register; filtered list is subset. Assessment Queue remains next to Registered; acceptance opens it. Backend unchanged. Confluence-only update may replace macro; direct portal also requires updated public folder.

V5.2: Fitment and Assessment queues, auditable fitment decisions, Admin-only deregistration.
Upgrade: stop CET-DIP; back up data/config; replace code preserving data/config; restart; replace macro with Confluence-DIP-V5.2-Macro.html. DB adds active marker and audit details automatically. Registered Queue remains full active register. Assessment Queue (next to Registered) includes Accepted for Assessment + Queued for Assessment Capacity. Fitment Queue includes Pending Fitment, Fitment in Progress, Awaiting Information. Acceptance auto-opens Assessment Queue; it does not start assessment.
Admin/Assessor Update fitment dialog: selected status + mandatory rationale. Accepted requires all six readiness checks. Queued for Assessment Capacity requires first five, not capacity. Reasons/checkbox evidence recorded. No Jira status writes. Returned to DAG is a retained business decision, not deregistration. Admin-only left-card deregistration arrow requires reason; soft deactivates registration, preserves cache/audit. Re-registration resets fitment and records REREGISTER. API checks roles and conflicts. History displays portal events. Actual assessment execution/dates/outcomes are not yet implemented. Existing direct portal and cache behavior retained.

V5.1 HYBRID CONFLUENCE + DIRECT PORTAL
Stop CET-DIP, back up E:\DIP\data and config.json, copy code preserving those folders/settings, start CET-DIP, replace macro with Confluence-DIP-V5.1-Macro.html.
Direct portal: https://dxb01-vwu-afna1.dibuat.ae/DIP/ — same login/fields/tabs/design, Registered Queue only. Reads cached Jira data from server; Refresh records never calls Jira. No DAG or registration action. Document links open Jira using the browser Jira session. Live comments require Confluence/Jira and are explicitly labeled in direct mode.
Confluence: both queues, live Jira retrieval, refreshes one latest Jira cache for registered demands only (Administrator/Assessor permissions). Cache includes fetched fields and attachment metadata/links, never attachment binaries; timestamp shown. Registration immediately seeds cache. No original duplicate snapshot. Registered items outside the filter still retrieved individually. Users without cache-write permission read live data but do not update server cache. Direct portal has no fitment/assessment edit workflows yet.
V5.0 users retain registration records; initial cached details appear after successful Confluence refresh. Upgrades from V4 create a pre-lean backup that retains original Jira copies; secure/delete after validation according to retention policy. Minimal registrations and audit remain separate from replaceable jira_cache. Browser-supplied Jira payload cannot be independently verified by this server.
Includes all V5.0 UI changes, 1300px detail/1360px queue limits and matched desktop panels. Direct and Confluence share native.js/native.css from this package.

V5.0 LEAN REGISTRATION — full backend and macro upgrade required.
1. Stop CET-DIP Windows service. Back up E:\DIP\data and config.json.
2. Copy package code into E:\DIP, preserving your existing data folder, config.json and credentials.
3. Start CET-DIP. Existing registrations migrate automatically. A complete pre-migration SQLite backup is created in data/intake-before-lean-*.sqlite; it contains old Jira copies. Secure it as a rollback backup and remove it after validation according to your retention policy. The live registration table no longer stores snapshots, current_data or synced_at. Users/audit/registration dates and users/fitment state are preserved.
4. Replace Confluence macro with Confluence-DIP-V5.0-Macro.html and reload the page.
Stored demand data: Jira ID/key, registration date/user, portal fitment state and REGISTER audit event only. Full issue payload is still validated transiently at registration, but not saved. Compatibility sync endpoint discards Jira payloads.
Jira fields and document links are read through the browser Jira session on login, Refresh Jira and every five minutes while the page is open. No persistent Jira cache. Registered issues outside the saved filter are fetched individually with four concurrent requests. Missing/denied Jira issues remain visible as registration records with an unavailable message; no invented fallback details. Documents open directly from Jira; no files or attachment metadata stored. Comments remain live-on-expand with five-minute memory cache. Portal does not independently verify browser-supplied Jira data.
Details height 1300px, queue 1360px, equal outer panel heights on desktop. Narrow screens retain smaller limits.
All preceding V4.12 UI changes retained. Fitment and assessment action workflows are not implemented yet.

V4.12 includes all V4.11 changes. Desktop detail content grows naturally up to 1100px (previously 560px), queue up to 1160px (previously 620px). Overflow scrolling begins only above limits. Narrow screens use 850px detail /650px queue. Requirement still has no inner scrollbar and expand/collapse is unchanged. A taller macro may require scrolling the Confluence page on smaller monitors. Replace macro with Confluence-DIP-V4.12-Macro.html; no service restart needed.

V4.11 includes all V4.10 changes. Overview has a collapsible Latest Jira Comments section below Description. Loads on first expansion using browser Jira session; last five visible comments by creation date, newest first. Cached in memory for five minutes, cleared on logout; comments are not written to portal database. Author initials, author, created time GST, edited marker and latest badge; full safe plain-text body, no inner scroll. Errors show Retry. Replace Confluence macro with Confluence-DIP-V4.11-Macro.html; no restart needed.

V4.10 includes all V4.9 changes. Requirement text has natural height with no inner scrollbar; expand/collapse is preserved. The existing main detail-panel scrolling remains. Replace the macro with Confluence-DIP-V4.10-Macro.html; no service restart needed.

V4.9 includes all V4.8 changes. Status left and compact Platform/Size badges right share one flex row with matching height; long values and narrow screens wrap for readability. Replace macro with Confluence-DIP-V4.9-Macro.html. No service restart needed.

V4.8 includes all V4.7 changes. Both queues sort by Jira Created descending, newest first, with missing/invalid dates last and key tie-breaker. Creation year is shown as a compact purple badge beside the issue key, above the summary. Year uses UTC. Replace the macro with Confluence-DIP-V4.8-Macro.html; no service restart required.

V4.7 includes all V4.6 changes. Registered Queue is muted gray when inactive and retains the current dark green/blue gradient when selected. Replace the macro with Confluence-DIP-V4.7-Macro.html. No service restart required.

V4.6 includes all V4.5 changes. Register Demand now appears only in the top-right action group beside Open Jira for unregistered demands. Existing permissions, confirmation and registration behavior are preserved. Replace the Confluence macro with Confluence-DIP-V4.6-Macro.html; no backend restart required.

V4.5 also removes the browser-session caption below Register Demand.
V4.5 — includes all V4.4 and V4.3 changes.
UI-only update: replace the Confluence HTML macro with Confluence-DIP-V4.5-Macro.html. No Node restart or database changes required for this macro-only update.
Overview starts Demand Department, Demand Owner, Demand Type, Chief Name Mapping, Accountable Executive, Accountable Executive Lead, Assignee. Three columns normally; four when expanded, with narrow-screen fallbacks. Status shows the value only, with distinct Technology Review and Accountable Executive Review highlights. Platform and Size remain in Overview and also appear as prominent header cards.
For full-folder upgrades preserve your existing config.json, data folder and credentials.

V4.4 UI UPDATE
==============
Queue heading now has a sidebar-collapse icon with tooltip and accessible label.
After hiding queue, a restore icon appears in demand header to show it again.
Open Jira is a highlighted blue button at the top-right of demand header.
Replace macro with Confluence-DIP-V4.4-Macro.html. Backend is unchanged from V4.3.
You may replace only the macro for this UI update. Source files are included.

V4.3 UPDATE
===========
Replace macro with Confluence-DIP-V4.3-Macro.html. Preserve data and config.json.
Overview now includes Assignee, Reporter, DAMO SPOC, Chief Name Mapping,
IDH Portfolio Head and Assigned Business Analyst. Demand Owner, Accountable
Executive and Accountable Executive Lead already existed and remain separate.
Assignee/Reporter use their system API IDs; added custom fields use discovery.
Chief Name Mapping is distinct from Chief Mapping in Governance; no alias assumed.
Search fills the queue panel width. Segoe UI/system fonts need no download.
Light teal/blue/violet gradients and stronger button accents are scoped to DIP,
not Confluence global styles. Text uses dark foregrounds and visible focus rings.
Actual Jira field names/values must still be checked on deployment.

CET DIP V4.2 - Automatic field discovery and compact detail tabs
===============================================================
UPGRADE
Stop-Service CET-DIP
Back up E:\DIP while stopped, including its entire data folder.
Extract application files into E:\DIP. Preserve existing config.json if customized.
DO NOT replace/delete data: accounts and registrations remain in intake.sqlite.
Start-Service CET-DIP
Replace Confluence HTML macro with Confluence-DIP-V4.2-Macro.html.
Node 22.13+ or 24 required. Existing LocalService permissions and IIS rewrite remain.

REFERENCE PAGE 197890530
Only FilterID | 21120 is required for selecting the saved filter.
Field IDs are now discovered through /planner/rest/api/2/field by display name.
Matching ignores case, whitespace and trailing colon. Missing fields show Not provided
and a warning. Duplicate names do NOT select the first result.
To resolve duplicates or differently named fields, add a reference-table row:
Demand Owner | customfield_ACTUAL_ID
Platform Owner | customfield_ACTUAL_ID
Accountable Executive Lead | customfield_ACTUAL_ID
Use real catalogue IDs, not the examples. Legacy DemandOwner, PlatformOwner and
AccountableExecutiveLead keys are also accepted. Never add passwords to this page.
Override is validated against catalogue; valid overrides can explicitly bind fields
whose API display names differ from Jira UI labels. No guessed Platform Owner fallback.

NEW DESIGN
32 percent queue / 68 percent detail. Expand details hides queue; Show queue restores it.
Six detail tabs: Overview, Business & Impact, Technology, Governance,
BRD & Documents, History. Tab row scrolls horizontally in constrained space.
Metadata fields use colourful, relevant inline SVG icons; labels remain visible.
Requirement and Justification are separate from Jira Description. Long text uses
expandable sections with preserved line breaks, rendered as text to prevent injection.
Jira wiki markup is not yet converted into full rich HTML.
Financial Benefits catalogue fields are discovered by prefix and shown with actual
labels and values. Zero is retained. A consolidated five-year matrix is not included.
Documents link directly to Jira with file colour accents; files are not replicated.
History shows real registration user/date, last sync and original snapshot.
Jira transition history and fitment decisions remain future features.

DATA
Existing SQLite account migration, roles, registration audit and original snapshots
are preserved. New issue snapshots include discovered detail values and field mappings.
Existing registered records gain new fields when present in the saved-filter refresh.
Records outside filter retain last known values. Missing original fields cannot be
retroactively invented in their registration snapshots.
Demand title uses Demand Title when available; Jira Summary remains stored.
No automatic Assignee-to-Platform-Owner or Reporter-to-Demand-Owner substitution.
Catalogue field grouping is portal-owned; Jira screen tabs are not scraped.
Login tokens remain memory-only; page reload requires login.
Browser-supplied Jira data is not independently verified by the portal backend.
Administrator/Assessor can register and persist refreshes. Viewer/Requester read only.

TESTED
JavaScript syntax, field-name normalization, duplicate detection, valid/invalid
ID overrides, legacy aliases, user/multiselect formatting, zero/false preservation.
Backend regression: authentication, CORS origin denial, role denial, eligibility,
duplicate registration, snapshot/date preservation, synchronization and logout.
Live Confluence/IIS rendering and your actual Jira catalogue have not been tested.

See previous deployment details below (field-ID requirement superseded above).

CET DIP V4.1 - Confluence native login and demand registration
===========================================================
First implementation package; replaces V3 server files, preserves existing users.
Node runtime REQUIRED: Node 22.13+ or Node 24. Use an approved supported build.
Uses built-in node:sqlite, no npm dependencies. Older Node builds cannot run it.

UPGRADE ON WINDOWS SERVER
1. Back up E:\DIP (especially data\users.json and config.json).
2. Stop-Service CET-DIP
3. Copy V4.1 files into E:\DIP. Keep existing config.json if customised.
   This ZIP intentionally does NOT contain users.json or an intake database.
   Do not overwrite your existing data folder. No account password is supplied.
4. Verify E:\DIP\node\node.exe --version meets the requirement.
5. LocalService needs Modify on data and logs as previously configured:
   Set-Location E:\DIP
   icacls .\data /grant '*S-1-5-19:(OI)(CI)(M)' /T
   icacls .\logs /grant '*S-1-5-19:(OI)(CI)(M)' /T
6. Start-Service CET-DIP
7. Check logs and Test-NetConnection 127.0.0.1 -Port 4000.
   Keep the existing IIS reverse proxy /DIP and HTTPS binding.

FRESH INSTALL ONLY
No users.json is required. SQLite tables are created automatically.
Use manage-users.js (interactive password prompt) to create the administrator:
Set-Location E:\DIP
.\node\node.exe .\manage-users.js add "dib\muhammad.yahya" Administrator
Existing users.json is migrated on the FIRST V4.1 startup. Do not edit it afterwards. See manage-users.js usage for other roles.

CONFLUENCE
Replace the old iframe macro with the entire contents of
Confluence-DIP-V4.1-Macro.html in an approved HTML macro. No html/head/body wrappers.
Confluence URL: https://connectjira.dib.ae/collaboration
DIP API URL: https://dxb01-vwu-afna1.dibuat.ae/DIP/api
Reference page: 197890530. These addresses are in native.js and the generated macro.
If editing native.js, regenerate the inline macro or edit its corresponding script.
The macro includes scoped CSS and no external dependencies.

REFERENCE PAGE TABLE: Property | Value
PageId | 197890530
FilterID | 21120
DemandOwner | actual Jira field ID, for example customfield_12345
PlatformOwner | actual Jira field ID
AccountableExecutiveLead | actual Jira field ID
Platform | actual Jira field ID
Size | actual Jira field ID

The field IDs above MUST be real IDs from your Jira/reference design.
Do not paste the example customfield_12345 blindly.
DemandOwner/PlatformOwner may map to reporter/assignee only if those truly
represent the business roles. Missing mappings display a warning and blanks.
Remove PortalPassword from the page. Credentials are entered in the login form.
Do not store a domain password, salted hash or API token in the reference page.

BEHAVIOUR
- Portal username and separate portal password entered directly in Confluence.
- Exact origin CORS; session token held only in page memory (not localStorage).
- Page reload requires login again. Logout revokes token. Server restart clears sessions.
- Sessions: 30-minute idle expiry and 8-hour maximum; account disable/version
  changes revoke sessions through the existing V3 user management mechanism.
- Jira uses the CURRENT browser user's Jira session. The user needs saved-filter
  access and issue permissions. No Jira service-account token is included.
- Automatic fetch after login, then every five minutes while page remains open.
- Paginates saved filter, up to 50 pages/5000 issues; no unattended scheduled sync.
- DAG Queue: Under Discussion mapping from existing V21.1 design, minus registered IDs.
- Select a demand to see owners, platform, size, created date, plain-text description
  and attachment links. Rich Jira wiki markup is currently displayed as text.
- Search matches key/title/platform/status. Default Jira order is oldest created.
- Register Demand: Administrator or Assessor only. Saves registration atomically.
- SQLite data\intake.sqlite: unique Jira issue ID and key; server timestamp,
  authenticated registering user, original snapshot, current data, sync timestamp,
  pending-fitment state and registration audit event.
- Original registration snapshot/date/user remain unchanged by Jira refresh.
- Registered Queue persists even if an item leaves the saved filter.
- Only registered items are eligible for future fitment. Fitment checklist/decisions
  and assessment workflow are NOT implemented in this first registration slice.
- Administrator/Assessor refreshes update current data for records present in filter.
  Viewer/Requester can read queues but cannot register or persist refresh updates.
- Records absent from the filter retain last known data/sync date, not a false live state.
- Documents are metadata and direct Jira links, not copied files in portal storage.

TRUST AND LIMITS
This remains a browser-fed integration. Portal cannot independently verify Jira
payloads without server-to-Jira connectivity; authorized users can alter their
submitted data. Registration timestamps/users are server-generated, while Jira
fields are browser-supplied. Not a trusted service-account synchronization.
All page scripts on the Confluence origin share that execution environment; allow
only trusted macros/scripts and use restricted reference-page editing permissions.
Confluence CSP must allow connection to the DIP HTTPS origin.
Full fitment, Jira writeback, individual record access partitions and file replication
are outside this first version. Queues are shared with authenticated portal users.
Back up SQLite using an approved SQLite backup procedure or stop the service before
copying the database and WAL/SHM files together. Do not copy only a live .sqlite file.

VALIDATION
Backend integration checks passed: unauthenticated access, wrong login, origin
rejection, administrator registration, noneligible rejection, duplicate conflict,
viewer write denial, snapshot/date preservation after sync and logout revocation.
JavaScript syntax passed. Macro fragment checked for no && entity hazards.
Live IIS/Confluence/browser testing has NOT been performed in your environment.
The generated login image is a visual concept, not a tested application screenshot.

V4.1 ACCOUNT DATABASE UPDATE
============================
Accounts now live in data\intake.sqlite, table portal_users, alongside registrations.
The first start imports existing users.json, preserving salts, password hashes,
roles, enabled status and session versions. Import and migration marker are one
transaction. Invalid legacy data stops startup without a partial import.
After migration users.json is NOT read for login or account maintenance. It is
retained untouched for rollback; archive it securely after confirming the upgrade.
CLI manage-users.js commands now read/write SQLite. No plaintext passwords are
stored. Existing passwords continue working. Username normalization is unchanged.
The database checks last-admin protection and concurrent account updates.
Do not create a fresh database and start it before copying legacy users.json: the
first startup marks migration complete even when no legacy file exists.
For an existing V4 installation, stop the service and keep the existing data folder.
For rollback, restore the complete pre-upgrade backup; edits made after migration
are not reflected in the legacy JSON file.
Person and lock icons are inline SVG inside login fields; labels remain accessible.
