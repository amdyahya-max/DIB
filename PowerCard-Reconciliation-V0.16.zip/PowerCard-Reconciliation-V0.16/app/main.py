from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, Response, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .config import app_base_path, auth_db_type, data_source
from .database import ensure_database
from .reconciliation import reconcile_environment
from .excel_export import build_reconciliation_xlsx
from .scenarios import SCENARIOS, list_scenarios
from .auth import (
    COOKIE_NAME, audit, authenticate, change_own_password, cookie_secure,
    create_session, create_user, current_user_optional, delete_session,
    ensure_auth_database, get_user, list_audit, list_users, require_admin,
    require_user, reset_password, setup_initial_admin, update_user, user_count,
)

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
APP_BASE_PATH = app_base_path()
COOKIE_PATH = APP_BASE_PATH or "/"

app = FastAPI(
    title="PowerCard V2/V3 Reconciliation API",
    version="0.16.0",
    description="Question-driven PowerCard reconciliation with local user authentication and administration.",
    root_path=APP_BASE_PATH,
)




def app_url(path: str = "") -> str:
    """Return a browser-visible URL under APP_BASE_PATH."""
    if not path or path == "/":
        return APP_BASE_PATH + "/" if APP_BASE_PATH else "/"
    suffix = "/" + path.lstrip("/")
    return APP_BASE_PATH + suffix if APP_BASE_PATH else suffix


class LoginRequest(BaseModel):
    username: str
    password: str


class SetupRequest(BaseModel):
    username: str
    displayName: str = "Administrator"
    password: str


class ChangePasswordRequest(BaseModel):
    currentPassword: str
    newPassword: str


class CreateUserRequest(BaseModel):
    username: str
    displayName: str
    password: str
    role: str = "user"
    enabled: bool = True
    mustChangePassword: bool = True


class UpdateUserRequest(BaseModel):
    displayName: Optional[str] = None
    role: Optional[str] = None
    enabled: Optional[bool] = None


class ResetPasswordRequest(BaseModel):
    newPassword: str
    forceChange: bool = True


class ReconcileRequest(BaseModel):
    environment: str
    scenario: str


class ExportFilteredRequest(BaseModel):
    environment: str
    scenario: str
    records: list[dict] = Field(default_factory=list)
    filterText: str = ""


@app.on_event("startup")
def startup_event():
    ensure_auth_database()
    if data_source() == "sqlite":
        ensure_database()


@app.get("/api/v1/health")
def health():
    return {"status": "UP", "version": "0.16.0", "dataSource": data_source(), "authentication": "local", "authDatabase": auth_db_type(), "appBasePath": APP_BASE_PATH or "/"}


@app.get("/api/v1/auth/setup-status")
def setup_status():
    return {"setupRequired": user_count() == 0}


@app.post("/api/v1/auth/setup")
def auth_setup(payload: SetupRequest):
    try:
        user = setup_initial_admin(payload.username, payload.displayName, payload.password)
        return {"created": True, "user": user}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/v1/auth/login")
def auth_login(payload: LoginRequest):
    user = authenticate(payload.username, payload.password)
    token, expires = create_session(user["id"])
    response = JSONResponse({"authenticated": True, "user": user})
    response.set_cookie(
        key=COOKIE_NAME,
        value=token,
        httponly=True,
        secure=cookie_secure(),
        samesite="lax",
        max_age=max(60, int((expires.timestamp())) - int(__import__('time').time())),
        path=COOKIE_PATH,
    )
    return response


@app.post("/api/v1/auth/logout")
def auth_logout(request: Request):
    user = current_user_optional(request)
    delete_session(request.cookies.get(COOKIE_NAME))
    if user:
        audit(user, "LOGOUT", user)
    response = JSONResponse({"loggedOut": True})
    response.delete_cookie(COOKIE_NAME, path=COOKIE_PATH)
    return response


@app.get("/api/v1/auth/me")
def auth_me(request: Request):
    user = current_user_optional(request)
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return {"user": user}


@app.post("/api/v1/auth/change-password")
def auth_change_password(payload: ChangePasswordRequest, request: Request):
    user = current_user_optional(request)
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required.")
    try:
        updated = change_own_password(user["id"], payload.currentPassword, payload.newPassword)
        return {"changed": True, "user": updated}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/v1/admin/users")
def admin_users(request: Request):
    require_admin(request)
    return {"users": list_users()}


@app.post("/api/v1/admin/users")
def admin_create_user(payload: CreateUserRequest, request: Request):
    actor = require_admin(request)
    try:
        user = create_user(payload.username, payload.displayName, payload.password, payload.role,
                           payload.enabled, payload.mustChangePassword, actor)
        return {"user": user}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.patch("/api/v1/admin/users/{user_id}")
def admin_update_user(user_id: int, payload: UpdateUserRequest, request: Request):
    actor = require_admin(request)
    try:
        user = update_user(user_id, display_name=payload.displayName, role=payload.role,
                           enabled=payload.enabled, actor=actor)
        return {"user": user}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/v1/admin/users/{user_id}/reset-password")
def admin_reset_password(user_id: int, payload: ResetPasswordRequest, request: Request):
    actor = require_admin(request)
    try:
        user = reset_password(user_id, payload.newPassword, actor, payload.forceChange)
        return {"user": user}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/v1/admin/audit")
def admin_audit(request: Request, limit: int = 100):
    require_admin(request)
    return {"events": list_audit(limit)}


@app.get("/api/v1/environments")
def environments(request: Request):
    require_user(request)
    return {"environments": [{"id": "PWCORE", "name": "PWCORE"}, {"id": "PCMOCK", "name": "PCMOCK"}]}


@app.get("/api/v1/scenarios")
def scenarios(request: Request):
    require_user(request)
    return {"scenarios": list_scenarios()}


@app.get("/api/v1/oracle-health/{environment}")
def oracle_health(environment: str, request: Request):
    require_user(request)
    env = environment.strip().upper()
    if env not in {"PWCORE", "PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if data_source() != "oracle":
        return {"environment": env, "dataSource": data_source(), "message": "Oracle health check is available when DATA_SOURCE=oracle."}
    try:
        from .oracle_repository import connection_health
        return connection_health(env)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/v1/reconcile")
def reconcile(payload: ReconcileRequest, request: Request):
    require_user(request)
    environment = payload.environment.strip().upper()
    scenario_id = payload.scenario.strip().upper()
    if environment not in {"PWCORE", "PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if scenario_id not in SCENARIOS:
        raise HTTPException(status_code=400, detail="Unsupported question/scenario.")
    try:
        return reconcile_environment(environment, scenario_id)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/v1/export-excel")
def export_excel(payload: ExportFilteredRequest, request: Request):
    require_user(request)
    environment = payload.environment.strip().upper()
    scenario_id = payload.scenario.strip().upper()
    if environment not in {"PWCORE", "PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if scenario_id not in SCENARIOS:
        raise HTTPException(status_code=400, detail="Unsupported question/scenario.")
    if SCENARIOS[scenario_id]["mode"] == "guidance":
        raise HTTPException(status_code=400, detail="Guidance scenarios do not have reconciliation data to export.")
    if not payload.records:
        raise HTTPException(status_code=400, detail="There are no matched records to export.")
    try:
        result = {
            "environment": environment,
            "dataSource": data_source(),
            "scenario": {"id": scenario_id, "label": SCENARIOS[scenario_id]["label"]},
            "summary": {"matchedCount": len(payload.records)},
            "matched": payload.records,
            "filterText": payload.filterText,
        }
        content = build_reconciliation_xlsx(result, matched_only=True)
        filename = f"PowerCard_{environment}_{scenario_id.lower()}_matched.xlsx"
        return Response(content=content,
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f'attachment; filename="{filename}"'})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")


@app.get("/login")
def login_page(request: Request):
    if user_count() == 0:
        return RedirectResponse(app_url("/setup"), status_code=302)
    user = current_user_optional(request)
    if user:
        return RedirectResponse(app_url("/change-password") if user.get("mustChangePassword") else app_url("/"), status_code=302)
    return FileResponse(WEB_DIR / "login.html")


@app.get("/setup")
def setup_page():
    if user_count() > 0:
        return RedirectResponse(app_url("/login"), status_code=302)
    return FileResponse(WEB_DIR / "setup.html")


@app.get("/change-password")
def change_password_page(request: Request):
    user = current_user_optional(request)
    if not user:
        return RedirectResponse(app_url("/login"), status_code=302)
    return FileResponse(WEB_DIR / "change-password.html")


@app.get("/admin")
def admin_page(request: Request):
    user = current_user_optional(request)
    if not user:
        return RedirectResponse(app_url("/login"), status_code=302)
    if user.get("mustChangePassword"):
        return RedirectResponse(app_url("/change-password"), status_code=302)
    if user.get("role") != "admin":
        return RedirectResponse(app_url("/"), status_code=302)
    return FileResponse(WEB_DIR / "admin.html")


@app.get("/")
def home(request: Request):
    user = current_user_optional(request)
    if not user:
        return RedirectResponse(app_url("/login"), status_code=302)
    if user.get("mustChangePassword"):
        return RedirectResponse(app_url("/change-password"), status_code=302)
    return FileResponse(WEB_DIR / "index.html")
