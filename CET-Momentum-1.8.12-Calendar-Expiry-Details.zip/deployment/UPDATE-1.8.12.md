# Deploy CET Momentum 1.8.12

My Calendar displays the signed-in user's Account expires on and Password expiry values in its compact top position bar. The values come from that user's SQLite roster record through the authenticated `/api/me` response. An Excel timestamp such as `2027-01-01T00:00:00` is displayed as `1 Jan 2027`. Explicit `Never` is shown as Never; an empty Account Expiry reads "No date in roster" and an empty Password Expiry reads "Not provided". This is informational; existing account access rules are unchanged.

This ZIP also includes the earlier individual Delete duplicate username fix, email-based Excel upload, and admin-protected bulk cleanup.

1. Stop the CET Momentum NSSM service. Back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder.
2. Extract this ZIP separately. Copy its `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` to matching application folders. Replace the **entire** deployed `dist` with this ZIP's ready-built `dist`.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`.
4. Restart the service. Confirm `/CETGamification/api/info` reports `"version":"1.8.12"`; refresh the browser with Ctrl+F5, then open My Calendar.

No SQLite schema migration, npm install, npm build, or helper update is required.
