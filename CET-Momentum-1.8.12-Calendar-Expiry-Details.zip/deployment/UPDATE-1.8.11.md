# Deploy CET Momentum 1.8.11

The individual **Delete** button in Administration → Users now works even when `CET_Users.xlsx` contains duplicate Windows usernames. It removes every Excel row belonging to the selected user and keeps the first row for each other duplicated username, so the workbook can sync again. The selected user's SQLite account becomes Removed; their attendance, linked audit records and other history remain. Their helper access is revoked. The administrator cannot delete their own account.

The separate bulk actions from 1.8.10 remain: **Delete selected non-admins** and **Delete all non-admin users** permanently purge the targeted users' SQLite data and remove their Excel rows, while protecting administrator accounts.

1. Stop the CET Momentum NSSM service. Back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder.
2. Extract this ZIP separately. Copy its `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` to matching application folders. Replace the **entire** deployed `dist` with the ready-built `dist` folder from the ZIP.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`. Close the Excel workbook before editing it through the portal.
4. Restart the service. Confirm `/CETGamification/api/info` reports `"version":"1.8.11"`; refresh the browser with Ctrl+F5 and retry the individual Delete action.

No SQLite schema migration, npm install, npm build, or helper update is required.
