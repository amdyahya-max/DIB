# Deploy CET Momentum 1.8.10

## Bulk cleanup

Administration → Users includes **Delete selected non-admins** and **Delete all non-admin users**. The all action removes every non-admin account in SQLite and every non-admin row in `data/CET_Users.xlsx`, including unsynced rows that were previously blocked by duplicate usernames. Administrator accounts stay in Excel and SQLite even if selected. Selected cleanup also removes duplicate username rows left in the workbook, retaining the first remaining row for each username. Each action has a confirmation screen.

Bulk cleanup removes the targeted users' SQLite attendance, absence, leave, helper, session, enrollment and linked audit records; there is no Removed history row. Individual Delete continues to retain a Removed history record. SQLite journal files, application log files and backups are outside the bulk cleanup. Back up the live workbook and database first.

## Install

1. Stop the CET Momentum NSSM service. Back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder.
2. Extract this ZIP separately. Copy its `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` into their matching folders. Replace the **entire** deployed `dist` with the ZIP's ready-built `dist`.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`. Close the Excel workbook while cleaning it.
4. Restart the service and confirm `/CETGamification/api/info` reports `"version":"1.8.10"`. Refresh the browser with Ctrl+F5. In Administration → Users choose the selected action or the all-non-admin action and review the confirmation before deleting.

No SQLite schema migration, npm install, npm build, or helper update is required.
