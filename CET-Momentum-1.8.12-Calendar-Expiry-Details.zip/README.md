# CET Momentum 1.8.12 portal update

My Calendar now shows the signed-in user's **Account expires on** and **Password expiry** in the compact top position bar. Dates from Excel timestamps appear as calendar dates; `Never` and missing values remain distinct. Individual **Delete** still handles duplicate usernames and retains the selected user's history. **Delete selected non-admins** and **Delete all non-admin users** continue to protect administrator accounts. Follow [deployment/UPDATE-1.8.12.md](deployment/UPDATE-1.8.12.md) to deploy it.

Excel upload updates existing users by email (case insensitive) when a supplied username differs, preserving the existing Windows username and enrolled helper identity. Usernames without a domain receive `dib\` automatically.

Account Expiry accepts dates, ISO timestamps such as `2027-01-01T00:00:00`, `Never`, and blank cells.

The CET Helper remains at 1.2.9. Keep the existing production `.env`, `data`, `storage`, `downloads`, `helper`, `Node`, and `node_modules` folders. Attendance and enrollment data are not included in this ZIP.

The animation runs in the browser. On the Windows Server session, the captured diagnostic reported `reducedMotion: true`, `animation: "none"`, and confirmed that the CSS keyframes were present. CET Race now shows **Animate cars** when the browser asks for reduced motion. Clicking it enables race-car motion for this portal in that browser; **Reduce motion** restores the system preference. Replay restarts the animation.

The portal logs one diagnostic per race view or replay in `STORAGE_DIR/logs/portal.log`, under the `race.diagnostics` event. It reports the browser motion preference, car animation style, keyframe availability, browser visibility, and observed animation activity. Open CET Race with its tab visible and leave it open for about five seconds before checking the log.
