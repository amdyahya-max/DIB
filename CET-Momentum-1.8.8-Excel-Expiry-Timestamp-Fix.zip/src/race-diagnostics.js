// Observe one displayed car per race view. The result is written by the portal,
// so users can report animation problems without opening browser developer tools.
export function observeRaceAnimation({lanes,month,current,query,replay,reducedMotion,animateAnyway}) {
  const region=lanes.current;
  const car=region?.querySelector('.race-car');
  if(!car)return undefined;
  let stopped=false,starts=0,ends=0,cancels=0;
  const timers=[];
  const visibilityAtStart=document.visibilityState;
  const snapshot=()=>{
    if(!car.isConnected)return null;
    const style=getComputedStyle(car),rectangle=car.getBoundingClientRect();
    return {name:style.animationName,duration:style.animationDuration,
      delay:style.animationDelay,state:style.animationPlayState,
      x:Math.round(rectangle.left*10)/10};
  };
  const first=snapshot(),positions=[];
  const handle=e=>{
    if(e.target!==car||e.animationName!=='race-arrive')return;
    if(e.type==='animationstart')starts++;
    if(e.type==='animationend')ends++;
    if(e.type==='animationcancel')cancels++;
  };
  for(const event of ['animationstart','animationend','animationcancel'])
    car.addEventListener(event,handle);
  const inspectKeyframes=()=>{
    let found=false,unreadable=0;
    const inspect=rules=>{
      for(const rule of rules){
        if(rule.name==='race-arrive')found=true;
        if(rule.cssRules)inspect(rule.cssRules);
      }
    };
    for(const sheet of document.styleSheets){
      try{inspect(sheet.cssRules);}catch{unreadable++;}
    }
    return {found,unreadable};
  };
  for(const ms of [120,500,1100,2300,3800])
    timers.push(setTimeout(()=>{const reading=snapshot();if(reading)positions.push(reading.x);},ms));
  timers.push(setTimeout(()=>{
    if(stopped)return;
    const last=snapshot();
    const moved=positions.length>0&&Math.max(...positions)-Math.min(...positions)>1;
    const hidden=visibilityAtStart!=='visible'||document.visibilityState!=='visible';
    const status=reducedMotion&&!animateAnyway&&first?.name==='none'?'suppressed_by_reduced_motion'
      :first?.name==='none'?'animation_style_missing'
      :first?.state==='paused'?'animation_paused'
      :hidden?'tab_hidden_result_inconclusive'
      :starts>0||ends>0||moved?'animation_activity_observed':'no_activity_observed';
    const details={status,month,group:current+1,query:!!query,replay,
      reducedMotion,animateAnyway,visibilityAtStart,visibilityAtEnd:document.visibilityState,
      cars:region.querySelectorAll('.race-car').length,
      keyframes:inspectKeyframes(),animation:first?.name||'no car',
      duration:first?.duration||'',delay:first?.delay||'',state:first?.state||'',
      starts,ends,cancels,moved,initialX:first?.x,finalX:last?.x,
      css:[...document.querySelectorAll('link[rel="stylesheet"]')]
        .map(link=>new URL(link.href).pathname.split('/').pop()).slice(0,3),
      browser:navigator.userAgent.slice(0,90)};
    const path=location.pathname.replace(/\/$/,'')+'/api/client-errors';
    fetch(path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({event:'race.diagnostics',page:location.pathname,message:JSON.stringify(details)})
    }).catch(()=>{});
  },4200));
  return ()=>{
    stopped=true;
    for(const timer of timers)clearTimeout(timer);
    for(const event of ['animationstart','animationend','animationcancel'])
      car.removeEventListener(event,handle);
  };
}
