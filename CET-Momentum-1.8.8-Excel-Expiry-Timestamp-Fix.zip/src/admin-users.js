export const searchFields=[
 ['all','All columns'],['name','Name'],['username','Username'],['employee_id','Employee ID'],['email','Email'],['company','Company'],['title','Title'],['manager','Manager'],['status','Effective status'],['account_expiry','Account expiry'],['portal','Portal access'],['special','Leader'],['admin','Administrator']
];

export function columnText(user,key){
 if(key==='status')return user.portal_status||(!user.roster_active?'Removed':user.status||'');
 if(key==='account_expiry')return user.account_expiry||'Blank (no expiry)';
 if(key==='portal')return user.admin_blocked?'Blocked':user.roster_active&&user.excel_enabled?'Enabled':'Roster blocked';
 if(key==='special')return user.special?'Leader':'Standard';
 if(key==='admin')return user.admin?'Administrator':'Standard';
 return String(user[key]??'');
}

export function filterSortUsers(users,{search='',searchField='all',status='all',sortKey='name',sortDirection='asc'}={}){
 const term=search.trim().toLocaleLowerCase();
 const fields=searchField==='all'?searchFields.filter(([key])=>key!=='all').map(([key])=>key):[searchField];
 return users.filter(user=>(status==='all'?columnText(user,'status')!=='Removed':columnText(user,'status')===status)&&(!term||fields.some(key=>columnText(user,key).toLocaleLowerCase().includes(term))))
  .sort((a,b)=>{
   const aValue=columnText(a,sortKey),bValue=columnText(b,sortKey);
   const compared=aValue.localeCompare(bValue,undefined,{numeric:true,sensitivity:'base'});
   return (sortDirection==='desc'?-compared:compared)||columnText(a,'username').localeCompare(columnText(b,'username'));
  });
}
