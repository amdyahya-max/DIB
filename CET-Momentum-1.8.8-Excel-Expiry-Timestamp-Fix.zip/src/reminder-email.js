export const validEmail=value=>typeof value==='string'&&/^[A-Za-z0-9.!#$'*+/=_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$/.test(value)&&value.length<=254;
export function reminderDrafts(users,report,portalUrl){
 const recipients=[...new Set(users.filter(u=>u.enabled&&(u.current.missing.length||u.previous.missing.length)&&validEmail(u.email)).map(u=>u.email.toLowerCase()))];
 const subject='CET Momentum | Please complete pending attendance confirmations';
 const body=`Dear colleagues,\r\n\r\nOur CET Momentum records show pending attendance confirmations for earlier working days in ${report.currentMonth} and/or ${report.previousMonth}, as of ${report.today} (Dubai time).\r\n\r\nPlease review your calendar, submit any outstanding timesheets in Magnitude, and confirm the corresponding dates in CET Momentum:\r\n${portalUrl}\r\n\r\nIf you were away, please record your absence. For locked dates or discrepancies, contact the CET administrator. If you have already updated your records, thank you and please disregard this reminder.\r\n\r\nThank you for keeping our team records up to date.\r\nCET Administration`;
 const link=emails=>'mailto:'+emails.map(encodeURIComponent).join(',')+'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);
 const batches=[];let current=[];for(const email of recipients){if(current.length&&link([...current,email]).length>1900){batches.push(current);current=[];}current.push(email);}if(current.length)batches.push(current);
 return batches.map(emails=>({emails,subject,body,href:link(emails)}));
}
