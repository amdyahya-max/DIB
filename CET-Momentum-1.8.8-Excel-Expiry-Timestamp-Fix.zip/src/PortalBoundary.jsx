import React from 'react';

export function reportPortalError(event,error,details) {
  return window.CETDiagnostics?.report(event,error,details)||'Please contact your administrator';
}

export class PortalBoundary extends React.Component {
  state={failed:false,reference:''};
  static getDerivedStateFromError(){return {failed:true};}
  componentDidCatch(error,info) {
    const reference=reportPortalError('react.render_failed',error,{stage:'render portal'});
    this.setState({reference});
  }
  render() {
    if(this.state.failed)return <section className="portal-startup" role="alert"><span className="eyebrow">CET MOMENTUM</span><h1>Let’s reload your portal</h1><p>A display error interrupted loading. Your saved attendance is safe.</p><p>Reference: {this.state.reference||'Recording diagnostic details…'}</p><button onClick={()=>location.reload()}>Retry loading</button></section>;
    return this.props.children;
  }
}
