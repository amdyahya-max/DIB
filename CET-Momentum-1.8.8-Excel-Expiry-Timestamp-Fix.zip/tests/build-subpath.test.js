import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');

test('the built portal loads its actual JavaScript and CSS beneath /CETGamification/',()=>{
  const html=fs.readFileSync(path.join(root,'dist','index.html'),'utf8');
  const expectedOrigin='https://dxb01-vwu-afna1.dibuat.ae/CETGamification/';
  const assets=[...html.matchAll(/(?:src|href)="([^"]*assets\/[^\"]+)"/g)].map(match=>match[1]);
  assert.equal(assets.length,2,'Expected the production JavaScript and CSS assets');
  for(const asset of assets){
    assert.ok(asset.startsWith('./assets/'),`Root asset path breaks IIS subpath: ${asset}`);
    const browserPath=new URL(asset,expectedOrigin).pathname;
    assert.ok(browserPath.startsWith('/CETGamification/assets/'),browserPath);
    const localFile=path.join(root,'dist',asset.slice(2));
    assert.ok(fs.statSync(localFile).size>0,`Build file missing: ${asset}`);
  }
  assert.match(fs.readFileSync(path.join(root,'vite.config.js'),'utf8'),/base:\s*['"]\.\/['"]/);
});
