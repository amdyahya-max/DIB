# Deploy CET Momentum 1.8.3 on Windows Server

Portal 1.8.2 served `index.html` from `/CETGamification/`, but its JavaScript and CSS links incorrectly pointed to `/assets/` at the site root. IIS returned missing-file responses, so the standalone startup screen remained open. This ZIP restores Vite's relative base and includes the resulting complete `dist` folder. It also includes the race motion control and diagnostics from 1.8.2.

1. Stop the CET Momentum NSSM service. Back up the current application, including its complete `storage` folder, while stopped.
2. Extract this ZIP to a separate folder. Copy `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` to the matching application folders. **Replace the entire old `dist` folder** with this ZIP's complete `dist` folder. Do not merge old hashed assets or temporary `race-diagnostics.js` into it.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, and `helper`. Keep your working IIS `web.config` and HTTPS binding. No SQLite migration, npm build, or helper update is required.
4. Start the service. Open `https://dxb01-vwu-afna1.dibuat.ae/CETGamification/api/info`; it should show `"version":"1.8.3"`. Refresh the portal with Ctrl+F5 to discard the old 1.8.2 page. The calendar should load, followed by CET Race.
5. In the affected browser, open **CET Race**. If reduced motion is enabled, click **Animate cars** and **Replay car animation**. Keep the tab visible for at least five seconds, then check `<STORAGE_DIR>/logs/portal.log` for `race.diagnostics`. **Reduce motion** restores the system preference.

The corrected HTML links to `./assets/index-...js` and `./assets/index-...css`, which the browser resolves beneath `/CETGamification/`. If the portal still shows a retry screen, use its reference to locate the exact `asset.failed` or other diagnostic record in `portal.log`. A remaining `/assets/...` entry indicates an old 1.8.2 `dist/index.html` or an intermediary serving a cached copy. Confirm the deployed `dist/index.html` contains the relative `./assets/` paths from this ZIP.

To roll back, stop the service and restore the previous application code and complete `dist` folder from your backup. Keep production `data` and `storage`.
