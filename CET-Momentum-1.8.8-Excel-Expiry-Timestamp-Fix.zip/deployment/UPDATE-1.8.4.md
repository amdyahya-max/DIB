# Deploy CET Momentum 1.8.4

The CET Race cars now animate automatically when the race page opens, even when the browser reports reduced motion. The Animate cars button has been removed; Replay car animation remains available. This change affects only the race cars. The build retains relative `./assets/` paths for the IIS `/CETGamification/` subpath.

1. Stop the CET Momentum NSSM service and back up the application and its complete `storage` folder while stopped.
2. Extract the ZIP separately. Copy the supplied `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` into the corresponding application folders. Replace the entire deployed `dist` folder with the supplied `dist` folder.
3. Preserve the production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and working IIS `web.config`. No SQLite migration, npm build, or helper update is required.
4. Restart the service and confirm `/CETGamification/api/info` reports version `1.8.4`. Refresh the browser with Ctrl+F5, open CET Race, and keep the tab visible to see the cars move automatically. Use Replay to see them move again.

The race page explicitly animates cars despite the browser's reduced-motion preference. Administrators should account for users who need limited movement. To roll back, restore the previous application code and complete `dist` folder from the backup while preserving production `data` and `storage`.
