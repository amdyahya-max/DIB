# CET Momentum on Windows Server with IIS reverse proxy

This runbook deploys one Node.js portal process as a Windows service. IIS terminates HTTPS and reverse-proxies to Node on loopback. The portal keeps SQLite on local disk; do not run multiple instances against one SQLite database or put its database on a network share.

## 1. Prepare the server folder

Use a layout like this:

```text
C:\CETMomentum\
  Node\node.exe                 # full Node.js 24 Windows distribution
  server\ src\ dist\ scripts\  # application files from the update package
  data\CET_Users.xlsx           # authoritative roster
  storage\                      # SQLite database
  service-logs\                 # NSSM stdout/stderr logs
```

Copy the application to `C:\CETMomentum`. Extract the full Node.js 24 Windows x64 distribution, including its `node_modules\npm` folder, into `C:\CETMomentum\Node`. Extract the current CET Momentum update over the application files. Put the authoritative `CET_Users.xlsx` in `data`. If migrating existing attendance, stop the old portal cleanly first, then copy the complete `storage` folder and roster; never copy a live SQLite database.

Create the environment file and set the public portal address. Open an elevated PowerShell window in `C:\CETMomentum`:

```powershell
# Fresh complete package already includes .env. Preserve an existing .env.
# Only if .env is missing:
# Copy-Item .env.example .env
notepad .env
```

Set `HOST=127.0.0.1` and `PORT=5000`. For a dedicated IIS hostname set, for example:

```dotenv
PUBLIC_URL=https://cet.example.internal
BASE_PATH=
```

For an IIS application path instead, use:

```dotenv
PUBLIC_URL=https://dxb01-vwu-afna1.dibuat.ae/CETGamification
BASE_PATH=/CETGamification
```

Use the real HTTPS URL, with no trailing slash. The helper must use this same public address. Keep `DATA_DIR=./data` and `STORAGE_DIR=./storage` unless you deliberately use other local paths.

## 2. Validate Node (dependencies included)

The app requires Node.js 24. Install production dependencies with Node's bundled npm JavaScript entry point; this does not call `npm.cmd`:

```powershell
.\Node\node.exe --version
# Complete release: packages are included, so no npm command is needed.
# Only if restoring missing dependencies:
# .\Node\node.exe .\Node\node_modules\npm\bin\npm-cli.js ci --omit=dev --no-audit --no-fund
```

This step needs access to the organization's configured npm registry if dependencies are not already installed. The complete package contains Windows-compatible dependencies and the prebuilt `dist` frontend, so no build step is needed for a normal deployment.

Before installing the service, confirm the roster and local app settings:

```powershell
.\Node\node.exe .\scripts\admin.js grant "DIB\yourusername"
.\Node\node.exe .\scripts\admin.js enroll "DIB\yourusername"
.\Node\node.exe .\server\index.js
```

Replace the sample account with the exact `Username` in the enabled Excel roster. The enrollment command prints a one-time code valid for 24 hours. In another PowerShell window, check `http://127.0.0.1:5000/CETGamification/api/info`. Stop the foreground test with Ctrl+C. The service will create and use the same `storage\cet.sqlite` database when run from this application folder.

## 3. Set least-privilege file permissions

The NSSM setup below runs as `NT AUTHORITY\LocalService`. Create the log directory and grant that identity read/execute access to the app, modify access to the SQLite and service-log folders:

```powershell
New-Item -ItemType Directory -Force .\storage, .\service-logs, .\data\logs | Out-Null
icacls C:\CETMomentum /grant '*S-1-5-19:(OI)(CI)(RX)' /T
icacls C:\CETMomentum\storage /grant '*S-1-5-19:(OI)(CI)(M)' /T
icacls C:\CETMomentum\service-logs /grant '*S-1-5-19:(OI)(CI)(M)' /T
icacls C:\CETMomentum\data\logs /grant '*S-1-5-19:(OI)(CI)(M)' /T
```

The service needs to read `data\CET_Users.xlsx` and watch the `data` directory, read the app and `Node` folders, and write to `storage`, `service-logs` and `data\logs`. Keep roster, SQLite, `.env`, and logs out of the IIS site's physical directory. If your organization requires a gMSA or another service identity, have IT configure it in NSSM and grant the same folder rights to that identity.

## 4. Install and start the Windows service with NSSM

Use your approved NSSM executable. Keep it at a stable path because Windows registers that NSSM executable as the service wrapper. The `CETMomentum.xml.example` file is only for WinSW; it is not used by this NSSM setup. The commands below assume NSSM is at `C:\Tools\nssm\win64\nssm.exe`; change that one path to wherever your existing `nssm.exe` is installed. Run these in **elevated PowerShell**:

```powershell
$nssm = 'C:\Tools\nssm\win64\nssm.exe'
New-Item -ItemType Directory -Force C:\CETMomentum\service-logs | Out-Null
& $nssm install CETMomentum C:\CETMomentum\Node\node.exe C:\CETMomentum\server\index.js
& $nssm set CETMomentum AppDirectory C:\CETMomentum
& $nssm set CETMomentum DisplayName 'CET Momentum Portal'
& $nssm set CETMomentum Description 'CET timesheet confirmation and gamification portal'
& $nssm set CETMomentum Start SERVICE_AUTO_START
& $nssm set CETMomentum ObjectName 'NT AUTHORITY\LocalService' ''
& $nssm set CETMomentum AppStdout C:\CETMomentum\service-logs\portal.out.log
& $nssm set CETMomentum AppStderr C:\CETMomentum\service-logs\portal.err.log
& $nssm set CETMomentum AppRotateFiles 1
& $nssm set CETMomentum AppRotateBytes 10485760
& $nssm set CETMomentum AppStopMethodSkip 0
& $nssm set CETMomentum AppStopMethodConsole 15000
& $nssm set CETMomentum AppExit Default Restart
& $nssm set CETMomentum AppThrottle 1500
& $nssm set CETMomentum AppRestartDelay 10000
& $nssm start CETMomentum
& $nssm status CETMomentum
```

This config runs the process as `NT AUTHORITY\LocalService`, rotates stdout/stderr logs at service restart when they exceed 10 MiB, sends Ctrl+C and waits up to 15 seconds during a normal stop, and restarts the app after an unexpected exit. The application handles Ctrl+C and SIGTERM by closing the roster watcher, HTTP listener, and SQLite connection. NSSM's documented stop sequence sends Ctrl+C first and has forced termination as a last resort. NSSM command names and behavior can vary by version; if a setting is not recognized, open the NSSM GUI with `& $nssm edit CETMomentum` and set the corresponding Application, Log on, I/O, Shutdown, and Exit actions tabs.

If a `CETMomentum` service already exists, stop it and edit its settings instead of installing a duplicate. The application path must be `C:\CETMomentum\Node\node.exe`, arguments `C:\CETMomentum\server\index.js`, and startup directory `C:\CETMomentum`. If NSSM itself is already managing this app under another service name, substitute that exact service name in the commands. To operate the service later:

```powershell
& $nssm stop CETMomentum
& $nssm start CETMomentum
& $nssm restart CETMomentum
& $nssm status CETMomentum
```

For minimum permissions, grant `NT AUTHORITY\LocalService` read/execute on the app and roster, and modify on `storage` and `service-logs` as described in section 3. If your organization uses a different approved service account, configure it in NSSM and grant that account the same access. NSSM itself must remain in its registered location; moving it can prevent Windows from starting the service.

## 5. Configure IIS as the HTTPS reverse proxy

Install IIS URL Rewrite and Application Request Routing (ARR). In IIS Manager, select the server node, open **Application Request Routing Cache → Server Proxy Settings**, and enable **Proxy**. Microsoft documents this reverse-proxy setup in [Reverse Proxy with URL Rewrite and ARR](https://learn.microsoft.com/en-us/iis/extensions/url-rewrite-module/reverse-proxy-with-url-rewrite-v2-and-application-request-routing).

Use a dedicated HTTPS hostname when available. Create an IIS site with an HTTPS binding and the approved certificate. Put only the app's proxy `web.config` in the IIS site's physical folder; use `deployment\web.config.root.example` as `web.config`. It forwards requests to `http://127.0.0.1:5000`.

If you must serve the portal under `/CETGamification`, create that IIS application/virtual directory and use `deployment\web.config.subpath.example` as its `web.config`. Set `BASE_PATH=/CETGamification` and `PUBLIC_URL=https://dxb01-vwu-afna1.dibuat.ae/CETGamification` in `.env`. Do not put the subpath rule at the site root unchanged.

Keep Node bound to `127.0.0.1`; do not expose port 5000 through the firewall. Publish HTTPS through IIS (normally 443) and allow the required network path to IIS. IIS Anonymous Authentication is used by this portal's helper/enrollment flow; Windows Authentication is not the portal's identity mechanism. Users connect CET Helper to the shared HTTPS URL and complete the existing admin approval/enrollment process.

## 6. Verify and operate

- On the server, `Invoke-WebRequest http://127.0.0.1:5000/CETGamification/api/info` should return JSON with version `1.8.0` and the configured `publicUrl`.
- From a client PC, open the HTTPS `PUBLIC_URL`; confirm the browser loads the calendar, the helper connects, and an approved user can confirm attendance.
- Check that an unauthorized or disabled roster account is denied. Verify helper reminders and the IIS-hosted helper download before rollout.
- Monitor `CET Momentum Portal` in Services, `service-logs`, Windows Event Viewer, IIS logs, and the portal's Administration audit page.
- For upgrades, stop the service, back up `.env`, `data`, and `storage`, apply the update, run `npm ci --omit=dev` if package dependencies changed, then start the service and verify `/api/info`.

## References

- NSSM usage, service commands, service account, logging and stop behaviour: https://www.nssm.cc/usage
- NSSM command-line reference: https://nssm.cc/commands
- Microsoft IIS ARR reverse proxy: https://learn.microsoft.com/en-us/iis/extensions/url-rewrite-module/reverse-proxy-with-url-rewrite-v2-and-application-request-routing
