# Deploy CET Momentum 1.8.2 on Windows Server

This is an already-built portal update for CET Momentum 1.8.1. No npm build, helper installation, or SQLite migration is required.

1. Stop the CET Momentum NSSM service. Back up the application and its production `storage` directory while the service is stopped.
2. Extract this ZIP to a separate folder. Copy `server`, `src`, `public`, `index.html`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` into the corresponding application folder. **Replace the old `dist` folder completely** with the supplied `dist` folder. This removes the earlier standalone `race-diagnostics.js` if you applied the temporary Node patch from the chat. The new race diagnostics are built into the frontend.
3. Preserve production `.env`, `data`, `storage`, `downloads`, `helper`, `Node`, and `node_modules`. Do not copy an empty database or roster over production. Keep the existing IIS `web.config` if its CET canonical redirect and proxy rules from 1.8.1 are already working; this update does not change IIS routing.
4. Start the service and open `https://dxb01-vwu-afna1.dibuat.ae/CETGamification/api/info`. Confirm `"version":"1.8.2"`. Refresh any open portal tab with Ctrl+F5 once.
5. Open **CET Race** in the affected browser. If it requests reduced motion, **Animate cars** appears beside **Find my car**. Click it to opt into motion, then click **Replay car animation**. The choice is stored only in that browser. Use **Reduce motion** to turn the override off.
6. Keep the race tab visible for five seconds. Open `<STORAGE_DIR>/logs/portal.log` on the server and search for `race.diagnostics`. Check `status`, `reducedMotion`, `animateAnyway`, `animation`, `starts`, `moved`, `visibilityAtStart`, and `visibilityAtEnd`. A hidden tab makes the activity result inconclusive. Some users have zero monthly progress: their car may animate briefly at the start without moving much distance.

Expected before opting in on the reported Server 2019 browser: `status:suppressed_by_reduced_motion`, `reducedMotion:true`, `animation:none`. Expected after clicking **Animate cars** while the tab is visible: `animation:race-arrive` and `status:animation_activity_observed` when events or movement are detected. Repeated logs can also be collected by opening CET Race again or using Replay.

If the error log cannot be written, give the NSSM service account Modify access to its configured `STORAGE_DIR`. The log excludes query strings and rotates at approximately 5 MiB. Earlier startup/error diagnostics remain available.

To roll back, stop the service and restore the previous code, full `dist` folder, and package metadata from your backup. Retain the production `data` and `storage` folders.
