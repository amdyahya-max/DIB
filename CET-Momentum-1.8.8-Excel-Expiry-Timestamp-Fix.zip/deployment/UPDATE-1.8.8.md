# Deploy CET Momentum 1.8.8

The Account Expiry column in an uploaded or synchronized workbook accepts a date (`2027-01-01`), an ISO timestamp (`2027-01-01T00:00:00`), `Never`, or an empty cell. Timestamps are treated as calendar dates, without a timezone conversion or time-of-day access cutoff. The canonical workbook and SQLite store `2027-01-01` after import. Password Expiry remains a separate, informational roster field.

1. Stop the CET Momentum NSSM service and back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder.
2. Extract this ZIP separately. Copy the supplied `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` to their matching locations. Replace the **entire** deployed `dist` folder with this ZIP's ready-built `dist` folder.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`. The NSSM identity needs write access to the roster workbook and `data` directory. Close the workbook in Excel before an upload.
4. Restart the service. Confirm `/CETGamification/api/info` reports `"version":"1.8.8"`, then refresh the browser with Ctrl+F5 and upload the workbook in Administration → Users.

No SQLite schema migration, npm install, npm build, or helper update is required. Existing attendance and helper enrollment data remain in production.
