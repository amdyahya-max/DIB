# Verification for 1.8.5

- Vite production build completed with `base: './'`, so the generated JavaScript and CSS links resolve under `/CETGamification/`.
- `npm test`: 17 passed, 0 failed.
- Tests cover adding a user to both Excel and SQLite, upload merge by username, preserving access flags and attendance history, retaining users omitted from the uploaded sheet, rejecting malformed or duplicate workbooks, preventing administrator self lockout, and enforcing admin-only API access and same-origin checks.
- The Windows Server IIS/NSSM deployment and Excel file permissions must be checked on the target server.
