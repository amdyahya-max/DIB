# Validation — CET Momentum 1.8.1

- Production frontend built with the existing Vite dependency versions.
- Node 24.19.0: all 14 existing backend/core/Excel/HTTP tests passed, with added checks for lowercase/mixed-case URL normalization, query-string preservation, HEAD requests, missing assets, client-error intake, log redaction and cross-origin rejection.
- Chromium browser checks against the production frontend passed:
  1. `/api/me` completes before delayed `/api/info`: loading screen appears, followed by the calendar without a JavaScript error.
  2. `/api/info` fails once: Retry screen and diagnostic report appear; Retry opens the calendar without a page refresh.
  3. Rendering throws: the error boundary displays a Retry screen and sends a diagnostic report.
  4. The JavaScript bundle fails to load: the standalone startup screen displays a Retry button and captures the failed asset.
- Updated IIS templates parse as valid XML. Actual IIS/ARR behavior and your organisation's server policies must be verified on the Windows server using the deployment checks. This environment does not run IIS.

Helper source/installer and database schema are unchanged.
