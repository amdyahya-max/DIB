# Verification for 1.8.7

- Build retains relative `./assets/` paths for `/CETGamification/` behind IIS.
- `npm test`: 20 passed, 0 failed. Unit tests cover effective status, editing and extending a user, stable SQLite identity and attendance history, delete with Excel row removal, device/session revocation, self deletion prevention, and the Removed filter.
- HTTP tests cover administrator routes, cross-site request rejection, status transitions, and the existing access controls.
- Production IIS/NSSM and workbook permissions must be checked on the Windows Server.
