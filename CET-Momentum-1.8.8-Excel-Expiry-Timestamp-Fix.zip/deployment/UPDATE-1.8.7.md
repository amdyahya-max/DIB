# Deploy CET Momentum 1.8.7

Administration → Users now shows each user's **effective status**: Active, Expired, Disabled, Blocked, or Removed. Expired reflects either an expired account date or Excel status Expired. Edit updates the existing user's roster fields in `CET_Users.xlsx` and SQLite; the Windows username remains fixed because enrolled helpers use it. Extend presents a calendar, sets the roster status to Enabled, and writes the new expiry to Excel and SQLite. An existing admin block stays in place.

Delete removes the user's row from the Excel roster and hides it from the default current-user list. The SQLite record, attendance and audit history remain for reporting. The portal marks the record Removed, revokes helper devices and sessions, and prevents new access. The administrator cannot delete their own account. Use the **Removed** status filter to view archived records. A later authorised Excel import can re-add the user, but the revoked helper will need fresh device approval.

1. Stop the CET Momentum NSSM service and back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder.
2. Extract this ZIP separately. Copy the supplied `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` to the matching application folders. Replace the **entire** deployed `dist` folder with this ZIP's ready-built `dist` folder.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`. The NSSM identity needs write access to the roster workbook and `data` directory. Do not keep the workbook open in Excel while editing or deleting a user.
4. Restart the service. Confirm `/CETGamification/api/info` reports `"version":"1.8.7"`, refresh with Ctrl+F5, then open Administration → Users.

No SQLite schema migration, npm install, npm build, or helper update is required. The new routes require an authenticated administrator and the existing same-origin protection. External edits to the canonical Excel workbook continue to sync; restoring an old workbook that includes a deleted user can re-add that user.
