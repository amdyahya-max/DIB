# Verification for 1.8.6

- Build uses relative `./assets/` paths for the IIS `/CETGamification/` mount.
- `npm test`: 19 passed, 0 failed. This covers blank, Never and dated expiries through Excel, SQLite, access checks, roster upload, and self access protection.
- Tests also cover column-specific search, roster status filtering, and sorting.
- Production IIS/NSSM behavior and workbook permissions require confirmation on the Windows Server.
