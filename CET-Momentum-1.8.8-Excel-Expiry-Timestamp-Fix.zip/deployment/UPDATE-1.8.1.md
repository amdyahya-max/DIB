# CET Momentum 1.8.1 — startup and URL update

This is an already-built update for the existing CET Momentum 1.8.0 package. It includes the changed portal code, complete new `dist` folder, frontend sources and IIS templates. Existing dependencies are sufficient. No npm download, rebuild, helper update or database migration is required.

## Apply on the Windows server

1. Stop the CET Momentum service using Services (`services.msc`) or your NSSM service interface. Back up the existing application and its complete `storage` folder while stopped.
2. Extract this ZIP to a separate temporary folder. From its `CET-Momentum` folder, copy `server`, `src`, `public`, `index.html`, `package.json`, `package-lock.json`, `README.md`, and `tests` over the corresponding application files. Replace the old application `dist` folder with the supplied complete `dist` folder. Copy the supplied `deployment` files into the application deployment folder.
3. Retain the production `.env`, `data`, `storage`, `Node`, `node_modules`, `helper`, `downloads`, and any existing live IIS `web.config` until the next step. This ZIP contains no replacement database, Excel roster, environment file or helper installer.
4. Your existing IIS setup uses a CETGamification application/subfolder. Back up its live `web.config`, then apply the rules from `deployment/web.config` there. If your live file has other settings, merge the two CET rewrite rules rather than discarding those settings. Put the canonical-address redirect above the proxy rule. Do not put the subfolder proxy template in the site root.
5. Verify the existing `.env` has `BASE_PATH=/CETGamification` and `PUBLIC_URL=https://dxb01-vwu-afna1.dibuat.ae/CETGamification`. Keep all other production values. Node remains at `127.0.0.1:5000`; the IIS binding and certificate stay as configured.
6. Start the service. Open each address below. Both should redirect to the canonical `/CETGamification/` address, then show your calendar:
   - `https://dxb01-vwu-afna1.dibuat.ae/cetgamification`
   - `https://dxb01-vwu-afna1.dibuat.ae/cetgamification/`
7. Confirm `https://dxb01-vwu-afna1.dibuat.ae/CETGamification/api/info` displays `"version":"1.8.1"`. Use Ctrl+F5 once after deployment if an open browser tab still has the old version.

An alternative `deployment/web.config.site-root.example` is included only for installations whose CET proxy rules are defined in the IIS site-root file. Merge those CET-only rules into the root file ahead of broad rules, preserving other applications. Use one proxy location. `web.config.root.example` remains the older example for hosting CET at `/`, which is a different configuration.

## What changed

- Calendar rendering waits for validated portal information, even when `/api/me` completes first.
- Initial portal-information requests time out after 12 seconds and display a Retry button with a diagnostic reference.
- A React error boundary displays a Retry screen after a rendering error.
- A small standalone startup script detects failed JavaScript assets and displays a Retry screen after 15 seconds if the interface cannot start.
- Missing static files return HTTP 404 instead of HTML masquerading as a JavaScript module.
- Direct Node browser requests accept any casing of the configured portal root, with or without a trailing slash, and redirect to its canonical path. IIS performs the same normalization before forwarding, because rewriting alone does not change the browser address.
- Query strings are preserved by the redirects. Helper/API POST methods are not changed by the Node page redirect.

## Troubleshoot without F12

Open `storage/logs/portal.log` with Notepad on the server. If `STORAGE_DIR` in `.env` points elsewhere, the file is in `<STORAGE_DIR>/logs/portal.log`.

Useful events are `portal.started`, `startup.api_failed`, `react.render_failed`, `browser.error`, `browser.rejection`, `asset.failed`, `asset.missing`, and `server.request_failed`. Match the reference shown on a user's Retry screen to the `reference` in the log.

Browser error reports are best effort: the user must still be able to reach the portal API for reports to arrive. If Node or IIS is completely unavailable, check the existing IIS and NSSM logs. Helpers continue using the existing helper log files.

The portal retains three bounded log files (`portal.log`, `.1`, `.2`), rotating at approximately 5 MiB per file. Reports omit URL query strings/fragments and redact common secret fields. The service account must have Modify permission on its existing storage folder to write logs.

## Rollback

Stop the service and restore the previous application code, previous complete `dist` folder and previous IIS `web.config`. Keep the production data folders in place. Start the service again. This update does not modify the database schema.
