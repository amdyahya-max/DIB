# Deploy CET Momentum 1.8.6

Account Expiry in **Administration → Users → Manage Excel roster → Add a user** now offers **Blank · no expiry**, **Never expires**, and **Expiry date**. The Excel `Account Expiry` column may contain an actual date, `Never` (case insensitive), or a blank cell. The database preserves `Never` as `Never` and a blank as NULL; both permit access when the user's roster status is Enabled and no separate admin block exists. Dated expiries continue to block access after the date.

The Users list now has a column selector for search, a roster status filter, and sortable column headings. The Account expiry column shows the value, including blank and Never. Existing user add and Excel upload behavior is retained.

1. Stop the CET Momentum NSSM service. Back up the application, including `data/CET_Users.xlsx` and the complete `storage` folder, while stopped.
2. Extract the ZIP into a separate folder. Copy the supplied `server`, `src`, `public`, `index.html`, `vite.config.js`, `package.json`, `package-lock.json`, `README.md`, `tests`, and `deployment` to the corresponding locations. **Replace the complete old `dist` folder** with the supplied ready-built `dist` folder.
3. Preserve production `.env`, `data`, `storage`, `Node`, `node_modules`, `downloads`, `helper`, and the working IIS `web.config`. The NSSM identity needs read/write access to the roster workbook and its parent `data` directory for adding or uploading users. No SQLite migration, npm install, npm build, or helper update is required.
4. Restart the service. Confirm `/CETGamification/api/info` shows `"version":"1.8.6"`, refresh the browser with Ctrl+F5, and check Administration → Users.

The upload still merges by Windows username: matching rows update; users absent from the uploaded file, admin/leader flags, and attendance history are preserved. Newly added users still need helper enrollment or device approval.
