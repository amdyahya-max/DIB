import {token,hash} from './core.js';
export function deviceRequests(router,core,auth,admin){
 const {db}=core;
 db.exec(`CREATE TABLE IF NOT EXISTS device_requests(id TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id),secret_hash TEXT UNIQUE NOT NULL,pc_name TEXT,reference TEXT,created_at TEXT,expires INTEGER,status TEXT,device_id TEXT,decided_by TEXT); CREATE TABLE IF NOT EXISTS device_labels(device_id TEXT PRIMARY KEY REFERENCES devices(id),pc_name TEXT);`);
 const expire=()=>db.prepare("UPDATE device_requests SET status='expired' WHERE status='pending' AND expires<=?").run(Date.now());
 router.post('/api/helper/requests',(req,res)=>{
  expire();const b=req.body,u=db.prepare('SELECT * FROM users WHERE username=?').get(String(b.username||'').trim().toLowerCase());
  if(!core.active(u))return res.status(403).json({error:'Only authorised, enabled CET users may request access.'});
  if(typeof b.secret!=='string'||!/^[a-f0-9]{64}$/.test(b.secret))return res.status(400).json({error:'Invalid installation credential.'});
  const existing=db.prepare('SELECT * FROM device_requests WHERE secret_hash=?').get(hash(b.secret));
  if(existing){if(existing.user_id!==u.id)return res.status(403).json({error:'Account mismatch.'});return res.json({id:existing.id,reference:existing.reference,status:existing.status});}
  if(db.prepare("SELECT count(*) n FROM device_requests WHERE user_id=? AND created_at>?").get(u.id,new Date(Date.now()-86400000).toISOString()).n>=5)return res.status(429).json({error:'Too many device requests today. Contact the administrator.'});
  const id=token(),reference=token().slice(0,8).toUpperCase();
  db.prepare('INSERT INTO device_requests VALUES(?,?,?,?,?,?,?,?,NULL,NULL)').run(id,u.id,hash(b.secret),String(b.pcName||'Unknown PC').slice(0,100),reference,new Date().toISOString(),Date.now()+86400000,'pending');
  core.audit(u.username,'device.request',{id,reference});res.json({id,reference,status:'pending'});
 });
 router.post('/api/helper/requests/status',(req,res)=>{
  expire();const r=db.prepare('SELECT * FROM device_requests WHERE id=? AND secret_hash=?').get(String(req.body.id||''),hash(String(req.body.secret||'')));
  if(!r)return res.status(403).json({error:'Device request not found.'});
  if(!core.active(core.user(r.user_id)))return res.status(403).json({error:'Your portal account is no longer enabled.'});
  const d=r.device_id&&db.prepare('SELECT * FROM devices WHERE id=?').get(r.device_id);
  res.json({status:d?.revoked?'revoked':r.status,reference:r.reference,id:r.device_id});
 });
 router.get('/api/admin/device-requests',auth,admin,(req,res)=>{expire();res.json(db.prepare(`SELECT r.id,r.pc_name,r.reference,r.created_at,r.expires,r.status,r.decided_by,u.name,u.username,(SELECT count(*) FROM devices d WHERE d.user_id=u.id AND d.revoked=0) AS approved_devices FROM device_requests r JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC LIMIT 200`).all());});
 router.post('/api/admin/device-requests/:id/:decision',auth,admin,(req,res)=>{
  expire();if(!['approve','reject'].includes(req.params.decision))return res.status(400).json({error:'Invalid decision.'});
  const r=db.prepare('SELECT * FROM device_requests WHERE id=?').get(req.params.id);
  if(!r||r.status!=='pending')return res.status(409).json({error:'Request is no longer awaiting approval.'});
  const approve=req.params.decision==='approve';if(approve&&!core.active(core.user(r.user_id)))return res.status(403).json({error:'User must be enabled before approval.'});
  const id=approve?token():null;
  db.exec('BEGIN IMMEDIATE');try{
   if(approve){db.prepare('INSERT INTO devices VALUES(?,?,?,?,0)').run(id,r.user_id,r.secret_hash,new Date().toISOString());db.prepare('INSERT INTO device_labels VALUES(?,?)').run(id,r.pc_name);}
   db.prepare('UPDATE device_requests SET status=?,device_id=?,decided_by=? WHERE id=?').run(approve?'approved':'rejected',id,req.user.username,r.id);
   core.audit(req.user.username,'device.request.'+req.params.decision,{id:r.id,deviceId:id});db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  res.json({ok:true});
 });
}
