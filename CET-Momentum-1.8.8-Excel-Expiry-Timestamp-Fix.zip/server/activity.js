import {dubaiNow} from './core.js';
export function attendanceActivity(core, today=dubaiNow().date){
 const currentMonth=today.slice(0,7), prev=new Date(currentMonth+'-01T12:00:00Z');prev.setUTCMonth(prev.getUTCMonth()-1);const previousMonth=prev.toISOString().slice(0,7);
 const summarize=(u,month)=>{const days=core.calendar(u,month).filter(d=>d.date<today);return {expected:days.filter(d=>d.eligible).length,confirmed:days.filter(d=>d.eligible&&d.confirmedAt).length,missing:days.filter(d=>d.eligible&&!d.confirmedAt).map(d=>d.date),activities:days.filter(d=>d.confirmedAt||d.absence).map(d=>({date:d.date,confirmedAt:d.confirmedAt,absence:d.absence}))};};
 return {today,currentMonth,previousMonth,previousMonthAllowed:core.settings().previousMonth,users:core.db.prepare('SELECT * FROM users ORDER BY name').all().map(u=>({id:u.id,name:u.name,username:u.username,email:u.email||'',enabled:core.active(u),current:summarize(u,currentMonth),previous:summarize(u,previousMonth)}))};
}
