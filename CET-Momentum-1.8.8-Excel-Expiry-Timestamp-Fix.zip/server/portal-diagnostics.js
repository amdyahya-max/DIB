import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';

// Keep startup diagnostics separate from the Excel directory and SQLite files.
export function portalDiagnostics(root) {
  const directory=path.resolve(root,process.env.STORAGE_DIR||'storage','logs');
  const file=path.join(directory,'portal.log');
  function clean(value,limit=800) {
    return String(value||'')
      .replace(/(https?:\/\/[^\s?#]+)[?#][^\s]*/gi,'$1[redacted]')
      .replace(/(secret|ticket|token|code|authorization|cookie)(["'\s:=]+)[^\s,;]+/gi,'$1$2[redacted]')
      .slice(0,limit);
  }
  function log(event,details={}) {
    const reference=details.reference||randomUUID();
    const entry={time:new Date().toISOString(),event,reference};
    for(const key of ['stage','message','stack','page','resource','method','version']) {
      if(details[key]) entry[key]=clean(details[key],key==='stack'?2000:800);
    }
    try {
      fs.mkdirSync(directory,{recursive:true});
      if(fs.existsSync(file)&&fs.statSync(file).size>=5*1024*1024) {
        fs.rmSync(file+'.2',{force:true});
        if(fs.existsSync(file+'.1')) fs.renameSync(file+'.1',file+'.2');
        fs.renameSync(file,file+'.1');
      }
      fs.appendFileSync(file,JSON.stringify(entry)+'\r\n','utf8');
    } catch(e) {console.error('Portal diagnostics could not be saved:',e.message);}
    return reference;
  }
  function routes(router) {
    const limits=new Map();
    const events=new Set(['browser.error','browser.rejection','asset.failed','react.render_failed','startup.api_failed','startup.timeout','race.diagnostics']);
    router.post('/api/client-errors',(req,res)=>{
      const key=req.socket.remoteAddress;
      const now=Date.now();
      for(const [k,v] of limits) if(now-v.start>=60000) limits.delete(k);
      const limit=limits.get(key)||{start:now,count:0};limit.count++;limits.set(key,limit);
      if(limit.count>250)return res.status(429).json({error:'Diagnostic limit reached.'});
      const b=req.body;
      if(!b||!events.has(b.event)||typeof b.message!=='string')return res.status(400).json({error:'Invalid diagnostic report.'});
      const reference=typeof b.reference==='string'&&/^[a-zA-Z0-9-]{8,80}$/.test(b.reference)?b.reference:randomUUID();
      log(b.event,{reference,stage:b.stage,message:b.message,stack:b.stack,
        page:String(b.page||'').split(/[?#]/)[0],resource:String(b.resource||'').split(/[?#]/)[0],version:'1.8.8'});
      res.status(202).json({reference});
    });
  }
  return {log,routes,file};
}
