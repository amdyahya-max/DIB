(function () {
  'use strict';
  var prefix=location.pathname.replace(/\/$/,'');
  var sent=0, minute=Date.now();
  function report(event,error,details) {
    if(Date.now()-minute>60000){sent=0;minute=Date.now();}
    var reference=window.crypto&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
    if(sent++>=8)return reference;
    var payload={event:event,reference:reference,message:String(error&&error.message||error||'Unknown error').slice(0,800),
      stack:String(error&&error.stack||'').slice(0,2000),page:location.pathname};
    if(details){payload.stage=details.stage;payload.resource=String(details.resource||'').split(/[?#]/)[0];}
    // This request is best effort: it must never produce another error report.
    var controller=new AbortController();var timeout=setTimeout(function(){controller.abort();},4000);
    fetch(prefix+'/api/client-errors',{method:'POST',credentials:'same-origin',keepalive:true,
      headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal})
      .catch(function(){}).finally(function(){clearTimeout(timeout);});
    return reference;
  }
  window.CETDiagnostics={report:report};
  var reference='';
  window.addEventListener('error',function(e){
    var target=e.target;
    if(target!==window&&target&&(target.src||target.href))reference=report('asset.failed','A portal file could not be loaded.',{resource:target.src||target.href});
    else reference=report('browser.error',e.error||e.message);
  },true);
  window.addEventListener('unhandledrejection',function(e){reference=report('browser.rejection',e.reason);});
  document.addEventListener('DOMContentLoaded',function(){
    var root=document.getElementById('root'),fallback=document.getElementById('portal-startup');
    if(!root||!fallback)return;
    function check(){if(root.childElementCount){fallback.hidden=true;return true;}return false;}
    var observer=new MutationObserver(check);observer.observe(root,{childList:true});check();
    document.getElementById('portal-retry').addEventListener('click',function(){location.reload();});
    setTimeout(function(){if(check())return;
      reference=reference||report('startup.timeout','Portal interface did not start within 15 seconds.');
      document.getElementById('portal-startup-title').textContent='The portal could not start';
      document.getElementById('portal-startup-message').textContent='Please retry. If this continues, share reference '+reference+' with your administrator.';
      document.getElementById('portal-retry').hidden=false;
    },15000);
  });
})();
