PowerCard-Reconciliation-V0.2
=============================

Local FastAPI + SQLite prototype for comparing V2 and V3 records.

V0.2 enhancement
----------------
The UI now has two selections:
1. Environment: PWCORE / PCMOCK
2. Question / Reconciliation Scenario dropdown

Each question can execute different query/filter and comparison logic.
The current SQLite demo includes four sample questions:
- Question 1: card presence comparison
- Question 2: card + client combination comparison
- Question 3: status N records only
- Question 4: status A records only

The question definitions are centralized in:
    app/scenarios.py

This is intentional. When the prototype is moved to Oracle, each scenario can be mapped to its own V2 SQL and V3 SQL without changing the frontend.

API endpoints
-------------
GET  /api/v1/health
GET  /api/v1/environments
GET  /api/v1/scenarios
POST /api/v1/reconcile

Example POST body:
{
  "environment": "PWCORE",
  "scenario": "CARD_PRESENCE"
}

Run
---
Double-click start.bat, or from Command Prompt:
    python\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000

Open:
    http://127.0.0.1:8000
Swagger:
    http://127.0.0.1:8000/docs

Important
---------
The four questions are demo placeholders for local SQLite testing. Replace their labels and query logic in app/scenarios.py with the actual PowerCard business questions and Oracle SQL when those are finalized.
