let selectedEnvironment = "PWCORE";
let selectedScenario = "CARD_PRESENCE";
let matchedRows = [];
let scenarios = [];

const $ = (id) => document.getElementById(id);

function setEnvironment(env) {
  selectedEnvironment = env;
  document.querySelectorAll(".env-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.env === env);
  });
  reconcile();
}

async function apiHealth() {
  try {
    const r = await fetch("/api/v1/health");
    if (!r.ok) throw new Error("Health check failed");
    $("apiState").textContent = "API Online";
    $("apiState").classList.add("online");
  } catch {
    $("apiState").textContent = "API Offline";
    $("apiState").classList.add("offline");
  }
}

async function loadScenarios() {
  const r = await fetch("/api/v1/scenarios");
  const data = await r.json();
  if (!r.ok) throw new Error(data.detail || "Unable to load questions");

  scenarios = data.scenarios || [];
  $("scenarioSelect").innerHTML = scenarios.map(s =>
    `<option value="${s.id}">${s.label}</option>`
  ).join("");

  if (scenarios.length) {
    selectedScenario = scenarios[0].id;
    updateScenarioDescription();
  }
}

function updateScenarioDescription() {
  const item = scenarios.find(s => s.id === selectedScenario);
  $("scenarioDescription").textContent = item ? item.description : "";
}

function renderMatched(rows) {
  const q = $("searchBox").value.trim().toLowerCase();
  const filtered = rows.filter(r =>
    !q ||
    r.cardNumber.toLowerCase().includes(q) ||
    r.clientCode.toLowerCase().includes(q)
  );

  $("matchedBody").innerHTML = filtered.map(r => `
    <tr>
      <td>${r.cardNumber}</td>
      <td>${r.clientCode}</td>
      <td>${r.v2Status}</td>
      <td>${r.v3Status}</td>
    </tr>
  `).join("") || `<tr><td colspan="4" class="empty">No matching records.</td></tr>`;
}

function renderMissing(rows) {
  $("missingBody").innerHTML = rows.map(r => `
    <tr>
      <td>${r.cardNumber}</td>
      <td>${r.clientCode}</td>
      <td>${r.status}</td>
    </tr>
  `).join("") || `<tr><td colspan="3" class="empty">No missing records.</td></tr>`;
}

async function reconcile() {
  $("refreshBtn").disabled = true;
  $("refreshBtn").textContent = "Comparing…";
  try {
    const r = await fetch("/api/v1/reconcile", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        environment: selectedEnvironment,
        scenario: selectedScenario
      })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.detail || "Reconciliation failed");

    $("v2Count").textContent = data.summary.v2Count;
    $("matchedCount").textContent = data.summary.matchedCount;
    $("v2OnlyCount").textContent = data.summary.v2OnlyCount;
    $("missingBadge").textContent = data.summary.v2OnlyCount;

    matchedRows = data.matched;
    renderMatched(matchedRows);
    renderMissing(data.v2Only);

    $("lastRefreshed").textContent =
      `Last refreshed: ${new Date().toLocaleTimeString()}`;
  } catch (e) {
    alert(e.message);
  } finally {
    $("refreshBtn").disabled = false;
    $("refreshBtn").textContent = "Fetch & Compare";
  }
}

document.querySelectorAll(".env-btn").forEach(btn => {
  btn.addEventListener("click", () => setEnvironment(btn.dataset.env));
});

$("scenarioSelect").addEventListener("change", (e) => {
  selectedScenario = e.target.value;
  updateScenarioDescription();
  reconcile();
});

$("refreshBtn").addEventListener("click", reconcile);
$("searchBox").addEventListener("input", () => renderMatched(matchedRows));

$("missingToggle").addEventListener("click", () => {
  const content = $("missingContent");
  const expanded = $("missingToggle").getAttribute("aria-expanded") === "true";
  $("missingToggle").setAttribute("aria-expanded", String(!expanded));
  content.classList.toggle("hidden", expanded);
});

(async function init() {
  await apiHealth();
  try {
    await loadScenarios();
    await reconcile();
  } catch (e) {
    alert(e.message);
  }
})();
