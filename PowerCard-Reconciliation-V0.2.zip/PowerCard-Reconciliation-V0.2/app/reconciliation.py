from .database import get_connection
from .scenarios import SCENARIOS


def _make_key(row, key_mode: str):
    if key_mode == "card_client":
        return f'{row["card_number"]}|{row["client_code"]}'
    return row["card_number"]


def _fetch(environment: str, version: str, scenario_id: str):
    scenario = SCENARIOS[scenario_id]
    sql = f"""
        SELECT card_number, client_code, status
        FROM cards
        WHERE environment = ?
          AND version = ?
          AND {scenario['where_sql']}
        ORDER BY card_number, client_code
    """
    params = (environment, version, *scenario["where_params"])

    with get_connection() as conn:
        rows = conn.execute(sql, params).fetchall()

    unique = {}
    for row in rows:
        key = _make_key(row, scenario["match_key"])
        unique[key] = {
            "cardNumber": row["card_number"],
            "clientCode": row["client_code"],
            "status": row["status"],
        }
    return unique


def reconcile_environment(environment: str, scenario_id: str):
    scenario = SCENARIOS[scenario_id]
    v2 = _fetch(environment, "V2", scenario_id)
    v3 = _fetch(environment, "V3", scenario_id)

    v2_keys = set(v2)
    v3_keys = set(v3)

    matched_keys = sorted(v2_keys & v3_keys)
    v2_only_keys = sorted(v2_keys - v3_keys)
    v3_only_keys = sorted(v3_keys - v2_keys)

    matched = []
    for key in matched_keys:
        matched.append({
            "cardNumber": v2[key]["cardNumber"],
            "clientCode": v2[key]["clientCode"],
            "v2Status": v2[key]["status"],
            "v3Status": v3[key]["status"],
        })

    return {
        "environment": environment,
        "scenario": {
            "id": scenario["id"],
            "label": scenario["label"],
            "description": scenario["description"],
        },
        "summary": {
            "v2Count": len(v2),
            "v3Count": len(v3),
            "matchedCount": len(matched),
            "v2OnlyCount": len(v2_only_keys),
            "v3OnlyCount": len(v3_only_keys),
        },
        "matched": matched,
        "v2Only": [v2[k] for k in v2_only_keys],
        "v3Only": [v3[k] for k in v3_only_keys],
    }
