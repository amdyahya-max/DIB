from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .database import ensure_database
from .reconciliation import reconcile_environment
from .scenarios import SCENARIOS, list_scenarios

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"

app = FastAPI(
    title="PowerCard V2/V3 Reconciliation API",
    version="0.2.0",
    description="Local SQLite prototype with environment and question/scenario-based reconciliation."
)


class ReconcileRequest(BaseModel):
    environment: str
    scenario: str


@app.on_event("startup")
def startup_event():
    ensure_database()


@app.get("/api/v1/health")
def health():
    return {"status": "UP", "version": "0.2.0"}


@app.get("/api/v1/environments")
def environments():
    return {
        "environments": [
            {"id": "PWCORE", "name": "PWCORE"},
            {"id": "PCMOCK", "name": "PCMOCK"},
        ]
    }


@app.get("/api/v1/scenarios")
def scenarios():
    return {"scenarios": list_scenarios()}


@app.post("/api/v1/reconcile")
def reconcile(request: ReconcileRequest):
    environment = request.environment.strip().upper()
    scenario_id = request.scenario.strip().upper()

    if environment not in {"PWCORE", "PCMOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported environment.")
    if scenario_id not in SCENARIOS:
        raise HTTPException(status_code=400, detail="Unsupported question/scenario.")

    return reconcile_environment(environment, scenario_id)


app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")


@app.get("/")
def home():
    return FileResponse(WEB_DIR / "index.html")
