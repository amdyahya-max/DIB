SCENARIOS = {
    "CARD_PRESENCE": {
        "id": "CARD_PRESENCE",
        "label": "Question 1 — Which cards exist in both V2 and V3?",
        "description": "Compares all card records by card number.",
        "where_sql": "1=1",
        "where_params": (),
        "match_key": "card_number",
    },
    "CARD_CLIENT": {
        "id": "CARD_CLIENT",
        "label": "Question 2 — Which card + client combinations match?",
        "description": "Compares using card number and client code together.",
        "where_sql": "1=1",
        "where_params": (),
        "match_key": "card_client",
    },
    "STATUS_N": {
        "id": "STATUS_N",
        "label": "Question 3 — Which status N cards match?",
        "description": "Fetches only records where status = N before comparing.",
        "where_sql": "status = ?",
        "where_params": ("N",),
        "match_key": "card_number",
    },
    "STATUS_A": {
        "id": "STATUS_A",
        "label": "Question 4 — Which status A cards match?",
        "description": "Fetches only records where status = A before comparing.",
        "where_sql": "status = ?",
        "where_params": ("A",),
        "match_key": "card_number",
    },
}

def list_scenarios():
    return [
        {"id": item["id"], "label": item["label"], "description": item["description"]}
        for item in SCENARIOS.values()
    ]
