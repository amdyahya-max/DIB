const endpoint='https://connectjira.dib.ae/planner/rest/api/2/myself';
const $=id=>document.getElementById(id);
$('origin').textContent=location.origin;
let diagnostic={origin:location.origin,endpoint,status:'Not tested'};
function show(state,title,detail){$('state').textContent=state;$('headline').textContent=title;$('detail').textContent=detail;}
$('test').addEventListener('click',async()=>{
 $('test').disabled=true;$('identity').hidden=true;$('identity').textContent='';
 diagnostic={time:new Date().toISOString(),origin:location.origin,endpoint,credentials:'include'};
 show('TESTING','Checking your Jira session…','Waiting up to 15 seconds for the browser request.');
 const control=new AbortController();const timeout=setTimeout(()=>control.abort(),15000);const start=performance.now();
 try{
  const response=await fetch(endpoint,{credentials:'include',headers:{Accept:'application/json'},signal:control.signal});
  diagnostic.httpStatus=response.status;diagnostic.redirected=response.redirected;diagnostic.contentType=response.headers.get('content-type');
  if(response.status===401){show('SIGN-IN REQUIRED','Jira did not authenticate this request','Sign into Jira in the same browser profile and retry. Cookie policies may also prevent your existing session from being sent.');}
  else if(response.status===403){show('FORBIDDEN','Jira rejected the request','Ask the Jira administrator to review permissions and request security controls.');}
  else if(!response.ok){show('HTTP ERROR','Jira returned HTTP '+response.status,'The response was readable, but the API request did not succeed.');}
  else if(!(diagnostic.contentType||'').toLowerCase().includes('json')){show('UNEXPECTED RESPONSE','Received a non-JSON response','This may be a sign-in page or proxy response. Complete Jira sign-in and retry.');}
  else{
   const user=await response.json();
   if(!user||!(user.name||user.key)||typeof user.displayName!=='string'){show('UNEXPECTED JSON','Response did not contain an expected Jira identity','Ask the administrator to review the endpoint response.');}
   else{show('CONNECTED','Your browser can read Jira as you','The localhost origin passed this read-only identity test. Issue permissions, search and write operations still need separate validation.');$('identity').textContent=user.displayName+' · '+(user.name||user.key);$('identity').hidden=false;}
  }
 }catch(error){
  diagnostic.errorType=error.name;
  if(error.name==='AbortError')show('TIMEOUT','No readable response within 15 seconds','Check Jira access and retry. This result alone cannot distinguish network delays from other blockers.');
  else show('BLOCKED OR UNREACHABLE','The browser could not read the Jira response','Possible causes include CORS, cross-site cookie policies, SSO redirects, DNS, network or certificate issues. JavaScript cannot identify the precise cause. Share these diagnostics with your Jira administrator.');
 }finally{clearTimeout(timeout);diagnostic.durationMs=Math.round(performance.now()-start);diagnostic.status=$('state').textContent;diagnostic.note='No cookies, tokens or profile fields collected in this diagnostic.';$('log').textContent=JSON.stringify(diagnostic,null,2);$('test').disabled=false;}
});
$('download').addEventListener('click',()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(diagnostic,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='CET-Jira-Diagnostics.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
