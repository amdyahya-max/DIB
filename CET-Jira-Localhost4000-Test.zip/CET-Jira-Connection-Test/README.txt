CET Jira browser-session connection test

1. Install an organisation-approved Node.js version if needed.
2. Extract the ZIP. Open a terminal in this folder and run: node server.js
   Alternatively double-click Start-Portal.cmd if your organisation allows it.
3. Open http://localhost:4000 in Edge or Chrome.
4. Open Jira from the page, sign in in the same browser profile, return and test.
5. Download diagnostics and share the result. No npm install is required.

The server binds only to 127.0.0.1. Run it on the PC where you open the browser.
If run on Windows Server, localhost refers to that server only when using its browser.
This is a connection test, not the complete intake portal.

CORS: the tested origin is exactly http://localhost:4000.
Jira/proxy configuration must permit this origin with credentials where approved.
http://127.0.0.1:4000 is a different origin: use the stated localhost URL.
Localhost and connectjira.dib.ae are cross-site. Cookie restrictions may block
a valid Jira session even if CORS is configured. Do not disable browser security.
A generic fetch error cannot identify the exact blocker. No no-cors workaround
is used because it would hide the response. Node does not proxy Jira requests.
No Jira credentials, cookies, tokens or demands are stored by the server.
The JSON diagnostic omits personal identity fields.
Use Ctrl+C in the terminal to stop.
