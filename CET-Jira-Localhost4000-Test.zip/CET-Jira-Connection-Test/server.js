const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const routes = {'/':'index.html','/index.html':'index.html','/app.js':'app.js','/style.css':'style.css'};
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
const server=http.createServer((req,res)=>{
 const pathname=new URL(req.url,'http://localhost:4000').pathname;
 if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}
 const file=routes[pathname];
 if(!file){res.writeHead(404);return res.end('Not found');}
 fs.readFile(path.join(__dirname,file),(err,data)=>{
  if(err){res.writeHead(500);return res.end('Unable to load page');}
  res.writeHead(200,{'Content-Type':types[path.extname(file)],'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; connect-src https://connectjira.dib.ae; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"});
  res.end(req.method==='HEAD'?undefined:data);
 });
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Port 4000 is already in use. Close the other application and retry.':e.message);process.exitCode=1;});
server.listen(4000,'127.0.0.1',()=>console.log('CET Jira connection test: http://localhost:4000 — Ctrl+C to stop'));
