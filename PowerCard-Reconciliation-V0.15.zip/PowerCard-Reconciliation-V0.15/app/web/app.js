
async function loadCurrentUser() {
  try {
    const r = await fetch('api/v1/auth/me', { credentials: 'same-origin' });
    if (r.status === 401) { window.location.href = 'login'; return; }
    const j = await r.json();
    if (j.user && j.user.mustChangePassword) { window.location.href = 'change-password'; return; }
    const badge = document.getElementById('userBadge');
    if (badge) badge.textContent = (j.user.displayName || j.user.username) + ' • ' + j.user.role;
    const admin = document.getElementById('adminLink');
    if (admin && j.user.role === 'admin') admin.classList.remove('hidden');
  } catch (e) {}
}

async function logoutCurrentUser() {
  try { await fetch('api/v1/auth/logout', { method: 'POST', credentials: 'same-origin' }); } catch(e) {}
  window.location.href = 'login';
}

document.addEventListener('DOMContentLoaded', function(){
  loadCurrentUser();
  var b=document.getElementById('logoutBtn');
  if(b) b.addEventListener('click', logoutCurrentUser);
});
let environment = 'PWCORE';
let selectedScenario = null;
let selectedScenarioMeta = null;
let lastResult = null;
let filteredMatchedRows = [];
let activeRequest = null;
let requestSequence = 0;
let pendingEnvironment = null;
let environmentCheckInProgress = false;

const $ = id => document.getElementById(id);

async function json(url, options={}) {
  const r = await fetch(url, options);
  let data = {};
  try { data = await r.json(); } catch { data = {}; }
  if (!r.ok) throw new Error(data.detail || `Request failed (${r.status})`);
  return data;
}

function friendlyOracleError(text='') {
  const t=String(text || '');
  if (/ORA-01017|invalid username\/password|logon denied/i.test(t)) return 'Database login failed. Please check the configured username and password.';
  if (/ORA-12154|could not resolve the connect identifier/i.test(t)) return 'Oracle TNS alias could not be resolved. Check TNS_ADMIN and tnsnames.ora.';
  if (/ORA-12514|listener does not currently know of service/i.test(t)) return 'Oracle listener was reached, but the configured service name is not registered.';
  if (/ORA-12541|no listener/i.test(t)) return 'Oracle listener is not reachable on the configured host and port.';
  if (/ORA-12170|timeout|timed out/i.test(t)) return 'Database connection timed out. Check network/VPN access and Oracle host/port connectivity.';
  if (/DPI-1047|cannot locate a 64-bit Oracle Client|Oracle Client library/i.test(t)) return 'Oracle Client could not be loaded. Check ORACLE_CLIENT_LIB_DIR and 64-bit client compatibility.';
  if (/DPY-3010|not supported by python-oracledb in thin mode/i.test(t)) return 'This Oracle database requires Thick mode. Set ORACLE_MODE=thick and configure Oracle Instant Client.';
  return 'The database connection could not be established. Review the technical details and configuration.';
}

function showDbErrorModal(environmentName, health, fallbackError='') {
  const v2Ok=health && health.v2 === true;
  const v3Ok=health && health.v3 === true;
  const errors=[health?.v2Error, health?.v3Error, fallbackError].filter(Boolean);
  $('dbErrorTitle').textContent=`${environmentName} connection failed`;
  $('dbErrorMessage').textContent=friendlyOracleError(errors.join(' | '));
  $('dbStatusGrid').innerHTML=`
    <div class="db-status-item"><strong>V2 Database</strong><span class="db-status-pill ${v2Ok?'ok':'fail'}">${v2Ok?'Connected':'Failed'}</span></div>
    <div class="db-status-item"><strong>V3 Database</strong><span class="db-status-pill ${v3Ok?'ok':'fail'}">${v3Ok?'Connected':'Failed'}</span></div>`;
  const tech=[];
  if(health?.v2Error) tech.push(`V2: ${health.v2Error}`);
  if(health?.v3Error) tech.push(`V3: ${health.v3Error}`);
  if(fallbackError && !tech.length) tech.push(fallbackError);
  $('dbErrorTechnical').textContent=tech.join('\n\n');
  $('dbErrorDetails').classList.toggle('hidden',tech.length===0);
  $('dbErrorModal').classList.remove('hidden');
}

function closeDbErrorModal(){ $('dbErrorModal').classList.add('hidden'); }

async function validateEnvironment(env, button) {
  if (environmentCheckInProgress) return false;
  environmentCheckInProgress=true;
  pendingEnvironment=env;
  if(button) button.classList.add('checking');
  $('autoStatus').textContent=`Checking ${env} database connections…`;
  try{
    const h=await json('api/v1/health');
    if(h.dataSource !== 'oracle') return true;
    const db=await json(`api/v1/oracle-health/${encodeURIComponent(env)}`);
    if(db.v2 === true && db.v3 === true) return true;
    showDbErrorModal(env,db);
    return false;
  }catch(e){
    showDbErrorModal(env,null,e.message);
    return false;
  }finally{
    environmentCheckInProgress=false;
    if(button) button.classList.remove('checking');
  }
}

async function init() {
  try {
    const h = await json('api/v1/health');
    $('health').textContent = `API ${h.status} • v${h.version}`;
    const s = await json('api/v1/scenarios');
    renderQuestions(s.scenarios);
  } catch(e) {
    $('health').textContent = 'API unavailable';
    $('autoStatus').textContent = 'API unavailable';
  }
  $('exportExcelBtn').disabled = true;
  $('copyCardsBtn').disabled = true;
}

function renderQuestions(items) {
  const host = $('questionTiles');
  host.innerHTML='';
  items.forEach((q, i) => {
    const b=document.createElement('button');
    b.className='question-tile';
    b.dataset.id=q.id;
    const status = q.mode === 'guidance' ? 'Guidance' : 'Query + Compare';
    b.innerHTML=`<span class="qno">${i+1}</span><strong>${q.label}</strong><small>${status}</small>`;
    b.onclick=()=>selectQuestion(q, b, true);
    host.appendChild(b);
  });
}

async function selectQuestion(q, button, shouldRun=true) {
  document.querySelectorAll('.question-tile').forEach(x=>x.classList.remove('active','loading'));
  button.classList.add('active');
  selectedScenario=q.id;
  selectedScenarioMeta=q;
  $('questionHelp').textContent=q.description;
  $('guidancePanel').classList.add('hidden');
  if (q.mode !== 'guidance') $('comparisonArea').classList.remove('hidden');
  if (shouldRun) await run(button);
}

document.querySelectorAll('.env-btn').forEach(b=>b.onclick=async()=>{
  const target=b.dataset.env;
  if (environment === target && b.classList.contains('active')) {
    const ok=await validateEnvironment(target,b);
    $('autoStatus').textContent=ok ? `${target} connections verified` : `${target} connection failed`;
    return;
  }

  const ok=await validateEnvironment(target,b);
  if(!ok){
    $('autoStatus').textContent=`${target} not selected — connection failed`;
    return;
  }

  document.querySelectorAll('.env-btn').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  environment=target;
  $('autoStatus').textContent=`${target} connected`;
  if (selectedScenario) {
    const tile=document.querySelector(`.question-tile[data-id="${selectedScenario}"]`);
    await run(tile);
  } else {
    $('autoStatus').textContent=`${target} connected — select a question`;
  }
});

async function run(tile) {
  if(!selectedScenario) return;
  const guidanceMode = selectedScenarioMeta && selectedScenarioMeta.mode === 'guidance';
  const seq=++requestSequence;

  if (activeRequest) activeRequest.abort();
  activeRequest = new AbortController();
  document.querySelectorAll('.question-tile').forEach(x=>x.classList.remove('loading'));
  if (tile) tile.classList.add('loading');

  $('exportExcelBtn').disabled=true;
  $('copyCardsBtn').disabled=true;
  $('autoStatus').textContent = guidanceMode ? 'Loading guidance…' : `Fetching ${selectedScenarioMeta.label}…`;
  $('resultMessage').textContent = guidanceMode ? '' : 'Fetching V2 data and reconciling against V3…';

  try {
    const data=await json('api/v1/reconcile',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({environment,scenario:selectedScenario}),
      signal:activeRequest.signal
    });
    if (seq !== requestSequence) return;
    lastResult=data;
    renderResult(data);
    $('autoStatus').textContent = guidanceMode ? 'Guidance loaded' : 'Result refreshed automatically';
  } catch(e) {
    if (e.name === 'AbortError') return;
    if (seq !== requestSequence) return;
    lastResult=null;
    filteredMatchedRows=[];
    $('resultMessage').textContent=e.message;
    $('autoStatus').textContent='Fetch failed — select the question to retry';
    if (/ORA-|DPY-|DPI-|database|connect|login|listener|TNS/i.test(e.message)) {
      showDbErrorModal(environment,null,e.message);
    }
  } finally {
    if (seq === requestSequence) {
      if (tile) tile.classList.remove('loading');
      activeRequest=null;
      $('exportExcelBtn').disabled=!lastResult || lastResult.mode === 'guidance' || filteredMatchedRows.length===0;
      $('copyCardsBtn').disabled=!lastResult || lastResult.mode === 'guidance' || filteredMatchedRows.length===0;
    }
  }
}

function renderResult(d) {
  if (d.mode === 'guidance') {
    $('comparisonArea').classList.add('hidden');
    $('guidancePanel').classList.remove('hidden');
    $('guidanceTitle').textContent=d.guidance.title;
    $('creditGuidance').innerHTML=d.guidance.credit.map(x=>`<li>${x}</li>`).join('');
    $('debitGuidance').innerHTML=d.guidance.debit.map(x=>`<li>${x}</li>`).join('');
    $('guidanceNote').textContent=d.guidance.note;
    resetStats();
    filteredMatchedRows=[];
    return;
  }
  $('guidancePanel').classList.add('hidden');
  $('comparisonArea').classList.remove('hidden');
  const s=d.summary;
  ['v2Count','v3Count','matchedCount','v2OnlyCount','v3OnlyCount'].forEach(k=>$(k).textContent=s[k]);
  $('v2OnlyLabel').textContent=s.v2OnlyCount;
  $('v3OnlyLabel').textContent=s.v3OnlyCount;
  $('resultTitle').textContent=`${d.scenario.label} — ${d.environment}`;
  $('resultMessage').textContent='V2 population fetched, V3 lookup completed, and card numbers reconciled.';
  fillMatched(d.matched);
  fillSingle('v2OnlyBody',d.v2Only);
  fillSingle('v3OnlyBody',d.v3Only);
  filteredMatchedRows = [...d.matched];
  $('searchBox').value='';
  $('exportExcelBtn').disabled=filteredMatchedRows.length===0;
  $('copyCardsBtn').disabled=filteredMatchedRows.length===0;
}

function resetStats(){
  ['v2Count','v3Count','matchedCount','v2OnlyCount','v3OnlyCount'].forEach(k=>$(k).textContent='0');
  $('v2OnlyLabel').textContent='0';
  $('v3OnlyLabel').textContent='0';
}

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function statusLabel(v){const raw=String(v??'').trim().toUpperCase(); if(raw==='N') return 'Active'; return raw || '';}
function fillMatched(rows) {$('matchedBody').innerHTML=rows.map(r=>`<tr><td>${esc(r.cardNumber)}</td><td>${esc(r.clientCode)}</td><td><span class="status-active">${esc(statusLabel(r.v2Status))}</span></td><td><span class="status-active">${esc(statusLabel(r.v3Status))}</span></td><td>${esc(r.productType)}</td><td>${esc(r.primaryCard)}</td></tr>`).join('') || '<tr><td colspan="6">No matched records</td></tr>';}
function fillSingle(id,rows) {$(id).innerHTML=rows.map(r=>`<tr><td>${esc(r.cardNumber)}</td><td>${esc(r.clientCode)}</td><td>${esc(statusLabel(r.status))}</td><td>${esc(r.productType)}</td><td>${esc(r.primaryCard)}</td></tr>`).join('') || '<tr><td colspan="5">No records</td></tr>';}

function applyMatchedFilter() {
  if(!lastResult || lastResult.mode === 'guidance') { filteredMatchedRows=[]; return; }
  const q=$('searchBox').value.trim().toLowerCase();
  filteredMatchedRows = lastResult.matched.filter(r => {
    const hay=[r.cardNumber,r.clientCode,r.v2Status,r.v3Status,statusLabel(r.v2Status),statusLabel(r.v3Status),r.productType,r.primaryCard]
      .map(v=>String(v??'').toLowerCase()).join(' ');
    return !q || hay.includes(q);
  });
  fillMatched(filteredMatchedRows);
  $('copyCardsBtn').disabled=filteredMatchedRows.length===0;
  $('exportExcelBtn').disabled=filteredMatchedRows.length===0;
  $('resultMessage').textContent = q
    ? `${filteredMatchedRows.length} of ${lastResult.matched.length} matched records shown after filter.`
    : 'V2 population fetched, V3 lookup completed, and card numbers reconciled.';
}

$('copyCardsBtn').onclick=async()=>{
  if(!lastResult || lastResult.mode === 'guidance' || !filteredMatchedRows.length) return;
  const cards=[...new Set(filteredMatchedRows.map(x=>x.cardNumber).filter(Boolean))];
  await navigator.clipboard.writeText(cards.join('\n'));
  $('copyCardsBtn').textContent=`Copied ${cards.length}`;
  setTimeout(()=>$('copyCardsBtn').textContent='Copy Cards',1200);
};

$('exportExcelBtn').onclick=async()=>{
  if(!lastResult || lastResult.mode==='guidance' || !filteredMatchedRows.length) return;
  const btn=$('exportExcelBtn');
  const old=btn.textContent;
  btn.disabled=true;
  btn.textContent='Preparing…';
  try{
    const r=await fetch('api/v1/export-excel',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        environment:lastResult.environment,
        scenario:lastResult.scenario.id,
        records:filteredMatchedRows,
        filterText:$('searchBox').value.trim()
      })
    });
    if(!r.ok){let d={};try{d=await r.json()}catch{};throw new Error(d.detail||'Excel export failed');}
    const blob=await r.blob();
    const cd=r.headers.get('content-disposition')||'';
    const m=cd.match(/filename="?([^";]+)"?/i);
    const filename=m?m[1]:`PowerCard_${lastResult.environment}_${lastResult.scenario.id}_matched.xlsx`;
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url;
    a.download=filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }catch(e){alert(e.message);}finally{btn.disabled=filteredMatchedRows.length===0;btn.textContent=old;}
};

$('searchBox').oninput=applyMatchedFilter;
$('dbErrorClose').onclick=closeDbErrorModal;
$('dbErrorModal').onclick=e=>{ if(e.target === $('dbErrorModal')) closeDbErrorModal(); };
document.addEventListener('keydown',e=>{ if(e.key==='Escape') closeDbErrorModal(); });
$('dbErrorRetry').onclick=async()=>{
  closeDbErrorModal();
  const env=pendingEnvironment || environment;
  const btn=document.querySelector(`.env-btn[data-env="${env}"]`);
  const ok=await validateEnvironment(env,btn);
  if(ok){
    document.querySelectorAll('.env-btn').forEach(x=>x.classList.remove('active'));
    if(btn) btn.classList.add('active');
    environment=env;
    $('autoStatus').textContent=`${env} connected`;
    if(selectedScenario){
      const tile=document.querySelector(`.question-tile[data-id="${selectedScenario}"]`);
      await run(tile);
    }
  } else {
    $('autoStatus').textContent=`${env} connection failed`;
  }
};
init();
