"""Service-friendly entry point for the PowerCard Reconciliation API.

This file is intentionally BAT-free. It can be launched directly with the
portable Python executable or configured as the executable argument for a
Windows service wrapper such as NSSM.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Always work relative to this project, even when Windows Service Control
# Manager starts the process from C:\Windows\System32.
ROOT_DIR = Path(__file__).resolve().parent
os.chdir(ROOT_DIR)
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Import config after cwd/sys.path are fixed. app.config loads project-root .env.
from app.config import app_base_path, data_source, oracle_mode  # noqa: E402


def _env_int(name: str, default: int, minimum: int = 1, maximum: int = 65535) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer; received {raw!r}") from exc
    if not minimum <= value <= maximum:
        raise RuntimeError(f"{name} must be between {minimum} and {maximum}")
    return value


def main() -> None:
    try:
        import uvicorn
    except ImportError as exc:
        raise RuntimeError("Uvicorn is not installed. Install requirements.txt first.") from exc

    host = os.getenv("API_HOST", "127.0.0.1").strip() or "127.0.0.1"
    port = _env_int("API_PORT", 8000)
    workers = _env_int("API_WORKERS", 1, 1, 16)
    log_level = os.getenv("API_LOG_LEVEL", "info").strip().lower() or "info"

    print("=" * 72, flush=True)
    print("PowerCard Reconciliation API v0.15.0", flush=True)
    print(f"Project directory : {ROOT_DIR}", flush=True)
    print(f"Data source       : {data_source()}", flush=True)
    if data_source() == "oracle":
        print(f"Oracle mode       : {oracle_mode()}", flush=True)
    print(f"Listen address    : http://{host}:{port}", flush=True)
    print(f"Published base    : {app_base_path() or '/'}", flush=True)
    print(f"Workers           : {workers}", flush=True)
    print("=" * 72, flush=True)

    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        workers=workers,
        log_level=log_level,
        access_log=True,
    )


if __name__ == "__main__":
    main()
