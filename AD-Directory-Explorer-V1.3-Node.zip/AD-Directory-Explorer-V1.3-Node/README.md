# AD Directory Explorer V1.3 — Node

## Fix in V1.3

V1.2 used a PowerShell helper function named `FT`. On Windows PowerShell, `ft` is a built-in alias for `Format-Table`. Because aliases take precedence over functions, account-expiry values were accidentally being sent to `Format-Table`, producing an error similar to:

```text
FT : Cannot convert System.Int64...
FullyQualifiedErrorId : DictionaryKeyUnknownType,Microsoft.PowerShell.Commands.FormatTableCommand
```

V1.3 renames the helper to `Convert-FileTimeIso` and also makes manager lookup more defensive.

Start as before:

```text
node server.js
```

Then browse to:

```text
http://localhost:8085
```

This version is designed for corporate Windows environments where:

- `.ps1` execution is blocked
- `.cmd` files are blocked
- Node.js itself is permitted
- NPM installation is restricted

The application runs with:

```text
node server.js
```

No NPM packages are required.

## Start

1. Extract the ZIP.
2. Open PowerShell or Command Prompt in the extracted folder.
3. Run:

```text
node server.js
```

4. Open:

```text
http://localhost:8085
```

5. Stop with `Ctrl+C`.

## How it works

Node hosts the local web application. For each read-only AD request, Node calls:

```text
powershell.exe -NoProfile -NonInteractive -Command <inline command>
```

The PowerShell commands use `System.DirectoryServices`, the same technique already proven to work on your PC.

No `.ps1` script is executed.

## Security

- Binds only to `127.0.0.1`
- Read-only directory searches
- Uses your current Windows identity
- No stored AD password
- No database
- No arbitrary LDAP endpoint exposed