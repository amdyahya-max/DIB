PowerCard Reconciliation V0.4
=============================

What changed
------------
1. All four business query questions are now executable in the local SQLite prototype:
   - Active Credit Cards
   - Active Debit Cards
   - CIF with Primary Card & No Supplementary Card
   - CIF with Primary + Supplementary Cards
2. Each selected question applies its own query logic independently to V2 and V3 and then reconciles by card number.
3. The supplementary-card question displays the related primary card where available.
4. "Create New Debit or Credit Card" is guidance-only. It does not execute SQL and does not perform V2/V3 comparison.
5. The SQLite schema now includes fields needed to simulate primary/supplementary relationships.

Run
---
1. Keep portable Python under .\python\python.exe
2. Double-click start.bat
3. Open http://127.0.0.1:8000
4. API docs: http://127.0.0.1:8000/docs

Important
---------
This is still a local SQLite simulation. For Oracle V0.5, the repository layer should be replaced with python-oracledb/TNS and the approved Oracle SQL should be mapped to each question for V2 and V3.
