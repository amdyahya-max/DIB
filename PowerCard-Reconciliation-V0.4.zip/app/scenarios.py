SCENARIOS = {
    "ACTIVE_CREDIT_CARDS": {
        "id": "ACTIVE_CREDIT_CARDS",
        "label": "Active Credit Cards",
        "description": "Fetch active delivered credit cards created in the last 180 days, then compare V2 vs V3.",
        "mode": "compare",
        "implemented": True,
        "sqlite_where": """
            status_code = 'N'
            AND delivery_card_flag = 'Y'
            AND product_type = 'CR'
            AND date_create_days_ago <= 180
            AND status_reason_code = 'SN'
            AND unpaid_status = '0'
            AND administrative_status = '0'
        """,
        "match_key": "card_number",
    },
    "ACTIVE_DEBIT_CARDS": {
        "id": "ACTIVE_DEBIT_CARDS",
        "label": "Active Debit Cards",
        "description": "Fetch active delivered debit cards created in the last 180 days, then compare V2 vs V3.",
        "mode": "compare",
        "implemented": True,
        "sqlite_where": """
            status_code = 'N'
            AND delivery_card_flag = 'Y'
            AND product_type = 'DC'
            AND date_create_days_ago <= 180
        """,
        "match_key": "card_number",
    },
    "PRIMARY_NO_SUPP": {
        "id": "PRIMARY_NO_SUPP",
        "label": "CIF with Primary Card & No Supplementary Card",
        "description": "Fetch active credit-card CIFs that have a primary card and no supplementary card, then compare V2 vs V3.",
        "mode": "compare",
        "implemented": True,
        "custom_sqlite_query": "PRIMARY_NO_SUPP",
        "match_key": "card_number",
    },
    "CIF_WITH_SUPP": {
        "id": "CIF_WITH_SUPP",
        "label": "CIF with Primary + Supplementary Cards",
        "description": "Fetch active credit-card CIFs with supplementary-card relationships, then compare V2 vs V3.",
        "mode": "compare",
        "implemented": True,
        "custom_sqlite_query": "CIF_WITH_SUPP",
        "match_key": "card_number",
    },
    "CREATE_NEW_CARD": {
        "id": "CREATE_NEW_CARD",
        "label": "Create New Debit or Credit Card",
        "description": "Guidance only. No database comparison is executed for this option.",
        "mode": "guidance",
        "implemented": True,
        "guidance": {
            "title": "Create New Debit or Credit Card",
            "credit": [
                "FINNONE — Create a new covered/credit-card application, create CIF and account number, create the application ID, and generate the LOS requestor file.",
                "OA job — Move the requestor file to PowerCard.",
                "PowerCard — Execute the required batches and generate the card. Coordinate with the Cards GBO team as required."
            ],
            "debit": [
                "T24 — Create a new debit-card request (with or without cheque book), including CIF and account number.",
                "Execute the ETL job — Load customer/account data and generate the debit-card requestor file for UAT.",
                "OA job — Move the requestor file to PowerCard.",
                "PowerCard — Execute the required batches and generate the card. Coordinate with the Cards GBO team as required."
            ],
            "note": "This option displays process guidance only; it does not run V2/V3 SQL or perform reconciliation."
        }
    },
}


def list_scenarios():
    return [
        {
            "id": item["id"],
            "label": item["label"],
            "description": item["description"],
            "implemented": item.get("implemented", False),
            "mode": item.get("mode", "compare"),
        }
        for item in SCENARIOS.values()
    ]
