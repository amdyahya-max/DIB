from .database import get_connection
from .scenarios import SCENARIOS


def _row_to_item(row):
    return {
        "cardNumber": row["card_number"],
        "clientCode": row["client_code"],
        "status": row["status_code"],
        "productType": row["product_type"],
        "primaryCard": row["basic_card_number"] if "basic_card_number" in row.keys() else None,
    }


def _fetch_standard(environment: str, version: str, scenario):
    sql = f"""
        SELECT card_number, client_code, status_code, product_type, basic_card_number
        FROM cards
        WHERE environment = ?
          AND version = ?
          AND {scenario['sqlite_where']}
        ORDER BY client_code, card_number
    """
    with get_connection() as conn:
        return conn.execute(sql, (environment, version)).fetchall()


def _fetch_primary_no_supp(environment: str, version: str):
    # SQLite equivalent of the supplied Oracle query:
    # active CR card, active/healthy shadow-account simulation, primary account,
    # shadow age <= 300 days, card age <= 180 days, and fewer than 2 cards for CIF.
    sql = """
        SELECT c.card_number, c.client_code, c.status_code, c.product_type, c.basic_card_number
        FROM cards c
        WHERE c.environment = ?
          AND c.version = ?
          AND c.status_code = 'N'
          AND c.delivery_card_flag = 'Y'
          AND c.product_type = 'CR'
          AND c.date_create_days_ago <= 180
          AND c.status_reason_code = 'SN'
          AND c.unpaid_status = '0'
          AND c.administrative_status = '0'
          AND c.primary_shadow_account_nbr IS NULL
          AND c.date_create_days_ago <= 300
          AND c.client_code IN (
              SELECT x.client_code
              FROM cards x
              WHERE x.environment = ? AND x.version = ?
              GROUP BY x.client_code
              HAVING COUNT(*) < 2
          )
        ORDER BY c.client_code ASC, c.card_number ASC
    """
    with get_connection() as conn:
        return conn.execute(sql, (environment, version, environment, version)).fetchall()


def _fetch_cif_with_supp(environment: str, version: str):
    # SQLite equivalent of the supplied Oracle query:
    # active CR cards for CIFs having a supplementary-card shadow relationship.
    # The original query returns basic_card_number as the primary card reference.
    sql = """
        SELECT c.card_number, c.client_code, c.status_code, c.product_type, c.basic_card_number
        FROM cards c
        WHERE c.environment = ?
          AND c.version = ?
          AND c.status_code = 'N'
          AND c.delivery_card_flag = 'Y'
          AND c.product_type = 'CR'
          AND c.date_create_days_ago <= 180
          AND c.client_code IN (
              SELECT DISTINCT x.client_code
              FROM cards x
              WHERE x.environment = ?
                AND x.version = ?
                AND x.primary_shadow_account_nbr IS NOT NULL
                AND x.date_create_days_ago <= 500
                AND x.status_reason_code = 'SN'
                AND x.unpaid_status = '0'
                AND x.administrative_status = '0'
          )
        ORDER BY c.client_code DESC, c.card_number ASC
    """
    with get_connection() as conn:
        return conn.execute(sql, (environment, version, environment, version)).fetchall()


def _fetch(environment: str, version: str, scenario_id: str):
    scenario = SCENARIOS[scenario_id]
    custom = scenario.get("custom_sqlite_query")
    if custom == "PRIMARY_NO_SUPP":
        rows = _fetch_primary_no_supp(environment, version)
    elif custom == "CIF_WITH_SUPP":
        rows = _fetch_cif_with_supp(environment, version)
    else:
        rows = _fetch_standard(environment, version, scenario)

    unique = {}
    for row in rows:
        item = _row_to_item(row)
        unique[item["cardNumber"]] = item
    return unique


def reconcile_environment(environment: str, scenario_id: str):
    scenario = SCENARIOS[scenario_id]

    if scenario.get("mode") == "guidance":
        return {
            "environment": environment,
            "scenario": {k: scenario[k] for k in ("id", "label", "description", "mode")},
            "configured": True,
            "mode": "guidance",
            "guidance": scenario["guidance"],
            "summary": {"v2Count": 0, "v3Count": 0, "matchedCount": 0, "v2OnlyCount": 0, "v3OnlyCount": 0},
            "matched": [], "v2Only": [], "v3Only": [],
        }

    v2 = _fetch(environment, "V2", scenario_id)
    v3 = _fetch(environment, "V3", scenario_id)

    v2_keys, v3_keys = set(v2), set(v3)
    matched_keys = sorted(v2_keys & v3_keys)
    v2_only_keys = sorted(v2_keys - v3_keys)
    v3_only_keys = sorted(v3_keys - v2_keys)

    matched = [{
        "cardNumber": v2[k]["cardNumber"],
        "clientCode": v2[k]["clientCode"],
        "v2Status": v2[k]["status"],
        "v3Status": v3[k]["status"],
        "productType": v2[k]["productType"],
        "primaryCard": v2[k].get("primaryCard") or v3[k].get("primaryCard"),
    } for k in matched_keys]

    return {
        "environment": environment,
        "scenario": {k: scenario[k] for k in ("id", "label", "description", "mode")},
        "configured": True,
        "mode": "compare",
        "summary": {
            "v2Count": len(v2), "v3Count": len(v3), "matchedCount": len(matched),
            "v2OnlyCount": len(v2_only_keys), "v3OnlyCount": len(v3_only_keys),
        },
        "matched": matched,
        "v2Only": [v2[k] for k in v2_only_keys],
        "v3Only": [v3[k] for k in v3_only_keys],
    }
