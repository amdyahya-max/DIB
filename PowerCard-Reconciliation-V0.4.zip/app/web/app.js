let environment = 'PWCORE';
let selectedScenario = null;
let selectedScenarioMeta = null;
let lastResult = null;

const $ = id => document.getElementById(id);

async function json(url, options={}) {
  const r = await fetch(url, options);
  const data = await r.json();
  if (!r.ok) throw new Error(data.detail || 'Request failed');
  return data;
}

async function init() {
  try {
    const h = await json('/api/v1/health');
    $('health').textContent = `API ${h.status} • v${h.version}`;
    const s = await json('/api/v1/scenarios');
    renderQuestions(s.scenarios);
  } catch(e) { $('health').textContent = 'API unavailable'; }
}

function renderQuestions(items) {
  const host = $('questionTiles'); host.innerHTML='';
  items.forEach((q, i) => {
    const b=document.createElement('button');
    b.className='question-tile';
    b.dataset.id=q.id;
    const status = q.mode === 'guidance' ? 'Guidance' : 'Query + Compare';
    b.innerHTML=`<span class="qno">${i+1}</span><strong>${q.label}</strong><small>${status}</small>`;
    b.onclick=()=>selectQuestion(q, b);
    host.appendChild(b);
  });
  if(items.length) host.querySelector(`[data-id="${items[0].id}"]`).click();
}

function selectQuestion(q, button) {
  document.querySelectorAll('.question-tile').forEach(x=>x.classList.remove('active'));
  button.classList.add('active');
  selectedScenario=q.id;
  selectedScenarioMeta=q;
  $('questionHelp').textContent=q.description;
  $('searchBtn').textContent = q.mode === 'guidance' ? 'Show Guidance' : 'Search, Fetch & Compare';
  $('guidancePanel').classList.add('hidden');
  if (q.mode !== 'guidance') $('comparisonArea').classList.remove('hidden');
}

document.querySelectorAll('.env-btn').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('.env-btn').forEach(x=>x.classList.remove('active'));
  b.classList.add('active'); environment=b.dataset.env;
});

$('searchBtn').onclick=run;
async function run() {
  if(!selectedScenario) return;
  const guidanceMode = selectedScenarioMeta && selectedScenarioMeta.mode === 'guidance';
  $('searchBtn').disabled=true;
  $('searchBtn').textContent=guidanceMode ? 'Loading guidance…' : 'Fetching V2 + V3 and comparing…';
  try {
    const data=await json('/api/v1/reconcile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({environment,scenario:selectedScenario})});
    lastResult=data;
    renderResult(data);
  } catch(e) { $('resultMessage').textContent=e.message; }
  finally {
    $('searchBtn').disabled=false;
    $('searchBtn').textContent=guidanceMode ? 'Show Guidance' : 'Search, Fetch & Compare';
  }
}

function renderResult(d) {
  if (d.mode === 'guidance') {
    $('comparisonArea').classList.add('hidden');
    $('guidancePanel').classList.remove('hidden');
    $('guidanceTitle').textContent=d.guidance.title;
    $('creditGuidance').innerHTML=d.guidance.credit.map(x=>`<li>${x}</li>`).join('');
    $('debitGuidance').innerHTML=d.guidance.debit.map(x=>`<li>${x}</li>`).join('');
    $('guidanceNote').textContent=d.guidance.note;
    return;
  }

  $('guidancePanel').classList.add('hidden');
  $('comparisonArea').classList.remove('hidden');
  const s=d.summary;
  ['v2Count','v3Count','matchedCount','v2OnlyCount','v3OnlyCount'].forEach(k=>$(k).textContent=s[k]);
  $('v2OnlyLabel').textContent=s.v2OnlyCount; $('v3OnlyLabel').textContent=s.v3OnlyCount;
  $('resultTitle').textContent=`${d.scenario.label} — ${d.environment}`;
  $('resultMessage').textContent='The selected business query was executed independently against V2 and V3, then the returned card records were reconciled by card number.';
  fillMatched(d.matched); fillSingle('v2OnlyBody',d.v2Only); fillSingle('v3OnlyBody',d.v3Only);
}

function fillMatched(rows) {
  $('matchedBody').innerHTML=rows.map(r=>`<tr><td>${r.cardNumber}</td><td>${r.clientCode}</td><td>${r.v2Status}</td><td>${r.v3Status}</td><td>${r.productType||''}</td><td>${r.primaryCard||''}</td></tr>`).join('') || '<tr><td colspan="6">No matched records</td></tr>';
}
function fillSingle(id,rows) {
  $(id).innerHTML=rows.map(r=>`<tr><td>${r.cardNumber}</td><td>${r.clientCode}</td><td>${r.status}</td><td>${r.productType||''}</td><td>${r.primaryCard||''}</td></tr>`).join('') || '<tr><td colspan="5">No records</td></tr>';
}

$('copyCardsBtn').onclick=async()=>{
  if(!lastResult || lastResult.mode === 'guidance') return;
  const cards=[...lastResult.matched,...lastResult.v2Only,...lastResult.v3Only].map(x=>x.cardNumber);
  await navigator.clipboard.writeText([...new Set(cards)].join('\n'));
  $('copyCardsBtn').textContent='Copied'; setTimeout(()=>$('copyCardsBtn').textContent='Copy Card Numbers',1200);
};

$('searchBox').oninput=e=>{
  const q=e.target.value.toLowerCase();
  document.querySelectorAll('tbody tr').forEach(tr=>tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none');
};

init();
