@echo off
setlocal
cd /d "%~dp0"

echo.
echo ============================================
echo  PowerCard Reconciliation V0.1
echo ============================================
echo.

if not exist "python\python.exe" (
  echo ERROR: python\python.exe was not found.
  echo Copy/extract your portable Python into the "python" folder first.
  echo.
  pause
  exit /b 1
)

echo Starting API on http://127.0.0.1:8000
echo Swagger API docs: http://127.0.0.1:8000/docs
echo Press CTRL+C in this window to stop the application.
echo.

start "" "http://127.0.0.1:8000"
python\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000

echo.
echo Application stopped.
pause
